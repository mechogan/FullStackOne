export function randomLog(quotes) {
  const index = Math.floor(Math.random() * quotes.length);
  console.log(quotes[index]);
}
