var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};

// ../../../../../Desktop/Demo/webview/icons.js
var init_icons = __esm({
  "../../../../../Desktop/Demo/webview/icons.js"() {
    document.querySelectorAll(".icon").forEach(async (icon) => {
      const iconName = Array.from(icon.classList.values()).filter((iconClass) => iconClass !== "icon").at(0);
      icon.innerHTML = await (await fetch(`assets/images/${iconName}.svg`)).text();
    });
  }
});

// ../../../../../Desktop/Demo/webview/theme.js
var themeSwitch, startDark;
var init_theme = __esm({
  async "../../../../../Desktop/Demo/webview/theme.js"() {
    themeSwitch = document.querySelector("#theme-switch input");
    startDark = !!parseInt(await rpc().theme.isDark());
    if (startDark) {
      document.documentElement.classList.add("dark");
      themeSwitch.checked = false;
    }
    themeSwitch.addEventListener("change", (e) => {
      const isDark = !e.currentTarget.checked;
      if (isDark) {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
      rpc().theme.saveDark(isDark ? "1" : "0");
    });
  }
});

// ../../../../../Desktop/Demo/utils/random.js
function randomElement(array) {
  const randomIndex = Math.floor(Math.random() * array.length);
  return array[randomIndex];
}
var init_random = __esm({
  "../../../../../Desktop/Demo/utils/random.js"() {
  }
});

// ../../../../../Desktop/Demo/webview/counter.js
var countView, sub, add, reset, count, updateCount, chatGPTQuotes;
var init_counter = __esm({
  async "../../../../../Desktop/Demo/webview/counter.js"() {
    init_random();
    countView = document.querySelector("#counter > div > div");
    [sub, add, reset] = document.querySelectorAll("#counter button");
    count = parseInt(await rpc().count.load());
    countView.innerText = count.toString();
    updateCount = () => {
      countView.innerText = count.toString();
      if (!count) {
        rpc().count.reset();
      } else {
        rpc().count.save(count.toString());
      }
      if (count % 3 === 1) {
        console.log(randomElement(chatGPTQuotes));
      }
    };
    sub.addEventListener("click", () => {
      count--;
      updateCount();
    });
    add.addEventListener("click", () => {
      count++;
      updateCount();
    });
    reset.addEventListener("click", () => {
      count = 0;
      updateCount();
    });
    chatGPTQuotes = [
      "Clicking that button like a boss \u2013 one press at a time!",
      "You're on fire! Keep clicking, and let the counting games begin.",
      "Clicking away like a champion. You're the true counter extraordinaire!",
      "Counting with precision \u2013 one click at a time. You've got this!",
      "Clicking faster than a caffeinated hummingbird. You're unstoppable!",
      "Clickity-click! You're the maestro of the counter symphony.",
      "Counting clicks like it's an Olympic sport. Gold medal vibes!",
      "Keep calm and click on. You're making history, one button at a time.",
      "Click, click, hooray! You're the click master, no doubt.",
      "You've got the Midas touch \u2013 but with a counter button. Click it all to gold!",
      "Clicking like it's going out of style. Spoiler: it's not!",
      "Counting clicks like a mathematician with a sense of humor. Go, you!",
      "Clicking with the precision of a ninja \u2013 silent but deadly accurate.",
      "Button-clicking virtuoso in action! Encore, encore!",
      "Clicking away, leaving a trail of smiles and counting triumphs.",
      "Clicking so fast, you might break the internet. Proceed with awesomeness!",
      "Counting clicks like a rockstar. Your fans are cheering!",
      "Clicking like there's no tomorrow. Spoiler alert: Tomorrow, you'll still be clicking!",
      "You're not just clicking; you're creating a masterpiece of counts!",
      "Clicking so smoothly, it's like butter \u2013 but without the mess.",
      "Clicking brilliance in progress! The world needs more counters like you.",
      "Counting clicks like a pro \u2013 because amateurs are for the faint-hearted.",
      "Clicking with finesse and style. You're the James Bond of counters!",
      "Click, click, hooray! The world is a better place with your counting skills.",
      "Clicking through life with flair and humor. Keep it up!",
      "Counting clicks like it's a dance. You've got the perfect moves!",
      "Click, click, hooray! The world is a better place with your counting skills.",
      "Counting clicks like a boss. Your finger must be in training!",
      "Clicking like it's the coolest thing you'll do today. Spoiler: it is!",
      "Click, laugh, repeat. Your clicking journey is pure joy!",
      "Counting clicks with the enthusiasm of a kid in a candy store. Keep that joy alive!",
      "Clicking like a pro \u2013 because amateurs are for beginners.",
      "Button clicking level: Expert. You're acing this game!",
      "Clicking away, making numbers look good. Keep up the fantastic work!",
      "Counting clicks like it's an art form. Picasso would be proud!",
      "Clicking with style, grace, and a touch of humor. That's how it's done!",
      "Clicking buttons with the precision of a surgeon. You're saving lives, one click at a time!"
    ];
  }
});

// ../../../../../Desktop/Demo/index.js
var Demo_exports = {};
var init_Demo = __esm({
  async "../../../../../Desktop/Demo/index.js"() {
    init_icons();
    await init_theme();
    await init_counter();
  }
});

// ../../../../../.cache/fullstacked/tmp-1708524313852.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames2 = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames2(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames2(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var require_base64 = __commonJS({
  "node_modules/source-map-js/lib/base64.js"(exports) {
    var intToCharMap = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("");
    exports.encode = function(number) {
      if (0 <= number && number < intToCharMap.length) {
        return intToCharMap[number];
      }
      throw new TypeError("Must be between 0 and 63: " + number);
    };
    exports.decode = function(charCode) {
      var bigA = 65;
      var bigZ = 90;
      var littleA = 97;
      var littleZ = 122;
      var zero = 48;
      var nine = 57;
      var plus = 43;
      var slash = 47;
      var littleOffset = 26;
      var numberOffset = 52;
      if (bigA <= charCode && charCode <= bigZ) {
        return charCode - bigA;
      }
      if (littleA <= charCode && charCode <= littleZ) {
        return charCode - littleA + littleOffset;
      }
      if (zero <= charCode && charCode <= nine) {
        return charCode - zero + numberOffset;
      }
      if (charCode == plus) {
        return 62;
      }
      if (charCode == slash) {
        return 63;
      }
      return -1;
    };
  }
});
var require_base64_vlq = __commonJS({
  "node_modules/source-map-js/lib/base64-vlq.js"(exports) {
    var base64 = require_base64();
    var VLQ_BASE_SHIFT = 5;
    var VLQ_BASE = 1 << VLQ_BASE_SHIFT;
    var VLQ_BASE_MASK = VLQ_BASE - 1;
    var VLQ_CONTINUATION_BIT = VLQ_BASE;
    function toVLQSigned(aValue) {
      return aValue < 0 ? (-aValue << 1) + 1 : (aValue << 1) + 0;
    }
    function fromVLQSigned(aValue) {
      var isNegative = (aValue & 1) === 1;
      var shifted = aValue >> 1;
      return isNegative ? -shifted : shifted;
    }
    exports.encode = function base64VLQ_encode(aValue) {
      var encoded = "";
      var digit;
      var vlq = toVLQSigned(aValue);
      do {
        digit = vlq & VLQ_BASE_MASK;
        vlq >>>= VLQ_BASE_SHIFT;
        if (vlq > 0) {
          digit |= VLQ_CONTINUATION_BIT;
        }
        encoded += base64.encode(digit);
      } while (vlq > 0);
      return encoded;
    };
    exports.decode = function base64VLQ_decode(aStr, aIndex, aOutParam) {
      var strLen = aStr.length;
      var result = 0;
      var shift = 0;
      var continuation, digit;
      do {
        if (aIndex >= strLen) {
          throw new Error("Expected more digits in base 64 VLQ value.");
        }
        digit = base64.decode(aStr.charCodeAt(aIndex++));
        if (digit === -1) {
          throw new Error("Invalid base64 digit: " + aStr.charAt(aIndex - 1));
        }
        continuation = !!(digit & VLQ_CONTINUATION_BIT);
        digit &= VLQ_BASE_MASK;
        result = result + (digit << shift);
        shift += VLQ_BASE_SHIFT;
      } while (continuation);
      aOutParam.value = fromVLQSigned(result);
      aOutParam.rest = aIndex;
    };
  }
});
var require_util = __commonJS({
  "node_modules/source-map-js/lib/util.js"(exports) {
    function getArg(aArgs, aName, aDefaultValue) {
      if (aName in aArgs) {
        return aArgs[aName];
      } else if (arguments.length === 3) {
        return aDefaultValue;
      } else {
        throw new Error('"' + aName + '" is a required argument.');
      }
    }
    exports.getArg = getArg;
    var urlRegexp = /^(?:([\w+\-.]+):)?\/\/(?:(\w+:\w+)@)?([\w.-]*)(?::(\d+))?(.*)$/;
    var dataUrlRegexp = /^data:.+\,.+$/;
    function urlParse(aUrl) {
      var match = aUrl.match(urlRegexp);
      if (!match) {
        return null;
      }
      return {
        scheme: match[1],
        auth: match[2],
        host: match[3],
        port: match[4],
        path: match[5]
      };
    }
    exports.urlParse = urlParse;
    function urlGenerate(aParsedUrl) {
      var url = "";
      if (aParsedUrl.scheme) {
        url += aParsedUrl.scheme + ":";
      }
      url += "//";
      if (aParsedUrl.auth) {
        url += aParsedUrl.auth + "@";
      }
      if (aParsedUrl.host) {
        url += aParsedUrl.host;
      }
      if (aParsedUrl.port) {
        url += ":" + aParsedUrl.port;
      }
      if (aParsedUrl.path) {
        url += aParsedUrl.path;
      }
      return url;
    }
    exports.urlGenerate = urlGenerate;
    var MAX_CACHED_INPUTS = 32;
    function lruMemoize(f) {
      var cache = [];
      return function(input) {
        for (var i = 0; i < cache.length; i++) {
          if (cache[i].input === input) {
            var temp = cache[0];
            cache[0] = cache[i];
            cache[i] = temp;
            return cache[0].result;
          }
        }
        var result = f(input);
        cache.unshift({
          input,
          result
        });
        if (cache.length > MAX_CACHED_INPUTS) {
          cache.pop();
        }
        return result;
      };
    }
    var normalize = lruMemoize(function normalize2(aPath) {
      var path = aPath;
      var url = urlParse(aPath);
      if (url) {
        if (!url.path) {
          return aPath;
        }
        path = url.path;
      }
      var isAbsolute = exports.isAbsolute(path);
      var parts = [];
      var start = 0;
      var i = 0;
      while (true) {
        start = i;
        i = path.indexOf("/", start);
        if (i === -1) {
          parts.push(path.slice(start));
          break;
        } else {
          parts.push(path.slice(start, i));
          while (i < path.length && path[i] === "/") {
            i++;
          }
        }
      }
      for (var part, up = 0, i = parts.length - 1; i >= 0; i--) {
        part = parts[i];
        if (part === ".") {
          parts.splice(i, 1);
        } else if (part === "..") {
          up++;
        } else if (up > 0) {
          if (part === "") {
            parts.splice(i + 1, up);
            up = 0;
          } else {
            parts.splice(i, 2);
            up--;
          }
        }
      }
      path = parts.join("/");
      if (path === "") {
        path = isAbsolute ? "/" : ".";
      }
      if (url) {
        url.path = path;
        return urlGenerate(url);
      }
      return path;
    });
    exports.normalize = normalize;
    function join(aRoot, aPath) {
      if (aRoot === "") {
        aRoot = ".";
      }
      if (aPath === "") {
        aPath = ".";
      }
      var aPathUrl = urlParse(aPath);
      var aRootUrl = urlParse(aRoot);
      if (aRootUrl) {
        aRoot = aRootUrl.path || "/";
      }
      if (aPathUrl && !aPathUrl.scheme) {
        if (aRootUrl) {
          aPathUrl.scheme = aRootUrl.scheme;
        }
        return urlGenerate(aPathUrl);
      }
      if (aPathUrl || aPath.match(dataUrlRegexp)) {
        return aPath;
      }
      if (aRootUrl && !aRootUrl.host && !aRootUrl.path) {
        aRootUrl.host = aPath;
        return urlGenerate(aRootUrl);
      }
      var joined = aPath.charAt(0) === "/" ? aPath : normalize(aRoot.replace(/\/+$/, "") + "/" + aPath);
      if (aRootUrl) {
        aRootUrl.path = joined;
        return urlGenerate(aRootUrl);
      }
      return joined;
    }
    exports.join = join;
    exports.isAbsolute = function(aPath) {
      return aPath.charAt(0) === "/" || urlRegexp.test(aPath);
    };
    function relative(aRoot, aPath) {
      if (aRoot === "") {
        aRoot = ".";
      }
      aRoot = aRoot.replace(/\/$/, "");
      var level = 0;
      while (aPath.indexOf(aRoot + "/") !== 0) {
        var index = aRoot.lastIndexOf("/");
        if (index < 0) {
          return aPath;
        }
        aRoot = aRoot.slice(0, index);
        if (aRoot.match(/^([^\/]+:\/)?\/*$/)) {
          return aPath;
        }
        ++level;
      }
      return Array(level + 1).join("../") + aPath.substr(aRoot.length + 1);
    }
    exports.relative = relative;
    var supportsNullProto = function() {
      var obj = /* @__PURE__ */ Object.create(null);
      return !("__proto__" in obj);
    }();
    function identity(s) {
      return s;
    }
    function toSetString(aStr) {
      if (isProtoString(aStr)) {
        return "$" + aStr;
      }
      return aStr;
    }
    exports.toSetString = supportsNullProto ? identity : toSetString;
    function fromSetString(aStr) {
      if (isProtoString(aStr)) {
        return aStr.slice(1);
      }
      return aStr;
    }
    exports.fromSetString = supportsNullProto ? identity : fromSetString;
    function isProtoString(s) {
      if (!s) {
        return false;
      }
      var length = s.length;
      if (length < 9) {
        return false;
      }
      if (s.charCodeAt(length - 1) !== 95 || s.charCodeAt(length - 2) !== 95 || s.charCodeAt(length - 3) !== 111 || s.charCodeAt(length - 4) !== 116 || s.charCodeAt(length - 5) !== 111 || s.charCodeAt(length - 6) !== 114 || s.charCodeAt(length - 7) !== 112 || s.charCodeAt(length - 8) !== 95 || s.charCodeAt(length - 9) !== 95) {
        return false;
      }
      for (var i = length - 10; i >= 0; i--) {
        if (s.charCodeAt(i) !== 36) {
          return false;
        }
      }
      return true;
    }
    function compareByOriginalPositions(mappingA, mappingB, onlyCompareOriginal) {
      var cmp = strcmp(mappingA.source, mappingB.source);
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalLine - mappingB.originalLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalColumn - mappingB.originalColumn;
      if (cmp !== 0 || onlyCompareOriginal) {
        return cmp;
      }
      cmp = mappingA.generatedColumn - mappingB.generatedColumn;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.generatedLine - mappingB.generatedLine;
      if (cmp !== 0) {
        return cmp;
      }
      return strcmp(mappingA.name, mappingB.name);
    }
    exports.compareByOriginalPositions = compareByOriginalPositions;
    function compareByOriginalPositionsNoSource(mappingA, mappingB, onlyCompareOriginal) {
      var cmp;
      cmp = mappingA.originalLine - mappingB.originalLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalColumn - mappingB.originalColumn;
      if (cmp !== 0 || onlyCompareOriginal) {
        return cmp;
      }
      cmp = mappingA.generatedColumn - mappingB.generatedColumn;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.generatedLine - mappingB.generatedLine;
      if (cmp !== 0) {
        return cmp;
      }
      return strcmp(mappingA.name, mappingB.name);
    }
    exports.compareByOriginalPositionsNoSource = compareByOriginalPositionsNoSource;
    function compareByGeneratedPositionsDeflated(mappingA, mappingB, onlyCompareGenerated) {
      var cmp = mappingA.generatedLine - mappingB.generatedLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.generatedColumn - mappingB.generatedColumn;
      if (cmp !== 0 || onlyCompareGenerated) {
        return cmp;
      }
      cmp = strcmp(mappingA.source, mappingB.source);
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalLine - mappingB.originalLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalColumn - mappingB.originalColumn;
      if (cmp !== 0) {
        return cmp;
      }
      return strcmp(mappingA.name, mappingB.name);
    }
    exports.compareByGeneratedPositionsDeflated = compareByGeneratedPositionsDeflated;
    function compareByGeneratedPositionsDeflatedNoLine(mappingA, mappingB, onlyCompareGenerated) {
      var cmp = mappingA.generatedColumn - mappingB.generatedColumn;
      if (cmp !== 0 || onlyCompareGenerated) {
        return cmp;
      }
      cmp = strcmp(mappingA.source, mappingB.source);
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalLine - mappingB.originalLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalColumn - mappingB.originalColumn;
      if (cmp !== 0) {
        return cmp;
      }
      return strcmp(mappingA.name, mappingB.name);
    }
    exports.compareByGeneratedPositionsDeflatedNoLine = compareByGeneratedPositionsDeflatedNoLine;
    function strcmp(aStr1, aStr2) {
      if (aStr1 === aStr2) {
        return 0;
      }
      if (aStr1 === null) {
        return 1;
      }
      if (aStr2 === null) {
        return -1;
      }
      if (aStr1 > aStr2) {
        return 1;
      }
      return -1;
    }
    function compareByGeneratedPositionsInflated(mappingA, mappingB) {
      var cmp = mappingA.generatedLine - mappingB.generatedLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.generatedColumn - mappingB.generatedColumn;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = strcmp(mappingA.source, mappingB.source);
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalLine - mappingB.originalLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalColumn - mappingB.originalColumn;
      if (cmp !== 0) {
        return cmp;
      }
      return strcmp(mappingA.name, mappingB.name);
    }
    exports.compareByGeneratedPositionsInflated = compareByGeneratedPositionsInflated;
    function parseSourceMapInput(str) {
      return JSON.parse(str.replace(/^\)]}'[^\n]*\n/, ""));
    }
    exports.parseSourceMapInput = parseSourceMapInput;
    function computeSourceURL(sourceRoot, sourceURL, sourceMapURL) {
      sourceURL = sourceURL || "";
      if (sourceRoot) {
        if (sourceRoot[sourceRoot.length - 1] !== "/" && sourceURL[0] !== "/") {
          sourceRoot += "/";
        }
        sourceURL = sourceRoot + sourceURL;
      }
      if (sourceMapURL) {
        var parsed = urlParse(sourceMapURL);
        if (!parsed) {
          throw new Error("sourceMapURL could not be parsed");
        }
        if (parsed.path) {
          var index = parsed.path.lastIndexOf("/");
          if (index >= 0) {
            parsed.path = parsed.path.substring(0, index + 1);
          }
        }
        sourceURL = join(urlGenerate(parsed), sourceURL);
      }
      return normalize(sourceURL);
    }
    exports.computeSourceURL = computeSourceURL;
  }
});
var require_array_set = __commonJS({
  "node_modules/source-map-js/lib/array-set.js"(exports) {
    var util = require_util();
    var has = Object.prototype.hasOwnProperty;
    var hasNativeMap = typeof Map !== "undefined";
    function ArraySet() {
      this._array = [];
      this._set = hasNativeMap ? /* @__PURE__ */ new Map() : /* @__PURE__ */ Object.create(null);
    }
    ArraySet.fromArray = function ArraySet_fromArray(aArray, aAllowDuplicates) {
      var set = new ArraySet();
      for (var i = 0, len = aArray.length; i < len; i++) {
        set.add(aArray[i], aAllowDuplicates);
      }
      return set;
    };
    ArraySet.prototype.size = function ArraySet_size() {
      return hasNativeMap ? this._set.size : Object.getOwnPropertyNames(this._set).length;
    };
    ArraySet.prototype.add = function ArraySet_add(aStr, aAllowDuplicates) {
      var sStr = hasNativeMap ? aStr : util.toSetString(aStr);
      var isDuplicate = hasNativeMap ? this.has(aStr) : has.call(this._set, sStr);
      var idx = this._array.length;
      if (!isDuplicate || aAllowDuplicates) {
        this._array.push(aStr);
      }
      if (!isDuplicate) {
        if (hasNativeMap) {
          this._set.set(aStr, idx);
        } else {
          this._set[sStr] = idx;
        }
      }
    };
    ArraySet.prototype.has = function ArraySet_has(aStr) {
      if (hasNativeMap) {
        return this._set.has(aStr);
      } else {
        var sStr = util.toSetString(aStr);
        return has.call(this._set, sStr);
      }
    };
    ArraySet.prototype.indexOf = function ArraySet_indexOf(aStr) {
      if (hasNativeMap) {
        var idx = this._set.get(aStr);
        if (idx >= 0) {
          return idx;
        }
      } else {
        var sStr = util.toSetString(aStr);
        if (has.call(this._set, sStr)) {
          return this._set[sStr];
        }
      }
      throw new Error('"' + aStr + '" is not in the set.');
    };
    ArraySet.prototype.at = function ArraySet_at(aIdx) {
      if (aIdx >= 0 && aIdx < this._array.length) {
        return this._array[aIdx];
      }
      throw new Error("No element indexed by " + aIdx);
    };
    ArraySet.prototype.toArray = function ArraySet_toArray() {
      return this._array.slice();
    };
    exports.ArraySet = ArraySet;
  }
});
var require_mapping_list = __commonJS({
  "node_modules/source-map-js/lib/mapping-list.js"(exports) {
    var util = require_util();
    function generatedPositionAfter(mappingA, mappingB) {
      var lineA = mappingA.generatedLine;
      var lineB = mappingB.generatedLine;
      var columnA = mappingA.generatedColumn;
      var columnB = mappingB.generatedColumn;
      return lineB > lineA || lineB == lineA && columnB >= columnA || util.compareByGeneratedPositionsInflated(mappingA, mappingB) <= 0;
    }
    function MappingList() {
      this._array = [];
      this._sorted = true;
      this._last = { generatedLine: -1, generatedColumn: 0 };
    }
    MappingList.prototype.unsortedForEach = function MappingList_forEach(aCallback, aThisArg) {
      this._array.forEach(aCallback, aThisArg);
    };
    MappingList.prototype.add = function MappingList_add(aMapping) {
      if (generatedPositionAfter(this._last, aMapping)) {
        this._last = aMapping;
        this._array.push(aMapping);
      } else {
        this._sorted = false;
        this._array.push(aMapping);
      }
    };
    MappingList.prototype.toArray = function MappingList_toArray() {
      if (!this._sorted) {
        this._array.sort(util.compareByGeneratedPositionsInflated);
        this._sorted = true;
      }
      return this._array;
    };
    exports.MappingList = MappingList;
  }
});
var require_source_map_generator = __commonJS({
  "node_modules/source-map-js/lib/source-map-generator.js"(exports) {
    var base64VLQ = require_base64_vlq();
    var util = require_util();
    var ArraySet = require_array_set().ArraySet;
    var MappingList = require_mapping_list().MappingList;
    function SourceMapGenerator(aArgs) {
      if (!aArgs) {
        aArgs = {};
      }
      this._file = util.getArg(aArgs, "file", null);
      this._sourceRoot = util.getArg(aArgs, "sourceRoot", null);
      this._skipValidation = util.getArg(aArgs, "skipValidation", false);
      this._sources = new ArraySet();
      this._names = new ArraySet();
      this._mappings = new MappingList();
      this._sourcesContents = null;
    }
    SourceMapGenerator.prototype._version = 3;
    SourceMapGenerator.fromSourceMap = function SourceMapGenerator_fromSourceMap(aSourceMapConsumer) {
      var sourceRoot = aSourceMapConsumer.sourceRoot;
      var generator = new SourceMapGenerator({
        file: aSourceMapConsumer.file,
        sourceRoot
      });
      aSourceMapConsumer.eachMapping(function(mapping) {
        var newMapping = {
          generated: {
            line: mapping.generatedLine,
            column: mapping.generatedColumn
          }
        };
        if (mapping.source != null) {
          newMapping.source = mapping.source;
          if (sourceRoot != null) {
            newMapping.source = util.relative(sourceRoot, newMapping.source);
          }
          newMapping.original = {
            line: mapping.originalLine,
            column: mapping.originalColumn
          };
          if (mapping.name != null) {
            newMapping.name = mapping.name;
          }
        }
        generator.addMapping(newMapping);
      });
      aSourceMapConsumer.sources.forEach(function(sourceFile) {
        var sourceRelative = sourceFile;
        if (sourceRoot !== null) {
          sourceRelative = util.relative(sourceRoot, sourceFile);
        }
        if (!generator._sources.has(sourceRelative)) {
          generator._sources.add(sourceRelative);
        }
        var content = aSourceMapConsumer.sourceContentFor(sourceFile);
        if (content != null) {
          generator.setSourceContent(sourceFile, content);
        }
      });
      return generator;
    };
    SourceMapGenerator.prototype.addMapping = function SourceMapGenerator_addMapping(aArgs) {
      var generated = util.getArg(aArgs, "generated");
      var original = util.getArg(aArgs, "original", null);
      var source = util.getArg(aArgs, "source", null);
      var name = util.getArg(aArgs, "name", null);
      if (!this._skipValidation) {
        this._validateMapping(generated, original, source, name);
      }
      if (source != null) {
        source = String(source);
        if (!this._sources.has(source)) {
          this._sources.add(source);
        }
      }
      if (name != null) {
        name = String(name);
        if (!this._names.has(name)) {
          this._names.add(name);
        }
      }
      this._mappings.add({
        generatedLine: generated.line,
        generatedColumn: generated.column,
        originalLine: original != null && original.line,
        originalColumn: original != null && original.column,
        source,
        name
      });
    };
    SourceMapGenerator.prototype.setSourceContent = function SourceMapGenerator_setSourceContent(aSourceFile, aSourceContent) {
      var source = aSourceFile;
      if (this._sourceRoot != null) {
        source = util.relative(this._sourceRoot, source);
      }
      if (aSourceContent != null) {
        if (!this._sourcesContents) {
          this._sourcesContents = /* @__PURE__ */ Object.create(null);
        }
        this._sourcesContents[util.toSetString(source)] = aSourceContent;
      } else if (this._sourcesContents) {
        delete this._sourcesContents[util.toSetString(source)];
        if (Object.keys(this._sourcesContents).length === 0) {
          this._sourcesContents = null;
        }
      }
    };
    SourceMapGenerator.prototype.applySourceMap = function SourceMapGenerator_applySourceMap(aSourceMapConsumer, aSourceFile, aSourceMapPath) {
      var sourceFile = aSourceFile;
      if (aSourceFile == null) {
        if (aSourceMapConsumer.file == null) {
          throw new Error(
            `SourceMapGenerator.prototype.applySourceMap requires either an explicit source file, or the source map's "file" property. Both were omitted.`
          );
        }
        sourceFile = aSourceMapConsumer.file;
      }
      var sourceRoot = this._sourceRoot;
      if (sourceRoot != null) {
        sourceFile = util.relative(sourceRoot, sourceFile);
      }
      var newSources = new ArraySet();
      var newNames = new ArraySet();
      this._mappings.unsortedForEach(function(mapping) {
        if (mapping.source === sourceFile && mapping.originalLine != null) {
          var original = aSourceMapConsumer.originalPositionFor({
            line: mapping.originalLine,
            column: mapping.originalColumn
          });
          if (original.source != null) {
            mapping.source = original.source;
            if (aSourceMapPath != null) {
              mapping.source = util.join(aSourceMapPath, mapping.source);
            }
            if (sourceRoot != null) {
              mapping.source = util.relative(sourceRoot, mapping.source);
            }
            mapping.originalLine = original.line;
            mapping.originalColumn = original.column;
            if (original.name != null) {
              mapping.name = original.name;
            }
          }
        }
        var source = mapping.source;
        if (source != null && !newSources.has(source)) {
          newSources.add(source);
        }
        var name = mapping.name;
        if (name != null && !newNames.has(name)) {
          newNames.add(name);
        }
      }, this);
      this._sources = newSources;
      this._names = newNames;
      aSourceMapConsumer.sources.forEach(function(sourceFile2) {
        var content = aSourceMapConsumer.sourceContentFor(sourceFile2);
        if (content != null) {
          if (aSourceMapPath != null) {
            sourceFile2 = util.join(aSourceMapPath, sourceFile2);
          }
          if (sourceRoot != null) {
            sourceFile2 = util.relative(sourceRoot, sourceFile2);
          }
          this.setSourceContent(sourceFile2, content);
        }
      }, this);
    };
    SourceMapGenerator.prototype._validateMapping = function SourceMapGenerator_validateMapping(aGenerated, aOriginal, aSource, aName) {
      if (aOriginal && typeof aOriginal.line !== "number" && typeof aOriginal.column !== "number") {
        throw new Error(
          "original.line and original.column are not numbers -- you probably meant to omit the original mapping entirely and only map the generated position. If so, pass null for the original mapping instead of an object with empty or null values."
        );
      }
      if (aGenerated && "line" in aGenerated && "column" in aGenerated && aGenerated.line > 0 && aGenerated.column >= 0 && !aOriginal && !aSource && !aName) {
        return;
      } else if (aGenerated && "line" in aGenerated && "column" in aGenerated && aOriginal && "line" in aOriginal && "column" in aOriginal && aGenerated.line > 0 && aGenerated.column >= 0 && aOriginal.line > 0 && aOriginal.column >= 0 && aSource) {
        return;
      } else {
        throw new Error("Invalid mapping: " + JSON.stringify({
          generated: aGenerated,
          source: aSource,
          original: aOriginal,
          name: aName
        }));
      }
    };
    SourceMapGenerator.prototype._serializeMappings = function SourceMapGenerator_serializeMappings() {
      var previousGeneratedColumn = 0;
      var previousGeneratedLine = 1;
      var previousOriginalColumn = 0;
      var previousOriginalLine = 0;
      var previousName = 0;
      var previousSource = 0;
      var result = "";
      var next;
      var mapping;
      var nameIdx;
      var sourceIdx;
      var mappings = this._mappings.toArray();
      for (var i = 0, len = mappings.length; i < len; i++) {
        mapping = mappings[i];
        next = "";
        if (mapping.generatedLine !== previousGeneratedLine) {
          previousGeneratedColumn = 0;
          while (mapping.generatedLine !== previousGeneratedLine) {
            next += ";";
            previousGeneratedLine++;
          }
        } else {
          if (i > 0) {
            if (!util.compareByGeneratedPositionsInflated(mapping, mappings[i - 1])) {
              continue;
            }
            next += ",";
          }
        }
        next += base64VLQ.encode(mapping.generatedColumn - previousGeneratedColumn);
        previousGeneratedColumn = mapping.generatedColumn;
        if (mapping.source != null) {
          sourceIdx = this._sources.indexOf(mapping.source);
          next += base64VLQ.encode(sourceIdx - previousSource);
          previousSource = sourceIdx;
          next += base64VLQ.encode(mapping.originalLine - 1 - previousOriginalLine);
          previousOriginalLine = mapping.originalLine - 1;
          next += base64VLQ.encode(mapping.originalColumn - previousOriginalColumn);
          previousOriginalColumn = mapping.originalColumn;
          if (mapping.name != null) {
            nameIdx = this._names.indexOf(mapping.name);
            next += base64VLQ.encode(nameIdx - previousName);
            previousName = nameIdx;
          }
        }
        result += next;
      }
      return result;
    };
    SourceMapGenerator.prototype._generateSourcesContent = function SourceMapGenerator_generateSourcesContent(aSources, aSourceRoot) {
      return aSources.map(function(source) {
        if (!this._sourcesContents) {
          return null;
        }
        if (aSourceRoot != null) {
          source = util.relative(aSourceRoot, source);
        }
        var key = util.toSetString(source);
        return Object.prototype.hasOwnProperty.call(this._sourcesContents, key) ? this._sourcesContents[key] : null;
      }, this);
    };
    SourceMapGenerator.prototype.toJSON = function SourceMapGenerator_toJSON() {
      var map = {
        version: this._version,
        sources: this._sources.toArray(),
        names: this._names.toArray(),
        mappings: this._serializeMappings()
      };
      if (this._file != null) {
        map.file = this._file;
      }
      if (this._sourceRoot != null) {
        map.sourceRoot = this._sourceRoot;
      }
      if (this._sourcesContents) {
        map.sourcesContent = this._generateSourcesContent(map.sources, map.sourceRoot);
      }
      return map;
    };
    SourceMapGenerator.prototype.toString = function SourceMapGenerator_toString() {
      return JSON.stringify(this.toJSON());
    };
    exports.SourceMapGenerator = SourceMapGenerator;
  }
});
var require_binary_search = __commonJS({
  "node_modules/source-map-js/lib/binary-search.js"(exports) {
    exports.GREATEST_LOWER_BOUND = 1;
    exports.LEAST_UPPER_BOUND = 2;
    function recursiveSearch(aLow, aHigh, aNeedle, aHaystack, aCompare, aBias) {
      var mid = Math.floor((aHigh - aLow) / 2) + aLow;
      var cmp = aCompare(aNeedle, aHaystack[mid], true);
      if (cmp === 0) {
        return mid;
      } else if (cmp > 0) {
        if (aHigh - mid > 1) {
          return recursiveSearch(mid, aHigh, aNeedle, aHaystack, aCompare, aBias);
        }
        if (aBias == exports.LEAST_UPPER_BOUND) {
          return aHigh < aHaystack.length ? aHigh : -1;
        } else {
          return mid;
        }
      } else {
        if (mid - aLow > 1) {
          return recursiveSearch(aLow, mid, aNeedle, aHaystack, aCompare, aBias);
        }
        if (aBias == exports.LEAST_UPPER_BOUND) {
          return mid;
        } else {
          return aLow < 0 ? -1 : aLow;
        }
      }
    }
    exports.search = function search(aNeedle, aHaystack, aCompare, aBias) {
      if (aHaystack.length === 0) {
        return -1;
      }
      var index = recursiveSearch(
        -1,
        aHaystack.length,
        aNeedle,
        aHaystack,
        aCompare,
        aBias || exports.GREATEST_LOWER_BOUND
      );
      if (index < 0) {
        return -1;
      }
      while (index - 1 >= 0) {
        if (aCompare(aHaystack[index], aHaystack[index - 1], true) !== 0) {
          break;
        }
        --index;
      }
      return index;
    };
  }
});
var require_quick_sort = __commonJS({
  "node_modules/source-map-js/lib/quick-sort.js"(exports) {
    function SortTemplate(comparator) {
      function swap(ary, x, y) {
        var temp = ary[x];
        ary[x] = ary[y];
        ary[y] = temp;
      }
      function randomIntInRange(low, high) {
        return Math.round(low + Math.random() * (high - low));
      }
      function doQuickSort(ary, comparator2, p, r) {
        if (p < r) {
          var pivotIndex = randomIntInRange(p, r);
          var i = p - 1;
          swap(ary, pivotIndex, r);
          var pivot = ary[r];
          for (var j = p; j < r; j++) {
            if (comparator2(ary[j], pivot, false) <= 0) {
              i += 1;
              swap(ary, i, j);
            }
          }
          swap(ary, i + 1, j);
          var q = i + 1;
          doQuickSort(ary, comparator2, p, q - 1);
          doQuickSort(ary, comparator2, q + 1, r);
        }
      }
      return doQuickSort;
    }
    function cloneSort(comparator) {
      let template = SortTemplate.toString();
      let templateFn = new Function(`return ${template}`)();
      return templateFn(comparator);
    }
    var sortCache = /* @__PURE__ */ new WeakMap();
    exports.quickSort = function(ary, comparator, start = 0) {
      let doQuickSort = sortCache.get(comparator);
      if (doQuickSort === void 0) {
        doQuickSort = cloneSort(comparator);
        sortCache.set(comparator, doQuickSort);
      }
      doQuickSort(ary, comparator, start, ary.length - 1);
    };
  }
});
var require_source_map_consumer = __commonJS({
  "node_modules/source-map-js/lib/source-map-consumer.js"(exports) {
    var util = require_util();
    var binarySearch = require_binary_search();
    var ArraySet = require_array_set().ArraySet;
    var base64VLQ = require_base64_vlq();
    var quickSort = require_quick_sort().quickSort;
    function SourceMapConsumer2(aSourceMap, aSourceMapURL) {
      var sourceMap = aSourceMap;
      if (typeof aSourceMap === "string") {
        sourceMap = util.parseSourceMapInput(aSourceMap);
      }
      return sourceMap.sections != null ? new IndexedSourceMapConsumer(sourceMap, aSourceMapURL) : new BasicSourceMapConsumer(sourceMap, aSourceMapURL);
    }
    SourceMapConsumer2.fromSourceMap = function(aSourceMap, aSourceMapURL) {
      return BasicSourceMapConsumer.fromSourceMap(aSourceMap, aSourceMapURL);
    };
    SourceMapConsumer2.prototype._version = 3;
    SourceMapConsumer2.prototype.__generatedMappings = null;
    Object.defineProperty(SourceMapConsumer2.prototype, "_generatedMappings", {
      configurable: true,
      enumerable: true,
      get: function() {
        if (!this.__generatedMappings) {
          this._parseMappings(this._mappings, this.sourceRoot);
        }
        return this.__generatedMappings;
      }
    });
    SourceMapConsumer2.prototype.__originalMappings = null;
    Object.defineProperty(SourceMapConsumer2.prototype, "_originalMappings", {
      configurable: true,
      enumerable: true,
      get: function() {
        if (!this.__originalMappings) {
          this._parseMappings(this._mappings, this.sourceRoot);
        }
        return this.__originalMappings;
      }
    });
    SourceMapConsumer2.prototype._charIsMappingSeparator = function SourceMapConsumer_charIsMappingSeparator(aStr, index) {
      var c = aStr.charAt(index);
      return c === ";" || c === ",";
    };
    SourceMapConsumer2.prototype._parseMappings = function SourceMapConsumer_parseMappings(aStr, aSourceRoot) {
      throw new Error("Subclasses must implement _parseMappings");
    };
    SourceMapConsumer2.GENERATED_ORDER = 1;
    SourceMapConsumer2.ORIGINAL_ORDER = 2;
    SourceMapConsumer2.GREATEST_LOWER_BOUND = 1;
    SourceMapConsumer2.LEAST_UPPER_BOUND = 2;
    SourceMapConsumer2.prototype.eachMapping = function SourceMapConsumer_eachMapping(aCallback, aContext, aOrder) {
      var context = aContext || null;
      var order = aOrder || SourceMapConsumer2.GENERATED_ORDER;
      var mappings;
      switch (order) {
        case SourceMapConsumer2.GENERATED_ORDER:
          mappings = this._generatedMappings;
          break;
        case SourceMapConsumer2.ORIGINAL_ORDER:
          mappings = this._originalMappings;
          break;
        default:
          throw new Error("Unknown order of iteration.");
      }
      var sourceRoot = this.sourceRoot;
      var boundCallback = aCallback.bind(context);
      var names = this._names;
      var sources = this._sources;
      var sourceMapURL = this._sourceMapURL;
      for (var i = 0, n = mappings.length; i < n; i++) {
        var mapping = mappings[i];
        var source = mapping.source === null ? null : sources.at(mapping.source);
        source = util.computeSourceURL(sourceRoot, source, sourceMapURL);
        boundCallback({
          source,
          generatedLine: mapping.generatedLine,
          generatedColumn: mapping.generatedColumn,
          originalLine: mapping.originalLine,
          originalColumn: mapping.originalColumn,
          name: mapping.name === null ? null : names.at(mapping.name)
        });
      }
    };
    SourceMapConsumer2.prototype.allGeneratedPositionsFor = function SourceMapConsumer_allGeneratedPositionsFor(aArgs) {
      var line = util.getArg(aArgs, "line");
      var needle = {
        source: util.getArg(aArgs, "source"),
        originalLine: line,
        originalColumn: util.getArg(aArgs, "column", 0)
      };
      needle.source = this._findSourceIndex(needle.source);
      if (needle.source < 0) {
        return [];
      }
      var mappings = [];
      var index = this._findMapping(
        needle,
        this._originalMappings,
        "originalLine",
        "originalColumn",
        util.compareByOriginalPositions,
        binarySearch.LEAST_UPPER_BOUND
      );
      if (index >= 0) {
        var mapping = this._originalMappings[index];
        if (aArgs.column === void 0) {
          var originalLine = mapping.originalLine;
          while (mapping && mapping.originalLine === originalLine) {
            mappings.push({
              line: util.getArg(mapping, "generatedLine", null),
              column: util.getArg(mapping, "generatedColumn", null),
              lastColumn: util.getArg(mapping, "lastGeneratedColumn", null)
            });
            mapping = this._originalMappings[++index];
          }
        } else {
          var originalColumn = mapping.originalColumn;
          while (mapping && mapping.originalLine === line && mapping.originalColumn == originalColumn) {
            mappings.push({
              line: util.getArg(mapping, "generatedLine", null),
              column: util.getArg(mapping, "generatedColumn", null),
              lastColumn: util.getArg(mapping, "lastGeneratedColumn", null)
            });
            mapping = this._originalMappings[++index];
          }
        }
      }
      return mappings;
    };
    exports.SourceMapConsumer = SourceMapConsumer2;
    function BasicSourceMapConsumer(aSourceMap, aSourceMapURL) {
      var sourceMap = aSourceMap;
      if (typeof aSourceMap === "string") {
        sourceMap = util.parseSourceMapInput(aSourceMap);
      }
      var version = util.getArg(sourceMap, "version");
      var sources = util.getArg(sourceMap, "sources");
      var names = util.getArg(sourceMap, "names", []);
      var sourceRoot = util.getArg(sourceMap, "sourceRoot", null);
      var sourcesContent = util.getArg(sourceMap, "sourcesContent", null);
      var mappings = util.getArg(sourceMap, "mappings");
      var file = util.getArg(sourceMap, "file", null);
      if (version != this._version) {
        throw new Error("Unsupported version: " + version);
      }
      if (sourceRoot) {
        sourceRoot = util.normalize(sourceRoot);
      }
      sources = sources.map(String).map(util.normalize).map(function(source) {
        return sourceRoot && util.isAbsolute(sourceRoot) && util.isAbsolute(source) ? util.relative(sourceRoot, source) : source;
      });
      this._names = ArraySet.fromArray(names.map(String), true);
      this._sources = ArraySet.fromArray(sources, true);
      this._absoluteSources = this._sources.toArray().map(function(s) {
        return util.computeSourceURL(sourceRoot, s, aSourceMapURL);
      });
      this.sourceRoot = sourceRoot;
      this.sourcesContent = sourcesContent;
      this._mappings = mappings;
      this._sourceMapURL = aSourceMapURL;
      this.file = file;
    }
    BasicSourceMapConsumer.prototype = Object.create(SourceMapConsumer2.prototype);
    BasicSourceMapConsumer.prototype.consumer = SourceMapConsumer2;
    BasicSourceMapConsumer.prototype._findSourceIndex = function(aSource) {
      var relativeSource = aSource;
      if (this.sourceRoot != null) {
        relativeSource = util.relative(this.sourceRoot, relativeSource);
      }
      if (this._sources.has(relativeSource)) {
        return this._sources.indexOf(relativeSource);
      }
      var i;
      for (i = 0; i < this._absoluteSources.length; ++i) {
        if (this._absoluteSources[i] == aSource) {
          return i;
        }
      }
      return -1;
    };
    BasicSourceMapConsumer.fromSourceMap = function SourceMapConsumer_fromSourceMap(aSourceMap, aSourceMapURL) {
      var smc = Object.create(BasicSourceMapConsumer.prototype);
      var names = smc._names = ArraySet.fromArray(aSourceMap._names.toArray(), true);
      var sources = smc._sources = ArraySet.fromArray(aSourceMap._sources.toArray(), true);
      smc.sourceRoot = aSourceMap._sourceRoot;
      smc.sourcesContent = aSourceMap._generateSourcesContent(
        smc._sources.toArray(),
        smc.sourceRoot
      );
      smc.file = aSourceMap._file;
      smc._sourceMapURL = aSourceMapURL;
      smc._absoluteSources = smc._sources.toArray().map(function(s) {
        return util.computeSourceURL(smc.sourceRoot, s, aSourceMapURL);
      });
      var generatedMappings = aSourceMap._mappings.toArray().slice();
      var destGeneratedMappings = smc.__generatedMappings = [];
      var destOriginalMappings = smc.__originalMappings = [];
      for (var i = 0, length = generatedMappings.length; i < length; i++) {
        var srcMapping = generatedMappings[i];
        var destMapping = new Mapping();
        destMapping.generatedLine = srcMapping.generatedLine;
        destMapping.generatedColumn = srcMapping.generatedColumn;
        if (srcMapping.source) {
          destMapping.source = sources.indexOf(srcMapping.source);
          destMapping.originalLine = srcMapping.originalLine;
          destMapping.originalColumn = srcMapping.originalColumn;
          if (srcMapping.name) {
            destMapping.name = names.indexOf(srcMapping.name);
          }
          destOriginalMappings.push(destMapping);
        }
        destGeneratedMappings.push(destMapping);
      }
      quickSort(smc.__originalMappings, util.compareByOriginalPositions);
      return smc;
    };
    BasicSourceMapConsumer.prototype._version = 3;
    Object.defineProperty(BasicSourceMapConsumer.prototype, "sources", {
      get: function() {
        return this._absoluteSources.slice();
      }
    });
    function Mapping() {
      this.generatedLine = 0;
      this.generatedColumn = 0;
      this.source = null;
      this.originalLine = null;
      this.originalColumn = null;
      this.name = null;
    }
    var compareGenerated = util.compareByGeneratedPositionsDeflatedNoLine;
    function sortGenerated(array, start) {
      let l = array.length;
      let n = array.length - start;
      if (n <= 1) {
        return;
      } else if (n == 2) {
        let a = array[start];
        let b = array[start + 1];
        if (compareGenerated(a, b) > 0) {
          array[start] = b;
          array[start + 1] = a;
        }
      } else if (n < 20) {
        for (let i = start; i < l; i++) {
          for (let j = i; j > start; j--) {
            let a = array[j - 1];
            let b = array[j];
            if (compareGenerated(a, b) <= 0) {
              break;
            }
            array[j - 1] = b;
            array[j] = a;
          }
        }
      } else {
        quickSort(array, compareGenerated, start);
      }
    }
    BasicSourceMapConsumer.prototype._parseMappings = function SourceMapConsumer_parseMappings(aStr, aSourceRoot) {
      var generatedLine = 1;
      var previousGeneratedColumn = 0;
      var previousOriginalLine = 0;
      var previousOriginalColumn = 0;
      var previousSource = 0;
      var previousName = 0;
      var length = aStr.length;
      var index = 0;
      var cachedSegments = {};
      var temp = {};
      var originalMappings = [];
      var generatedMappings = [];
      var mapping, str, segment, end, value;
      let subarrayStart = 0;
      while (index < length) {
        if (aStr.charAt(index) === ";") {
          generatedLine++;
          index++;
          previousGeneratedColumn = 0;
          sortGenerated(generatedMappings, subarrayStart);
          subarrayStart = generatedMappings.length;
        } else if (aStr.charAt(index) === ",") {
          index++;
        } else {
          mapping = new Mapping();
          mapping.generatedLine = generatedLine;
          for (end = index; end < length; end++) {
            if (this._charIsMappingSeparator(aStr, end)) {
              break;
            }
          }
          str = aStr.slice(index, end);
          segment = [];
          while (index < end) {
            base64VLQ.decode(aStr, index, temp);
            value = temp.value;
            index = temp.rest;
            segment.push(value);
          }
          if (segment.length === 2) {
            throw new Error("Found a source, but no line and column");
          }
          if (segment.length === 3) {
            throw new Error("Found a source and line, but no column");
          }
          mapping.generatedColumn = previousGeneratedColumn + segment[0];
          previousGeneratedColumn = mapping.generatedColumn;
          if (segment.length > 1) {
            mapping.source = previousSource + segment[1];
            previousSource += segment[1];
            mapping.originalLine = previousOriginalLine + segment[2];
            previousOriginalLine = mapping.originalLine;
            mapping.originalLine += 1;
            mapping.originalColumn = previousOriginalColumn + segment[3];
            previousOriginalColumn = mapping.originalColumn;
            if (segment.length > 4) {
              mapping.name = previousName + segment[4];
              previousName += segment[4];
            }
          }
          generatedMappings.push(mapping);
          if (typeof mapping.originalLine === "number") {
            let currentSource = mapping.source;
            while (originalMappings.length <= currentSource) {
              originalMappings.push(null);
            }
            if (originalMappings[currentSource] === null) {
              originalMappings[currentSource] = [];
            }
            originalMappings[currentSource].push(mapping);
          }
        }
      }
      sortGenerated(generatedMappings, subarrayStart);
      this.__generatedMappings = generatedMappings;
      for (var i = 0; i < originalMappings.length; i++) {
        if (originalMappings[i] != null) {
          quickSort(originalMappings[i], util.compareByOriginalPositionsNoSource);
        }
      }
      this.__originalMappings = [].concat(...originalMappings);
    };
    BasicSourceMapConsumer.prototype._findMapping = function SourceMapConsumer_findMapping(aNeedle, aMappings, aLineName, aColumnName, aComparator, aBias) {
      if (aNeedle[aLineName] <= 0) {
        throw new TypeError("Line must be greater than or equal to 1, got " + aNeedle[aLineName]);
      }
      if (aNeedle[aColumnName] < 0) {
        throw new TypeError("Column must be greater than or equal to 0, got " + aNeedle[aColumnName]);
      }
      return binarySearch.search(aNeedle, aMappings, aComparator, aBias);
    };
    BasicSourceMapConsumer.prototype.computeColumnSpans = function SourceMapConsumer_computeColumnSpans() {
      for (var index = 0; index < this._generatedMappings.length; ++index) {
        var mapping = this._generatedMappings[index];
        if (index + 1 < this._generatedMappings.length) {
          var nextMapping = this._generatedMappings[index + 1];
          if (mapping.generatedLine === nextMapping.generatedLine) {
            mapping.lastGeneratedColumn = nextMapping.generatedColumn - 1;
            continue;
          }
        }
        mapping.lastGeneratedColumn = Infinity;
      }
    };
    BasicSourceMapConsumer.prototype.originalPositionFor = function SourceMapConsumer_originalPositionFor(aArgs) {
      var needle = {
        generatedLine: util.getArg(aArgs, "line"),
        generatedColumn: util.getArg(aArgs, "column")
      };
      var index = this._findMapping(
        needle,
        this._generatedMappings,
        "generatedLine",
        "generatedColumn",
        util.compareByGeneratedPositionsDeflated,
        util.getArg(aArgs, "bias", SourceMapConsumer2.GREATEST_LOWER_BOUND)
      );
      if (index >= 0) {
        var mapping = this._generatedMappings[index];
        if (mapping.generatedLine === needle.generatedLine) {
          var source = util.getArg(mapping, "source", null);
          if (source !== null) {
            source = this._sources.at(source);
            source = util.computeSourceURL(this.sourceRoot, source, this._sourceMapURL);
          }
          var name = util.getArg(mapping, "name", null);
          if (name !== null) {
            name = this._names.at(name);
          }
          return {
            source,
            line: util.getArg(mapping, "originalLine", null),
            column: util.getArg(mapping, "originalColumn", null),
            name
          };
        }
      }
      return {
        source: null,
        line: null,
        column: null,
        name: null
      };
    };
    BasicSourceMapConsumer.prototype.hasContentsOfAllSources = function BasicSourceMapConsumer_hasContentsOfAllSources() {
      if (!this.sourcesContent) {
        return false;
      }
      return this.sourcesContent.length >= this._sources.size() && !this.sourcesContent.some(function(sc) {
        return sc == null;
      });
    };
    BasicSourceMapConsumer.prototype.sourceContentFor = function SourceMapConsumer_sourceContentFor(aSource, nullOnMissing) {
      if (!this.sourcesContent) {
        return null;
      }
      var index = this._findSourceIndex(aSource);
      if (index >= 0) {
        return this.sourcesContent[index];
      }
      var relativeSource = aSource;
      if (this.sourceRoot != null) {
        relativeSource = util.relative(this.sourceRoot, relativeSource);
      }
      var url;
      if (this.sourceRoot != null && (url = util.urlParse(this.sourceRoot))) {
        var fileUriAbsPath = relativeSource.replace(/^file:\/\//, "");
        if (url.scheme == "file" && this._sources.has(fileUriAbsPath)) {
          return this.sourcesContent[this._sources.indexOf(fileUriAbsPath)];
        }
        if ((!url.path || url.path == "/") && this._sources.has("/" + relativeSource)) {
          return this.sourcesContent[this._sources.indexOf("/" + relativeSource)];
        }
      }
      if (nullOnMissing) {
        return null;
      } else {
        throw new Error('"' + relativeSource + '" is not in the SourceMap.');
      }
    };
    BasicSourceMapConsumer.prototype.generatedPositionFor = function SourceMapConsumer_generatedPositionFor(aArgs) {
      var source = util.getArg(aArgs, "source");
      source = this._findSourceIndex(source);
      if (source < 0) {
        return {
          line: null,
          column: null,
          lastColumn: null
        };
      }
      var needle = {
        source,
        originalLine: util.getArg(aArgs, "line"),
        originalColumn: util.getArg(aArgs, "column")
      };
      var index = this._findMapping(
        needle,
        this._originalMappings,
        "originalLine",
        "originalColumn",
        util.compareByOriginalPositions,
        util.getArg(aArgs, "bias", SourceMapConsumer2.GREATEST_LOWER_BOUND)
      );
      if (index >= 0) {
        var mapping = this._originalMappings[index];
        if (mapping.source === needle.source) {
          return {
            line: util.getArg(mapping, "generatedLine", null),
            column: util.getArg(mapping, "generatedColumn", null),
            lastColumn: util.getArg(mapping, "lastGeneratedColumn", null)
          };
        }
      }
      return {
        line: null,
        column: null,
        lastColumn: null
      };
    };
    exports.BasicSourceMapConsumer = BasicSourceMapConsumer;
    function IndexedSourceMapConsumer(aSourceMap, aSourceMapURL) {
      var sourceMap = aSourceMap;
      if (typeof aSourceMap === "string") {
        sourceMap = util.parseSourceMapInput(aSourceMap);
      }
      var version = util.getArg(sourceMap, "version");
      var sections = util.getArg(sourceMap, "sections");
      if (version != this._version) {
        throw new Error("Unsupported version: " + version);
      }
      this._sources = new ArraySet();
      this._names = new ArraySet();
      var lastOffset = {
        line: -1,
        column: 0
      };
      this._sections = sections.map(function(s) {
        if (s.url) {
          throw new Error("Support for url field in sections not implemented.");
        }
        var offset = util.getArg(s, "offset");
        var offsetLine = util.getArg(offset, "line");
        var offsetColumn = util.getArg(offset, "column");
        if (offsetLine < lastOffset.line || offsetLine === lastOffset.line && offsetColumn < lastOffset.column) {
          throw new Error("Section offsets must be ordered and non-overlapping.");
        }
        lastOffset = offset;
        return {
          generatedOffset: {
            // The offset fields are 0-based, but we use 1-based indices when
            // encoding/decoding from VLQ.
            generatedLine: offsetLine + 1,
            generatedColumn: offsetColumn + 1
          },
          consumer: new SourceMapConsumer2(util.getArg(s, "map"), aSourceMapURL)
        };
      });
    }
    IndexedSourceMapConsumer.prototype = Object.create(SourceMapConsumer2.prototype);
    IndexedSourceMapConsumer.prototype.constructor = SourceMapConsumer2;
    IndexedSourceMapConsumer.prototype._version = 3;
    Object.defineProperty(IndexedSourceMapConsumer.prototype, "sources", {
      get: function() {
        var sources = [];
        for (var i = 0; i < this._sections.length; i++) {
          for (var j = 0; j < this._sections[i].consumer.sources.length; j++) {
            sources.push(this._sections[i].consumer.sources[j]);
          }
        }
        return sources;
      }
    });
    IndexedSourceMapConsumer.prototype.originalPositionFor = function IndexedSourceMapConsumer_originalPositionFor(aArgs) {
      var needle = {
        generatedLine: util.getArg(aArgs, "line"),
        generatedColumn: util.getArg(aArgs, "column")
      };
      var sectionIndex = binarySearch.search(
        needle,
        this._sections,
        function(needle2, section2) {
          var cmp = needle2.generatedLine - section2.generatedOffset.generatedLine;
          if (cmp) {
            return cmp;
          }
          return needle2.generatedColumn - section2.generatedOffset.generatedColumn;
        }
      );
      var section = this._sections[sectionIndex];
      if (!section) {
        return {
          source: null,
          line: null,
          column: null,
          name: null
        };
      }
      return section.consumer.originalPositionFor({
        line: needle.generatedLine - (section.generatedOffset.generatedLine - 1),
        column: needle.generatedColumn - (section.generatedOffset.generatedLine === needle.generatedLine ? section.generatedOffset.generatedColumn - 1 : 0),
        bias: aArgs.bias
      });
    };
    IndexedSourceMapConsumer.prototype.hasContentsOfAllSources = function IndexedSourceMapConsumer_hasContentsOfAllSources() {
      return this._sections.every(function(s) {
        return s.consumer.hasContentsOfAllSources();
      });
    };
    IndexedSourceMapConsumer.prototype.sourceContentFor = function IndexedSourceMapConsumer_sourceContentFor(aSource, nullOnMissing) {
      for (var i = 0; i < this._sections.length; i++) {
        var section = this._sections[i];
        var content = section.consumer.sourceContentFor(aSource, true);
        if (content) {
          return content;
        }
      }
      if (nullOnMissing) {
        return null;
      } else {
        throw new Error('"' + aSource + '" is not in the SourceMap.');
      }
    };
    IndexedSourceMapConsumer.prototype.generatedPositionFor = function IndexedSourceMapConsumer_generatedPositionFor(aArgs) {
      for (var i = 0; i < this._sections.length; i++) {
        var section = this._sections[i];
        if (section.consumer._findSourceIndex(util.getArg(aArgs, "source")) === -1) {
          continue;
        }
        var generatedPosition = section.consumer.generatedPositionFor(aArgs);
        if (generatedPosition) {
          var ret = {
            line: generatedPosition.line + (section.generatedOffset.generatedLine - 1),
            column: generatedPosition.column + (section.generatedOffset.generatedLine === generatedPosition.line ? section.generatedOffset.generatedColumn - 1 : 0)
          };
          return ret;
        }
      }
      return {
        line: null,
        column: null
      };
    };
    IndexedSourceMapConsumer.prototype._parseMappings = function IndexedSourceMapConsumer_parseMappings(aStr, aSourceRoot) {
      this.__generatedMappings = [];
      this.__originalMappings = [];
      for (var i = 0; i < this._sections.length; i++) {
        var section = this._sections[i];
        var sectionMappings = section.consumer._generatedMappings;
        for (var j = 0; j < sectionMappings.length; j++) {
          var mapping = sectionMappings[j];
          var source = section.consumer._sources.at(mapping.source);
          source = util.computeSourceURL(section.consumer.sourceRoot, source, this._sourceMapURL);
          this._sources.add(source);
          source = this._sources.indexOf(source);
          var name = null;
          if (mapping.name) {
            name = section.consumer._names.at(mapping.name);
            this._names.add(name);
            name = this._names.indexOf(name);
          }
          var adjustedMapping = {
            source,
            generatedLine: mapping.generatedLine + (section.generatedOffset.generatedLine - 1),
            generatedColumn: mapping.generatedColumn + (section.generatedOffset.generatedLine === mapping.generatedLine ? section.generatedOffset.generatedColumn - 1 : 0),
            originalLine: mapping.originalLine,
            originalColumn: mapping.originalColumn,
            name
          };
          this.__generatedMappings.push(adjustedMapping);
          if (typeof adjustedMapping.originalLine === "number") {
            this.__originalMappings.push(adjustedMapping);
          }
        }
      }
      quickSort(this.__generatedMappings, util.compareByGeneratedPositionsDeflated);
      quickSort(this.__originalMappings, util.compareByOriginalPositions);
    };
    exports.IndexedSourceMapConsumer = IndexedSourceMapConsumer;
  }
});
var require_source_node = __commonJS({
  "node_modules/source-map-js/lib/source-node.js"(exports) {
    var SourceMapGenerator = require_source_map_generator().SourceMapGenerator;
    var util = require_util();
    var REGEX_NEWLINE = /(\r?\n)/;
    var NEWLINE_CODE = 10;
    var isSourceNode = "$$$isSourceNode$$$";
    function SourceNode(aLine, aColumn, aSource, aChunks, aName) {
      this.children = [];
      this.sourceContents = {};
      this.line = aLine == null ? null : aLine;
      this.column = aColumn == null ? null : aColumn;
      this.source = aSource == null ? null : aSource;
      this.name = aName == null ? null : aName;
      this[isSourceNode] = true;
      if (aChunks != null)
        this.add(aChunks);
    }
    SourceNode.fromStringWithSourceMap = function SourceNode_fromStringWithSourceMap(aGeneratedCode, aSourceMapConsumer, aRelativePath) {
      var node = new SourceNode();
      var remainingLines = aGeneratedCode.split(REGEX_NEWLINE);
      var remainingLinesIndex = 0;
      var shiftNextLine = function() {
        var lineContents = getNextLine();
        var newLine = getNextLine() || "";
        return lineContents + newLine;
        function getNextLine() {
          return remainingLinesIndex < remainingLines.length ? remainingLines[remainingLinesIndex++] : void 0;
        }
      };
      var lastGeneratedLine = 1, lastGeneratedColumn = 0;
      var lastMapping = null;
      aSourceMapConsumer.eachMapping(function(mapping) {
        if (lastMapping !== null) {
          if (lastGeneratedLine < mapping.generatedLine) {
            addMappingWithCode(lastMapping, shiftNextLine());
            lastGeneratedLine++;
            lastGeneratedColumn = 0;
          } else {
            var nextLine = remainingLines[remainingLinesIndex] || "";
            var code = nextLine.substr(0, mapping.generatedColumn - lastGeneratedColumn);
            remainingLines[remainingLinesIndex] = nextLine.substr(mapping.generatedColumn - lastGeneratedColumn);
            lastGeneratedColumn = mapping.generatedColumn;
            addMappingWithCode(lastMapping, code);
            lastMapping = mapping;
            return;
          }
        }
        while (lastGeneratedLine < mapping.generatedLine) {
          node.add(shiftNextLine());
          lastGeneratedLine++;
        }
        if (lastGeneratedColumn < mapping.generatedColumn) {
          var nextLine = remainingLines[remainingLinesIndex] || "";
          node.add(nextLine.substr(0, mapping.generatedColumn));
          remainingLines[remainingLinesIndex] = nextLine.substr(mapping.generatedColumn);
          lastGeneratedColumn = mapping.generatedColumn;
        }
        lastMapping = mapping;
      }, this);
      if (remainingLinesIndex < remainingLines.length) {
        if (lastMapping) {
          addMappingWithCode(lastMapping, shiftNextLine());
        }
        node.add(remainingLines.splice(remainingLinesIndex).join(""));
      }
      aSourceMapConsumer.sources.forEach(function(sourceFile) {
        var content = aSourceMapConsumer.sourceContentFor(sourceFile);
        if (content != null) {
          if (aRelativePath != null) {
            sourceFile = util.join(aRelativePath, sourceFile);
          }
          node.setSourceContent(sourceFile, content);
        }
      });
      return node;
      function addMappingWithCode(mapping, code) {
        if (mapping === null || mapping.source === void 0) {
          node.add(code);
        } else {
          var source = aRelativePath ? util.join(aRelativePath, mapping.source) : mapping.source;
          node.add(new SourceNode(
            mapping.originalLine,
            mapping.originalColumn,
            source,
            code,
            mapping.name
          ));
        }
      }
    };
    SourceNode.prototype.add = function SourceNode_add(aChunk) {
      if (Array.isArray(aChunk)) {
        aChunk.forEach(function(chunk) {
          this.add(chunk);
        }, this);
      } else if (aChunk[isSourceNode] || typeof aChunk === "string") {
        if (aChunk) {
          this.children.push(aChunk);
        }
      } else {
        throw new TypeError(
          "Expected a SourceNode, string, or an array of SourceNodes and strings. Got " + aChunk
        );
      }
      return this;
    };
    SourceNode.prototype.prepend = function SourceNode_prepend(aChunk) {
      if (Array.isArray(aChunk)) {
        for (var i = aChunk.length - 1; i >= 0; i--) {
          this.prepend(aChunk[i]);
        }
      } else if (aChunk[isSourceNode] || typeof aChunk === "string") {
        this.children.unshift(aChunk);
      } else {
        throw new TypeError(
          "Expected a SourceNode, string, or an array of SourceNodes and strings. Got " + aChunk
        );
      }
      return this;
    };
    SourceNode.prototype.walk = function SourceNode_walk(aFn) {
      var chunk;
      for (var i = 0, len = this.children.length; i < len; i++) {
        chunk = this.children[i];
        if (chunk[isSourceNode]) {
          chunk.walk(aFn);
        } else {
          if (chunk !== "") {
            aFn(chunk, {
              source: this.source,
              line: this.line,
              column: this.column,
              name: this.name
            });
          }
        }
      }
    };
    SourceNode.prototype.join = function SourceNode_join(aSep) {
      var newChildren;
      var i;
      var len = this.children.length;
      if (len > 0) {
        newChildren = [];
        for (i = 0; i < len - 1; i++) {
          newChildren.push(this.children[i]);
          newChildren.push(aSep);
        }
        newChildren.push(this.children[i]);
        this.children = newChildren;
      }
      return this;
    };
    SourceNode.prototype.replaceRight = function SourceNode_replaceRight(aPattern, aReplacement) {
      var lastChild = this.children[this.children.length - 1];
      if (lastChild[isSourceNode]) {
        lastChild.replaceRight(aPattern, aReplacement);
      } else if (typeof lastChild === "string") {
        this.children[this.children.length - 1] = lastChild.replace(aPattern, aReplacement);
      } else {
        this.children.push("".replace(aPattern, aReplacement));
      }
      return this;
    };
    SourceNode.prototype.setSourceContent = function SourceNode_setSourceContent(aSourceFile, aSourceContent) {
      this.sourceContents[util.toSetString(aSourceFile)] = aSourceContent;
    };
    SourceNode.prototype.walkSourceContents = function SourceNode_walkSourceContents(aFn) {
      for (var i = 0, len = this.children.length; i < len; i++) {
        if (this.children[i][isSourceNode]) {
          this.children[i].walkSourceContents(aFn);
        }
      }
      var sources = Object.keys(this.sourceContents);
      for (var i = 0, len = sources.length; i < len; i++) {
        aFn(util.fromSetString(sources[i]), this.sourceContents[sources[i]]);
      }
    };
    SourceNode.prototype.toString = function SourceNode_toString() {
      var str = "";
      this.walk(function(chunk) {
        str += chunk;
      });
      return str;
    };
    SourceNode.prototype.toStringWithSourceMap = function SourceNode_toStringWithSourceMap(aArgs) {
      var generated = {
        code: "",
        line: 1,
        column: 0
      };
      var map = new SourceMapGenerator(aArgs);
      var sourceMappingActive = false;
      var lastOriginalSource = null;
      var lastOriginalLine = null;
      var lastOriginalColumn = null;
      var lastOriginalName = null;
      this.walk(function(chunk, original) {
        generated.code += chunk;
        if (original.source !== null && original.line !== null && original.column !== null) {
          if (lastOriginalSource !== original.source || lastOriginalLine !== original.line || lastOriginalColumn !== original.column || lastOriginalName !== original.name) {
            map.addMapping({
              source: original.source,
              original: {
                line: original.line,
                column: original.column
              },
              generated: {
                line: generated.line,
                column: generated.column
              },
              name: original.name
            });
          }
          lastOriginalSource = original.source;
          lastOriginalLine = original.line;
          lastOriginalColumn = original.column;
          lastOriginalName = original.name;
          sourceMappingActive = true;
        } else if (sourceMappingActive) {
          map.addMapping({
            generated: {
              line: generated.line,
              column: generated.column
            }
          });
          lastOriginalSource = null;
          sourceMappingActive = false;
        }
        for (var idx = 0, length = chunk.length; idx < length; idx++) {
          if (chunk.charCodeAt(idx) === NEWLINE_CODE) {
            generated.line++;
            generated.column = 0;
            if (idx + 1 === length) {
              lastOriginalSource = null;
              sourceMappingActive = false;
            } else if (sourceMappingActive) {
              map.addMapping({
                source: original.source,
                original: {
                  line: original.line,
                  column: original.column
                },
                generated: {
                  line: generated.line,
                  column: generated.column
                },
                name: original.name
              });
            }
          } else {
            generated.column++;
          }
        }
      });
      this.walkSourceContents(function(sourceFile, sourceContent) {
        map.setSourceContent(sourceFile, sourceContent);
      });
      return { code: generated.code, map };
    };
    exports.SourceNode = SourceNode;
  }
});
var require_source_map = __commonJS({
  "node_modules/source-map-js/source-map.js"(exports) {
    exports.SourceMapGenerator = require_source_map_generator().SourceMapGenerator;
    exports.SourceMapConsumer = require_source_map_consumer().SourceMapConsumer;
    exports.SourceNode = require_source_node().SourceNode;
  }
});
var import_source_map_js = __toESM(require_source_map(), 1);
async function fetchCall(pathComponents, ...args) {
  const url = new URL(window.location.origin);
  url.pathname = pathComponents.join("/");
  const response = await fetch(url.toString(), {
    method: "POST",
    body: JSON.stringify(args)
  });
  return response.headers.get("content-type")?.startsWith("application/json") ? response.json() : response.text();
}
function recurseInProxy(target, pathComponents = []) {
  return new Proxy(target, {
    apply: (target2, _, argArray) => {
      return target2(pathComponents, ...argArray);
    },
    get: (_, p) => {
      pathComponents.push(p);
      return recurseInProxy(target, pathComponents);
    }
  });
}
function rpc2() {
  return recurseInProxy(fetchCall);
}
window.rpc = rpc2;
window.onPush = {};
window.push = (messageType, message) => {
  const callback = window.onPush[messageType];
  if (!callback)
    throw `No onPush callback for message type [${messageType}]. Received message [${message}]`;
  callback(message);
};
var platform = await rpc2().platform();
if (platform === "node") {
  const url = (window.location.protocol === "http:" ? "ws:" : "wss:") + "//" + window.location.host;
  const ws = new WebSocket(url);
  ws.onmessage = ({ data }) => {
    const { messageType, message } = JSON.parse(data);
    window.push(messageType, message);
  };
}
window.sourceMapConsumer = import_source_map_js.SourceMapConsumer;
init_Demo();
export {
  rpc2 as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vd2Vidmlldy9pY29ucy5qcyIsICIuLi93ZWJ2aWV3L3RoZW1lLmpzIiwgIi4uL3V0aWxzL3JhbmRvbS5qcyIsICIuLi93ZWJ2aWV3L2NvdW50ZXIuanMiLCAiLi4vaW5kZXguanMiLCAiLi4vLi4vLi4vLmNhY2hlL2Z1bGxzdGFja2VkL3RtcC0xNzA4NTI0MzEzODUyLmpzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLmljb25cIikuZm9yRWFjaChhc3luYyBpY29uID0+IHtcbiAgY29uc3QgaWNvbk5hbWUgPSBBcnJheS5mcm9tKGljb24uY2xhc3NMaXN0LnZhbHVlcygpKS5maWx0ZXIoaWNvbkNsYXNzID0+IGljb25DbGFzcyAhPT0gXCJpY29uXCIpLmF0KDApO1xuICBpY29uLmlubmVySFRNTCA9IGF3YWl0IChhd2FpdCBmZXRjaChgYXNzZXRzL2ltYWdlcy8ke2ljb25OYW1lfS5zdmdgKSkudGV4dCgpXG59KTtcblxuIiwgImNvbnN0IHRoZW1lU3dpdGNoID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiN0aGVtZS1zd2l0Y2ggaW5wdXRcIik7XG5cbmNvbnN0IHN0YXJ0RGFyayA9ICEhcGFyc2VJbnQoYXdhaXQgcnBjKCkudGhlbWUuaXNEYXJrKCkpO1xuaWYoc3RhcnREYXJrKXtcbiAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNsYXNzTGlzdC5hZGQoXCJkYXJrXCIpO1xuICB0aGVtZVN3aXRjaC5jaGVja2VkID0gZmFsc2U7XG59XG5cbnRoZW1lU3dpdGNoLmFkZEV2ZW50TGlzdGVuZXIoXCJjaGFuZ2VcIiwgZSA9PiB7XG4gIGNvbnN0IGlzRGFyayA9ICFlLmN1cnJlbnRUYXJnZXQuY2hlY2tlZDtcbiAgaWYoaXNEYXJrKXtcbiAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xhc3NMaXN0LmFkZChcImRhcmtcIilcbiAgfSBlbHNlIHtcbiAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShcImRhcmtcIilcbiAgfVxuXG4gIHJwYygpLnRoZW1lLnNhdmVEYXJrKGlzRGFyayA/IFwiMVwiIDogXCIwXCIpXG59KVxuIiwgImV4cG9ydCBmdW5jdGlvbiByYW5kb21FbGVtZW50KGFycmF5KSB7XG4gIGNvbnN0IHJhbmRvbUluZGV4ID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogYXJyYXkubGVuZ3RoKTtcbiAgcmV0dXJuIGFycmF5W3JhbmRvbUluZGV4XTtcbn1cbiIsICJpbXBvcnQgeyByYW5kb21FbGVtZW50IH0gZnJvbSBcIi4uL3V0aWxzL3JhbmRvbS5qc1wiO1xuXG5jb25zdCBjb3VudFZpZXcgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI2NvdW50ZXIgPiBkaXYgPiBkaXZcIik7XG5jb25zdCBbIHN1YiwgYWRkLCByZXNldCBdID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIiNjb3VudGVyIGJ1dHRvblwiKTtcblxubGV0IGNvdW50ID0gcGFyc2VJbnQoYXdhaXQgcnBjKCkuY291bnQubG9hZCgpKTtcbmNvdW50Vmlldy5pbm5lclRleHQgPSBjb3VudC50b1N0cmluZygpO1xuXG5jb25zdCB1cGRhdGVDb3VudCA9ICgpID0+IHtcbiAgY291bnRWaWV3LmlubmVyVGV4dCA9IGNvdW50LnRvU3RyaW5nKCk7XG4gIGlmKCFjb3VudCl7XG4gICAgcnBjKCkuY291bnQucmVzZXQoKTtcbiAgfSBlbHNlIHtcbiAgICBycGMoKS5jb3VudC5zYXZlKGNvdW50LnRvU3RyaW5nKCkpO1xuICB9XG5cbiAgaWYoY291bnQgJSAzID09PSAxKSB7XG4gICAgY29uc29sZS5sb2cocmFuZG9tRWxlbWVudChjaGF0R1BUUXVvdGVzKSk7XG4gIH1cbn1cblxuc3ViLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gIGNvdW50LS07XG4gIHVwZGF0ZUNvdW50KCk7XG59KTtcblxuYWRkLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gIGNvdW50Kys7XG4gIHVwZGF0ZUNvdW50KClcbn0pO1xuXG5yZXNldC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICBjb3VudCA9IDA7XG4gIHVwZGF0ZUNvdW50KCk7XG59KTtcblxuXG5jb25zdCBjaGF0R1BUUXVvdGVzID0gW1xuICBcIkNsaWNraW5nIHRoYXQgYnV0dG9uIGxpa2UgYSBib3NzIFx1MjAxMyBvbmUgcHJlc3MgYXQgYSB0aW1lIVwiLFxuICBcIllvdSdyZSBvbiBmaXJlISBLZWVwIGNsaWNraW5nLCBhbmQgbGV0IHRoZSBjb3VudGluZyBnYW1lcyBiZWdpbi5cIixcbiAgXCJDbGlja2luZyBhd2F5IGxpa2UgYSBjaGFtcGlvbi4gWW91J3JlIHRoZSB0cnVlIGNvdW50ZXIgZXh0cmFvcmRpbmFpcmUhXCIsXG4gIFwiQ291bnRpbmcgd2l0aCBwcmVjaXNpb24gXHUyMDEzIG9uZSBjbGljayBhdCBhIHRpbWUuIFlvdSd2ZSBnb3QgdGhpcyFcIixcbiAgXCJDbGlja2luZyBmYXN0ZXIgdGhhbiBhIGNhZmZlaW5hdGVkIGh1bW1pbmdiaXJkLiBZb3UncmUgdW5zdG9wcGFibGUhXCIsXG4gIFwiQ2xpY2tpdHktY2xpY2shIFlvdSdyZSB0aGUgbWFlc3RybyBvZiB0aGUgY291bnRlciBzeW1waG9ueS5cIixcbiAgXCJDb3VudGluZyBjbGlja3MgbGlrZSBpdCdzIGFuIE9seW1waWMgc3BvcnQuIEdvbGQgbWVkYWwgdmliZXMhXCIsXG4gIFwiS2VlcCBjYWxtIGFuZCBjbGljayBvbi4gWW91J3JlIG1ha2luZyBoaXN0b3J5LCBvbmUgYnV0dG9uIGF0IGEgdGltZS5cIixcbiAgXCJDbGljaywgY2xpY2ssIGhvb3JheSEgWW91J3JlIHRoZSBjbGljayBtYXN0ZXIsIG5vIGRvdWJ0LlwiLFxuICBcIllvdSd2ZSBnb3QgdGhlIE1pZGFzIHRvdWNoIFx1MjAxMyBidXQgd2l0aCBhIGNvdW50ZXIgYnV0dG9uLiBDbGljayBpdCBhbGwgdG8gZ29sZCFcIixcbiAgXCJDbGlja2luZyBsaWtlIGl0J3MgZ29pbmcgb3V0IG9mIHN0eWxlLiBTcG9pbGVyOiBpdCdzIG5vdCFcIixcbiAgXCJDb3VudGluZyBjbGlja3MgbGlrZSBhIG1hdGhlbWF0aWNpYW4gd2l0aCBhIHNlbnNlIG9mIGh1bW9yLiBHbywgeW91IVwiLFxuICBcIkNsaWNraW5nIHdpdGggdGhlIHByZWNpc2lvbiBvZiBhIG5pbmphIFx1MjAxMyBzaWxlbnQgYnV0IGRlYWRseSBhY2N1cmF0ZS5cIixcbiAgXCJCdXR0b24tY2xpY2tpbmcgdmlydHVvc28gaW4gYWN0aW9uISBFbmNvcmUsIGVuY29yZSFcIixcbiAgXCJDbGlja2luZyBhd2F5LCBsZWF2aW5nIGEgdHJhaWwgb2Ygc21pbGVzIGFuZCBjb3VudGluZyB0cml1bXBocy5cIixcbiAgXCJDbGlja2luZyBzbyBmYXN0LCB5b3UgbWlnaHQgYnJlYWsgdGhlIGludGVybmV0LiBQcm9jZWVkIHdpdGggYXdlc29tZW5lc3MhXCIsXG4gIFwiQ291bnRpbmcgY2xpY2tzIGxpa2UgYSByb2Nrc3Rhci4gWW91ciBmYW5zIGFyZSBjaGVlcmluZyFcIixcbiAgXCJDbGlja2luZyBsaWtlIHRoZXJlJ3Mgbm8gdG9tb3Jyb3cuIFNwb2lsZXIgYWxlcnQ6IFRvbW9ycm93LCB5b3UnbGwgc3RpbGwgYmUgY2xpY2tpbmchXCIsXG4gIFwiWW91J3JlIG5vdCBqdXN0IGNsaWNraW5nOyB5b3UncmUgY3JlYXRpbmcgYSBtYXN0ZXJwaWVjZSBvZiBjb3VudHMhXCIsXG4gIFwiQ2xpY2tpbmcgc28gc21vb3RobHksIGl0J3MgbGlrZSBidXR0ZXIgXHUyMDEzIGJ1dCB3aXRob3V0IHRoZSBtZXNzLlwiLFxuICBcIkNsaWNraW5nIGJyaWxsaWFuY2UgaW4gcHJvZ3Jlc3MhIFRoZSB3b3JsZCBuZWVkcyBtb3JlIGNvdW50ZXJzIGxpa2UgeW91LlwiLFxuICBcIkNvdW50aW5nIGNsaWNrcyBsaWtlIGEgcHJvIFx1MjAxMyBiZWNhdXNlIGFtYXRldXJzIGFyZSBmb3IgdGhlIGZhaW50LWhlYXJ0ZWQuXCIsXG4gIFwiQ2xpY2tpbmcgd2l0aCBmaW5lc3NlIGFuZCBzdHlsZS4gWW91J3JlIHRoZSBKYW1lcyBCb25kIG9mIGNvdW50ZXJzIVwiLFxuICBcIkNsaWNrLCBjbGljaywgaG9vcmF5ISBUaGUgd29ybGQgaXMgYSBiZXR0ZXIgcGxhY2Ugd2l0aCB5b3VyIGNvdW50aW5nIHNraWxscy5cIixcbiAgXCJDbGlja2luZyB0aHJvdWdoIGxpZmUgd2l0aCBmbGFpciBhbmQgaHVtb3IuIEtlZXAgaXQgdXAhXCIsXG4gIFwiQ291bnRpbmcgY2xpY2tzIGxpa2UgaXQncyBhIGRhbmNlLiBZb3UndmUgZ290IHRoZSBwZXJmZWN0IG1vdmVzIVwiLFxuICBcIkNsaWNrLCBjbGljaywgaG9vcmF5ISBUaGUgd29ybGQgaXMgYSBiZXR0ZXIgcGxhY2Ugd2l0aCB5b3VyIGNvdW50aW5nIHNraWxscy5cIixcbiAgXCJDb3VudGluZyBjbGlja3MgbGlrZSBhIGJvc3MuIFlvdXIgZmluZ2VyIG11c3QgYmUgaW4gdHJhaW5pbmchXCIsXG4gIFwiQ2xpY2tpbmcgbGlrZSBpdCdzIHRoZSBjb29sZXN0IHRoaW5nIHlvdSdsbCBkbyB0b2RheS4gU3BvaWxlcjogaXQgaXMhXCIsXG4gIFwiQ2xpY2ssIGxhdWdoLCByZXBlYXQuIFlvdXIgY2xpY2tpbmcgam91cm5leSBpcyBwdXJlIGpveSFcIixcbiAgXCJDb3VudGluZyBjbGlja3Mgd2l0aCB0aGUgZW50aHVzaWFzbSBvZiBhIGtpZCBpbiBhIGNhbmR5IHN0b3JlLiBLZWVwIHRoYXQgam95IGFsaXZlIVwiLFxuICBcIkNsaWNraW5nIGxpa2UgYSBwcm8gXHUyMDEzIGJlY2F1c2UgYW1hdGV1cnMgYXJlIGZvciBiZWdpbm5lcnMuXCIsXG4gIFwiQnV0dG9uIGNsaWNraW5nIGxldmVsOiBFeHBlcnQuIFlvdSdyZSBhY2luZyB0aGlzIGdhbWUhXCIsXG4gIFwiQ2xpY2tpbmcgYXdheSwgbWFraW5nIG51bWJlcnMgbG9vayBnb29kLiBLZWVwIHVwIHRoZSBmYW50YXN0aWMgd29yayFcIixcbiAgXCJDb3VudGluZyBjbGlja3MgbGlrZSBpdCdzIGFuIGFydCBmb3JtLiBQaWNhc3NvIHdvdWxkIGJlIHByb3VkIVwiLFxuICBcIkNsaWNraW5nIHdpdGggc3R5bGUsIGdyYWNlLCBhbmQgYSB0b3VjaCBvZiBodW1vci4gVGhhdCdzIGhvdyBpdCdzIGRvbmUhXCIsXG4gIFwiQ2xpY2tpbmcgYnV0dG9ucyB3aXRoIHRoZSBwcmVjaXNpb24gb2YgYSBzdXJnZW9uLiBZb3UncmUgc2F2aW5nIGxpdmVzLCBvbmUgY2xpY2sgYXQgYSB0aW1lIVwiXG5dOyIsICJpbXBvcnQgXCIuL3dlYnZpZXcvaWNvbnMuanNcIjtcbmltcG9ydCBcIi4vd2Vidmlldy90aGVtZS5qc1wiO1xuaW1wb3J0IFwiLi93ZWJ2aWV3L2NvdW50ZXIuanNcIjsiLCAidmFyIF9fY3JlYXRlID0gT2JqZWN0LmNyZWF0ZTtcbnZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19nZXRPd25Qcm9wRGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3I7XG52YXIgX19nZXRPd25Qcm9wTmFtZXMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcztcbnZhciBfX2dldFByb3RvT2YgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2Y7XG52YXIgX19oYXNPd25Qcm9wID0gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eTtcbnZhciBfX2NvbW1vbkpTID0gKGNiLCBtb2QpID0+IGZ1bmN0aW9uIF9fcmVxdWlyZSgpIHtcbiAgcmV0dXJuIG1vZCB8fCAoMCwgY2JbX19nZXRPd25Qcm9wTmFtZXMoY2IpWzBdXSkoKG1vZCA9IHsgZXhwb3J0czoge30gfSkuZXhwb3J0cywgbW9kKSwgbW9kLmV4cG9ydHM7XG59O1xudmFyIF9fY29weVByb3BzID0gKHRvLCBmcm9tLCBleGNlcHQsIGRlc2MpID0+IHtcbiAgaWYgKGZyb20gJiYgdHlwZW9mIGZyb20gPT09IFwib2JqZWN0XCIgfHwgdHlwZW9mIGZyb20gPT09IFwiZnVuY3Rpb25cIikge1xuICAgIGZvciAobGV0IGtleSBvZiBfX2dldE93blByb3BOYW1lcyhmcm9tKSlcbiAgICAgIGlmICghX19oYXNPd25Qcm9wLmNhbGwodG8sIGtleSkgJiYga2V5ICE9PSBleGNlcHQpXG4gICAgICAgIF9fZGVmUHJvcCh0bywga2V5LCB7IGdldDogKCkgPT4gZnJvbVtrZXldLCBlbnVtZXJhYmxlOiAhKGRlc2MgPSBfX2dldE93blByb3BEZXNjKGZyb20sIGtleSkpIHx8IGRlc2MuZW51bWVyYWJsZSB9KTtcbiAgfVxuICByZXR1cm4gdG87XG59O1xudmFyIF9fdG9FU00gPSAobW9kLCBpc05vZGVNb2RlLCB0YXJnZXQpID0+ICh0YXJnZXQgPSBtb2QgIT0gbnVsbCA/IF9fY3JlYXRlKF9fZ2V0UHJvdG9PZihtb2QpKSA6IHt9LCBfX2NvcHlQcm9wcyhcbiAgLy8gSWYgdGhlIGltcG9ydGVyIGlzIGluIG5vZGUgY29tcGF0aWJpbGl0eSBtb2RlIG9yIHRoaXMgaXMgbm90IGFuIEVTTVxuICAvLyBmaWxlIHRoYXQgaGFzIGJlZW4gY29udmVydGVkIHRvIGEgQ29tbW9uSlMgZmlsZSB1c2luZyBhIEJhYmVsLVxuICAvLyBjb21wYXRpYmxlIHRyYW5zZm9ybSAoaS5lLiBcIl9fZXNNb2R1bGVcIiBoYXMgbm90IGJlZW4gc2V0KSwgdGhlbiBzZXRcbiAgLy8gXCJkZWZhdWx0XCIgdG8gdGhlIENvbW1vbkpTIFwibW9kdWxlLmV4cG9ydHNcIiBmb3Igbm9kZSBjb21wYXRpYmlsaXR5LlxuICBpc05vZGVNb2RlIHx8ICFtb2QgfHwgIW1vZC5fX2VzTW9kdWxlID8gX19kZWZQcm9wKHRhcmdldCwgXCJkZWZhdWx0XCIsIHsgdmFsdWU6IG1vZCwgZW51bWVyYWJsZTogdHJ1ZSB9KSA6IHRhcmdldCxcbiAgbW9kXG4pKTtcblxuLy8gbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvbGliL2Jhc2U2NC5qc1xudmFyIHJlcXVpcmVfYmFzZTY0ID0gX19jb21tb25KUyh7XG4gIFwibm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvbGliL2Jhc2U2NC5qc1wiKGV4cG9ydHMpIHtcbiAgICB2YXIgaW50VG9DaGFyTWFwID0gXCJBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OSsvXCIuc3BsaXQoXCJcIik7XG4gICAgZXhwb3J0cy5lbmNvZGUgPSBmdW5jdGlvbihudW1iZXIpIHtcbiAgICAgIGlmICgwIDw9IG51bWJlciAmJiBudW1iZXIgPCBpbnRUb0NoYXJNYXAubGVuZ3RoKSB7XG4gICAgICAgIHJldHVybiBpbnRUb0NoYXJNYXBbbnVtYmVyXTtcbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJNdXN0IGJlIGJldHdlZW4gMCBhbmQgNjM6IFwiICsgbnVtYmVyKTtcbiAgICB9O1xuICAgIGV4cG9ydHMuZGVjb2RlID0gZnVuY3Rpb24oY2hhckNvZGUpIHtcbiAgICAgIHZhciBiaWdBID0gNjU7XG4gICAgICB2YXIgYmlnWiA9IDkwO1xuICAgICAgdmFyIGxpdHRsZUEgPSA5NztcbiAgICAgIHZhciBsaXR0bGVaID0gMTIyO1xuICAgICAgdmFyIHplcm8gPSA0ODtcbiAgICAgIHZhciBuaW5lID0gNTc7XG4gICAgICB2YXIgcGx1cyA9IDQzO1xuICAgICAgdmFyIHNsYXNoID0gNDc7XG4gICAgICB2YXIgbGl0dGxlT2Zmc2V0ID0gMjY7XG4gICAgICB2YXIgbnVtYmVyT2Zmc2V0ID0gNTI7XG4gICAgICBpZiAoYmlnQSA8PSBjaGFyQ29kZSAmJiBjaGFyQ29kZSA8PSBiaWdaKSB7XG4gICAgICAgIHJldHVybiBjaGFyQ29kZSAtIGJpZ0E7XG4gICAgICB9XG4gICAgICBpZiAobGl0dGxlQSA8PSBjaGFyQ29kZSAmJiBjaGFyQ29kZSA8PSBsaXR0bGVaKSB7XG4gICAgICAgIHJldHVybiBjaGFyQ29kZSAtIGxpdHRsZUEgKyBsaXR0bGVPZmZzZXQ7XG4gICAgICB9XG4gICAgICBpZiAoemVybyA8PSBjaGFyQ29kZSAmJiBjaGFyQ29kZSA8PSBuaW5lKSB7XG4gICAgICAgIHJldHVybiBjaGFyQ29kZSAtIHplcm8gKyBudW1iZXJPZmZzZXQ7XG4gICAgICB9XG4gICAgICBpZiAoY2hhckNvZGUgPT0gcGx1cykge1xuICAgICAgICByZXR1cm4gNjI7XG4gICAgICB9XG4gICAgICBpZiAoY2hhckNvZGUgPT0gc2xhc2gpIHtcbiAgICAgICAgcmV0dXJuIDYzO1xuICAgICAgfVxuICAgICAgcmV0dXJuIC0xO1xuICAgIH07XG4gIH1cbn0pO1xuXG4vLyBub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvYmFzZTY0LXZscS5qc1xudmFyIHJlcXVpcmVfYmFzZTY0X3ZscSA9IF9fY29tbW9uSlMoe1xuICBcIm5vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi9iYXNlNjQtdmxxLmpzXCIoZXhwb3J0cykge1xuICAgIHZhciBiYXNlNjQgPSByZXF1aXJlX2Jhc2U2NCgpO1xuICAgIHZhciBWTFFfQkFTRV9TSElGVCA9IDU7XG4gICAgdmFyIFZMUV9CQVNFID0gMSA8PCBWTFFfQkFTRV9TSElGVDtcbiAgICB2YXIgVkxRX0JBU0VfTUFTSyA9IFZMUV9CQVNFIC0gMTtcbiAgICB2YXIgVkxRX0NPTlRJTlVBVElPTl9CSVQgPSBWTFFfQkFTRTtcbiAgICBmdW5jdGlvbiB0b1ZMUVNpZ25lZChhVmFsdWUpIHtcbiAgICAgIHJldHVybiBhVmFsdWUgPCAwID8gKC1hVmFsdWUgPDwgMSkgKyAxIDogKGFWYWx1ZSA8PCAxKSArIDA7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGZyb21WTFFTaWduZWQoYVZhbHVlKSB7XG4gICAgICB2YXIgaXNOZWdhdGl2ZSA9IChhVmFsdWUgJiAxKSA9PT0gMTtcbiAgICAgIHZhciBzaGlmdGVkID0gYVZhbHVlID4+IDE7XG4gICAgICByZXR1cm4gaXNOZWdhdGl2ZSA/IC1zaGlmdGVkIDogc2hpZnRlZDtcbiAgICB9XG4gICAgZXhwb3J0cy5lbmNvZGUgPSBmdW5jdGlvbiBiYXNlNjRWTFFfZW5jb2RlKGFWYWx1ZSkge1xuICAgICAgdmFyIGVuY29kZWQgPSBcIlwiO1xuICAgICAgdmFyIGRpZ2l0O1xuICAgICAgdmFyIHZscSA9IHRvVkxRU2lnbmVkKGFWYWx1ZSk7XG4gICAgICBkbyB7XG4gICAgICAgIGRpZ2l0ID0gdmxxICYgVkxRX0JBU0VfTUFTSztcbiAgICAgICAgdmxxID4+Pj0gVkxRX0JBU0VfU0hJRlQ7XG4gICAgICAgIGlmICh2bHEgPiAwKSB7XG4gICAgICAgICAgZGlnaXQgfD0gVkxRX0NPTlRJTlVBVElPTl9CSVQ7XG4gICAgICAgIH1cbiAgICAgICAgZW5jb2RlZCArPSBiYXNlNjQuZW5jb2RlKGRpZ2l0KTtcbiAgICAgIH0gd2hpbGUgKHZscSA+IDApO1xuICAgICAgcmV0dXJuIGVuY29kZWQ7XG4gICAgfTtcbiAgICBleHBvcnRzLmRlY29kZSA9IGZ1bmN0aW9uIGJhc2U2NFZMUV9kZWNvZGUoYVN0ciwgYUluZGV4LCBhT3V0UGFyYW0pIHtcbiAgICAgIHZhciBzdHJMZW4gPSBhU3RyLmxlbmd0aDtcbiAgICAgIHZhciByZXN1bHQgPSAwO1xuICAgICAgdmFyIHNoaWZ0ID0gMDtcbiAgICAgIHZhciBjb250aW51YXRpb24sIGRpZ2l0O1xuICAgICAgZG8ge1xuICAgICAgICBpZiAoYUluZGV4ID49IHN0ckxlbikge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIG1vcmUgZGlnaXRzIGluIGJhc2UgNjQgVkxRIHZhbHVlLlwiKTtcbiAgICAgICAgfVxuICAgICAgICBkaWdpdCA9IGJhc2U2NC5kZWNvZGUoYVN0ci5jaGFyQ29kZUF0KGFJbmRleCsrKSk7XG4gICAgICAgIGlmIChkaWdpdCA9PT0gLTEpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIGJhc2U2NCBkaWdpdDogXCIgKyBhU3RyLmNoYXJBdChhSW5kZXggLSAxKSk7XG4gICAgICAgIH1cbiAgICAgICAgY29udGludWF0aW9uID0gISEoZGlnaXQgJiBWTFFfQ09OVElOVUFUSU9OX0JJVCk7XG4gICAgICAgIGRpZ2l0ICY9IFZMUV9CQVNFX01BU0s7XG4gICAgICAgIHJlc3VsdCA9IHJlc3VsdCArIChkaWdpdCA8PCBzaGlmdCk7XG4gICAgICAgIHNoaWZ0ICs9IFZMUV9CQVNFX1NISUZUO1xuICAgICAgfSB3aGlsZSAoY29udGludWF0aW9uKTtcbiAgICAgIGFPdXRQYXJhbS52YWx1ZSA9IGZyb21WTFFTaWduZWQocmVzdWx0KTtcbiAgICAgIGFPdXRQYXJhbS5yZXN0ID0gYUluZGV4O1xuICAgIH07XG4gIH1cbn0pO1xuXG4vLyBub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvdXRpbC5qc1xudmFyIHJlcXVpcmVfdXRpbCA9IF9fY29tbW9uSlMoe1xuICBcIm5vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi91dGlsLmpzXCIoZXhwb3J0cykge1xuICAgIGZ1bmN0aW9uIGdldEFyZyhhQXJncywgYU5hbWUsIGFEZWZhdWx0VmFsdWUpIHtcbiAgICAgIGlmIChhTmFtZSBpbiBhQXJncykge1xuICAgICAgICByZXR1cm4gYUFyZ3NbYU5hbWVdO1xuICAgICAgfSBlbHNlIGlmIChhcmd1bWVudHMubGVuZ3RoID09PSAzKSB7XG4gICAgICAgIHJldHVybiBhRGVmYXVsdFZhbHVlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdcIicgKyBhTmFtZSArICdcIiBpcyBhIHJlcXVpcmVkIGFyZ3VtZW50LicpO1xuICAgICAgfVxuICAgIH1cbiAgICBleHBvcnRzLmdldEFyZyA9IGdldEFyZztcbiAgICB2YXIgdXJsUmVnZXhwID0gL14oPzooW1xcdytcXC0uXSspOik/XFwvXFwvKD86KFxcdys6XFx3KylAKT8oW1xcdy4tXSopKD86OihcXGQrKSk/KC4qKSQvO1xuICAgIHZhciBkYXRhVXJsUmVnZXhwID0gL15kYXRhOi4rXFwsLiskLztcbiAgICBmdW5jdGlvbiB1cmxQYXJzZShhVXJsKSB7XG4gICAgICB2YXIgbWF0Y2ggPSBhVXJsLm1hdGNoKHVybFJlZ2V4cCk7XG4gICAgICBpZiAoIW1hdGNoKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc2NoZW1lOiBtYXRjaFsxXSxcbiAgICAgICAgYXV0aDogbWF0Y2hbMl0sXG4gICAgICAgIGhvc3Q6IG1hdGNoWzNdLFxuICAgICAgICBwb3J0OiBtYXRjaFs0XSxcbiAgICAgICAgcGF0aDogbWF0Y2hbNV1cbiAgICAgIH07XG4gICAgfVxuICAgIGV4cG9ydHMudXJsUGFyc2UgPSB1cmxQYXJzZTtcbiAgICBmdW5jdGlvbiB1cmxHZW5lcmF0ZShhUGFyc2VkVXJsKSB7XG4gICAgICB2YXIgdXJsID0gXCJcIjtcbiAgICAgIGlmIChhUGFyc2VkVXJsLnNjaGVtZSkge1xuICAgICAgICB1cmwgKz0gYVBhcnNlZFVybC5zY2hlbWUgKyBcIjpcIjtcbiAgICAgIH1cbiAgICAgIHVybCArPSBcIi8vXCI7XG4gICAgICBpZiAoYVBhcnNlZFVybC5hdXRoKSB7XG4gICAgICAgIHVybCArPSBhUGFyc2VkVXJsLmF1dGggKyBcIkBcIjtcbiAgICAgIH1cbiAgICAgIGlmIChhUGFyc2VkVXJsLmhvc3QpIHtcbiAgICAgICAgdXJsICs9IGFQYXJzZWRVcmwuaG9zdDtcbiAgICAgIH1cbiAgICAgIGlmIChhUGFyc2VkVXJsLnBvcnQpIHtcbiAgICAgICAgdXJsICs9IFwiOlwiICsgYVBhcnNlZFVybC5wb3J0O1xuICAgICAgfVxuICAgICAgaWYgKGFQYXJzZWRVcmwucGF0aCkge1xuICAgICAgICB1cmwgKz0gYVBhcnNlZFVybC5wYXRoO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHVybDtcbiAgICB9XG4gICAgZXhwb3J0cy51cmxHZW5lcmF0ZSA9IHVybEdlbmVyYXRlO1xuICAgIHZhciBNQVhfQ0FDSEVEX0lOUFVUUyA9IDMyO1xuICAgIGZ1bmN0aW9uIGxydU1lbW9pemUoZikge1xuICAgICAgdmFyIGNhY2hlID0gW107XG4gICAgICByZXR1cm4gZnVuY3Rpb24oaW5wdXQpIHtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBjYWNoZS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGlmIChjYWNoZVtpXS5pbnB1dCA9PT0gaW5wdXQpIHtcbiAgICAgICAgICAgIHZhciB0ZW1wID0gY2FjaGVbMF07XG4gICAgICAgICAgICBjYWNoZVswXSA9IGNhY2hlW2ldO1xuICAgICAgICAgICAgY2FjaGVbaV0gPSB0ZW1wO1xuICAgICAgICAgICAgcmV0dXJuIGNhY2hlWzBdLnJlc3VsdDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHJlc3VsdCA9IGYoaW5wdXQpO1xuICAgICAgICBjYWNoZS51bnNoaWZ0KHtcbiAgICAgICAgICBpbnB1dCxcbiAgICAgICAgICByZXN1bHRcbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChjYWNoZS5sZW5ndGggPiBNQVhfQ0FDSEVEX0lOUFVUUykge1xuICAgICAgICAgIGNhY2hlLnBvcCgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICB9O1xuICAgIH1cbiAgICB2YXIgbm9ybWFsaXplID0gbHJ1TWVtb2l6ZShmdW5jdGlvbiBub3JtYWxpemUyKGFQYXRoKSB7XG4gICAgICB2YXIgcGF0aCA9IGFQYXRoO1xuICAgICAgdmFyIHVybCA9IHVybFBhcnNlKGFQYXRoKTtcbiAgICAgIGlmICh1cmwpIHtcbiAgICAgICAgaWYgKCF1cmwucGF0aCkge1xuICAgICAgICAgIHJldHVybiBhUGF0aDtcbiAgICAgICAgfVxuICAgICAgICBwYXRoID0gdXJsLnBhdGg7XG4gICAgICB9XG4gICAgICB2YXIgaXNBYnNvbHV0ZSA9IGV4cG9ydHMuaXNBYnNvbHV0ZShwYXRoKTtcbiAgICAgIHZhciBwYXJ0cyA9IFtdO1xuICAgICAgdmFyIHN0YXJ0ID0gMDtcbiAgICAgIHZhciBpID0gMDtcbiAgICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICAgIHN0YXJ0ID0gaTtcbiAgICAgICAgaSA9IHBhdGguaW5kZXhPZihcIi9cIiwgc3RhcnQpO1xuICAgICAgICBpZiAoaSA9PT0gLTEpIHtcbiAgICAgICAgICBwYXJ0cy5wdXNoKHBhdGguc2xpY2Uoc3RhcnQpKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBwYXJ0cy5wdXNoKHBhdGguc2xpY2Uoc3RhcnQsIGkpKTtcbiAgICAgICAgICB3aGlsZSAoaSA8IHBhdGgubGVuZ3RoICYmIHBhdGhbaV0gPT09IFwiL1wiKSB7XG4gICAgICAgICAgICBpKys7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBmb3IgKHZhciBwYXJ0LCB1cCA9IDAsIGkgPSBwYXJ0cy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgICBwYXJ0ID0gcGFydHNbaV07XG4gICAgICAgIGlmIChwYXJ0ID09PSBcIi5cIikge1xuICAgICAgICAgIHBhcnRzLnNwbGljZShpLCAxKTtcbiAgICAgICAgfSBlbHNlIGlmIChwYXJ0ID09PSBcIi4uXCIpIHtcbiAgICAgICAgICB1cCsrO1xuICAgICAgICB9IGVsc2UgaWYgKHVwID4gMCkge1xuICAgICAgICAgIGlmIChwYXJ0ID09PSBcIlwiKSB7XG4gICAgICAgICAgICBwYXJ0cy5zcGxpY2UoaSArIDEsIHVwKTtcbiAgICAgICAgICAgIHVwID0gMDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcGFydHMuc3BsaWNlKGksIDIpO1xuICAgICAgICAgICAgdXAtLTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHBhdGggPSBwYXJ0cy5qb2luKFwiL1wiKTtcbiAgICAgIGlmIChwYXRoID09PSBcIlwiKSB7XG4gICAgICAgIHBhdGggPSBpc0Fic29sdXRlID8gXCIvXCIgOiBcIi5cIjtcbiAgICAgIH1cbiAgICAgIGlmICh1cmwpIHtcbiAgICAgICAgdXJsLnBhdGggPSBwYXRoO1xuICAgICAgICByZXR1cm4gdXJsR2VuZXJhdGUodXJsKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBwYXRoO1xuICAgIH0pO1xuICAgIGV4cG9ydHMubm9ybWFsaXplID0gbm9ybWFsaXplO1xuICAgIGZ1bmN0aW9uIGpvaW4oYVJvb3QsIGFQYXRoKSB7XG4gICAgICBpZiAoYVJvb3QgPT09IFwiXCIpIHtcbiAgICAgICAgYVJvb3QgPSBcIi5cIjtcbiAgICAgIH1cbiAgICAgIGlmIChhUGF0aCA9PT0gXCJcIikge1xuICAgICAgICBhUGF0aCA9IFwiLlwiO1xuICAgICAgfVxuICAgICAgdmFyIGFQYXRoVXJsID0gdXJsUGFyc2UoYVBhdGgpO1xuICAgICAgdmFyIGFSb290VXJsID0gdXJsUGFyc2UoYVJvb3QpO1xuICAgICAgaWYgKGFSb290VXJsKSB7XG4gICAgICAgIGFSb290ID0gYVJvb3RVcmwucGF0aCB8fCBcIi9cIjtcbiAgICAgIH1cbiAgICAgIGlmIChhUGF0aFVybCAmJiAhYVBhdGhVcmwuc2NoZW1lKSB7XG4gICAgICAgIGlmIChhUm9vdFVybCkge1xuICAgICAgICAgIGFQYXRoVXJsLnNjaGVtZSA9IGFSb290VXJsLnNjaGVtZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdXJsR2VuZXJhdGUoYVBhdGhVcmwpO1xuICAgICAgfVxuICAgICAgaWYgKGFQYXRoVXJsIHx8IGFQYXRoLm1hdGNoKGRhdGFVcmxSZWdleHApKSB7XG4gICAgICAgIHJldHVybiBhUGF0aDtcbiAgICAgIH1cbiAgICAgIGlmIChhUm9vdFVybCAmJiAhYVJvb3RVcmwuaG9zdCAmJiAhYVJvb3RVcmwucGF0aCkge1xuICAgICAgICBhUm9vdFVybC5ob3N0ID0gYVBhdGg7XG4gICAgICAgIHJldHVybiB1cmxHZW5lcmF0ZShhUm9vdFVybCk7XG4gICAgICB9XG4gICAgICB2YXIgam9pbmVkID0gYVBhdGguY2hhckF0KDApID09PSBcIi9cIiA/IGFQYXRoIDogbm9ybWFsaXplKGFSb290LnJlcGxhY2UoL1xcLyskLywgXCJcIikgKyBcIi9cIiArIGFQYXRoKTtcbiAgICAgIGlmIChhUm9vdFVybCkge1xuICAgICAgICBhUm9vdFVybC5wYXRoID0gam9pbmVkO1xuICAgICAgICByZXR1cm4gdXJsR2VuZXJhdGUoYVJvb3RVcmwpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGpvaW5lZDtcbiAgICB9XG4gICAgZXhwb3J0cy5qb2luID0gam9pbjtcbiAgICBleHBvcnRzLmlzQWJzb2x1dGUgPSBmdW5jdGlvbihhUGF0aCkge1xuICAgICAgcmV0dXJuIGFQYXRoLmNoYXJBdCgwKSA9PT0gXCIvXCIgfHwgdXJsUmVnZXhwLnRlc3QoYVBhdGgpO1xuICAgIH07XG4gICAgZnVuY3Rpb24gcmVsYXRpdmUoYVJvb3QsIGFQYXRoKSB7XG4gICAgICBpZiAoYVJvb3QgPT09IFwiXCIpIHtcbiAgICAgICAgYVJvb3QgPSBcIi5cIjtcbiAgICAgIH1cbiAgICAgIGFSb290ID0gYVJvb3QucmVwbGFjZSgvXFwvJC8sIFwiXCIpO1xuICAgICAgdmFyIGxldmVsID0gMDtcbiAgICAgIHdoaWxlIChhUGF0aC5pbmRleE9mKGFSb290ICsgXCIvXCIpICE9PSAwKSB7XG4gICAgICAgIHZhciBpbmRleCA9IGFSb290Lmxhc3RJbmRleE9mKFwiL1wiKTtcbiAgICAgICAgaWYgKGluZGV4IDwgMCkge1xuICAgICAgICAgIHJldHVybiBhUGF0aDtcbiAgICAgICAgfVxuICAgICAgICBhUm9vdCA9IGFSb290LnNsaWNlKDAsIGluZGV4KTtcbiAgICAgICAgaWYgKGFSb290Lm1hdGNoKC9eKFteXFwvXSs6XFwvKT9cXC8qJC8pKSB7XG4gICAgICAgICAgcmV0dXJuIGFQYXRoO1xuICAgICAgICB9XG4gICAgICAgICsrbGV2ZWw7XG4gICAgICB9XG4gICAgICByZXR1cm4gQXJyYXkobGV2ZWwgKyAxKS5qb2luKFwiLi4vXCIpICsgYVBhdGguc3Vic3RyKGFSb290Lmxlbmd0aCArIDEpO1xuICAgIH1cbiAgICBleHBvcnRzLnJlbGF0aXZlID0gcmVsYXRpdmU7XG4gICAgdmFyIHN1cHBvcnRzTnVsbFByb3RvID0gZnVuY3Rpb24oKSB7XG4gICAgICB2YXIgb2JqID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICByZXR1cm4gIShcIl9fcHJvdG9fX1wiIGluIG9iaik7XG4gICAgfSgpO1xuICAgIGZ1bmN0aW9uIGlkZW50aXR5KHMpIHtcbiAgICAgIHJldHVybiBzO1xuICAgIH1cbiAgICBmdW5jdGlvbiB0b1NldFN0cmluZyhhU3RyKSB7XG4gICAgICBpZiAoaXNQcm90b1N0cmluZyhhU3RyKSkge1xuICAgICAgICByZXR1cm4gXCIkXCIgKyBhU3RyO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGFTdHI7XG4gICAgfVxuICAgIGV4cG9ydHMudG9TZXRTdHJpbmcgPSBzdXBwb3J0c051bGxQcm90byA/IGlkZW50aXR5IDogdG9TZXRTdHJpbmc7XG4gICAgZnVuY3Rpb24gZnJvbVNldFN0cmluZyhhU3RyKSB7XG4gICAgICBpZiAoaXNQcm90b1N0cmluZyhhU3RyKSkge1xuICAgICAgICByZXR1cm4gYVN0ci5zbGljZSgxKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBhU3RyO1xuICAgIH1cbiAgICBleHBvcnRzLmZyb21TZXRTdHJpbmcgPSBzdXBwb3J0c051bGxQcm90byA/IGlkZW50aXR5IDogZnJvbVNldFN0cmluZztcbiAgICBmdW5jdGlvbiBpc1Byb3RvU3RyaW5nKHMpIHtcbiAgICAgIGlmICghcykge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICB2YXIgbGVuZ3RoID0gcy5sZW5ndGg7XG4gICAgICBpZiAobGVuZ3RoIDwgOSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBpZiAocy5jaGFyQ29kZUF0KGxlbmd0aCAtIDEpICE9PSA5NSB8fCBzLmNoYXJDb2RlQXQobGVuZ3RoIC0gMikgIT09IDk1IHx8IHMuY2hhckNvZGVBdChsZW5ndGggLSAzKSAhPT0gMTExIHx8IHMuY2hhckNvZGVBdChsZW5ndGggLSA0KSAhPT0gMTE2IHx8IHMuY2hhckNvZGVBdChsZW5ndGggLSA1KSAhPT0gMTExIHx8IHMuY2hhckNvZGVBdChsZW5ndGggLSA2KSAhPT0gMTE0IHx8IHMuY2hhckNvZGVBdChsZW5ndGggLSA3KSAhPT0gMTEyIHx8IHMuY2hhckNvZGVBdChsZW5ndGggLSA4KSAhPT0gOTUgfHwgcy5jaGFyQ29kZUF0KGxlbmd0aCAtIDkpICE9PSA5NSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBmb3IgKHZhciBpID0gbGVuZ3RoIC0gMTA7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgIGlmIChzLmNoYXJDb2RlQXQoaSkgIT09IDM2KSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gY29tcGFyZUJ5T3JpZ2luYWxQb3NpdGlvbnMobWFwcGluZ0EsIG1hcHBpbmdCLCBvbmx5Q29tcGFyZU9yaWdpbmFsKSB7XG4gICAgICB2YXIgY21wID0gc3RyY21wKG1hcHBpbmdBLnNvdXJjZSwgbWFwcGluZ0Iuc291cmNlKTtcbiAgICAgIGlmIChjbXAgIT09IDApIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIGNtcCA9IG1hcHBpbmdBLm9yaWdpbmFsTGluZSAtIG1hcHBpbmdCLm9yaWdpbmFsTGluZTtcbiAgICAgIGlmIChjbXAgIT09IDApIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIGNtcCA9IG1hcHBpbmdBLm9yaWdpbmFsQ29sdW1uIC0gbWFwcGluZ0Iub3JpZ2luYWxDb2x1bW47XG4gICAgICBpZiAoY21wICE9PSAwIHx8IG9ubHlDb21wYXJlT3JpZ2luYWwpIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIGNtcCA9IG1hcHBpbmdBLmdlbmVyYXRlZENvbHVtbiAtIG1hcHBpbmdCLmdlbmVyYXRlZENvbHVtbjtcbiAgICAgIGlmIChjbXAgIT09IDApIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIGNtcCA9IG1hcHBpbmdBLmdlbmVyYXRlZExpbmUgLSBtYXBwaW5nQi5nZW5lcmF0ZWRMaW5lO1xuICAgICAgaWYgKGNtcCAhPT0gMCkge1xuICAgICAgICByZXR1cm4gY21wO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHN0cmNtcChtYXBwaW5nQS5uYW1lLCBtYXBwaW5nQi5uYW1lKTtcbiAgICB9XG4gICAgZXhwb3J0cy5jb21wYXJlQnlPcmlnaW5hbFBvc2l0aW9ucyA9IGNvbXBhcmVCeU9yaWdpbmFsUG9zaXRpb25zO1xuICAgIGZ1bmN0aW9uIGNvbXBhcmVCeU9yaWdpbmFsUG9zaXRpb25zTm9Tb3VyY2UobWFwcGluZ0EsIG1hcHBpbmdCLCBvbmx5Q29tcGFyZU9yaWdpbmFsKSB7XG4gICAgICB2YXIgY21wO1xuICAgICAgY21wID0gbWFwcGluZ0Eub3JpZ2luYWxMaW5lIC0gbWFwcGluZ0Iub3JpZ2luYWxMaW5lO1xuICAgICAgaWYgKGNtcCAhPT0gMCkge1xuICAgICAgICByZXR1cm4gY21wO1xuICAgICAgfVxuICAgICAgY21wID0gbWFwcGluZ0Eub3JpZ2luYWxDb2x1bW4gLSBtYXBwaW5nQi5vcmlnaW5hbENvbHVtbjtcbiAgICAgIGlmIChjbXAgIT09IDAgfHwgb25seUNvbXBhcmVPcmlnaW5hbCkge1xuICAgICAgICByZXR1cm4gY21wO1xuICAgICAgfVxuICAgICAgY21wID0gbWFwcGluZ0EuZ2VuZXJhdGVkQ29sdW1uIC0gbWFwcGluZ0IuZ2VuZXJhdGVkQ29sdW1uO1xuICAgICAgaWYgKGNtcCAhPT0gMCkge1xuICAgICAgICByZXR1cm4gY21wO1xuICAgICAgfVxuICAgICAgY21wID0gbWFwcGluZ0EuZ2VuZXJhdGVkTGluZSAtIG1hcHBpbmdCLmdlbmVyYXRlZExpbmU7XG4gICAgICBpZiAoY21wICE9PSAwKSB7XG4gICAgICAgIHJldHVybiBjbXA7XG4gICAgICB9XG4gICAgICByZXR1cm4gc3RyY21wKG1hcHBpbmdBLm5hbWUsIG1hcHBpbmdCLm5hbWUpO1xuICAgIH1cbiAgICBleHBvcnRzLmNvbXBhcmVCeU9yaWdpbmFsUG9zaXRpb25zTm9Tb3VyY2UgPSBjb21wYXJlQnlPcmlnaW5hbFBvc2l0aW9uc05vU291cmNlO1xuICAgIGZ1bmN0aW9uIGNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0RlZmxhdGVkKG1hcHBpbmdBLCBtYXBwaW5nQiwgb25seUNvbXBhcmVHZW5lcmF0ZWQpIHtcbiAgICAgIHZhciBjbXAgPSBtYXBwaW5nQS5nZW5lcmF0ZWRMaW5lIC0gbWFwcGluZ0IuZ2VuZXJhdGVkTGluZTtcbiAgICAgIGlmIChjbXAgIT09IDApIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIGNtcCA9IG1hcHBpbmdBLmdlbmVyYXRlZENvbHVtbiAtIG1hcHBpbmdCLmdlbmVyYXRlZENvbHVtbjtcbiAgICAgIGlmIChjbXAgIT09IDAgfHwgb25seUNvbXBhcmVHZW5lcmF0ZWQpIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIGNtcCA9IHN0cmNtcChtYXBwaW5nQS5zb3VyY2UsIG1hcHBpbmdCLnNvdXJjZSk7XG4gICAgICBpZiAoY21wICE9PSAwKSB7XG4gICAgICAgIHJldHVybiBjbXA7XG4gICAgICB9XG4gICAgICBjbXAgPSBtYXBwaW5nQS5vcmlnaW5hbExpbmUgLSBtYXBwaW5nQi5vcmlnaW5hbExpbmU7XG4gICAgICBpZiAoY21wICE9PSAwKSB7XG4gICAgICAgIHJldHVybiBjbXA7XG4gICAgICB9XG4gICAgICBjbXAgPSBtYXBwaW5nQS5vcmlnaW5hbENvbHVtbiAtIG1hcHBpbmdCLm9yaWdpbmFsQ29sdW1uO1xuICAgICAgaWYgKGNtcCAhPT0gMCkge1xuICAgICAgICByZXR1cm4gY21wO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHN0cmNtcChtYXBwaW5nQS5uYW1lLCBtYXBwaW5nQi5uYW1lKTtcbiAgICB9XG4gICAgZXhwb3J0cy5jb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNEZWZsYXRlZCA9IGNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0RlZmxhdGVkO1xuICAgIGZ1bmN0aW9uIGNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0RlZmxhdGVkTm9MaW5lKG1hcHBpbmdBLCBtYXBwaW5nQiwgb25seUNvbXBhcmVHZW5lcmF0ZWQpIHtcbiAgICAgIHZhciBjbXAgPSBtYXBwaW5nQS5nZW5lcmF0ZWRDb2x1bW4gLSBtYXBwaW5nQi5nZW5lcmF0ZWRDb2x1bW47XG4gICAgICBpZiAoY21wICE9PSAwIHx8IG9ubHlDb21wYXJlR2VuZXJhdGVkKSB7XG4gICAgICAgIHJldHVybiBjbXA7XG4gICAgICB9XG4gICAgICBjbXAgPSBzdHJjbXAobWFwcGluZ0Euc291cmNlLCBtYXBwaW5nQi5zb3VyY2UpO1xuICAgICAgaWYgKGNtcCAhPT0gMCkge1xuICAgICAgICByZXR1cm4gY21wO1xuICAgICAgfVxuICAgICAgY21wID0gbWFwcGluZ0Eub3JpZ2luYWxMaW5lIC0gbWFwcGluZ0Iub3JpZ2luYWxMaW5lO1xuICAgICAgaWYgKGNtcCAhPT0gMCkge1xuICAgICAgICByZXR1cm4gY21wO1xuICAgICAgfVxuICAgICAgY21wID0gbWFwcGluZ0Eub3JpZ2luYWxDb2x1bW4gLSBtYXBwaW5nQi5vcmlnaW5hbENvbHVtbjtcbiAgICAgIGlmIChjbXAgIT09IDApIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzdHJjbXAobWFwcGluZ0EubmFtZSwgbWFwcGluZ0IubmFtZSk7XG4gICAgfVxuICAgIGV4cG9ydHMuY29tcGFyZUJ5R2VuZXJhdGVkUG9zaXRpb25zRGVmbGF0ZWROb0xpbmUgPSBjb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNEZWZsYXRlZE5vTGluZTtcbiAgICBmdW5jdGlvbiBzdHJjbXAoYVN0cjEsIGFTdHIyKSB7XG4gICAgICBpZiAoYVN0cjEgPT09IGFTdHIyKSB7XG4gICAgICAgIHJldHVybiAwO1xuICAgICAgfVxuICAgICAgaWYgKGFTdHIxID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiAxO1xuICAgICAgfVxuICAgICAgaWYgKGFTdHIyID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiAtMTtcbiAgICAgIH1cbiAgICAgIGlmIChhU3RyMSA+IGFTdHIyKSB7XG4gICAgICAgIHJldHVybiAxO1xuICAgICAgfVxuICAgICAgcmV0dXJuIC0xO1xuICAgIH1cbiAgICBmdW5jdGlvbiBjb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNJbmZsYXRlZChtYXBwaW5nQSwgbWFwcGluZ0IpIHtcbiAgICAgIHZhciBjbXAgPSBtYXBwaW5nQS5nZW5lcmF0ZWRMaW5lIC0gbWFwcGluZ0IuZ2VuZXJhdGVkTGluZTtcbiAgICAgIGlmIChjbXAgIT09IDApIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIGNtcCA9IG1hcHBpbmdBLmdlbmVyYXRlZENvbHVtbiAtIG1hcHBpbmdCLmdlbmVyYXRlZENvbHVtbjtcbiAgICAgIGlmIChjbXAgIT09IDApIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIGNtcCA9IHN0cmNtcChtYXBwaW5nQS5zb3VyY2UsIG1hcHBpbmdCLnNvdXJjZSk7XG4gICAgICBpZiAoY21wICE9PSAwKSB7XG4gICAgICAgIHJldHVybiBjbXA7XG4gICAgICB9XG4gICAgICBjbXAgPSBtYXBwaW5nQS5vcmlnaW5hbExpbmUgLSBtYXBwaW5nQi5vcmlnaW5hbExpbmU7XG4gICAgICBpZiAoY21wICE9PSAwKSB7XG4gICAgICAgIHJldHVybiBjbXA7XG4gICAgICB9XG4gICAgICBjbXAgPSBtYXBwaW5nQS5vcmlnaW5hbENvbHVtbiAtIG1hcHBpbmdCLm9yaWdpbmFsQ29sdW1uO1xuICAgICAgaWYgKGNtcCAhPT0gMCkge1xuICAgICAgICByZXR1cm4gY21wO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHN0cmNtcChtYXBwaW5nQS5uYW1lLCBtYXBwaW5nQi5uYW1lKTtcbiAgICB9XG4gICAgZXhwb3J0cy5jb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNJbmZsYXRlZCA9IGNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0luZmxhdGVkO1xuICAgIGZ1bmN0aW9uIHBhcnNlU291cmNlTWFwSW5wdXQoc3RyKSB7XG4gICAgICByZXR1cm4gSlNPTi5wYXJzZShzdHIucmVwbGFjZSgvXlxcKV19J1teXFxuXSpcXG4vLCBcIlwiKSk7XG4gICAgfVxuICAgIGV4cG9ydHMucGFyc2VTb3VyY2VNYXBJbnB1dCA9IHBhcnNlU291cmNlTWFwSW5wdXQ7XG4gICAgZnVuY3Rpb24gY29tcHV0ZVNvdXJjZVVSTChzb3VyY2VSb290LCBzb3VyY2VVUkwsIHNvdXJjZU1hcFVSTCkge1xuICAgICAgc291cmNlVVJMID0gc291cmNlVVJMIHx8IFwiXCI7XG4gICAgICBpZiAoc291cmNlUm9vdCkge1xuICAgICAgICBpZiAoc291cmNlUm9vdFtzb3VyY2VSb290Lmxlbmd0aCAtIDFdICE9PSBcIi9cIiAmJiBzb3VyY2VVUkxbMF0gIT09IFwiL1wiKSB7XG4gICAgICAgICAgc291cmNlUm9vdCArPSBcIi9cIjtcbiAgICAgICAgfVxuICAgICAgICBzb3VyY2VVUkwgPSBzb3VyY2VSb290ICsgc291cmNlVVJMO1xuICAgICAgfVxuICAgICAgaWYgKHNvdXJjZU1hcFVSTCkge1xuICAgICAgICB2YXIgcGFyc2VkID0gdXJsUGFyc2Uoc291cmNlTWFwVVJMKTtcbiAgICAgICAgaWYgKCFwYXJzZWQpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJzb3VyY2VNYXBVUkwgY291bGQgbm90IGJlIHBhcnNlZFwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocGFyc2VkLnBhdGgpIHtcbiAgICAgICAgICB2YXIgaW5kZXggPSBwYXJzZWQucGF0aC5sYXN0SW5kZXhPZihcIi9cIik7XG4gICAgICAgICAgaWYgKGluZGV4ID49IDApIHtcbiAgICAgICAgICAgIHBhcnNlZC5wYXRoID0gcGFyc2VkLnBhdGguc3Vic3RyaW5nKDAsIGluZGV4ICsgMSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHNvdXJjZVVSTCA9IGpvaW4odXJsR2VuZXJhdGUocGFyc2VkKSwgc291cmNlVVJMKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBub3JtYWxpemUoc291cmNlVVJMKTtcbiAgICB9XG4gICAgZXhwb3J0cy5jb21wdXRlU291cmNlVVJMID0gY29tcHV0ZVNvdXJjZVVSTDtcbiAgfVxufSk7XG5cbi8vIG5vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi9hcnJheS1zZXQuanNcbnZhciByZXF1aXJlX2FycmF5X3NldCA9IF9fY29tbW9uSlMoe1xuICBcIm5vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi9hcnJheS1zZXQuanNcIihleHBvcnRzKSB7XG4gICAgdmFyIHV0aWwgPSByZXF1aXJlX3V0aWwoKTtcbiAgICB2YXIgaGFzID0gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eTtcbiAgICB2YXIgaGFzTmF0aXZlTWFwID0gdHlwZW9mIE1hcCAhPT0gXCJ1bmRlZmluZWRcIjtcbiAgICBmdW5jdGlvbiBBcnJheVNldCgpIHtcbiAgICAgIHRoaXMuX2FycmF5ID0gW107XG4gICAgICB0aGlzLl9zZXQgPSBoYXNOYXRpdmVNYXAgPyAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpIDogLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgfVxuICAgIEFycmF5U2V0LmZyb21BcnJheSA9IGZ1bmN0aW9uIEFycmF5U2V0X2Zyb21BcnJheShhQXJyYXksIGFBbGxvd0R1cGxpY2F0ZXMpIHtcbiAgICAgIHZhciBzZXQgPSBuZXcgQXJyYXlTZXQoKTtcbiAgICAgIGZvciAodmFyIGkgPSAwLCBsZW4gPSBhQXJyYXkubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgc2V0LmFkZChhQXJyYXlbaV0sIGFBbGxvd0R1cGxpY2F0ZXMpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHNldDtcbiAgICB9O1xuICAgIEFycmF5U2V0LnByb3RvdHlwZS5zaXplID0gZnVuY3Rpb24gQXJyYXlTZXRfc2l6ZSgpIHtcbiAgICAgIHJldHVybiBoYXNOYXRpdmVNYXAgPyB0aGlzLl9zZXQuc2l6ZSA6IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHRoaXMuX3NldCkubGVuZ3RoO1xuICAgIH07XG4gICAgQXJyYXlTZXQucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uIEFycmF5U2V0X2FkZChhU3RyLCBhQWxsb3dEdXBsaWNhdGVzKSB7XG4gICAgICB2YXIgc1N0ciA9IGhhc05hdGl2ZU1hcCA/IGFTdHIgOiB1dGlsLnRvU2V0U3RyaW5nKGFTdHIpO1xuICAgICAgdmFyIGlzRHVwbGljYXRlID0gaGFzTmF0aXZlTWFwID8gdGhpcy5oYXMoYVN0cikgOiBoYXMuY2FsbCh0aGlzLl9zZXQsIHNTdHIpO1xuICAgICAgdmFyIGlkeCA9IHRoaXMuX2FycmF5Lmxlbmd0aDtcbiAgICAgIGlmICghaXNEdXBsaWNhdGUgfHwgYUFsbG93RHVwbGljYXRlcykge1xuICAgICAgICB0aGlzLl9hcnJheS5wdXNoKGFTdHIpO1xuICAgICAgfVxuICAgICAgaWYgKCFpc0R1cGxpY2F0ZSkge1xuICAgICAgICBpZiAoaGFzTmF0aXZlTWFwKSB7XG4gICAgICAgICAgdGhpcy5fc2V0LnNldChhU3RyLCBpZHgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRoaXMuX3NldFtzU3RyXSA9IGlkeDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgQXJyYXlTZXQucHJvdG90eXBlLmhhcyA9IGZ1bmN0aW9uIEFycmF5U2V0X2hhcyhhU3RyKSB7XG4gICAgICBpZiAoaGFzTmF0aXZlTWFwKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9zZXQuaGFzKGFTdHIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdmFyIHNTdHIgPSB1dGlsLnRvU2V0U3RyaW5nKGFTdHIpO1xuICAgICAgICByZXR1cm4gaGFzLmNhbGwodGhpcy5fc2V0LCBzU3RyKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIEFycmF5U2V0LnByb3RvdHlwZS5pbmRleE9mID0gZnVuY3Rpb24gQXJyYXlTZXRfaW5kZXhPZihhU3RyKSB7XG4gICAgICBpZiAoaGFzTmF0aXZlTWFwKSB7XG4gICAgICAgIHZhciBpZHggPSB0aGlzLl9zZXQuZ2V0KGFTdHIpO1xuICAgICAgICBpZiAoaWR4ID49IDApIHtcbiAgICAgICAgICByZXR1cm4gaWR4O1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2YXIgc1N0ciA9IHV0aWwudG9TZXRTdHJpbmcoYVN0cik7XG4gICAgICAgIGlmIChoYXMuY2FsbCh0aGlzLl9zZXQsIHNTdHIpKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuX3NldFtzU3RyXTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IEVycm9yKCdcIicgKyBhU3RyICsgJ1wiIGlzIG5vdCBpbiB0aGUgc2V0LicpO1xuICAgIH07XG4gICAgQXJyYXlTZXQucHJvdG90eXBlLmF0ID0gZnVuY3Rpb24gQXJyYXlTZXRfYXQoYUlkeCkge1xuICAgICAgaWYgKGFJZHggPj0gMCAmJiBhSWR4IDwgdGhpcy5fYXJyYXkubGVuZ3RoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9hcnJheVthSWR4XTtcbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBFcnJvcihcIk5vIGVsZW1lbnQgaW5kZXhlZCBieSBcIiArIGFJZHgpO1xuICAgIH07XG4gICAgQXJyYXlTZXQucHJvdG90eXBlLnRvQXJyYXkgPSBmdW5jdGlvbiBBcnJheVNldF90b0FycmF5KCkge1xuICAgICAgcmV0dXJuIHRoaXMuX2FycmF5LnNsaWNlKCk7XG4gICAgfTtcbiAgICBleHBvcnRzLkFycmF5U2V0ID0gQXJyYXlTZXQ7XG4gIH1cbn0pO1xuXG4vLyBub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvbWFwcGluZy1saXN0LmpzXG52YXIgcmVxdWlyZV9tYXBwaW5nX2xpc3QgPSBfX2NvbW1vbkpTKHtcbiAgXCJub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvbWFwcGluZy1saXN0LmpzXCIoZXhwb3J0cykge1xuICAgIHZhciB1dGlsID0gcmVxdWlyZV91dGlsKCk7XG4gICAgZnVuY3Rpb24gZ2VuZXJhdGVkUG9zaXRpb25BZnRlcihtYXBwaW5nQSwgbWFwcGluZ0IpIHtcbiAgICAgIHZhciBsaW5lQSA9IG1hcHBpbmdBLmdlbmVyYXRlZExpbmU7XG4gICAgICB2YXIgbGluZUIgPSBtYXBwaW5nQi5nZW5lcmF0ZWRMaW5lO1xuICAgICAgdmFyIGNvbHVtbkEgPSBtYXBwaW5nQS5nZW5lcmF0ZWRDb2x1bW47XG4gICAgICB2YXIgY29sdW1uQiA9IG1hcHBpbmdCLmdlbmVyYXRlZENvbHVtbjtcbiAgICAgIHJldHVybiBsaW5lQiA+IGxpbmVBIHx8IGxpbmVCID09IGxpbmVBICYmIGNvbHVtbkIgPj0gY29sdW1uQSB8fCB1dGlsLmNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0luZmxhdGVkKG1hcHBpbmdBLCBtYXBwaW5nQikgPD0gMDtcbiAgICB9XG4gICAgZnVuY3Rpb24gTWFwcGluZ0xpc3QoKSB7XG4gICAgICB0aGlzLl9hcnJheSA9IFtdO1xuICAgICAgdGhpcy5fc29ydGVkID0gdHJ1ZTtcbiAgICAgIHRoaXMuX2xhc3QgPSB7IGdlbmVyYXRlZExpbmU6IC0xLCBnZW5lcmF0ZWRDb2x1bW46IDAgfTtcbiAgICB9XG4gICAgTWFwcGluZ0xpc3QucHJvdG90eXBlLnVuc29ydGVkRm9yRWFjaCA9IGZ1bmN0aW9uIE1hcHBpbmdMaXN0X2ZvckVhY2goYUNhbGxiYWNrLCBhVGhpc0FyZykge1xuICAgICAgdGhpcy5fYXJyYXkuZm9yRWFjaChhQ2FsbGJhY2ssIGFUaGlzQXJnKTtcbiAgICB9O1xuICAgIE1hcHBpbmdMaXN0LnByb3RvdHlwZS5hZGQgPSBmdW5jdGlvbiBNYXBwaW5nTGlzdF9hZGQoYU1hcHBpbmcpIHtcbiAgICAgIGlmIChnZW5lcmF0ZWRQb3NpdGlvbkFmdGVyKHRoaXMuX2xhc3QsIGFNYXBwaW5nKSkge1xuICAgICAgICB0aGlzLl9sYXN0ID0gYU1hcHBpbmc7XG4gICAgICAgIHRoaXMuX2FycmF5LnB1c2goYU1hcHBpbmcpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5fc29ydGVkID0gZmFsc2U7XG4gICAgICAgIHRoaXMuX2FycmF5LnB1c2goYU1hcHBpbmcpO1xuICAgICAgfVxuICAgIH07XG4gICAgTWFwcGluZ0xpc3QucHJvdG90eXBlLnRvQXJyYXkgPSBmdW5jdGlvbiBNYXBwaW5nTGlzdF90b0FycmF5KCkge1xuICAgICAgaWYgKCF0aGlzLl9zb3J0ZWQpIHtcbiAgICAgICAgdGhpcy5fYXJyYXkuc29ydCh1dGlsLmNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0luZmxhdGVkKTtcbiAgICAgICAgdGhpcy5fc29ydGVkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzLl9hcnJheTtcbiAgICB9O1xuICAgIGV4cG9ydHMuTWFwcGluZ0xpc3QgPSBNYXBwaW5nTGlzdDtcbiAgfVxufSk7XG5cbi8vIG5vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi9zb3VyY2UtbWFwLWdlbmVyYXRvci5qc1xudmFyIHJlcXVpcmVfc291cmNlX21hcF9nZW5lcmF0b3IgPSBfX2NvbW1vbkpTKHtcbiAgXCJub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvc291cmNlLW1hcC1nZW5lcmF0b3IuanNcIihleHBvcnRzKSB7XG4gICAgdmFyIGJhc2U2NFZMUSA9IHJlcXVpcmVfYmFzZTY0X3ZscSgpO1xuICAgIHZhciB1dGlsID0gcmVxdWlyZV91dGlsKCk7XG4gICAgdmFyIEFycmF5U2V0ID0gcmVxdWlyZV9hcnJheV9zZXQoKS5BcnJheVNldDtcbiAgICB2YXIgTWFwcGluZ0xpc3QgPSByZXF1aXJlX21hcHBpbmdfbGlzdCgpLk1hcHBpbmdMaXN0O1xuICAgIGZ1bmN0aW9uIFNvdXJjZU1hcEdlbmVyYXRvcihhQXJncykge1xuICAgICAgaWYgKCFhQXJncykge1xuICAgICAgICBhQXJncyA9IHt9O1xuICAgICAgfVxuICAgICAgdGhpcy5fZmlsZSA9IHV0aWwuZ2V0QXJnKGFBcmdzLCBcImZpbGVcIiwgbnVsbCk7XG4gICAgICB0aGlzLl9zb3VyY2VSb290ID0gdXRpbC5nZXRBcmcoYUFyZ3MsIFwic291cmNlUm9vdFwiLCBudWxsKTtcbiAgICAgIHRoaXMuX3NraXBWYWxpZGF0aW9uID0gdXRpbC5nZXRBcmcoYUFyZ3MsIFwic2tpcFZhbGlkYXRpb25cIiwgZmFsc2UpO1xuICAgICAgdGhpcy5fc291cmNlcyA9IG5ldyBBcnJheVNldCgpO1xuICAgICAgdGhpcy5fbmFtZXMgPSBuZXcgQXJyYXlTZXQoKTtcbiAgICAgIHRoaXMuX21hcHBpbmdzID0gbmV3IE1hcHBpbmdMaXN0KCk7XG4gICAgICB0aGlzLl9zb3VyY2VzQ29udGVudHMgPSBudWxsO1xuICAgIH1cbiAgICBTb3VyY2VNYXBHZW5lcmF0b3IucHJvdG90eXBlLl92ZXJzaW9uID0gMztcbiAgICBTb3VyY2VNYXBHZW5lcmF0b3IuZnJvbVNvdXJjZU1hcCA9IGZ1bmN0aW9uIFNvdXJjZU1hcEdlbmVyYXRvcl9mcm9tU291cmNlTWFwKGFTb3VyY2VNYXBDb25zdW1lcikge1xuICAgICAgdmFyIHNvdXJjZVJvb3QgPSBhU291cmNlTWFwQ29uc3VtZXIuc291cmNlUm9vdDtcbiAgICAgIHZhciBnZW5lcmF0b3IgPSBuZXcgU291cmNlTWFwR2VuZXJhdG9yKHtcbiAgICAgICAgZmlsZTogYVNvdXJjZU1hcENvbnN1bWVyLmZpbGUsXG4gICAgICAgIHNvdXJjZVJvb3RcbiAgICAgIH0pO1xuICAgICAgYVNvdXJjZU1hcENvbnN1bWVyLmVhY2hNYXBwaW5nKGZ1bmN0aW9uKG1hcHBpbmcpIHtcbiAgICAgICAgdmFyIG5ld01hcHBpbmcgPSB7XG4gICAgICAgICAgZ2VuZXJhdGVkOiB7XG4gICAgICAgICAgICBsaW5lOiBtYXBwaW5nLmdlbmVyYXRlZExpbmUsXG4gICAgICAgICAgICBjb2x1bW46IG1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uXG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBpZiAobWFwcGluZy5zb3VyY2UgIT0gbnVsbCkge1xuICAgICAgICAgIG5ld01hcHBpbmcuc291cmNlID0gbWFwcGluZy5zb3VyY2U7XG4gICAgICAgICAgaWYgKHNvdXJjZVJvb3QgIT0gbnVsbCkge1xuICAgICAgICAgICAgbmV3TWFwcGluZy5zb3VyY2UgPSB1dGlsLnJlbGF0aXZlKHNvdXJjZVJvb3QsIG5ld01hcHBpbmcuc291cmNlKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgbmV3TWFwcGluZy5vcmlnaW5hbCA9IHtcbiAgICAgICAgICAgIGxpbmU6IG1hcHBpbmcub3JpZ2luYWxMaW5lLFxuICAgICAgICAgICAgY29sdW1uOiBtYXBwaW5nLm9yaWdpbmFsQ29sdW1uXG4gICAgICAgICAgfTtcbiAgICAgICAgICBpZiAobWFwcGluZy5uYW1lICE9IG51bGwpIHtcbiAgICAgICAgICAgIG5ld01hcHBpbmcubmFtZSA9IG1hcHBpbmcubmFtZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZ2VuZXJhdG9yLmFkZE1hcHBpbmcobmV3TWFwcGluZyk7XG4gICAgICB9KTtcbiAgICAgIGFTb3VyY2VNYXBDb25zdW1lci5zb3VyY2VzLmZvckVhY2goZnVuY3Rpb24oc291cmNlRmlsZSkge1xuICAgICAgICB2YXIgc291cmNlUmVsYXRpdmUgPSBzb3VyY2VGaWxlO1xuICAgICAgICBpZiAoc291cmNlUm9vdCAhPT0gbnVsbCkge1xuICAgICAgICAgIHNvdXJjZVJlbGF0aXZlID0gdXRpbC5yZWxhdGl2ZShzb3VyY2VSb290LCBzb3VyY2VGaWxlKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWdlbmVyYXRvci5fc291cmNlcy5oYXMoc291cmNlUmVsYXRpdmUpKSB7XG4gICAgICAgICAgZ2VuZXJhdG9yLl9zb3VyY2VzLmFkZChzb3VyY2VSZWxhdGl2ZSk7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGNvbnRlbnQgPSBhU291cmNlTWFwQ29uc3VtZXIuc291cmNlQ29udGVudEZvcihzb3VyY2VGaWxlKTtcbiAgICAgICAgaWYgKGNvbnRlbnQgIT0gbnVsbCkge1xuICAgICAgICAgIGdlbmVyYXRvci5zZXRTb3VyY2VDb250ZW50KHNvdXJjZUZpbGUsIGNvbnRlbnQpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHJldHVybiBnZW5lcmF0b3I7XG4gICAgfTtcbiAgICBTb3VyY2VNYXBHZW5lcmF0b3IucHJvdG90eXBlLmFkZE1hcHBpbmcgPSBmdW5jdGlvbiBTb3VyY2VNYXBHZW5lcmF0b3JfYWRkTWFwcGluZyhhQXJncykge1xuICAgICAgdmFyIGdlbmVyYXRlZCA9IHV0aWwuZ2V0QXJnKGFBcmdzLCBcImdlbmVyYXRlZFwiKTtcbiAgICAgIHZhciBvcmlnaW5hbCA9IHV0aWwuZ2V0QXJnKGFBcmdzLCBcIm9yaWdpbmFsXCIsIG51bGwpO1xuICAgICAgdmFyIHNvdXJjZSA9IHV0aWwuZ2V0QXJnKGFBcmdzLCBcInNvdXJjZVwiLCBudWxsKTtcbiAgICAgIHZhciBuYW1lID0gdXRpbC5nZXRBcmcoYUFyZ3MsIFwibmFtZVwiLCBudWxsKTtcbiAgICAgIGlmICghdGhpcy5fc2tpcFZhbGlkYXRpb24pIHtcbiAgICAgICAgdGhpcy5fdmFsaWRhdGVNYXBwaW5nKGdlbmVyYXRlZCwgb3JpZ2luYWwsIHNvdXJjZSwgbmFtZSk7XG4gICAgICB9XG4gICAgICBpZiAoc291cmNlICE9IG51bGwpIHtcbiAgICAgICAgc291cmNlID0gU3RyaW5nKHNvdXJjZSk7XG4gICAgICAgIGlmICghdGhpcy5fc291cmNlcy5oYXMoc291cmNlKSkge1xuICAgICAgICAgIHRoaXMuX3NvdXJjZXMuYWRkKHNvdXJjZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChuYW1lICE9IG51bGwpIHtcbiAgICAgICAgbmFtZSA9IFN0cmluZyhuYW1lKTtcbiAgICAgICAgaWYgKCF0aGlzLl9uYW1lcy5oYXMobmFtZSkpIHtcbiAgICAgICAgICB0aGlzLl9uYW1lcy5hZGQobmFtZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRoaXMuX21hcHBpbmdzLmFkZCh7XG4gICAgICAgIGdlbmVyYXRlZExpbmU6IGdlbmVyYXRlZC5saW5lLFxuICAgICAgICBnZW5lcmF0ZWRDb2x1bW46IGdlbmVyYXRlZC5jb2x1bW4sXG4gICAgICAgIG9yaWdpbmFsTGluZTogb3JpZ2luYWwgIT0gbnVsbCAmJiBvcmlnaW5hbC5saW5lLFxuICAgICAgICBvcmlnaW5hbENvbHVtbjogb3JpZ2luYWwgIT0gbnVsbCAmJiBvcmlnaW5hbC5jb2x1bW4sXG4gICAgICAgIHNvdXJjZSxcbiAgICAgICAgbmFtZVxuICAgICAgfSk7XG4gICAgfTtcbiAgICBTb3VyY2VNYXBHZW5lcmF0b3IucHJvdG90eXBlLnNldFNvdXJjZUNvbnRlbnQgPSBmdW5jdGlvbiBTb3VyY2VNYXBHZW5lcmF0b3Jfc2V0U291cmNlQ29udGVudChhU291cmNlRmlsZSwgYVNvdXJjZUNvbnRlbnQpIHtcbiAgICAgIHZhciBzb3VyY2UgPSBhU291cmNlRmlsZTtcbiAgICAgIGlmICh0aGlzLl9zb3VyY2VSb290ICE9IG51bGwpIHtcbiAgICAgICAgc291cmNlID0gdXRpbC5yZWxhdGl2ZSh0aGlzLl9zb3VyY2VSb290LCBzb3VyY2UpO1xuICAgICAgfVxuICAgICAgaWYgKGFTb3VyY2VDb250ZW50ICE9IG51bGwpIHtcbiAgICAgICAgaWYgKCF0aGlzLl9zb3VyY2VzQ29udGVudHMpIHtcbiAgICAgICAgICB0aGlzLl9zb3VyY2VzQ29udGVudHMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLl9zb3VyY2VzQ29udGVudHNbdXRpbC50b1NldFN0cmluZyhzb3VyY2UpXSA9IGFTb3VyY2VDb250ZW50O1xuICAgICAgfSBlbHNlIGlmICh0aGlzLl9zb3VyY2VzQ29udGVudHMpIHtcbiAgICAgICAgZGVsZXRlIHRoaXMuX3NvdXJjZXNDb250ZW50c1t1dGlsLnRvU2V0U3RyaW5nKHNvdXJjZSldO1xuICAgICAgICBpZiAoT2JqZWN0LmtleXModGhpcy5fc291cmNlc0NvbnRlbnRzKS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICB0aGlzLl9zb3VyY2VzQ29udGVudHMgPSBudWxsO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcbiAgICBTb3VyY2VNYXBHZW5lcmF0b3IucHJvdG90eXBlLmFwcGx5U291cmNlTWFwID0gZnVuY3Rpb24gU291cmNlTWFwR2VuZXJhdG9yX2FwcGx5U291cmNlTWFwKGFTb3VyY2VNYXBDb25zdW1lciwgYVNvdXJjZUZpbGUsIGFTb3VyY2VNYXBQYXRoKSB7XG4gICAgICB2YXIgc291cmNlRmlsZSA9IGFTb3VyY2VGaWxlO1xuICAgICAgaWYgKGFTb3VyY2VGaWxlID09IG51bGwpIHtcbiAgICAgICAgaWYgKGFTb3VyY2VNYXBDb25zdW1lci5maWxlID09IG51bGwpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgICBgU291cmNlTWFwR2VuZXJhdG9yLnByb3RvdHlwZS5hcHBseVNvdXJjZU1hcCByZXF1aXJlcyBlaXRoZXIgYW4gZXhwbGljaXQgc291cmNlIGZpbGUsIG9yIHRoZSBzb3VyY2UgbWFwJ3MgXCJmaWxlXCIgcHJvcGVydHkuIEJvdGggd2VyZSBvbWl0dGVkLmBcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIHNvdXJjZUZpbGUgPSBhU291cmNlTWFwQ29uc3VtZXIuZmlsZTtcbiAgICAgIH1cbiAgICAgIHZhciBzb3VyY2VSb290ID0gdGhpcy5fc291cmNlUm9vdDtcbiAgICAgIGlmIChzb3VyY2VSb290ICE9IG51bGwpIHtcbiAgICAgICAgc291cmNlRmlsZSA9IHV0aWwucmVsYXRpdmUoc291cmNlUm9vdCwgc291cmNlRmlsZSk7XG4gICAgICB9XG4gICAgICB2YXIgbmV3U291cmNlcyA9IG5ldyBBcnJheVNldCgpO1xuICAgICAgdmFyIG5ld05hbWVzID0gbmV3IEFycmF5U2V0KCk7XG4gICAgICB0aGlzLl9tYXBwaW5ncy51bnNvcnRlZEZvckVhY2goZnVuY3Rpb24obWFwcGluZykge1xuICAgICAgICBpZiAobWFwcGluZy5zb3VyY2UgPT09IHNvdXJjZUZpbGUgJiYgbWFwcGluZy5vcmlnaW5hbExpbmUgIT0gbnVsbCkge1xuICAgICAgICAgIHZhciBvcmlnaW5hbCA9IGFTb3VyY2VNYXBDb25zdW1lci5vcmlnaW5hbFBvc2l0aW9uRm9yKHtcbiAgICAgICAgICAgIGxpbmU6IG1hcHBpbmcub3JpZ2luYWxMaW5lLFxuICAgICAgICAgICAgY29sdW1uOiBtYXBwaW5nLm9yaWdpbmFsQ29sdW1uXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgaWYgKG9yaWdpbmFsLnNvdXJjZSAhPSBudWxsKSB7XG4gICAgICAgICAgICBtYXBwaW5nLnNvdXJjZSA9IG9yaWdpbmFsLnNvdXJjZTtcbiAgICAgICAgICAgIGlmIChhU291cmNlTWFwUGF0aCAhPSBudWxsKSB7XG4gICAgICAgICAgICAgIG1hcHBpbmcuc291cmNlID0gdXRpbC5qb2luKGFTb3VyY2VNYXBQYXRoLCBtYXBwaW5nLnNvdXJjZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoc291cmNlUm9vdCAhPSBudWxsKSB7XG4gICAgICAgICAgICAgIG1hcHBpbmcuc291cmNlID0gdXRpbC5yZWxhdGl2ZShzb3VyY2VSb290LCBtYXBwaW5nLnNvdXJjZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtYXBwaW5nLm9yaWdpbmFsTGluZSA9IG9yaWdpbmFsLmxpbmU7XG4gICAgICAgICAgICBtYXBwaW5nLm9yaWdpbmFsQ29sdW1uID0gb3JpZ2luYWwuY29sdW1uO1xuICAgICAgICAgICAgaWYgKG9yaWdpbmFsLm5hbWUgIT0gbnVsbCkge1xuICAgICAgICAgICAgICBtYXBwaW5nLm5hbWUgPSBvcmlnaW5hbC5uYW1lO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB2YXIgc291cmNlID0gbWFwcGluZy5zb3VyY2U7XG4gICAgICAgIGlmIChzb3VyY2UgIT0gbnVsbCAmJiAhbmV3U291cmNlcy5oYXMoc291cmNlKSkge1xuICAgICAgICAgIG5ld1NvdXJjZXMuYWRkKHNvdXJjZSk7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIG5hbWUgPSBtYXBwaW5nLm5hbWU7XG4gICAgICAgIGlmIChuYW1lICE9IG51bGwgJiYgIW5ld05hbWVzLmhhcyhuYW1lKSkge1xuICAgICAgICAgIG5ld05hbWVzLmFkZChuYW1lKTtcbiAgICAgICAgfVxuICAgICAgfSwgdGhpcyk7XG4gICAgICB0aGlzLl9zb3VyY2VzID0gbmV3U291cmNlcztcbiAgICAgIHRoaXMuX25hbWVzID0gbmV3TmFtZXM7XG4gICAgICBhU291cmNlTWFwQ29uc3VtZXIuc291cmNlcy5mb3JFYWNoKGZ1bmN0aW9uKHNvdXJjZUZpbGUyKSB7XG4gICAgICAgIHZhciBjb250ZW50ID0gYVNvdXJjZU1hcENvbnN1bWVyLnNvdXJjZUNvbnRlbnRGb3Ioc291cmNlRmlsZTIpO1xuICAgICAgICBpZiAoY29udGVudCAhPSBudWxsKSB7XG4gICAgICAgICAgaWYgKGFTb3VyY2VNYXBQYXRoICE9IG51bGwpIHtcbiAgICAgICAgICAgIHNvdXJjZUZpbGUyID0gdXRpbC5qb2luKGFTb3VyY2VNYXBQYXRoLCBzb3VyY2VGaWxlMik7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChzb3VyY2VSb290ICE9IG51bGwpIHtcbiAgICAgICAgICAgIHNvdXJjZUZpbGUyID0gdXRpbC5yZWxhdGl2ZShzb3VyY2VSb290LCBzb3VyY2VGaWxlMik7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRoaXMuc2V0U291cmNlQ29udGVudChzb3VyY2VGaWxlMiwgY29udGVudCk7XG4gICAgICAgIH1cbiAgICAgIH0sIHRoaXMpO1xuICAgIH07XG4gICAgU291cmNlTWFwR2VuZXJhdG9yLnByb3RvdHlwZS5fdmFsaWRhdGVNYXBwaW5nID0gZnVuY3Rpb24gU291cmNlTWFwR2VuZXJhdG9yX3ZhbGlkYXRlTWFwcGluZyhhR2VuZXJhdGVkLCBhT3JpZ2luYWwsIGFTb3VyY2UsIGFOYW1lKSB7XG4gICAgICBpZiAoYU9yaWdpbmFsICYmIHR5cGVvZiBhT3JpZ2luYWwubGluZSAhPT0gXCJudW1iZXJcIiAmJiB0eXBlb2YgYU9yaWdpbmFsLmNvbHVtbiAhPT0gXCJudW1iZXJcIikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgXCJvcmlnaW5hbC5saW5lIGFuZCBvcmlnaW5hbC5jb2x1bW4gYXJlIG5vdCBudW1iZXJzIC0tIHlvdSBwcm9iYWJseSBtZWFudCB0byBvbWl0IHRoZSBvcmlnaW5hbCBtYXBwaW5nIGVudGlyZWx5IGFuZCBvbmx5IG1hcCB0aGUgZ2VuZXJhdGVkIHBvc2l0aW9uLiBJZiBzbywgcGFzcyBudWxsIGZvciB0aGUgb3JpZ2luYWwgbWFwcGluZyBpbnN0ZWFkIG9mIGFuIG9iamVjdCB3aXRoIGVtcHR5IG9yIG51bGwgdmFsdWVzLlwiXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBpZiAoYUdlbmVyYXRlZCAmJiBcImxpbmVcIiBpbiBhR2VuZXJhdGVkICYmIFwiY29sdW1uXCIgaW4gYUdlbmVyYXRlZCAmJiBhR2VuZXJhdGVkLmxpbmUgPiAwICYmIGFHZW5lcmF0ZWQuY29sdW1uID49IDAgJiYgIWFPcmlnaW5hbCAmJiAhYVNvdXJjZSAmJiAhYU5hbWUpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSBlbHNlIGlmIChhR2VuZXJhdGVkICYmIFwibGluZVwiIGluIGFHZW5lcmF0ZWQgJiYgXCJjb2x1bW5cIiBpbiBhR2VuZXJhdGVkICYmIGFPcmlnaW5hbCAmJiBcImxpbmVcIiBpbiBhT3JpZ2luYWwgJiYgXCJjb2x1bW5cIiBpbiBhT3JpZ2luYWwgJiYgYUdlbmVyYXRlZC5saW5lID4gMCAmJiBhR2VuZXJhdGVkLmNvbHVtbiA+PSAwICYmIGFPcmlnaW5hbC5saW5lID4gMCAmJiBhT3JpZ2luYWwuY29sdW1uID49IDAgJiYgYVNvdXJjZSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIG1hcHBpbmc6IFwiICsgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGdlbmVyYXRlZDogYUdlbmVyYXRlZCxcbiAgICAgICAgICBzb3VyY2U6IGFTb3VyY2UsXG4gICAgICAgICAgb3JpZ2luYWw6IGFPcmlnaW5hbCxcbiAgICAgICAgICBuYW1lOiBhTmFtZVxuICAgICAgICB9KSk7XG4gICAgICB9XG4gICAgfTtcbiAgICBTb3VyY2VNYXBHZW5lcmF0b3IucHJvdG90eXBlLl9zZXJpYWxpemVNYXBwaW5ncyA9IGZ1bmN0aW9uIFNvdXJjZU1hcEdlbmVyYXRvcl9zZXJpYWxpemVNYXBwaW5ncygpIHtcbiAgICAgIHZhciBwcmV2aW91c0dlbmVyYXRlZENvbHVtbiA9IDA7XG4gICAgICB2YXIgcHJldmlvdXNHZW5lcmF0ZWRMaW5lID0gMTtcbiAgICAgIHZhciBwcmV2aW91c09yaWdpbmFsQ29sdW1uID0gMDtcbiAgICAgIHZhciBwcmV2aW91c09yaWdpbmFsTGluZSA9IDA7XG4gICAgICB2YXIgcHJldmlvdXNOYW1lID0gMDtcbiAgICAgIHZhciBwcmV2aW91c1NvdXJjZSA9IDA7XG4gICAgICB2YXIgcmVzdWx0ID0gXCJcIjtcbiAgICAgIHZhciBuZXh0O1xuICAgICAgdmFyIG1hcHBpbmc7XG4gICAgICB2YXIgbmFtZUlkeDtcbiAgICAgIHZhciBzb3VyY2VJZHg7XG4gICAgICB2YXIgbWFwcGluZ3MgPSB0aGlzLl9tYXBwaW5ncy50b0FycmF5KCk7XG4gICAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gbWFwcGluZ3MubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgbWFwcGluZyA9IG1hcHBpbmdzW2ldO1xuICAgICAgICBuZXh0ID0gXCJcIjtcbiAgICAgICAgaWYgKG1hcHBpbmcuZ2VuZXJhdGVkTGluZSAhPT0gcHJldmlvdXNHZW5lcmF0ZWRMaW5lKSB7XG4gICAgICAgICAgcHJldmlvdXNHZW5lcmF0ZWRDb2x1bW4gPSAwO1xuICAgICAgICAgIHdoaWxlIChtYXBwaW5nLmdlbmVyYXRlZExpbmUgIT09IHByZXZpb3VzR2VuZXJhdGVkTGluZSkge1xuICAgICAgICAgICAgbmV4dCArPSBcIjtcIjtcbiAgICAgICAgICAgIHByZXZpb3VzR2VuZXJhdGVkTGluZSsrO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAoaSA+IDApIHtcbiAgICAgICAgICAgIGlmICghdXRpbC5jb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNJbmZsYXRlZChtYXBwaW5nLCBtYXBwaW5nc1tpIC0gMV0pKSB7XG4gICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbmV4dCArPSBcIixcIjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgbmV4dCArPSBiYXNlNjRWTFEuZW5jb2RlKG1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uIC0gcHJldmlvdXNHZW5lcmF0ZWRDb2x1bW4pO1xuICAgICAgICBwcmV2aW91c0dlbmVyYXRlZENvbHVtbiA9IG1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uO1xuICAgICAgICBpZiAobWFwcGluZy5zb3VyY2UgIT0gbnVsbCkge1xuICAgICAgICAgIHNvdXJjZUlkeCA9IHRoaXMuX3NvdXJjZXMuaW5kZXhPZihtYXBwaW5nLnNvdXJjZSk7XG4gICAgICAgICAgbmV4dCArPSBiYXNlNjRWTFEuZW5jb2RlKHNvdXJjZUlkeCAtIHByZXZpb3VzU291cmNlKTtcbiAgICAgICAgICBwcmV2aW91c1NvdXJjZSA9IHNvdXJjZUlkeDtcbiAgICAgICAgICBuZXh0ICs9IGJhc2U2NFZMUS5lbmNvZGUobWFwcGluZy5vcmlnaW5hbExpbmUgLSAxIC0gcHJldmlvdXNPcmlnaW5hbExpbmUpO1xuICAgICAgICAgIHByZXZpb3VzT3JpZ2luYWxMaW5lID0gbWFwcGluZy5vcmlnaW5hbExpbmUgLSAxO1xuICAgICAgICAgIG5leHQgKz0gYmFzZTY0VkxRLmVuY29kZShtYXBwaW5nLm9yaWdpbmFsQ29sdW1uIC0gcHJldmlvdXNPcmlnaW5hbENvbHVtbik7XG4gICAgICAgICAgcHJldmlvdXNPcmlnaW5hbENvbHVtbiA9IG1hcHBpbmcub3JpZ2luYWxDb2x1bW47XG4gICAgICAgICAgaWYgKG1hcHBpbmcubmFtZSAhPSBudWxsKSB7XG4gICAgICAgICAgICBuYW1lSWR4ID0gdGhpcy5fbmFtZXMuaW5kZXhPZihtYXBwaW5nLm5hbWUpO1xuICAgICAgICAgICAgbmV4dCArPSBiYXNlNjRWTFEuZW5jb2RlKG5hbWVJZHggLSBwcmV2aW91c05hbWUpO1xuICAgICAgICAgICAgcHJldmlvdXNOYW1lID0gbmFtZUlkeDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmVzdWx0ICs9IG5leHQ7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH07XG4gICAgU291cmNlTWFwR2VuZXJhdG9yLnByb3RvdHlwZS5fZ2VuZXJhdGVTb3VyY2VzQ29udGVudCA9IGZ1bmN0aW9uIFNvdXJjZU1hcEdlbmVyYXRvcl9nZW5lcmF0ZVNvdXJjZXNDb250ZW50KGFTb3VyY2VzLCBhU291cmNlUm9vdCkge1xuICAgICAgcmV0dXJuIGFTb3VyY2VzLm1hcChmdW5jdGlvbihzb3VyY2UpIHtcbiAgICAgICAgaWYgKCF0aGlzLl9zb3VyY2VzQ29udGVudHMpIHtcbiAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoYVNvdXJjZVJvb3QgIT0gbnVsbCkge1xuICAgICAgICAgIHNvdXJjZSA9IHV0aWwucmVsYXRpdmUoYVNvdXJjZVJvb3QsIHNvdXJjZSk7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIGtleSA9IHV0aWwudG9TZXRTdHJpbmcoc291cmNlKTtcbiAgICAgICAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbCh0aGlzLl9zb3VyY2VzQ29udGVudHMsIGtleSkgPyB0aGlzLl9zb3VyY2VzQ29udGVudHNba2V5XSA6IG51bGw7XG4gICAgICB9LCB0aGlzKTtcbiAgICB9O1xuICAgIFNvdXJjZU1hcEdlbmVyYXRvci5wcm90b3R5cGUudG9KU09OID0gZnVuY3Rpb24gU291cmNlTWFwR2VuZXJhdG9yX3RvSlNPTigpIHtcbiAgICAgIHZhciBtYXAgPSB7XG4gICAgICAgIHZlcnNpb246IHRoaXMuX3ZlcnNpb24sXG4gICAgICAgIHNvdXJjZXM6IHRoaXMuX3NvdXJjZXMudG9BcnJheSgpLFxuICAgICAgICBuYW1lczogdGhpcy5fbmFtZXMudG9BcnJheSgpLFxuICAgICAgICBtYXBwaW5nczogdGhpcy5fc2VyaWFsaXplTWFwcGluZ3MoKVxuICAgICAgfTtcbiAgICAgIGlmICh0aGlzLl9maWxlICE9IG51bGwpIHtcbiAgICAgICAgbWFwLmZpbGUgPSB0aGlzLl9maWxlO1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMuX3NvdXJjZVJvb3QgIT0gbnVsbCkge1xuICAgICAgICBtYXAuc291cmNlUm9vdCA9IHRoaXMuX3NvdXJjZVJvb3Q7XG4gICAgICB9XG4gICAgICBpZiAodGhpcy5fc291cmNlc0NvbnRlbnRzKSB7XG4gICAgICAgIG1hcC5zb3VyY2VzQ29udGVudCA9IHRoaXMuX2dlbmVyYXRlU291cmNlc0NvbnRlbnQobWFwLnNvdXJjZXMsIG1hcC5zb3VyY2VSb290KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBtYXA7XG4gICAgfTtcbiAgICBTb3VyY2VNYXBHZW5lcmF0b3IucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24gU291cmNlTWFwR2VuZXJhdG9yX3RvU3RyaW5nKCkge1xuICAgICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KHRoaXMudG9KU09OKCkpO1xuICAgIH07XG4gICAgZXhwb3J0cy5Tb3VyY2VNYXBHZW5lcmF0b3IgPSBTb3VyY2VNYXBHZW5lcmF0b3I7XG4gIH1cbn0pO1xuXG4vLyBub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvYmluYXJ5LXNlYXJjaC5qc1xudmFyIHJlcXVpcmVfYmluYXJ5X3NlYXJjaCA9IF9fY29tbW9uSlMoe1xuICBcIm5vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi9iaW5hcnktc2VhcmNoLmpzXCIoZXhwb3J0cykge1xuICAgIGV4cG9ydHMuR1JFQVRFU1RfTE9XRVJfQk9VTkQgPSAxO1xuICAgIGV4cG9ydHMuTEVBU1RfVVBQRVJfQk9VTkQgPSAyO1xuICAgIGZ1bmN0aW9uIHJlY3Vyc2l2ZVNlYXJjaChhTG93LCBhSGlnaCwgYU5lZWRsZSwgYUhheXN0YWNrLCBhQ29tcGFyZSwgYUJpYXMpIHtcbiAgICAgIHZhciBtaWQgPSBNYXRoLmZsb29yKChhSGlnaCAtIGFMb3cpIC8gMikgKyBhTG93O1xuICAgICAgdmFyIGNtcCA9IGFDb21wYXJlKGFOZWVkbGUsIGFIYXlzdGFja1ttaWRdLCB0cnVlKTtcbiAgICAgIGlmIChjbXAgPT09IDApIHtcbiAgICAgICAgcmV0dXJuIG1pZDtcbiAgICAgIH0gZWxzZSBpZiAoY21wID4gMCkge1xuICAgICAgICBpZiAoYUhpZ2ggLSBtaWQgPiAxKSB7XG4gICAgICAgICAgcmV0dXJuIHJlY3Vyc2l2ZVNlYXJjaChtaWQsIGFIaWdoLCBhTmVlZGxlLCBhSGF5c3RhY2ssIGFDb21wYXJlLCBhQmlhcyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGFCaWFzID09IGV4cG9ydHMuTEVBU1RfVVBQRVJfQk9VTkQpIHtcbiAgICAgICAgICByZXR1cm4gYUhpZ2ggPCBhSGF5c3RhY2subGVuZ3RoID8gYUhpZ2ggOiAtMTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gbWlkO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAobWlkIC0gYUxvdyA+IDEpIHtcbiAgICAgICAgICByZXR1cm4gcmVjdXJzaXZlU2VhcmNoKGFMb3csIG1pZCwgYU5lZWRsZSwgYUhheXN0YWNrLCBhQ29tcGFyZSwgYUJpYXMpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChhQmlhcyA9PSBleHBvcnRzLkxFQVNUX1VQUEVSX0JPVU5EKSB7XG4gICAgICAgICAgcmV0dXJuIG1pZDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gYUxvdyA8IDAgPyAtMSA6IGFMb3c7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgZXhwb3J0cy5zZWFyY2ggPSBmdW5jdGlvbiBzZWFyY2goYU5lZWRsZSwgYUhheXN0YWNrLCBhQ29tcGFyZSwgYUJpYXMpIHtcbiAgICAgIGlmIChhSGF5c3RhY2subGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiAtMTtcbiAgICAgIH1cbiAgICAgIHZhciBpbmRleCA9IHJlY3Vyc2l2ZVNlYXJjaChcbiAgICAgICAgLTEsXG4gICAgICAgIGFIYXlzdGFjay5sZW5ndGgsXG4gICAgICAgIGFOZWVkbGUsXG4gICAgICAgIGFIYXlzdGFjayxcbiAgICAgICAgYUNvbXBhcmUsXG4gICAgICAgIGFCaWFzIHx8IGV4cG9ydHMuR1JFQVRFU1RfTE9XRVJfQk9VTkRcbiAgICAgICk7XG4gICAgICBpZiAoaW5kZXggPCAwKSB7XG4gICAgICAgIHJldHVybiAtMTtcbiAgICAgIH1cbiAgICAgIHdoaWxlIChpbmRleCAtIDEgPj0gMCkge1xuICAgICAgICBpZiAoYUNvbXBhcmUoYUhheXN0YWNrW2luZGV4XSwgYUhheXN0YWNrW2luZGV4IC0gMV0sIHRydWUpICE9PSAwKSB7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgLS1pbmRleDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBpbmRleDtcbiAgICB9O1xuICB9XG59KTtcblxuLy8gbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvbGliL3F1aWNrLXNvcnQuanNcbnZhciByZXF1aXJlX3F1aWNrX3NvcnQgPSBfX2NvbW1vbkpTKHtcbiAgXCJub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvcXVpY2stc29ydC5qc1wiKGV4cG9ydHMpIHtcbiAgICBmdW5jdGlvbiBTb3J0VGVtcGxhdGUoY29tcGFyYXRvcikge1xuICAgICAgZnVuY3Rpb24gc3dhcChhcnksIHgsIHkpIHtcbiAgICAgICAgdmFyIHRlbXAgPSBhcnlbeF07XG4gICAgICAgIGFyeVt4XSA9IGFyeVt5XTtcbiAgICAgICAgYXJ5W3ldID0gdGVtcDtcbiAgICAgIH1cbiAgICAgIGZ1bmN0aW9uIHJhbmRvbUludEluUmFuZ2UobG93LCBoaWdoKSB7XG4gICAgICAgIHJldHVybiBNYXRoLnJvdW5kKGxvdyArIE1hdGgucmFuZG9tKCkgKiAoaGlnaCAtIGxvdykpO1xuICAgICAgfVxuICAgICAgZnVuY3Rpb24gZG9RdWlja1NvcnQoYXJ5LCBjb21wYXJhdG9yMiwgcCwgcikge1xuICAgICAgICBpZiAocCA8IHIpIHtcbiAgICAgICAgICB2YXIgcGl2b3RJbmRleCA9IHJhbmRvbUludEluUmFuZ2UocCwgcik7XG4gICAgICAgICAgdmFyIGkgPSBwIC0gMTtcbiAgICAgICAgICBzd2FwKGFyeSwgcGl2b3RJbmRleCwgcik7XG4gICAgICAgICAgdmFyIHBpdm90ID0gYXJ5W3JdO1xuICAgICAgICAgIGZvciAodmFyIGogPSBwOyBqIDwgcjsgaisrKSB7XG4gICAgICAgICAgICBpZiAoY29tcGFyYXRvcjIoYXJ5W2pdLCBwaXZvdCwgZmFsc2UpIDw9IDApIHtcbiAgICAgICAgICAgICAgaSArPSAxO1xuICAgICAgICAgICAgICBzd2FwKGFyeSwgaSwgaik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHN3YXAoYXJ5LCBpICsgMSwgaik7XG4gICAgICAgICAgdmFyIHEgPSBpICsgMTtcbiAgICAgICAgICBkb1F1aWNrU29ydChhcnksIGNvbXBhcmF0b3IyLCBwLCBxIC0gMSk7XG4gICAgICAgICAgZG9RdWlja1NvcnQoYXJ5LCBjb21wYXJhdG9yMiwgcSArIDEsIHIpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gZG9RdWlja1NvcnQ7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNsb25lU29ydChjb21wYXJhdG9yKSB7XG4gICAgICBsZXQgdGVtcGxhdGUgPSBTb3J0VGVtcGxhdGUudG9TdHJpbmcoKTtcbiAgICAgIGxldCB0ZW1wbGF0ZUZuID0gbmV3IEZ1bmN0aW9uKGByZXR1cm4gJHt0ZW1wbGF0ZX1gKSgpO1xuICAgICAgcmV0dXJuIHRlbXBsYXRlRm4oY29tcGFyYXRvcik7XG4gICAgfVxuICAgIHZhciBzb3J0Q2FjaGUgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbiAgICBleHBvcnRzLnF1aWNrU29ydCA9IGZ1bmN0aW9uKGFyeSwgY29tcGFyYXRvciwgc3RhcnQgPSAwKSB7XG4gICAgICBsZXQgZG9RdWlja1NvcnQgPSBzb3J0Q2FjaGUuZ2V0KGNvbXBhcmF0b3IpO1xuICAgICAgaWYgKGRvUXVpY2tTb3J0ID09PSB2b2lkIDApIHtcbiAgICAgICAgZG9RdWlja1NvcnQgPSBjbG9uZVNvcnQoY29tcGFyYXRvcik7XG4gICAgICAgIHNvcnRDYWNoZS5zZXQoY29tcGFyYXRvciwgZG9RdWlja1NvcnQpO1xuICAgICAgfVxuICAgICAgZG9RdWlja1NvcnQoYXJ5LCBjb21wYXJhdG9yLCBzdGFydCwgYXJ5Lmxlbmd0aCAtIDEpO1xuICAgIH07XG4gIH1cbn0pO1xuXG4vLyBub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvc291cmNlLW1hcC1jb25zdW1lci5qc1xudmFyIHJlcXVpcmVfc291cmNlX21hcF9jb25zdW1lciA9IF9fY29tbW9uSlMoe1xuICBcIm5vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi9zb3VyY2UtbWFwLWNvbnN1bWVyLmpzXCIoZXhwb3J0cykge1xuICAgIHZhciB1dGlsID0gcmVxdWlyZV91dGlsKCk7XG4gICAgdmFyIGJpbmFyeVNlYXJjaCA9IHJlcXVpcmVfYmluYXJ5X3NlYXJjaCgpO1xuICAgIHZhciBBcnJheVNldCA9IHJlcXVpcmVfYXJyYXlfc2V0KCkuQXJyYXlTZXQ7XG4gICAgdmFyIGJhc2U2NFZMUSA9IHJlcXVpcmVfYmFzZTY0X3ZscSgpO1xuICAgIHZhciBxdWlja1NvcnQgPSByZXF1aXJlX3F1aWNrX3NvcnQoKS5xdWlja1NvcnQ7XG4gICAgZnVuY3Rpb24gU291cmNlTWFwQ29uc3VtZXIyKGFTb3VyY2VNYXAsIGFTb3VyY2VNYXBVUkwpIHtcbiAgICAgIHZhciBzb3VyY2VNYXAgPSBhU291cmNlTWFwO1xuICAgICAgaWYgKHR5cGVvZiBhU291cmNlTWFwID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHNvdXJjZU1hcCA9IHV0aWwucGFyc2VTb3VyY2VNYXBJbnB1dChhU291cmNlTWFwKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzb3VyY2VNYXAuc2VjdGlvbnMgIT0gbnVsbCA/IG5ldyBJbmRleGVkU291cmNlTWFwQ29uc3VtZXIoc291cmNlTWFwLCBhU291cmNlTWFwVVJMKSA6IG5ldyBCYXNpY1NvdXJjZU1hcENvbnN1bWVyKHNvdXJjZU1hcCwgYVNvdXJjZU1hcFVSTCk7XG4gICAgfVxuICAgIFNvdXJjZU1hcENvbnN1bWVyMi5mcm9tU291cmNlTWFwID0gZnVuY3Rpb24oYVNvdXJjZU1hcCwgYVNvdXJjZU1hcFVSTCkge1xuICAgICAgcmV0dXJuIEJhc2ljU291cmNlTWFwQ29uc3VtZXIuZnJvbVNvdXJjZU1hcChhU291cmNlTWFwLCBhU291cmNlTWFwVVJMKTtcbiAgICB9O1xuICAgIFNvdXJjZU1hcENvbnN1bWVyMi5wcm90b3R5cGUuX3ZlcnNpb24gPSAzO1xuICAgIFNvdXJjZU1hcENvbnN1bWVyMi5wcm90b3R5cGUuX19nZW5lcmF0ZWRNYXBwaW5ncyA9IG51bGw7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFNvdXJjZU1hcENvbnN1bWVyMi5wcm90b3R5cGUsIFwiX2dlbmVyYXRlZE1hcHBpbmdzXCIsIHtcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBnZXQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICBpZiAoIXRoaXMuX19nZW5lcmF0ZWRNYXBwaW5ncykge1xuICAgICAgICAgIHRoaXMuX3BhcnNlTWFwcGluZ3ModGhpcy5fbWFwcGluZ3MsIHRoaXMuc291cmNlUm9vdCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMuX19nZW5lcmF0ZWRNYXBwaW5ncztcbiAgICAgIH1cbiAgICB9KTtcbiAgICBTb3VyY2VNYXBDb25zdW1lcjIucHJvdG90eXBlLl9fb3JpZ2luYWxNYXBwaW5ncyA9IG51bGw7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KFNvdXJjZU1hcENvbnN1bWVyMi5wcm90b3R5cGUsIFwiX29yaWdpbmFsTWFwcGluZ3NcIiwge1xuICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGdldDogZnVuY3Rpb24oKSB7XG4gICAgICAgIGlmICghdGhpcy5fX29yaWdpbmFsTWFwcGluZ3MpIHtcbiAgICAgICAgICB0aGlzLl9wYXJzZU1hcHBpbmdzKHRoaXMuX21hcHBpbmdzLCB0aGlzLnNvdXJjZVJvb3QpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9fb3JpZ2luYWxNYXBwaW5ncztcbiAgICAgIH1cbiAgICB9KTtcbiAgICBTb3VyY2VNYXBDb25zdW1lcjIucHJvdG90eXBlLl9jaGFySXNNYXBwaW5nU2VwYXJhdG9yID0gZnVuY3Rpb24gU291cmNlTWFwQ29uc3VtZXJfY2hhcklzTWFwcGluZ1NlcGFyYXRvcihhU3RyLCBpbmRleCkge1xuICAgICAgdmFyIGMgPSBhU3RyLmNoYXJBdChpbmRleCk7XG4gICAgICByZXR1cm4gYyA9PT0gXCI7XCIgfHwgYyA9PT0gXCIsXCI7XG4gICAgfTtcbiAgICBTb3VyY2VNYXBDb25zdW1lcjIucHJvdG90eXBlLl9wYXJzZU1hcHBpbmdzID0gZnVuY3Rpb24gU291cmNlTWFwQ29uc3VtZXJfcGFyc2VNYXBwaW5ncyhhU3RyLCBhU291cmNlUm9vdCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiU3ViY2xhc3NlcyBtdXN0IGltcGxlbWVudCBfcGFyc2VNYXBwaW5nc1wiKTtcbiAgICB9O1xuICAgIFNvdXJjZU1hcENvbnN1bWVyMi5HRU5FUkFURURfT1JERVIgPSAxO1xuICAgIFNvdXJjZU1hcENvbnN1bWVyMi5PUklHSU5BTF9PUkRFUiA9IDI7XG4gICAgU291cmNlTWFwQ29uc3VtZXIyLkdSRUFURVNUX0xPV0VSX0JPVU5EID0gMTtcbiAgICBTb3VyY2VNYXBDb25zdW1lcjIuTEVBU1RfVVBQRVJfQk9VTkQgPSAyO1xuICAgIFNvdXJjZU1hcENvbnN1bWVyMi5wcm90b3R5cGUuZWFjaE1hcHBpbmcgPSBmdW5jdGlvbiBTb3VyY2VNYXBDb25zdW1lcl9lYWNoTWFwcGluZyhhQ2FsbGJhY2ssIGFDb250ZXh0LCBhT3JkZXIpIHtcbiAgICAgIHZhciBjb250ZXh0ID0gYUNvbnRleHQgfHwgbnVsbDtcbiAgICAgIHZhciBvcmRlciA9IGFPcmRlciB8fCBTb3VyY2VNYXBDb25zdW1lcjIuR0VORVJBVEVEX09SREVSO1xuICAgICAgdmFyIG1hcHBpbmdzO1xuICAgICAgc3dpdGNoIChvcmRlcikge1xuICAgICAgICBjYXNlIFNvdXJjZU1hcENvbnN1bWVyMi5HRU5FUkFURURfT1JERVI6XG4gICAgICAgICAgbWFwcGluZ3MgPSB0aGlzLl9nZW5lcmF0ZWRNYXBwaW5ncztcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBTb3VyY2VNYXBDb25zdW1lcjIuT1JJR0lOQUxfT1JERVI6XG4gICAgICAgICAgbWFwcGluZ3MgPSB0aGlzLl9vcmlnaW5hbE1hcHBpbmdzO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIlVua25vd24gb3JkZXIgb2YgaXRlcmF0aW9uLlwiKTtcbiAgICAgIH1cbiAgICAgIHZhciBzb3VyY2VSb290ID0gdGhpcy5zb3VyY2VSb290O1xuICAgICAgdmFyIGJvdW5kQ2FsbGJhY2sgPSBhQ2FsbGJhY2suYmluZChjb250ZXh0KTtcbiAgICAgIHZhciBuYW1lcyA9IHRoaXMuX25hbWVzO1xuICAgICAgdmFyIHNvdXJjZXMgPSB0aGlzLl9zb3VyY2VzO1xuICAgICAgdmFyIHNvdXJjZU1hcFVSTCA9IHRoaXMuX3NvdXJjZU1hcFVSTDtcbiAgICAgIGZvciAodmFyIGkgPSAwLCBuID0gbWFwcGluZ3MubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgIHZhciBtYXBwaW5nID0gbWFwcGluZ3NbaV07XG4gICAgICAgIHZhciBzb3VyY2UgPSBtYXBwaW5nLnNvdXJjZSA9PT0gbnVsbCA/IG51bGwgOiBzb3VyY2VzLmF0KG1hcHBpbmcuc291cmNlKTtcbiAgICAgICAgc291cmNlID0gdXRpbC5jb21wdXRlU291cmNlVVJMKHNvdXJjZVJvb3QsIHNvdXJjZSwgc291cmNlTWFwVVJMKTtcbiAgICAgICAgYm91bmRDYWxsYmFjayh7XG4gICAgICAgICAgc291cmNlLFxuICAgICAgICAgIGdlbmVyYXRlZExpbmU6IG1hcHBpbmcuZ2VuZXJhdGVkTGluZSxcbiAgICAgICAgICBnZW5lcmF0ZWRDb2x1bW46IG1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uLFxuICAgICAgICAgIG9yaWdpbmFsTGluZTogbWFwcGluZy5vcmlnaW5hbExpbmUsXG4gICAgICAgICAgb3JpZ2luYWxDb2x1bW46IG1hcHBpbmcub3JpZ2luYWxDb2x1bW4sXG4gICAgICAgICAgbmFtZTogbWFwcGluZy5uYW1lID09PSBudWxsID8gbnVsbCA6IG5hbWVzLmF0KG1hcHBpbmcubmFtZSlcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfTtcbiAgICBTb3VyY2VNYXBDb25zdW1lcjIucHJvdG90eXBlLmFsbEdlbmVyYXRlZFBvc2l0aW9uc0ZvciA9IGZ1bmN0aW9uIFNvdXJjZU1hcENvbnN1bWVyX2FsbEdlbmVyYXRlZFBvc2l0aW9uc0ZvcihhQXJncykge1xuICAgICAgdmFyIGxpbmUgPSB1dGlsLmdldEFyZyhhQXJncywgXCJsaW5lXCIpO1xuICAgICAgdmFyIG5lZWRsZSA9IHtcbiAgICAgICAgc291cmNlOiB1dGlsLmdldEFyZyhhQXJncywgXCJzb3VyY2VcIiksXG4gICAgICAgIG9yaWdpbmFsTGluZTogbGluZSxcbiAgICAgICAgb3JpZ2luYWxDb2x1bW46IHV0aWwuZ2V0QXJnKGFBcmdzLCBcImNvbHVtblwiLCAwKVxuICAgICAgfTtcbiAgICAgIG5lZWRsZS5zb3VyY2UgPSB0aGlzLl9maW5kU291cmNlSW5kZXgobmVlZGxlLnNvdXJjZSk7XG4gICAgICBpZiAobmVlZGxlLnNvdXJjZSA8IDApIHtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgICAgfVxuICAgICAgdmFyIG1hcHBpbmdzID0gW107XG4gICAgICB2YXIgaW5kZXggPSB0aGlzLl9maW5kTWFwcGluZyhcbiAgICAgICAgbmVlZGxlLFxuICAgICAgICB0aGlzLl9vcmlnaW5hbE1hcHBpbmdzLFxuICAgICAgICBcIm9yaWdpbmFsTGluZVwiLFxuICAgICAgICBcIm9yaWdpbmFsQ29sdW1uXCIsXG4gICAgICAgIHV0aWwuY29tcGFyZUJ5T3JpZ2luYWxQb3NpdGlvbnMsXG4gICAgICAgIGJpbmFyeVNlYXJjaC5MRUFTVF9VUFBFUl9CT1VORFxuICAgICAgKTtcbiAgICAgIGlmIChpbmRleCA+PSAwKSB7XG4gICAgICAgIHZhciBtYXBwaW5nID0gdGhpcy5fb3JpZ2luYWxNYXBwaW5nc1tpbmRleF07XG4gICAgICAgIGlmIChhQXJncy5jb2x1bW4gPT09IHZvaWQgMCkge1xuICAgICAgICAgIHZhciBvcmlnaW5hbExpbmUgPSBtYXBwaW5nLm9yaWdpbmFsTGluZTtcbiAgICAgICAgICB3aGlsZSAobWFwcGluZyAmJiBtYXBwaW5nLm9yaWdpbmFsTGluZSA9PT0gb3JpZ2luYWxMaW5lKSB7XG4gICAgICAgICAgICBtYXBwaW5ncy5wdXNoKHtcbiAgICAgICAgICAgICAgbGluZTogdXRpbC5nZXRBcmcobWFwcGluZywgXCJnZW5lcmF0ZWRMaW5lXCIsIG51bGwpLFxuICAgICAgICAgICAgICBjb2x1bW46IHV0aWwuZ2V0QXJnKG1hcHBpbmcsIFwiZ2VuZXJhdGVkQ29sdW1uXCIsIG51bGwpLFxuICAgICAgICAgICAgICBsYXN0Q29sdW1uOiB1dGlsLmdldEFyZyhtYXBwaW5nLCBcImxhc3RHZW5lcmF0ZWRDb2x1bW5cIiwgbnVsbClcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgbWFwcGluZyA9IHRoaXMuX29yaWdpbmFsTWFwcGluZ3NbKytpbmRleF07XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHZhciBvcmlnaW5hbENvbHVtbiA9IG1hcHBpbmcub3JpZ2luYWxDb2x1bW47XG4gICAgICAgICAgd2hpbGUgKG1hcHBpbmcgJiYgbWFwcGluZy5vcmlnaW5hbExpbmUgPT09IGxpbmUgJiYgbWFwcGluZy5vcmlnaW5hbENvbHVtbiA9PSBvcmlnaW5hbENvbHVtbikge1xuICAgICAgICAgICAgbWFwcGluZ3MucHVzaCh7XG4gICAgICAgICAgICAgIGxpbmU6IHV0aWwuZ2V0QXJnKG1hcHBpbmcsIFwiZ2VuZXJhdGVkTGluZVwiLCBudWxsKSxcbiAgICAgICAgICAgICAgY29sdW1uOiB1dGlsLmdldEFyZyhtYXBwaW5nLCBcImdlbmVyYXRlZENvbHVtblwiLCBudWxsKSxcbiAgICAgICAgICAgICAgbGFzdENvbHVtbjogdXRpbC5nZXRBcmcobWFwcGluZywgXCJsYXN0R2VuZXJhdGVkQ29sdW1uXCIsIG51bGwpXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIG1hcHBpbmcgPSB0aGlzLl9vcmlnaW5hbE1hcHBpbmdzWysraW5kZXhdO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIG1hcHBpbmdzO1xuICAgIH07XG4gICAgZXhwb3J0cy5Tb3VyY2VNYXBDb25zdW1lciA9IFNvdXJjZU1hcENvbnN1bWVyMjtcbiAgICBmdW5jdGlvbiBCYXNpY1NvdXJjZU1hcENvbnN1bWVyKGFTb3VyY2VNYXAsIGFTb3VyY2VNYXBVUkwpIHtcbiAgICAgIHZhciBzb3VyY2VNYXAgPSBhU291cmNlTWFwO1xuICAgICAgaWYgKHR5cGVvZiBhU291cmNlTWFwID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHNvdXJjZU1hcCA9IHV0aWwucGFyc2VTb3VyY2VNYXBJbnB1dChhU291cmNlTWFwKTtcbiAgICAgIH1cbiAgICAgIHZhciB2ZXJzaW9uID0gdXRpbC5nZXRBcmcoc291cmNlTWFwLCBcInZlcnNpb25cIik7XG4gICAgICB2YXIgc291cmNlcyA9IHV0aWwuZ2V0QXJnKHNvdXJjZU1hcCwgXCJzb3VyY2VzXCIpO1xuICAgICAgdmFyIG5hbWVzID0gdXRpbC5nZXRBcmcoc291cmNlTWFwLCBcIm5hbWVzXCIsIFtdKTtcbiAgICAgIHZhciBzb3VyY2VSb290ID0gdXRpbC5nZXRBcmcoc291cmNlTWFwLCBcInNvdXJjZVJvb3RcIiwgbnVsbCk7XG4gICAgICB2YXIgc291cmNlc0NvbnRlbnQgPSB1dGlsLmdldEFyZyhzb3VyY2VNYXAsIFwic291cmNlc0NvbnRlbnRcIiwgbnVsbCk7XG4gICAgICB2YXIgbWFwcGluZ3MgPSB1dGlsLmdldEFyZyhzb3VyY2VNYXAsIFwibWFwcGluZ3NcIik7XG4gICAgICB2YXIgZmlsZSA9IHV0aWwuZ2V0QXJnKHNvdXJjZU1hcCwgXCJmaWxlXCIsIG51bGwpO1xuICAgICAgaWYgKHZlcnNpb24gIT0gdGhpcy5fdmVyc2lvbikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJVbnN1cHBvcnRlZCB2ZXJzaW9uOiBcIiArIHZlcnNpb24pO1xuICAgICAgfVxuICAgICAgaWYgKHNvdXJjZVJvb3QpIHtcbiAgICAgICAgc291cmNlUm9vdCA9IHV0aWwubm9ybWFsaXplKHNvdXJjZVJvb3QpO1xuICAgICAgfVxuICAgICAgc291cmNlcyA9IHNvdXJjZXMubWFwKFN0cmluZykubWFwKHV0aWwubm9ybWFsaXplKS5tYXAoZnVuY3Rpb24oc291cmNlKSB7XG4gICAgICAgIHJldHVybiBzb3VyY2VSb290ICYmIHV0aWwuaXNBYnNvbHV0ZShzb3VyY2VSb290KSAmJiB1dGlsLmlzQWJzb2x1dGUoc291cmNlKSA/IHV0aWwucmVsYXRpdmUoc291cmNlUm9vdCwgc291cmNlKSA6IHNvdXJjZTtcbiAgICAgIH0pO1xuICAgICAgdGhpcy5fbmFtZXMgPSBBcnJheVNldC5mcm9tQXJyYXkobmFtZXMubWFwKFN0cmluZyksIHRydWUpO1xuICAgICAgdGhpcy5fc291cmNlcyA9IEFycmF5U2V0LmZyb21BcnJheShzb3VyY2VzLCB0cnVlKTtcbiAgICAgIHRoaXMuX2Fic29sdXRlU291cmNlcyA9IHRoaXMuX3NvdXJjZXMudG9BcnJheSgpLm1hcChmdW5jdGlvbihzKSB7XG4gICAgICAgIHJldHVybiB1dGlsLmNvbXB1dGVTb3VyY2VVUkwoc291cmNlUm9vdCwgcywgYVNvdXJjZU1hcFVSTCk7XG4gICAgICB9KTtcbiAgICAgIHRoaXMuc291cmNlUm9vdCA9IHNvdXJjZVJvb3Q7XG4gICAgICB0aGlzLnNvdXJjZXNDb250ZW50ID0gc291cmNlc0NvbnRlbnQ7XG4gICAgICB0aGlzLl9tYXBwaW5ncyA9IG1hcHBpbmdzO1xuICAgICAgdGhpcy5fc291cmNlTWFwVVJMID0gYVNvdXJjZU1hcFVSTDtcbiAgICAgIHRoaXMuZmlsZSA9IGZpbGU7XG4gICAgfVxuICAgIEJhc2ljU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlID0gT2JqZWN0LmNyZWF0ZShTb3VyY2VNYXBDb25zdW1lcjIucHJvdG90eXBlKTtcbiAgICBCYXNpY1NvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5jb25zdW1lciA9IFNvdXJjZU1hcENvbnN1bWVyMjtcbiAgICBCYXNpY1NvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5fZmluZFNvdXJjZUluZGV4ID0gZnVuY3Rpb24oYVNvdXJjZSkge1xuICAgICAgdmFyIHJlbGF0aXZlU291cmNlID0gYVNvdXJjZTtcbiAgICAgIGlmICh0aGlzLnNvdXJjZVJvb3QgIT0gbnVsbCkge1xuICAgICAgICByZWxhdGl2ZVNvdXJjZSA9IHV0aWwucmVsYXRpdmUodGhpcy5zb3VyY2VSb290LCByZWxhdGl2ZVNvdXJjZSk7XG4gICAgICB9XG4gICAgICBpZiAodGhpcy5fc291cmNlcy5oYXMocmVsYXRpdmVTb3VyY2UpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9zb3VyY2VzLmluZGV4T2YocmVsYXRpdmVTb3VyY2UpO1xuICAgICAgfVxuICAgICAgdmFyIGk7XG4gICAgICBmb3IgKGkgPSAwOyBpIDwgdGhpcy5fYWJzb2x1dGVTb3VyY2VzLmxlbmd0aDsgKytpKSB7XG4gICAgICAgIGlmICh0aGlzLl9hYnNvbHV0ZVNvdXJjZXNbaV0gPT0gYVNvdXJjZSkge1xuICAgICAgICAgIHJldHVybiBpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gLTE7XG4gICAgfTtcbiAgICBCYXNpY1NvdXJjZU1hcENvbnN1bWVyLmZyb21Tb3VyY2VNYXAgPSBmdW5jdGlvbiBTb3VyY2VNYXBDb25zdW1lcl9mcm9tU291cmNlTWFwKGFTb3VyY2VNYXAsIGFTb3VyY2VNYXBVUkwpIHtcbiAgICAgIHZhciBzbWMgPSBPYmplY3QuY3JlYXRlKEJhc2ljU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlKTtcbiAgICAgIHZhciBuYW1lcyA9IHNtYy5fbmFtZXMgPSBBcnJheVNldC5mcm9tQXJyYXkoYVNvdXJjZU1hcC5fbmFtZXMudG9BcnJheSgpLCB0cnVlKTtcbiAgICAgIHZhciBzb3VyY2VzID0gc21jLl9zb3VyY2VzID0gQXJyYXlTZXQuZnJvbUFycmF5KGFTb3VyY2VNYXAuX3NvdXJjZXMudG9BcnJheSgpLCB0cnVlKTtcbiAgICAgIHNtYy5zb3VyY2VSb290ID0gYVNvdXJjZU1hcC5fc291cmNlUm9vdDtcbiAgICAgIHNtYy5zb3VyY2VzQ29udGVudCA9IGFTb3VyY2VNYXAuX2dlbmVyYXRlU291cmNlc0NvbnRlbnQoXG4gICAgICAgIHNtYy5fc291cmNlcy50b0FycmF5KCksXG4gICAgICAgIHNtYy5zb3VyY2VSb290XG4gICAgICApO1xuICAgICAgc21jLmZpbGUgPSBhU291cmNlTWFwLl9maWxlO1xuICAgICAgc21jLl9zb3VyY2VNYXBVUkwgPSBhU291cmNlTWFwVVJMO1xuICAgICAgc21jLl9hYnNvbHV0ZVNvdXJjZXMgPSBzbWMuX3NvdXJjZXMudG9BcnJheSgpLm1hcChmdW5jdGlvbihzKSB7XG4gICAgICAgIHJldHVybiB1dGlsLmNvbXB1dGVTb3VyY2VVUkwoc21jLnNvdXJjZVJvb3QsIHMsIGFTb3VyY2VNYXBVUkwpO1xuICAgICAgfSk7XG4gICAgICB2YXIgZ2VuZXJhdGVkTWFwcGluZ3MgPSBhU291cmNlTWFwLl9tYXBwaW5ncy50b0FycmF5KCkuc2xpY2UoKTtcbiAgICAgIHZhciBkZXN0R2VuZXJhdGVkTWFwcGluZ3MgPSBzbWMuX19nZW5lcmF0ZWRNYXBwaW5ncyA9IFtdO1xuICAgICAgdmFyIGRlc3RPcmlnaW5hbE1hcHBpbmdzID0gc21jLl9fb3JpZ2luYWxNYXBwaW5ncyA9IFtdO1xuICAgICAgZm9yICh2YXIgaSA9IDAsIGxlbmd0aCA9IGdlbmVyYXRlZE1hcHBpbmdzLmxlbmd0aDsgaSA8IGxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHZhciBzcmNNYXBwaW5nID0gZ2VuZXJhdGVkTWFwcGluZ3NbaV07XG4gICAgICAgIHZhciBkZXN0TWFwcGluZyA9IG5ldyBNYXBwaW5nKCk7XG4gICAgICAgIGRlc3RNYXBwaW5nLmdlbmVyYXRlZExpbmUgPSBzcmNNYXBwaW5nLmdlbmVyYXRlZExpbmU7XG4gICAgICAgIGRlc3RNYXBwaW5nLmdlbmVyYXRlZENvbHVtbiA9IHNyY01hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uO1xuICAgICAgICBpZiAoc3JjTWFwcGluZy5zb3VyY2UpIHtcbiAgICAgICAgICBkZXN0TWFwcGluZy5zb3VyY2UgPSBzb3VyY2VzLmluZGV4T2Yoc3JjTWFwcGluZy5zb3VyY2UpO1xuICAgICAgICAgIGRlc3RNYXBwaW5nLm9yaWdpbmFsTGluZSA9IHNyY01hcHBpbmcub3JpZ2luYWxMaW5lO1xuICAgICAgICAgIGRlc3RNYXBwaW5nLm9yaWdpbmFsQ29sdW1uID0gc3JjTWFwcGluZy5vcmlnaW5hbENvbHVtbjtcbiAgICAgICAgICBpZiAoc3JjTWFwcGluZy5uYW1lKSB7XG4gICAgICAgICAgICBkZXN0TWFwcGluZy5uYW1lID0gbmFtZXMuaW5kZXhPZihzcmNNYXBwaW5nLm5hbWUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBkZXN0T3JpZ2luYWxNYXBwaW5ncy5wdXNoKGRlc3RNYXBwaW5nKTtcbiAgICAgICAgfVxuICAgICAgICBkZXN0R2VuZXJhdGVkTWFwcGluZ3MucHVzaChkZXN0TWFwcGluZyk7XG4gICAgICB9XG4gICAgICBxdWlja1NvcnQoc21jLl9fb3JpZ2luYWxNYXBwaW5ncywgdXRpbC5jb21wYXJlQnlPcmlnaW5hbFBvc2l0aW9ucyk7XG4gICAgICByZXR1cm4gc21jO1xuICAgIH07XG4gICAgQmFzaWNTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuX3ZlcnNpb24gPSAzO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShCYXNpY1NvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZSwgXCJzb3VyY2VzXCIsIHtcbiAgICAgIGdldDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9hYnNvbHV0ZVNvdXJjZXMuc2xpY2UoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBmdW5jdGlvbiBNYXBwaW5nKCkge1xuICAgICAgdGhpcy5nZW5lcmF0ZWRMaW5lID0gMDtcbiAgICAgIHRoaXMuZ2VuZXJhdGVkQ29sdW1uID0gMDtcbiAgICAgIHRoaXMuc291cmNlID0gbnVsbDtcbiAgICAgIHRoaXMub3JpZ2luYWxMaW5lID0gbnVsbDtcbiAgICAgIHRoaXMub3JpZ2luYWxDb2x1bW4gPSBudWxsO1xuICAgICAgdGhpcy5uYW1lID0gbnVsbDtcbiAgICB9XG4gICAgdmFyIGNvbXBhcmVHZW5lcmF0ZWQgPSB1dGlsLmNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0RlZmxhdGVkTm9MaW5lO1xuICAgIGZ1bmN0aW9uIHNvcnRHZW5lcmF0ZWQoYXJyYXksIHN0YXJ0KSB7XG4gICAgICBsZXQgbCA9IGFycmF5Lmxlbmd0aDtcbiAgICAgIGxldCBuID0gYXJyYXkubGVuZ3RoIC0gc3RhcnQ7XG4gICAgICBpZiAobiA8PSAxKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH0gZWxzZSBpZiAobiA9PSAyKSB7XG4gICAgICAgIGxldCBhID0gYXJyYXlbc3RhcnRdO1xuICAgICAgICBsZXQgYiA9IGFycmF5W3N0YXJ0ICsgMV07XG4gICAgICAgIGlmIChjb21wYXJlR2VuZXJhdGVkKGEsIGIpID4gMCkge1xuICAgICAgICAgIGFycmF5W3N0YXJ0XSA9IGI7XG4gICAgICAgICAgYXJyYXlbc3RhcnQgKyAxXSA9IGE7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAobiA8IDIwKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSBzdGFydDsgaSA8IGw7IGkrKykge1xuICAgICAgICAgIGZvciAobGV0IGogPSBpOyBqID4gc3RhcnQ7IGotLSkge1xuICAgICAgICAgICAgbGV0IGEgPSBhcnJheVtqIC0gMV07XG4gICAgICAgICAgICBsZXQgYiA9IGFycmF5W2pdO1xuICAgICAgICAgICAgaWYgKGNvbXBhcmVHZW5lcmF0ZWQoYSwgYikgPD0gMCkge1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGFycmF5W2ogLSAxXSA9IGI7XG4gICAgICAgICAgICBhcnJheVtqXSA9IGE7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBxdWlja1NvcnQoYXJyYXksIGNvbXBhcmVHZW5lcmF0ZWQsIHN0YXJ0KTtcbiAgICAgIH1cbiAgICB9XG4gICAgQmFzaWNTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuX3BhcnNlTWFwcGluZ3MgPSBmdW5jdGlvbiBTb3VyY2VNYXBDb25zdW1lcl9wYXJzZU1hcHBpbmdzKGFTdHIsIGFTb3VyY2VSb290KSB7XG4gICAgICB2YXIgZ2VuZXJhdGVkTGluZSA9IDE7XG4gICAgICB2YXIgcHJldmlvdXNHZW5lcmF0ZWRDb2x1bW4gPSAwO1xuICAgICAgdmFyIHByZXZpb3VzT3JpZ2luYWxMaW5lID0gMDtcbiAgICAgIHZhciBwcmV2aW91c09yaWdpbmFsQ29sdW1uID0gMDtcbiAgICAgIHZhciBwcmV2aW91c1NvdXJjZSA9IDA7XG4gICAgICB2YXIgcHJldmlvdXNOYW1lID0gMDtcbiAgICAgIHZhciBsZW5ndGggPSBhU3RyLmxlbmd0aDtcbiAgICAgIHZhciBpbmRleCA9IDA7XG4gICAgICB2YXIgY2FjaGVkU2VnbWVudHMgPSB7fTtcbiAgICAgIHZhciB0ZW1wID0ge307XG4gICAgICB2YXIgb3JpZ2luYWxNYXBwaW5ncyA9IFtdO1xuICAgICAgdmFyIGdlbmVyYXRlZE1hcHBpbmdzID0gW107XG4gICAgICB2YXIgbWFwcGluZywgc3RyLCBzZWdtZW50LCBlbmQsIHZhbHVlO1xuICAgICAgbGV0IHN1YmFycmF5U3RhcnQgPSAwO1xuICAgICAgd2hpbGUgKGluZGV4IDwgbGVuZ3RoKSB7XG4gICAgICAgIGlmIChhU3RyLmNoYXJBdChpbmRleCkgPT09IFwiO1wiKSB7XG4gICAgICAgICAgZ2VuZXJhdGVkTGluZSsrO1xuICAgICAgICAgIGluZGV4Kys7XG4gICAgICAgICAgcHJldmlvdXNHZW5lcmF0ZWRDb2x1bW4gPSAwO1xuICAgICAgICAgIHNvcnRHZW5lcmF0ZWQoZ2VuZXJhdGVkTWFwcGluZ3MsIHN1YmFycmF5U3RhcnQpO1xuICAgICAgICAgIHN1YmFycmF5U3RhcnQgPSBnZW5lcmF0ZWRNYXBwaW5ncy5sZW5ndGg7XG4gICAgICAgIH0gZWxzZSBpZiAoYVN0ci5jaGFyQXQoaW5kZXgpID09PSBcIixcIikge1xuICAgICAgICAgIGluZGV4Kys7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbWFwcGluZyA9IG5ldyBNYXBwaW5nKCk7XG4gICAgICAgICAgbWFwcGluZy5nZW5lcmF0ZWRMaW5lID0gZ2VuZXJhdGVkTGluZTtcbiAgICAgICAgICBmb3IgKGVuZCA9IGluZGV4OyBlbmQgPCBsZW5ndGg7IGVuZCsrKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5fY2hhcklzTWFwcGluZ1NlcGFyYXRvcihhU3RyLCBlbmQpKSB7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBzdHIgPSBhU3RyLnNsaWNlKGluZGV4LCBlbmQpO1xuICAgICAgICAgIHNlZ21lbnQgPSBbXTtcbiAgICAgICAgICB3aGlsZSAoaW5kZXggPCBlbmQpIHtcbiAgICAgICAgICAgIGJhc2U2NFZMUS5kZWNvZGUoYVN0ciwgaW5kZXgsIHRlbXApO1xuICAgICAgICAgICAgdmFsdWUgPSB0ZW1wLnZhbHVlO1xuICAgICAgICAgICAgaW5kZXggPSB0ZW1wLnJlc3Q7XG4gICAgICAgICAgICBzZWdtZW50LnB1c2godmFsdWUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoc2VnbWVudC5sZW5ndGggPT09IDIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkZvdW5kIGEgc291cmNlLCBidXQgbm8gbGluZSBhbmQgY29sdW1uXCIpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoc2VnbWVudC5sZW5ndGggPT09IDMpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkZvdW5kIGEgc291cmNlIGFuZCBsaW5lLCBidXQgbm8gY29sdW1uXCIpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBtYXBwaW5nLmdlbmVyYXRlZENvbHVtbiA9IHByZXZpb3VzR2VuZXJhdGVkQ29sdW1uICsgc2VnbWVudFswXTtcbiAgICAgICAgICBwcmV2aW91c0dlbmVyYXRlZENvbHVtbiA9IG1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uO1xuICAgICAgICAgIGlmIChzZWdtZW50Lmxlbmd0aCA+IDEpIHtcbiAgICAgICAgICAgIG1hcHBpbmcuc291cmNlID0gcHJldmlvdXNTb3VyY2UgKyBzZWdtZW50WzFdO1xuICAgICAgICAgICAgcHJldmlvdXNTb3VyY2UgKz0gc2VnbWVudFsxXTtcbiAgICAgICAgICAgIG1hcHBpbmcub3JpZ2luYWxMaW5lID0gcHJldmlvdXNPcmlnaW5hbExpbmUgKyBzZWdtZW50WzJdO1xuICAgICAgICAgICAgcHJldmlvdXNPcmlnaW5hbExpbmUgPSBtYXBwaW5nLm9yaWdpbmFsTGluZTtcbiAgICAgICAgICAgIG1hcHBpbmcub3JpZ2luYWxMaW5lICs9IDE7XG4gICAgICAgICAgICBtYXBwaW5nLm9yaWdpbmFsQ29sdW1uID0gcHJldmlvdXNPcmlnaW5hbENvbHVtbiArIHNlZ21lbnRbM107XG4gICAgICAgICAgICBwcmV2aW91c09yaWdpbmFsQ29sdW1uID0gbWFwcGluZy5vcmlnaW5hbENvbHVtbjtcbiAgICAgICAgICAgIGlmIChzZWdtZW50Lmxlbmd0aCA+IDQpIHtcbiAgICAgICAgICAgICAgbWFwcGluZy5uYW1lID0gcHJldmlvdXNOYW1lICsgc2VnbWVudFs0XTtcbiAgICAgICAgICAgICAgcHJldmlvdXNOYW1lICs9IHNlZ21lbnRbNF07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGdlbmVyYXRlZE1hcHBpbmdzLnB1c2gobWFwcGluZyk7XG4gICAgICAgICAgaWYgKHR5cGVvZiBtYXBwaW5nLm9yaWdpbmFsTGluZSA9PT0gXCJudW1iZXJcIikge1xuICAgICAgICAgICAgbGV0IGN1cnJlbnRTb3VyY2UgPSBtYXBwaW5nLnNvdXJjZTtcbiAgICAgICAgICAgIHdoaWxlIChvcmlnaW5hbE1hcHBpbmdzLmxlbmd0aCA8PSBjdXJyZW50U291cmNlKSB7XG4gICAgICAgICAgICAgIG9yaWdpbmFsTWFwcGluZ3MucHVzaChudWxsKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChvcmlnaW5hbE1hcHBpbmdzW2N1cnJlbnRTb3VyY2VdID09PSBudWxsKSB7XG4gICAgICAgICAgICAgIG9yaWdpbmFsTWFwcGluZ3NbY3VycmVudFNvdXJjZV0gPSBbXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG9yaWdpbmFsTWFwcGluZ3NbY3VycmVudFNvdXJjZV0ucHVzaChtYXBwaW5nKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHNvcnRHZW5lcmF0ZWQoZ2VuZXJhdGVkTWFwcGluZ3MsIHN1YmFycmF5U3RhcnQpO1xuICAgICAgdGhpcy5fX2dlbmVyYXRlZE1hcHBpbmdzID0gZ2VuZXJhdGVkTWFwcGluZ3M7XG4gICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG9yaWdpbmFsTWFwcGluZ3MubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgaWYgKG9yaWdpbmFsTWFwcGluZ3NbaV0gIT0gbnVsbCkge1xuICAgICAgICAgIHF1aWNrU29ydChvcmlnaW5hbE1hcHBpbmdzW2ldLCB1dGlsLmNvbXBhcmVCeU9yaWdpbmFsUG9zaXRpb25zTm9Tb3VyY2UpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLl9fb3JpZ2luYWxNYXBwaW5ncyA9IFtdLmNvbmNhdCguLi5vcmlnaW5hbE1hcHBpbmdzKTtcbiAgICB9O1xuICAgIEJhc2ljU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLl9maW5kTWFwcGluZyA9IGZ1bmN0aW9uIFNvdXJjZU1hcENvbnN1bWVyX2ZpbmRNYXBwaW5nKGFOZWVkbGUsIGFNYXBwaW5ncywgYUxpbmVOYW1lLCBhQ29sdW1uTmFtZSwgYUNvbXBhcmF0b3IsIGFCaWFzKSB7XG4gICAgICBpZiAoYU5lZWRsZVthTGluZU5hbWVdIDw9IDApIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkxpbmUgbXVzdCBiZSBncmVhdGVyIHRoYW4gb3IgZXF1YWwgdG8gMSwgZ290IFwiICsgYU5lZWRsZVthTGluZU5hbWVdKTtcbiAgICAgIH1cbiAgICAgIGlmIChhTmVlZGxlW2FDb2x1bW5OYW1lXSA8IDApIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNvbHVtbiBtdXN0IGJlIGdyZWF0ZXIgdGhhbiBvciBlcXVhbCB0byAwLCBnb3QgXCIgKyBhTmVlZGxlW2FDb2x1bW5OYW1lXSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gYmluYXJ5U2VhcmNoLnNlYXJjaChhTmVlZGxlLCBhTWFwcGluZ3MsIGFDb21wYXJhdG9yLCBhQmlhcyk7XG4gICAgfTtcbiAgICBCYXNpY1NvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5jb21wdXRlQ29sdW1uU3BhbnMgPSBmdW5jdGlvbiBTb3VyY2VNYXBDb25zdW1lcl9jb21wdXRlQ29sdW1uU3BhbnMoKSB7XG4gICAgICBmb3IgKHZhciBpbmRleCA9IDA7IGluZGV4IDwgdGhpcy5fZ2VuZXJhdGVkTWFwcGluZ3MubGVuZ3RoOyArK2luZGV4KSB7XG4gICAgICAgIHZhciBtYXBwaW5nID0gdGhpcy5fZ2VuZXJhdGVkTWFwcGluZ3NbaW5kZXhdO1xuICAgICAgICBpZiAoaW5kZXggKyAxIDwgdGhpcy5fZ2VuZXJhdGVkTWFwcGluZ3MubGVuZ3RoKSB7XG4gICAgICAgICAgdmFyIG5leHRNYXBwaW5nID0gdGhpcy5fZ2VuZXJhdGVkTWFwcGluZ3NbaW5kZXggKyAxXTtcbiAgICAgICAgICBpZiAobWFwcGluZy5nZW5lcmF0ZWRMaW5lID09PSBuZXh0TWFwcGluZy5nZW5lcmF0ZWRMaW5lKSB7XG4gICAgICAgICAgICBtYXBwaW5nLmxhc3RHZW5lcmF0ZWRDb2x1bW4gPSBuZXh0TWFwcGluZy5nZW5lcmF0ZWRDb2x1bW4gLSAxO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIG1hcHBpbmcubGFzdEdlbmVyYXRlZENvbHVtbiA9IEluZmluaXR5O1xuICAgICAgfVxuICAgIH07XG4gICAgQmFzaWNTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUub3JpZ2luYWxQb3NpdGlvbkZvciA9IGZ1bmN0aW9uIFNvdXJjZU1hcENvbnN1bWVyX29yaWdpbmFsUG9zaXRpb25Gb3IoYUFyZ3MpIHtcbiAgICAgIHZhciBuZWVkbGUgPSB7XG4gICAgICAgIGdlbmVyYXRlZExpbmU6IHV0aWwuZ2V0QXJnKGFBcmdzLCBcImxpbmVcIiksXG4gICAgICAgIGdlbmVyYXRlZENvbHVtbjogdXRpbC5nZXRBcmcoYUFyZ3MsIFwiY29sdW1uXCIpXG4gICAgICB9O1xuICAgICAgdmFyIGluZGV4ID0gdGhpcy5fZmluZE1hcHBpbmcoXG4gICAgICAgIG5lZWRsZSxcbiAgICAgICAgdGhpcy5fZ2VuZXJhdGVkTWFwcGluZ3MsXG4gICAgICAgIFwiZ2VuZXJhdGVkTGluZVwiLFxuICAgICAgICBcImdlbmVyYXRlZENvbHVtblwiLFxuICAgICAgICB1dGlsLmNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0RlZmxhdGVkLFxuICAgICAgICB1dGlsLmdldEFyZyhhQXJncywgXCJiaWFzXCIsIFNvdXJjZU1hcENvbnN1bWVyMi5HUkVBVEVTVF9MT1dFUl9CT1VORClcbiAgICAgICk7XG4gICAgICBpZiAoaW5kZXggPj0gMCkge1xuICAgICAgICB2YXIgbWFwcGluZyA9IHRoaXMuX2dlbmVyYXRlZE1hcHBpbmdzW2luZGV4XTtcbiAgICAgICAgaWYgKG1hcHBpbmcuZ2VuZXJhdGVkTGluZSA9PT0gbmVlZGxlLmdlbmVyYXRlZExpbmUpIHtcbiAgICAgICAgICB2YXIgc291cmNlID0gdXRpbC5nZXRBcmcobWFwcGluZywgXCJzb3VyY2VcIiwgbnVsbCk7XG4gICAgICAgICAgaWYgKHNvdXJjZSAhPT0gbnVsbCkge1xuICAgICAgICAgICAgc291cmNlID0gdGhpcy5fc291cmNlcy5hdChzb3VyY2UpO1xuICAgICAgICAgICAgc291cmNlID0gdXRpbC5jb21wdXRlU291cmNlVVJMKHRoaXMuc291cmNlUm9vdCwgc291cmNlLCB0aGlzLl9zb3VyY2VNYXBVUkwpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB2YXIgbmFtZSA9IHV0aWwuZ2V0QXJnKG1hcHBpbmcsIFwibmFtZVwiLCBudWxsKTtcbiAgICAgICAgICBpZiAobmFtZSAhPT0gbnVsbCkge1xuICAgICAgICAgICAgbmFtZSA9IHRoaXMuX25hbWVzLmF0KG5hbWUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc291cmNlLFxuICAgICAgICAgICAgbGluZTogdXRpbC5nZXRBcmcobWFwcGluZywgXCJvcmlnaW5hbExpbmVcIiwgbnVsbCksXG4gICAgICAgICAgICBjb2x1bW46IHV0aWwuZ2V0QXJnKG1hcHBpbmcsIFwib3JpZ2luYWxDb2x1bW5cIiwgbnVsbCksXG4gICAgICAgICAgICBuYW1lXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc291cmNlOiBudWxsLFxuICAgICAgICBsaW5lOiBudWxsLFxuICAgICAgICBjb2x1bW46IG51bGwsXG4gICAgICAgIG5hbWU6IG51bGxcbiAgICAgIH07XG4gICAgfTtcbiAgICBCYXNpY1NvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5oYXNDb250ZW50c09mQWxsU291cmNlcyA9IGZ1bmN0aW9uIEJhc2ljU291cmNlTWFwQ29uc3VtZXJfaGFzQ29udGVudHNPZkFsbFNvdXJjZXMoKSB7XG4gICAgICBpZiAoIXRoaXMuc291cmNlc0NvbnRlbnQpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXMuc291cmNlc0NvbnRlbnQubGVuZ3RoID49IHRoaXMuX3NvdXJjZXMuc2l6ZSgpICYmICF0aGlzLnNvdXJjZXNDb250ZW50LnNvbWUoZnVuY3Rpb24oc2MpIHtcbiAgICAgICAgcmV0dXJuIHNjID09IG51bGw7XG4gICAgICB9KTtcbiAgICB9O1xuICAgIEJhc2ljU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLnNvdXJjZUNvbnRlbnRGb3IgPSBmdW5jdGlvbiBTb3VyY2VNYXBDb25zdW1lcl9zb3VyY2VDb250ZW50Rm9yKGFTb3VyY2UsIG51bGxPbk1pc3NpbmcpIHtcbiAgICAgIGlmICghdGhpcy5zb3VyY2VzQ29udGVudCkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICAgIHZhciBpbmRleCA9IHRoaXMuX2ZpbmRTb3VyY2VJbmRleChhU291cmNlKTtcbiAgICAgIGlmIChpbmRleCA+PSAwKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnNvdXJjZXNDb250ZW50W2luZGV4XTtcbiAgICAgIH1cbiAgICAgIHZhciByZWxhdGl2ZVNvdXJjZSA9IGFTb3VyY2U7XG4gICAgICBpZiAodGhpcy5zb3VyY2VSb290ICE9IG51bGwpIHtcbiAgICAgICAgcmVsYXRpdmVTb3VyY2UgPSB1dGlsLnJlbGF0aXZlKHRoaXMuc291cmNlUm9vdCwgcmVsYXRpdmVTb3VyY2UpO1xuICAgICAgfVxuICAgICAgdmFyIHVybDtcbiAgICAgIGlmICh0aGlzLnNvdXJjZVJvb3QgIT0gbnVsbCAmJiAodXJsID0gdXRpbC51cmxQYXJzZSh0aGlzLnNvdXJjZVJvb3QpKSkge1xuICAgICAgICB2YXIgZmlsZVVyaUFic1BhdGggPSByZWxhdGl2ZVNvdXJjZS5yZXBsYWNlKC9eZmlsZTpcXC9cXC8vLCBcIlwiKTtcbiAgICAgICAgaWYgKHVybC5zY2hlbWUgPT0gXCJmaWxlXCIgJiYgdGhpcy5fc291cmNlcy5oYXMoZmlsZVVyaUFic1BhdGgpKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuc291cmNlc0NvbnRlbnRbdGhpcy5fc291cmNlcy5pbmRleE9mKGZpbGVVcmlBYnNQYXRoKV07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCghdXJsLnBhdGggfHwgdXJsLnBhdGggPT0gXCIvXCIpICYmIHRoaXMuX3NvdXJjZXMuaGFzKFwiL1wiICsgcmVsYXRpdmVTb3VyY2UpKSB7XG4gICAgICAgICAgcmV0dXJuIHRoaXMuc291cmNlc0NvbnRlbnRbdGhpcy5fc291cmNlcy5pbmRleE9mKFwiL1wiICsgcmVsYXRpdmVTb3VyY2UpXTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKG51bGxPbk1pc3NpbmcpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1wiJyArIHJlbGF0aXZlU291cmNlICsgJ1wiIGlzIG5vdCBpbiB0aGUgU291cmNlTWFwLicpO1xuICAgICAgfVxuICAgIH07XG4gICAgQmFzaWNTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuZ2VuZXJhdGVkUG9zaXRpb25Gb3IgPSBmdW5jdGlvbiBTb3VyY2VNYXBDb25zdW1lcl9nZW5lcmF0ZWRQb3NpdGlvbkZvcihhQXJncykge1xuICAgICAgdmFyIHNvdXJjZSA9IHV0aWwuZ2V0QXJnKGFBcmdzLCBcInNvdXJjZVwiKTtcbiAgICAgIHNvdXJjZSA9IHRoaXMuX2ZpbmRTb3VyY2VJbmRleChzb3VyY2UpO1xuICAgICAgaWYgKHNvdXJjZSA8IDApIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBsaW5lOiBudWxsLFxuICAgICAgICAgIGNvbHVtbjogbnVsbCxcbiAgICAgICAgICBsYXN0Q29sdW1uOiBudWxsXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICB2YXIgbmVlZGxlID0ge1xuICAgICAgICBzb3VyY2UsXG4gICAgICAgIG9yaWdpbmFsTGluZTogdXRpbC5nZXRBcmcoYUFyZ3MsIFwibGluZVwiKSxcbiAgICAgICAgb3JpZ2luYWxDb2x1bW46IHV0aWwuZ2V0QXJnKGFBcmdzLCBcImNvbHVtblwiKVxuICAgICAgfTtcbiAgICAgIHZhciBpbmRleCA9IHRoaXMuX2ZpbmRNYXBwaW5nKFxuICAgICAgICBuZWVkbGUsXG4gICAgICAgIHRoaXMuX29yaWdpbmFsTWFwcGluZ3MsXG4gICAgICAgIFwib3JpZ2luYWxMaW5lXCIsXG4gICAgICAgIFwib3JpZ2luYWxDb2x1bW5cIixcbiAgICAgICAgdXRpbC5jb21wYXJlQnlPcmlnaW5hbFBvc2l0aW9ucyxcbiAgICAgICAgdXRpbC5nZXRBcmcoYUFyZ3MsIFwiYmlhc1wiLCBTb3VyY2VNYXBDb25zdW1lcjIuR1JFQVRFU1RfTE9XRVJfQk9VTkQpXG4gICAgICApO1xuICAgICAgaWYgKGluZGV4ID49IDApIHtcbiAgICAgICAgdmFyIG1hcHBpbmcgPSB0aGlzLl9vcmlnaW5hbE1hcHBpbmdzW2luZGV4XTtcbiAgICAgICAgaWYgKG1hcHBpbmcuc291cmNlID09PSBuZWVkbGUuc291cmNlKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGxpbmU6IHV0aWwuZ2V0QXJnKG1hcHBpbmcsIFwiZ2VuZXJhdGVkTGluZVwiLCBudWxsKSxcbiAgICAgICAgICAgIGNvbHVtbjogdXRpbC5nZXRBcmcobWFwcGluZywgXCJnZW5lcmF0ZWRDb2x1bW5cIiwgbnVsbCksXG4gICAgICAgICAgICBsYXN0Q29sdW1uOiB1dGlsLmdldEFyZyhtYXBwaW5nLCBcImxhc3RHZW5lcmF0ZWRDb2x1bW5cIiwgbnVsbClcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4ge1xuICAgICAgICBsaW5lOiBudWxsLFxuICAgICAgICBjb2x1bW46IG51bGwsXG4gICAgICAgIGxhc3RDb2x1bW46IG51bGxcbiAgICAgIH07XG4gICAgfTtcbiAgICBleHBvcnRzLkJhc2ljU291cmNlTWFwQ29uc3VtZXIgPSBCYXNpY1NvdXJjZU1hcENvbnN1bWVyO1xuICAgIGZ1bmN0aW9uIEluZGV4ZWRTb3VyY2VNYXBDb25zdW1lcihhU291cmNlTWFwLCBhU291cmNlTWFwVVJMKSB7XG4gICAgICB2YXIgc291cmNlTWFwID0gYVNvdXJjZU1hcDtcbiAgICAgIGlmICh0eXBlb2YgYVNvdXJjZU1hcCA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICBzb3VyY2VNYXAgPSB1dGlsLnBhcnNlU291cmNlTWFwSW5wdXQoYVNvdXJjZU1hcCk7XG4gICAgICB9XG4gICAgICB2YXIgdmVyc2lvbiA9IHV0aWwuZ2V0QXJnKHNvdXJjZU1hcCwgXCJ2ZXJzaW9uXCIpO1xuICAgICAgdmFyIHNlY3Rpb25zID0gdXRpbC5nZXRBcmcoc291cmNlTWFwLCBcInNlY3Rpb25zXCIpO1xuICAgICAgaWYgKHZlcnNpb24gIT0gdGhpcy5fdmVyc2lvbikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJVbnN1cHBvcnRlZCB2ZXJzaW9uOiBcIiArIHZlcnNpb24pO1xuICAgICAgfVxuICAgICAgdGhpcy5fc291cmNlcyA9IG5ldyBBcnJheVNldCgpO1xuICAgICAgdGhpcy5fbmFtZXMgPSBuZXcgQXJyYXlTZXQoKTtcbiAgICAgIHZhciBsYXN0T2Zmc2V0ID0ge1xuICAgICAgICBsaW5lOiAtMSxcbiAgICAgICAgY29sdW1uOiAwXG4gICAgICB9O1xuICAgICAgdGhpcy5fc2VjdGlvbnMgPSBzZWN0aW9ucy5tYXAoZnVuY3Rpb24ocykge1xuICAgICAgICBpZiAocy51cmwpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJTdXBwb3J0IGZvciB1cmwgZmllbGQgaW4gc2VjdGlvbnMgbm90IGltcGxlbWVudGVkLlwiKTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgb2Zmc2V0ID0gdXRpbC5nZXRBcmcocywgXCJvZmZzZXRcIik7XG4gICAgICAgIHZhciBvZmZzZXRMaW5lID0gdXRpbC5nZXRBcmcob2Zmc2V0LCBcImxpbmVcIik7XG4gICAgICAgIHZhciBvZmZzZXRDb2x1bW4gPSB1dGlsLmdldEFyZyhvZmZzZXQsIFwiY29sdW1uXCIpO1xuICAgICAgICBpZiAob2Zmc2V0TGluZSA8IGxhc3RPZmZzZXQubGluZSB8fCBvZmZzZXRMaW5lID09PSBsYXN0T2Zmc2V0LmxpbmUgJiYgb2Zmc2V0Q29sdW1uIDwgbGFzdE9mZnNldC5jb2x1bW4pIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJTZWN0aW9uIG9mZnNldHMgbXVzdCBiZSBvcmRlcmVkIGFuZCBub24tb3ZlcmxhcHBpbmcuXCIpO1xuICAgICAgICB9XG4gICAgICAgIGxhc3RPZmZzZXQgPSBvZmZzZXQ7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgZ2VuZXJhdGVkT2Zmc2V0OiB7XG4gICAgICAgICAgICAvLyBUaGUgb2Zmc2V0IGZpZWxkcyBhcmUgMC1iYXNlZCwgYnV0IHdlIHVzZSAxLWJhc2VkIGluZGljZXMgd2hlblxuICAgICAgICAgICAgLy8gZW5jb2RpbmcvZGVjb2RpbmcgZnJvbSBWTFEuXG4gICAgICAgICAgICBnZW5lcmF0ZWRMaW5lOiBvZmZzZXRMaW5lICsgMSxcbiAgICAgICAgICAgIGdlbmVyYXRlZENvbHVtbjogb2Zmc2V0Q29sdW1uICsgMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgY29uc3VtZXI6IG5ldyBTb3VyY2VNYXBDb25zdW1lcjIodXRpbC5nZXRBcmcocywgXCJtYXBcIiksIGFTb3VyY2VNYXBVUkwpXG4gICAgICAgIH07XG4gICAgICB9KTtcbiAgICB9XG4gICAgSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUoU291cmNlTWFwQ29uc3VtZXIyLnByb3RvdHlwZSk7XG4gICAgSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5jb25zdHJ1Y3RvciA9IFNvdXJjZU1hcENvbnN1bWVyMjtcbiAgICBJbmRleGVkU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLl92ZXJzaW9uID0gMztcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZSwgXCJzb3VyY2VzXCIsIHtcbiAgICAgIGdldDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBzb3VyY2VzID0gW107XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy5fc2VjdGlvbnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IHRoaXMuX3NlY3Rpb25zW2ldLmNvbnN1bWVyLnNvdXJjZXMubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgIHNvdXJjZXMucHVzaCh0aGlzLl9zZWN0aW9uc1tpXS5jb25zdW1lci5zb3VyY2VzW2pdKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHNvdXJjZXM7XG4gICAgICB9XG4gICAgfSk7XG4gICAgSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5vcmlnaW5hbFBvc2l0aW9uRm9yID0gZnVuY3Rpb24gSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyX29yaWdpbmFsUG9zaXRpb25Gb3IoYUFyZ3MpIHtcbiAgICAgIHZhciBuZWVkbGUgPSB7XG4gICAgICAgIGdlbmVyYXRlZExpbmU6IHV0aWwuZ2V0QXJnKGFBcmdzLCBcImxpbmVcIiksXG4gICAgICAgIGdlbmVyYXRlZENvbHVtbjogdXRpbC5nZXRBcmcoYUFyZ3MsIFwiY29sdW1uXCIpXG4gICAgICB9O1xuICAgICAgdmFyIHNlY3Rpb25JbmRleCA9IGJpbmFyeVNlYXJjaC5zZWFyY2goXG4gICAgICAgIG5lZWRsZSxcbiAgICAgICAgdGhpcy5fc2VjdGlvbnMsXG4gICAgICAgIGZ1bmN0aW9uKG5lZWRsZTIsIHNlY3Rpb24yKSB7XG4gICAgICAgICAgdmFyIGNtcCA9IG5lZWRsZTIuZ2VuZXJhdGVkTGluZSAtIHNlY3Rpb24yLmdlbmVyYXRlZE9mZnNldC5nZW5lcmF0ZWRMaW5lO1xuICAgICAgICAgIGlmIChjbXApIHtcbiAgICAgICAgICAgIHJldHVybiBjbXA7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBuZWVkbGUyLmdlbmVyYXRlZENvbHVtbiAtIHNlY3Rpb24yLmdlbmVyYXRlZE9mZnNldC5nZW5lcmF0ZWRDb2x1bW47XG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgICB2YXIgc2VjdGlvbiA9IHRoaXMuX3NlY3Rpb25zW3NlY3Rpb25JbmRleF07XG4gICAgICBpZiAoIXNlY3Rpb24pIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzb3VyY2U6IG51bGwsXG4gICAgICAgICAgbGluZTogbnVsbCxcbiAgICAgICAgICBjb2x1bW46IG51bGwsXG4gICAgICAgICAgbmFtZTogbnVsbFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHNlY3Rpb24uY29uc3VtZXIub3JpZ2luYWxQb3NpdGlvbkZvcih7XG4gICAgICAgIGxpbmU6IG5lZWRsZS5nZW5lcmF0ZWRMaW5lIC0gKHNlY3Rpb24uZ2VuZXJhdGVkT2Zmc2V0LmdlbmVyYXRlZExpbmUgLSAxKSxcbiAgICAgICAgY29sdW1uOiBuZWVkbGUuZ2VuZXJhdGVkQ29sdW1uIC0gKHNlY3Rpb24uZ2VuZXJhdGVkT2Zmc2V0LmdlbmVyYXRlZExpbmUgPT09IG5lZWRsZS5nZW5lcmF0ZWRMaW5lID8gc2VjdGlvbi5nZW5lcmF0ZWRPZmZzZXQuZ2VuZXJhdGVkQ29sdW1uIC0gMSA6IDApLFxuICAgICAgICBiaWFzOiBhQXJncy5iaWFzXG4gICAgICB9KTtcbiAgICB9O1xuICAgIEluZGV4ZWRTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuaGFzQ29udGVudHNPZkFsbFNvdXJjZXMgPSBmdW5jdGlvbiBJbmRleGVkU291cmNlTWFwQ29uc3VtZXJfaGFzQ29udGVudHNPZkFsbFNvdXJjZXMoKSB7XG4gICAgICByZXR1cm4gdGhpcy5fc2VjdGlvbnMuZXZlcnkoZnVuY3Rpb24ocykge1xuICAgICAgICByZXR1cm4gcy5jb25zdW1lci5oYXNDb250ZW50c09mQWxsU291cmNlcygpO1xuICAgICAgfSk7XG4gICAgfTtcbiAgICBJbmRleGVkU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLnNvdXJjZUNvbnRlbnRGb3IgPSBmdW5jdGlvbiBJbmRleGVkU291cmNlTWFwQ29uc3VtZXJfc291cmNlQ29udGVudEZvcihhU291cmNlLCBudWxsT25NaXNzaW5nKSB7XG4gICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuX3NlY3Rpb25zLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHZhciBzZWN0aW9uID0gdGhpcy5fc2VjdGlvbnNbaV07XG4gICAgICAgIHZhciBjb250ZW50ID0gc2VjdGlvbi5jb25zdW1lci5zb3VyY2VDb250ZW50Rm9yKGFTb3VyY2UsIHRydWUpO1xuICAgICAgICBpZiAoY29udGVudCkge1xuICAgICAgICAgIHJldHVybiBjb250ZW50O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAobnVsbE9uTWlzc2luZykge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignXCInICsgYVNvdXJjZSArICdcIiBpcyBub3QgaW4gdGhlIFNvdXJjZU1hcC4nKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIEluZGV4ZWRTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuZ2VuZXJhdGVkUG9zaXRpb25Gb3IgPSBmdW5jdGlvbiBJbmRleGVkU291cmNlTWFwQ29uc3VtZXJfZ2VuZXJhdGVkUG9zaXRpb25Gb3IoYUFyZ3MpIHtcbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy5fc2VjdGlvbnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgdmFyIHNlY3Rpb24gPSB0aGlzLl9zZWN0aW9uc1tpXTtcbiAgICAgICAgaWYgKHNlY3Rpb24uY29uc3VtZXIuX2ZpbmRTb3VyY2VJbmRleCh1dGlsLmdldEFyZyhhQXJncywgXCJzb3VyY2VcIikpID09PSAtMSkge1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIHZhciBnZW5lcmF0ZWRQb3NpdGlvbiA9IHNlY3Rpb24uY29uc3VtZXIuZ2VuZXJhdGVkUG9zaXRpb25Gb3IoYUFyZ3MpO1xuICAgICAgICBpZiAoZ2VuZXJhdGVkUG9zaXRpb24pIHtcbiAgICAgICAgICB2YXIgcmV0ID0ge1xuICAgICAgICAgICAgbGluZTogZ2VuZXJhdGVkUG9zaXRpb24ubGluZSArIChzZWN0aW9uLmdlbmVyYXRlZE9mZnNldC5nZW5lcmF0ZWRMaW5lIC0gMSksXG4gICAgICAgICAgICBjb2x1bW46IGdlbmVyYXRlZFBvc2l0aW9uLmNvbHVtbiArIChzZWN0aW9uLmdlbmVyYXRlZE9mZnNldC5nZW5lcmF0ZWRMaW5lID09PSBnZW5lcmF0ZWRQb3NpdGlvbi5saW5lID8gc2VjdGlvbi5nZW5lcmF0ZWRPZmZzZXQuZ2VuZXJhdGVkQ29sdW1uIC0gMSA6IDApXG4gICAgICAgICAgfTtcbiAgICAgICAgICByZXR1cm4gcmV0O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4ge1xuICAgICAgICBsaW5lOiBudWxsLFxuICAgICAgICBjb2x1bW46IG51bGxcbiAgICAgIH07XG4gICAgfTtcbiAgICBJbmRleGVkU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLl9wYXJzZU1hcHBpbmdzID0gZnVuY3Rpb24gSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyX3BhcnNlTWFwcGluZ3MoYVN0ciwgYVNvdXJjZVJvb3QpIHtcbiAgICAgIHRoaXMuX19nZW5lcmF0ZWRNYXBwaW5ncyA9IFtdO1xuICAgICAgdGhpcy5fX29yaWdpbmFsTWFwcGluZ3MgPSBbXTtcbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy5fc2VjdGlvbnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgdmFyIHNlY3Rpb24gPSB0aGlzLl9zZWN0aW9uc1tpXTtcbiAgICAgICAgdmFyIHNlY3Rpb25NYXBwaW5ncyA9IHNlY3Rpb24uY29uc3VtZXIuX2dlbmVyYXRlZE1hcHBpbmdzO1xuICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IHNlY3Rpb25NYXBwaW5ncy5sZW5ndGg7IGorKykge1xuICAgICAgICAgIHZhciBtYXBwaW5nID0gc2VjdGlvbk1hcHBpbmdzW2pdO1xuICAgICAgICAgIHZhciBzb3VyY2UgPSBzZWN0aW9uLmNvbnN1bWVyLl9zb3VyY2VzLmF0KG1hcHBpbmcuc291cmNlKTtcbiAgICAgICAgICBzb3VyY2UgPSB1dGlsLmNvbXB1dGVTb3VyY2VVUkwoc2VjdGlvbi5jb25zdW1lci5zb3VyY2VSb290LCBzb3VyY2UsIHRoaXMuX3NvdXJjZU1hcFVSTCk7XG4gICAgICAgICAgdGhpcy5fc291cmNlcy5hZGQoc291cmNlKTtcbiAgICAgICAgICBzb3VyY2UgPSB0aGlzLl9zb3VyY2VzLmluZGV4T2Yoc291cmNlKTtcbiAgICAgICAgICB2YXIgbmFtZSA9IG51bGw7XG4gICAgICAgICAgaWYgKG1hcHBpbmcubmFtZSkge1xuICAgICAgICAgICAgbmFtZSA9IHNlY3Rpb24uY29uc3VtZXIuX25hbWVzLmF0KG1hcHBpbmcubmFtZSk7XG4gICAgICAgICAgICB0aGlzLl9uYW1lcy5hZGQobmFtZSk7XG4gICAgICAgICAgICBuYW1lID0gdGhpcy5fbmFtZXMuaW5kZXhPZihuYW1lKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIGFkanVzdGVkTWFwcGluZyA9IHtcbiAgICAgICAgICAgIHNvdXJjZSxcbiAgICAgICAgICAgIGdlbmVyYXRlZExpbmU6IG1hcHBpbmcuZ2VuZXJhdGVkTGluZSArIChzZWN0aW9uLmdlbmVyYXRlZE9mZnNldC5nZW5lcmF0ZWRMaW5lIC0gMSksXG4gICAgICAgICAgICBnZW5lcmF0ZWRDb2x1bW46IG1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uICsgKHNlY3Rpb24uZ2VuZXJhdGVkT2Zmc2V0LmdlbmVyYXRlZExpbmUgPT09IG1hcHBpbmcuZ2VuZXJhdGVkTGluZSA/IHNlY3Rpb24uZ2VuZXJhdGVkT2Zmc2V0LmdlbmVyYXRlZENvbHVtbiAtIDEgOiAwKSxcbiAgICAgICAgICAgIG9yaWdpbmFsTGluZTogbWFwcGluZy5vcmlnaW5hbExpbmUsXG4gICAgICAgICAgICBvcmlnaW5hbENvbHVtbjogbWFwcGluZy5vcmlnaW5hbENvbHVtbixcbiAgICAgICAgICAgIG5hbWVcbiAgICAgICAgICB9O1xuICAgICAgICAgIHRoaXMuX19nZW5lcmF0ZWRNYXBwaW5ncy5wdXNoKGFkanVzdGVkTWFwcGluZyk7XG4gICAgICAgICAgaWYgKHR5cGVvZiBhZGp1c3RlZE1hcHBpbmcub3JpZ2luYWxMaW5lID09PSBcIm51bWJlclwiKSB7XG4gICAgICAgICAgICB0aGlzLl9fb3JpZ2luYWxNYXBwaW5ncy5wdXNoKGFkanVzdGVkTWFwcGluZyk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBxdWlja1NvcnQodGhpcy5fX2dlbmVyYXRlZE1hcHBpbmdzLCB1dGlsLmNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0RlZmxhdGVkKTtcbiAgICAgIHF1aWNrU29ydCh0aGlzLl9fb3JpZ2luYWxNYXBwaW5ncywgdXRpbC5jb21wYXJlQnlPcmlnaW5hbFBvc2l0aW9ucyk7XG4gICAgfTtcbiAgICBleHBvcnRzLkluZGV4ZWRTb3VyY2VNYXBDb25zdW1lciA9IEluZGV4ZWRTb3VyY2VNYXBDb25zdW1lcjtcbiAgfVxufSk7XG5cbi8vIG5vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi9zb3VyY2Utbm9kZS5qc1xudmFyIHJlcXVpcmVfc291cmNlX25vZGUgPSBfX2NvbW1vbkpTKHtcbiAgXCJub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvc291cmNlLW5vZGUuanNcIihleHBvcnRzKSB7XG4gICAgdmFyIFNvdXJjZU1hcEdlbmVyYXRvciA9IHJlcXVpcmVfc291cmNlX21hcF9nZW5lcmF0b3IoKS5Tb3VyY2VNYXBHZW5lcmF0b3I7XG4gICAgdmFyIHV0aWwgPSByZXF1aXJlX3V0aWwoKTtcbiAgICB2YXIgUkVHRVhfTkVXTElORSA9IC8oXFxyP1xcbikvO1xuICAgIHZhciBORVdMSU5FX0NPREUgPSAxMDtcbiAgICB2YXIgaXNTb3VyY2VOb2RlID0gXCIkJCRpc1NvdXJjZU5vZGUkJCRcIjtcbiAgICBmdW5jdGlvbiBTb3VyY2VOb2RlKGFMaW5lLCBhQ29sdW1uLCBhU291cmNlLCBhQ2h1bmtzLCBhTmFtZSkge1xuICAgICAgdGhpcy5jaGlsZHJlbiA9IFtdO1xuICAgICAgdGhpcy5zb3VyY2VDb250ZW50cyA9IHt9O1xuICAgICAgdGhpcy5saW5lID0gYUxpbmUgPT0gbnVsbCA/IG51bGwgOiBhTGluZTtcbiAgICAgIHRoaXMuY29sdW1uID0gYUNvbHVtbiA9PSBudWxsID8gbnVsbCA6IGFDb2x1bW47XG4gICAgICB0aGlzLnNvdXJjZSA9IGFTb3VyY2UgPT0gbnVsbCA/IG51bGwgOiBhU291cmNlO1xuICAgICAgdGhpcy5uYW1lID0gYU5hbWUgPT0gbnVsbCA/IG51bGwgOiBhTmFtZTtcbiAgICAgIHRoaXNbaXNTb3VyY2VOb2RlXSA9IHRydWU7XG4gICAgICBpZiAoYUNodW5rcyAhPSBudWxsKVxuICAgICAgICB0aGlzLmFkZChhQ2h1bmtzKTtcbiAgICB9XG4gICAgU291cmNlTm9kZS5mcm9tU3RyaW5nV2l0aFNvdXJjZU1hcCA9IGZ1bmN0aW9uIFNvdXJjZU5vZGVfZnJvbVN0cmluZ1dpdGhTb3VyY2VNYXAoYUdlbmVyYXRlZENvZGUsIGFTb3VyY2VNYXBDb25zdW1lciwgYVJlbGF0aXZlUGF0aCkge1xuICAgICAgdmFyIG5vZGUgPSBuZXcgU291cmNlTm9kZSgpO1xuICAgICAgdmFyIHJlbWFpbmluZ0xpbmVzID0gYUdlbmVyYXRlZENvZGUuc3BsaXQoUkVHRVhfTkVXTElORSk7XG4gICAgICB2YXIgcmVtYWluaW5nTGluZXNJbmRleCA9IDA7XG4gICAgICB2YXIgc2hpZnROZXh0TGluZSA9IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgbGluZUNvbnRlbnRzID0gZ2V0TmV4dExpbmUoKTtcbiAgICAgICAgdmFyIG5ld0xpbmUgPSBnZXROZXh0TGluZSgpIHx8IFwiXCI7XG4gICAgICAgIHJldHVybiBsaW5lQ29udGVudHMgKyBuZXdMaW5lO1xuICAgICAgICBmdW5jdGlvbiBnZXROZXh0TGluZSgpIHtcbiAgICAgICAgICByZXR1cm4gcmVtYWluaW5nTGluZXNJbmRleCA8IHJlbWFpbmluZ0xpbmVzLmxlbmd0aCA/IHJlbWFpbmluZ0xpbmVzW3JlbWFpbmluZ0xpbmVzSW5kZXgrK10gOiB2b2lkIDA7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICB2YXIgbGFzdEdlbmVyYXRlZExpbmUgPSAxLCBsYXN0R2VuZXJhdGVkQ29sdW1uID0gMDtcbiAgICAgIHZhciBsYXN0TWFwcGluZyA9IG51bGw7XG4gICAgICBhU291cmNlTWFwQ29uc3VtZXIuZWFjaE1hcHBpbmcoZnVuY3Rpb24obWFwcGluZykge1xuICAgICAgICBpZiAobGFzdE1hcHBpbmcgIT09IG51bGwpIHtcbiAgICAgICAgICBpZiAobGFzdEdlbmVyYXRlZExpbmUgPCBtYXBwaW5nLmdlbmVyYXRlZExpbmUpIHtcbiAgICAgICAgICAgIGFkZE1hcHBpbmdXaXRoQ29kZShsYXN0TWFwcGluZywgc2hpZnROZXh0TGluZSgpKTtcbiAgICAgICAgICAgIGxhc3RHZW5lcmF0ZWRMaW5lKys7XG4gICAgICAgICAgICBsYXN0R2VuZXJhdGVkQ29sdW1uID0gMDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdmFyIG5leHRMaW5lID0gcmVtYWluaW5nTGluZXNbcmVtYWluaW5nTGluZXNJbmRleF0gfHwgXCJcIjtcbiAgICAgICAgICAgIHZhciBjb2RlID0gbmV4dExpbmUuc3Vic3RyKDAsIG1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uIC0gbGFzdEdlbmVyYXRlZENvbHVtbik7XG4gICAgICAgICAgICByZW1haW5pbmdMaW5lc1tyZW1haW5pbmdMaW5lc0luZGV4XSA9IG5leHRMaW5lLnN1YnN0cihtYXBwaW5nLmdlbmVyYXRlZENvbHVtbiAtIGxhc3RHZW5lcmF0ZWRDb2x1bW4pO1xuICAgICAgICAgICAgbGFzdEdlbmVyYXRlZENvbHVtbiA9IG1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uO1xuICAgICAgICAgICAgYWRkTWFwcGluZ1dpdGhDb2RlKGxhc3RNYXBwaW5nLCBjb2RlKTtcbiAgICAgICAgICAgIGxhc3RNYXBwaW5nID0gbWFwcGluZztcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgd2hpbGUgKGxhc3RHZW5lcmF0ZWRMaW5lIDwgbWFwcGluZy5nZW5lcmF0ZWRMaW5lKSB7XG4gICAgICAgICAgbm9kZS5hZGQoc2hpZnROZXh0TGluZSgpKTtcbiAgICAgICAgICBsYXN0R2VuZXJhdGVkTGluZSsrO1xuICAgICAgICB9XG4gICAgICAgIGlmIChsYXN0R2VuZXJhdGVkQ29sdW1uIDwgbWFwcGluZy5nZW5lcmF0ZWRDb2x1bW4pIHtcbiAgICAgICAgICB2YXIgbmV4dExpbmUgPSByZW1haW5pbmdMaW5lc1tyZW1haW5pbmdMaW5lc0luZGV4XSB8fCBcIlwiO1xuICAgICAgICAgIG5vZGUuYWRkKG5leHRMaW5lLnN1YnN0cigwLCBtYXBwaW5nLmdlbmVyYXRlZENvbHVtbikpO1xuICAgICAgICAgIHJlbWFpbmluZ0xpbmVzW3JlbWFpbmluZ0xpbmVzSW5kZXhdID0gbmV4dExpbmUuc3Vic3RyKG1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uKTtcbiAgICAgICAgICBsYXN0R2VuZXJhdGVkQ29sdW1uID0gbWFwcGluZy5nZW5lcmF0ZWRDb2x1bW47XG4gICAgICAgIH1cbiAgICAgICAgbGFzdE1hcHBpbmcgPSBtYXBwaW5nO1xuICAgICAgfSwgdGhpcyk7XG4gICAgICBpZiAocmVtYWluaW5nTGluZXNJbmRleCA8IHJlbWFpbmluZ0xpbmVzLmxlbmd0aCkge1xuICAgICAgICBpZiAobGFzdE1hcHBpbmcpIHtcbiAgICAgICAgICBhZGRNYXBwaW5nV2l0aENvZGUobGFzdE1hcHBpbmcsIHNoaWZ0TmV4dExpbmUoKSk7XG4gICAgICAgIH1cbiAgICAgICAgbm9kZS5hZGQocmVtYWluaW5nTGluZXMuc3BsaWNlKHJlbWFpbmluZ0xpbmVzSW5kZXgpLmpvaW4oXCJcIikpO1xuICAgICAgfVxuICAgICAgYVNvdXJjZU1hcENvbnN1bWVyLnNvdXJjZXMuZm9yRWFjaChmdW5jdGlvbihzb3VyY2VGaWxlKSB7XG4gICAgICAgIHZhciBjb250ZW50ID0gYVNvdXJjZU1hcENvbnN1bWVyLnNvdXJjZUNvbnRlbnRGb3Ioc291cmNlRmlsZSk7XG4gICAgICAgIGlmIChjb250ZW50ICE9IG51bGwpIHtcbiAgICAgICAgICBpZiAoYVJlbGF0aXZlUGF0aCAhPSBudWxsKSB7XG4gICAgICAgICAgICBzb3VyY2VGaWxlID0gdXRpbC5qb2luKGFSZWxhdGl2ZVBhdGgsIHNvdXJjZUZpbGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBub2RlLnNldFNvdXJjZUNvbnRlbnQoc291cmNlRmlsZSwgY29udGVudCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIG5vZGU7XG4gICAgICBmdW5jdGlvbiBhZGRNYXBwaW5nV2l0aENvZGUobWFwcGluZywgY29kZSkge1xuICAgICAgICBpZiAobWFwcGluZyA9PT0gbnVsbCB8fCBtYXBwaW5nLnNvdXJjZSA9PT0gdm9pZCAwKSB7XG4gICAgICAgICAgbm9kZS5hZGQoY29kZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdmFyIHNvdXJjZSA9IGFSZWxhdGl2ZVBhdGggPyB1dGlsLmpvaW4oYVJlbGF0aXZlUGF0aCwgbWFwcGluZy5zb3VyY2UpIDogbWFwcGluZy5zb3VyY2U7XG4gICAgICAgICAgbm9kZS5hZGQobmV3IFNvdXJjZU5vZGUoXG4gICAgICAgICAgICBtYXBwaW5nLm9yaWdpbmFsTGluZSxcbiAgICAgICAgICAgIG1hcHBpbmcub3JpZ2luYWxDb2x1bW4sXG4gICAgICAgICAgICBzb3VyY2UsXG4gICAgICAgICAgICBjb2RlLFxuICAgICAgICAgICAgbWFwcGluZy5uYW1lXG4gICAgICAgICAgKSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICAgIFNvdXJjZU5vZGUucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uIFNvdXJjZU5vZGVfYWRkKGFDaHVuaykge1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoYUNodW5rKSkge1xuICAgICAgICBhQ2h1bmsuZm9yRWFjaChmdW5jdGlvbihjaHVuaykge1xuICAgICAgICAgIHRoaXMuYWRkKGNodW5rKTtcbiAgICAgICAgfSwgdGhpcyk7XG4gICAgICB9IGVsc2UgaWYgKGFDaHVua1tpc1NvdXJjZU5vZGVdIHx8IHR5cGVvZiBhQ2h1bmsgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgaWYgKGFDaHVuaykge1xuICAgICAgICAgIHRoaXMuY2hpbGRyZW4ucHVzaChhQ2h1bmspO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFxuICAgICAgICAgIFwiRXhwZWN0ZWQgYSBTb3VyY2VOb2RlLCBzdHJpbmcsIG9yIGFuIGFycmF5IG9mIFNvdXJjZU5vZGVzIGFuZCBzdHJpbmdzLiBHb3QgXCIgKyBhQ2h1bmtcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH07XG4gICAgU291cmNlTm9kZS5wcm90b3R5cGUucHJlcGVuZCA9IGZ1bmN0aW9uIFNvdXJjZU5vZGVfcHJlcGVuZChhQ2h1bmspIHtcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGFDaHVuaykpIHtcbiAgICAgICAgZm9yICh2YXIgaSA9IGFDaHVuay5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgICAgIHRoaXMucHJlcGVuZChhQ2h1bmtbaV0pO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGFDaHVua1tpc1NvdXJjZU5vZGVdIHx8IHR5cGVvZiBhQ2h1bmsgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgdGhpcy5jaGlsZHJlbi51bnNoaWZ0KGFDaHVuayk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFxuICAgICAgICAgIFwiRXhwZWN0ZWQgYSBTb3VyY2VOb2RlLCBzdHJpbmcsIG9yIGFuIGFycmF5IG9mIFNvdXJjZU5vZGVzIGFuZCBzdHJpbmdzLiBHb3QgXCIgKyBhQ2h1bmtcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH07XG4gICAgU291cmNlTm9kZS5wcm90b3R5cGUud2FsayA9IGZ1bmN0aW9uIFNvdXJjZU5vZGVfd2FsayhhRm4pIHtcbiAgICAgIHZhciBjaHVuaztcbiAgICAgIGZvciAodmFyIGkgPSAwLCBsZW4gPSB0aGlzLmNoaWxkcmVuLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgIGNodW5rID0gdGhpcy5jaGlsZHJlbltpXTtcbiAgICAgICAgaWYgKGNodW5rW2lzU291cmNlTm9kZV0pIHtcbiAgICAgICAgICBjaHVuay53YWxrKGFGbik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKGNodW5rICE9PSBcIlwiKSB7XG4gICAgICAgICAgICBhRm4oY2h1bmssIHtcbiAgICAgICAgICAgICAgc291cmNlOiB0aGlzLnNvdXJjZSxcbiAgICAgICAgICAgICAgbGluZTogdGhpcy5saW5lLFxuICAgICAgICAgICAgICBjb2x1bW46IHRoaXMuY29sdW1uLFxuICAgICAgICAgICAgICBuYW1lOiB0aGlzLm5hbWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgU291cmNlTm9kZS5wcm90b3R5cGUuam9pbiA9IGZ1bmN0aW9uIFNvdXJjZU5vZGVfam9pbihhU2VwKSB7XG4gICAgICB2YXIgbmV3Q2hpbGRyZW47XG4gICAgICB2YXIgaTtcbiAgICAgIHZhciBsZW4gPSB0aGlzLmNoaWxkcmVuLmxlbmd0aDtcbiAgICAgIGlmIChsZW4gPiAwKSB7XG4gICAgICAgIG5ld0NoaWxkcmVuID0gW107XG4gICAgICAgIGZvciAoaSA9IDA7IGkgPCBsZW4gLSAxOyBpKyspIHtcbiAgICAgICAgICBuZXdDaGlsZHJlbi5wdXNoKHRoaXMuY2hpbGRyZW5baV0pO1xuICAgICAgICAgIG5ld0NoaWxkcmVuLnB1c2goYVNlcCk7XG4gICAgICAgIH1cbiAgICAgICAgbmV3Q2hpbGRyZW4ucHVzaCh0aGlzLmNoaWxkcmVuW2ldKTtcbiAgICAgICAgdGhpcy5jaGlsZHJlbiA9IG5ld0NoaWxkcmVuO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfTtcbiAgICBTb3VyY2VOb2RlLnByb3RvdHlwZS5yZXBsYWNlUmlnaHQgPSBmdW5jdGlvbiBTb3VyY2VOb2RlX3JlcGxhY2VSaWdodChhUGF0dGVybiwgYVJlcGxhY2VtZW50KSB7XG4gICAgICB2YXIgbGFzdENoaWxkID0gdGhpcy5jaGlsZHJlblt0aGlzLmNoaWxkcmVuLmxlbmd0aCAtIDFdO1xuICAgICAgaWYgKGxhc3RDaGlsZFtpc1NvdXJjZU5vZGVdKSB7XG4gICAgICAgIGxhc3RDaGlsZC5yZXBsYWNlUmlnaHQoYVBhdHRlcm4sIGFSZXBsYWNlbWVudCk7XG4gICAgICB9IGVsc2UgaWYgKHR5cGVvZiBsYXN0Q2hpbGQgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgdGhpcy5jaGlsZHJlblt0aGlzLmNoaWxkcmVuLmxlbmd0aCAtIDFdID0gbGFzdENoaWxkLnJlcGxhY2UoYVBhdHRlcm4sIGFSZXBsYWNlbWVudCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmNoaWxkcmVuLnB1c2goXCJcIi5yZXBsYWNlKGFQYXR0ZXJuLCBhUmVwbGFjZW1lbnQpKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH07XG4gICAgU291cmNlTm9kZS5wcm90b3R5cGUuc2V0U291cmNlQ29udGVudCA9IGZ1bmN0aW9uIFNvdXJjZU5vZGVfc2V0U291cmNlQ29udGVudChhU291cmNlRmlsZSwgYVNvdXJjZUNvbnRlbnQpIHtcbiAgICAgIHRoaXMuc291cmNlQ29udGVudHNbdXRpbC50b1NldFN0cmluZyhhU291cmNlRmlsZSldID0gYVNvdXJjZUNvbnRlbnQ7XG4gICAgfTtcbiAgICBTb3VyY2VOb2RlLnByb3RvdHlwZS53YWxrU291cmNlQ29udGVudHMgPSBmdW5jdGlvbiBTb3VyY2VOb2RlX3dhbGtTb3VyY2VDb250ZW50cyhhRm4pIHtcbiAgICAgIGZvciAodmFyIGkgPSAwLCBsZW4gPSB0aGlzLmNoaWxkcmVuLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgIGlmICh0aGlzLmNoaWxkcmVuW2ldW2lzU291cmNlTm9kZV0pIHtcbiAgICAgICAgICB0aGlzLmNoaWxkcmVuW2ldLndhbGtTb3VyY2VDb250ZW50cyhhRm4pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB2YXIgc291cmNlcyA9IE9iamVjdC5rZXlzKHRoaXMuc291cmNlQ29udGVudHMpO1xuICAgICAgZm9yICh2YXIgaSA9IDAsIGxlbiA9IHNvdXJjZXMubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgYUZuKHV0aWwuZnJvbVNldFN0cmluZyhzb3VyY2VzW2ldKSwgdGhpcy5zb3VyY2VDb250ZW50c1tzb3VyY2VzW2ldXSk7XG4gICAgICB9XG4gICAgfTtcbiAgICBTb3VyY2VOb2RlLnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uIFNvdXJjZU5vZGVfdG9TdHJpbmcoKSB7XG4gICAgICB2YXIgc3RyID0gXCJcIjtcbiAgICAgIHRoaXMud2FsayhmdW5jdGlvbihjaHVuaykge1xuICAgICAgICBzdHIgKz0gY2h1bms7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiBzdHI7XG4gICAgfTtcbiAgICBTb3VyY2VOb2RlLnByb3RvdHlwZS50b1N0cmluZ1dpdGhTb3VyY2VNYXAgPSBmdW5jdGlvbiBTb3VyY2VOb2RlX3RvU3RyaW5nV2l0aFNvdXJjZU1hcChhQXJncykge1xuICAgICAgdmFyIGdlbmVyYXRlZCA9IHtcbiAgICAgICAgY29kZTogXCJcIixcbiAgICAgICAgbGluZTogMSxcbiAgICAgICAgY29sdW1uOiAwXG4gICAgICB9O1xuICAgICAgdmFyIG1hcCA9IG5ldyBTb3VyY2VNYXBHZW5lcmF0b3IoYUFyZ3MpO1xuICAgICAgdmFyIHNvdXJjZU1hcHBpbmdBY3RpdmUgPSBmYWxzZTtcbiAgICAgIHZhciBsYXN0T3JpZ2luYWxTb3VyY2UgPSBudWxsO1xuICAgICAgdmFyIGxhc3RPcmlnaW5hbExpbmUgPSBudWxsO1xuICAgICAgdmFyIGxhc3RPcmlnaW5hbENvbHVtbiA9IG51bGw7XG4gICAgICB2YXIgbGFzdE9yaWdpbmFsTmFtZSA9IG51bGw7XG4gICAgICB0aGlzLndhbGsoZnVuY3Rpb24oY2h1bmssIG9yaWdpbmFsKSB7XG4gICAgICAgIGdlbmVyYXRlZC5jb2RlICs9IGNodW5rO1xuICAgICAgICBpZiAob3JpZ2luYWwuc291cmNlICE9PSBudWxsICYmIG9yaWdpbmFsLmxpbmUgIT09IG51bGwgJiYgb3JpZ2luYWwuY29sdW1uICE9PSBudWxsKSB7XG4gICAgICAgICAgaWYgKGxhc3RPcmlnaW5hbFNvdXJjZSAhPT0gb3JpZ2luYWwuc291cmNlIHx8IGxhc3RPcmlnaW5hbExpbmUgIT09IG9yaWdpbmFsLmxpbmUgfHwgbGFzdE9yaWdpbmFsQ29sdW1uICE9PSBvcmlnaW5hbC5jb2x1bW4gfHwgbGFzdE9yaWdpbmFsTmFtZSAhPT0gb3JpZ2luYWwubmFtZSkge1xuICAgICAgICAgICAgbWFwLmFkZE1hcHBpbmcoe1xuICAgICAgICAgICAgICBzb3VyY2U6IG9yaWdpbmFsLnNvdXJjZSxcbiAgICAgICAgICAgICAgb3JpZ2luYWw6IHtcbiAgICAgICAgICAgICAgICBsaW5lOiBvcmlnaW5hbC5saW5lLFxuICAgICAgICAgICAgICAgIGNvbHVtbjogb3JpZ2luYWwuY29sdW1uXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGdlbmVyYXRlZDoge1xuICAgICAgICAgICAgICAgIGxpbmU6IGdlbmVyYXRlZC5saW5lLFxuICAgICAgICAgICAgICAgIGNvbHVtbjogZ2VuZXJhdGVkLmNvbHVtblxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBuYW1lOiBvcmlnaW5hbC5uYW1lXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgbGFzdE9yaWdpbmFsU291cmNlID0gb3JpZ2luYWwuc291cmNlO1xuICAgICAgICAgIGxhc3RPcmlnaW5hbExpbmUgPSBvcmlnaW5hbC5saW5lO1xuICAgICAgICAgIGxhc3RPcmlnaW5hbENvbHVtbiA9IG9yaWdpbmFsLmNvbHVtbjtcbiAgICAgICAgICBsYXN0T3JpZ2luYWxOYW1lID0gb3JpZ2luYWwubmFtZTtcbiAgICAgICAgICBzb3VyY2VNYXBwaW5nQWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIGlmIChzb3VyY2VNYXBwaW5nQWN0aXZlKSB7XG4gICAgICAgICAgbWFwLmFkZE1hcHBpbmcoe1xuICAgICAgICAgICAgZ2VuZXJhdGVkOiB7XG4gICAgICAgICAgICAgIGxpbmU6IGdlbmVyYXRlZC5saW5lLFxuICAgICAgICAgICAgICBjb2x1bW46IGdlbmVyYXRlZC5jb2x1bW5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgICBsYXN0T3JpZ2luYWxTb3VyY2UgPSBudWxsO1xuICAgICAgICAgIHNvdXJjZU1hcHBpbmdBY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKHZhciBpZHggPSAwLCBsZW5ndGggPSBjaHVuay5sZW5ndGg7IGlkeCA8IGxlbmd0aDsgaWR4KyspIHtcbiAgICAgICAgICBpZiAoY2h1bmsuY2hhckNvZGVBdChpZHgpID09PSBORVdMSU5FX0NPREUpIHtcbiAgICAgICAgICAgIGdlbmVyYXRlZC5saW5lKys7XG4gICAgICAgICAgICBnZW5lcmF0ZWQuY29sdW1uID0gMDtcbiAgICAgICAgICAgIGlmIChpZHggKyAxID09PSBsZW5ndGgpIHtcbiAgICAgICAgICAgICAgbGFzdE9yaWdpbmFsU291cmNlID0gbnVsbDtcbiAgICAgICAgICAgICAgc291cmNlTWFwcGluZ0FjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChzb3VyY2VNYXBwaW5nQWN0aXZlKSB7XG4gICAgICAgICAgICAgIG1hcC5hZGRNYXBwaW5nKHtcbiAgICAgICAgICAgICAgICBzb3VyY2U6IG9yaWdpbmFsLnNvdXJjZSxcbiAgICAgICAgICAgICAgICBvcmlnaW5hbDoge1xuICAgICAgICAgICAgICAgICAgbGluZTogb3JpZ2luYWwubGluZSxcbiAgICAgICAgICAgICAgICAgIGNvbHVtbjogb3JpZ2luYWwuY29sdW1uXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBnZW5lcmF0ZWQ6IHtcbiAgICAgICAgICAgICAgICAgIGxpbmU6IGdlbmVyYXRlZC5saW5lLFxuICAgICAgICAgICAgICAgICAgY29sdW1uOiBnZW5lcmF0ZWQuY29sdW1uXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBuYW1lOiBvcmlnaW5hbC5uYW1lXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBnZW5lcmF0ZWQuY29sdW1uKys7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHRoaXMud2Fsa1NvdXJjZUNvbnRlbnRzKGZ1bmN0aW9uKHNvdXJjZUZpbGUsIHNvdXJjZUNvbnRlbnQpIHtcbiAgICAgICAgbWFwLnNldFNvdXJjZUNvbnRlbnQoc291cmNlRmlsZSwgc291cmNlQ29udGVudCk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiB7IGNvZGU6IGdlbmVyYXRlZC5jb2RlLCBtYXAgfTtcbiAgICB9O1xuICAgIGV4cG9ydHMuU291cmNlTm9kZSA9IFNvdXJjZU5vZGU7XG4gIH1cbn0pO1xuXG4vLyBub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9zb3VyY2UtbWFwLmpzXG52YXIgcmVxdWlyZV9zb3VyY2VfbWFwID0gX19jb21tb25KUyh7XG4gIFwibm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvc291cmNlLW1hcC5qc1wiKGV4cG9ydHMpIHtcbiAgICBleHBvcnRzLlNvdXJjZU1hcEdlbmVyYXRvciA9IHJlcXVpcmVfc291cmNlX21hcF9nZW5lcmF0b3IoKS5Tb3VyY2VNYXBHZW5lcmF0b3I7XG4gICAgZXhwb3J0cy5Tb3VyY2VNYXBDb25zdW1lciA9IHJlcXVpcmVfc291cmNlX21hcF9jb25zdW1lcigpLlNvdXJjZU1hcENvbnN1bWVyO1xuICAgIGV4cG9ydHMuU291cmNlTm9kZSA9IHJlcXVpcmVfc291cmNlX25vZGUoKS5Tb3VyY2VOb2RlO1xuICB9XG59KTtcblxuLy8gc3JjL3dlYnZpZXcudHNcbnZhciBpbXBvcnRfc291cmNlX21hcF9qcyA9IF9fdG9FU00ocmVxdWlyZV9zb3VyY2VfbWFwKCksIDEpO1xuYXN5bmMgZnVuY3Rpb24gZmV0Y2hDYWxsKHBhdGhDb21wb25lbnRzLCAuLi5hcmdzKSB7XG4gIGNvbnN0IHVybCA9IG5ldyBVUkwod2luZG93LmxvY2F0aW9uLm9yaWdpbik7XG4gIHVybC5wYXRobmFtZSA9IHBhdGhDb21wb25lbnRzLmpvaW4oXCIvXCIpO1xuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybC50b1N0cmluZygpLCB7XG4gICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeShhcmdzKVxuICB9KTtcbiAgcmV0dXJuIHJlc3BvbnNlLmhlYWRlcnMuZ2V0KFwiY29udGVudC10eXBlXCIpPy5zdGFydHNXaXRoKFwiYXBwbGljYXRpb24vanNvblwiKSA/IHJlc3BvbnNlLmpzb24oKSA6IHJlc3BvbnNlLnRleHQoKTtcbn1cbmZ1bmN0aW9uIHJlY3Vyc2VJblByb3h5KHRhcmdldCwgcGF0aENvbXBvbmVudHMgPSBbXSkge1xuICByZXR1cm4gbmV3IFByb3h5KHRhcmdldCwge1xuICAgIGFwcGx5OiAodGFyZ2V0MiwgXywgYXJnQXJyYXkpID0+IHtcbiAgICAgIHJldHVybiB0YXJnZXQyKHBhdGhDb21wb25lbnRzLCAuLi5hcmdBcnJheSk7XG4gICAgfSxcbiAgICBnZXQ6IChfLCBwKSA9PiB7XG4gICAgICBwYXRoQ29tcG9uZW50cy5wdXNoKHApO1xuICAgICAgcmV0dXJuIHJlY3Vyc2VJblByb3h5KHRhcmdldCwgcGF0aENvbXBvbmVudHMpO1xuICAgIH1cbiAgfSk7XG59XG5mdW5jdGlvbiBycGMoKSB7XG4gIHJldHVybiByZWN1cnNlSW5Qcm94eShmZXRjaENhbGwpO1xufVxud2luZG93LnJwYyA9IHJwYztcbndpbmRvdy5vblB1c2ggPSB7fTtcbndpbmRvdy5wdXNoID0gKG1lc3NhZ2VUeXBlLCBtZXNzYWdlKSA9PiB7XG4gIGNvbnN0IGNhbGxiYWNrID0gd2luZG93Lm9uUHVzaFttZXNzYWdlVHlwZV07XG4gIGlmICghY2FsbGJhY2spXG4gICAgdGhyb3cgYE5vIG9uUHVzaCBjYWxsYmFjayBmb3IgbWVzc2FnZSB0eXBlIFske21lc3NhZ2VUeXBlfV0uIFJlY2VpdmVkIG1lc3NhZ2UgWyR7bWVzc2FnZX1dYDtcbiAgY2FsbGJhY2sobWVzc2FnZSk7XG59O1xudmFyIHBsYXRmb3JtID0gYXdhaXQgcnBjKCkucGxhdGZvcm0oKTtcbmlmIChwbGF0Zm9ybSA9PT0gXCJub2RlXCIpIHtcbiAgY29uc3QgdXJsID0gKHdpbmRvdy5sb2NhdGlvbi5wcm90b2NvbCA9PT0gXCJodHRwOlwiID8gXCJ3czpcIiA6IFwid3NzOlwiKSArIFwiLy9cIiArIHdpbmRvdy5sb2NhdGlvbi5ob3N0O1xuICBjb25zdCB3cyA9IG5ldyBXZWJTb2NrZXQodXJsKTtcbiAgd3Mub25tZXNzYWdlID0gKHsgZGF0YSB9KSA9PiB7XG4gICAgY29uc3QgeyBtZXNzYWdlVHlwZSwgbWVzc2FnZSB9ID0gSlNPTi5wYXJzZShkYXRhKTtcbiAgICB3aW5kb3cucHVzaChtZXNzYWdlVHlwZSwgbWVzc2FnZSk7XG4gIH07XG59XG53aW5kb3cuc291cmNlTWFwQ29uc3VtZXIgPSBpbXBvcnRfc291cmNlX21hcF9qcy5Tb3VyY2VNYXBDb25zdW1lcjtcbmV4cG9ydCB7XG4gIHJwYyBhcyBkZWZhdWx0XG59O1xuXG5pbXBvcnQoXCIvVXNlcnMvY3BsZXBhZ2UvRGVza3RvcC9EZW1vL2luZGV4LmpzXCIpOyJdLAogICJtYXBwaW5ncyI6ICI7Ozs7OztBQUFBO0FBQUE7QUFBQSxhQUFTLGlCQUFpQixPQUFPLEVBQUUsUUFBUSxPQUFNLFNBQVE7QUFDdkQsWUFBTSxXQUFXLE1BQU0sS0FBSyxLQUFLLFVBQVUsT0FBTyxDQUFDLEVBQUUsT0FBTyxlQUFhLGNBQWMsTUFBTSxFQUFFLEdBQUcsQ0FBQztBQUNuRyxXQUFLLFlBQVksT0FBTyxNQUFNLE1BQU0saUJBQWlCLFFBQVEsTUFBTSxHQUFHLEtBQUs7QUFBQSxJQUM3RSxDQUFDO0FBQUE7QUFBQTs7O0FDSEQsSUFBTSxhQUVBO0FBRk47QUFBQTtBQUFBLElBQU0sY0FBYyxTQUFTLGNBQWMscUJBQXFCO0FBRWhFLElBQU0sWUFBWSxDQUFDLENBQUMsU0FBUyxNQUFNLElBQUksRUFBRSxNQUFNLE9BQU8sQ0FBQztBQUN2RCxRQUFHLFdBQVU7QUFDWCxlQUFTLGdCQUFnQixVQUFVLElBQUksTUFBTTtBQUM3QyxrQkFBWSxVQUFVO0FBQUEsSUFDeEI7QUFFQSxnQkFBWSxpQkFBaUIsVUFBVSxPQUFLO0FBQzFDLFlBQU0sU0FBUyxDQUFDLEVBQUUsY0FBYztBQUNoQyxVQUFHLFFBQU87QUFDUixpQkFBUyxnQkFBZ0IsVUFBVSxJQUFJLE1BQU07QUFBQSxNQUMvQyxPQUFPO0FBQ0wsaUJBQVMsZ0JBQWdCLFVBQVUsT0FBTyxNQUFNO0FBQUEsTUFDbEQ7QUFFQSxVQUFJLEVBQUUsTUFBTSxTQUFTLFNBQVMsTUFBTSxHQUFHO0FBQUEsSUFDekMsQ0FBQztBQUFBO0FBQUE7OztBQ2pCTSxTQUFTLGNBQWMsT0FBTztBQUNuQyxRQUFNLGNBQWMsS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLE1BQU0sTUFBTTtBQUMzRCxTQUFPLE1BQU0sV0FBVztBQUMxQjtBQUhBO0FBQUE7QUFBQTtBQUFBOzs7QUNBQSxJQUVNLFdBQ0UsS0FBSyxLQUFLLE9BRWQsT0FHRSxhQTZCQTtBQXJDTjtBQUFBO0FBQUE7QUFFQSxJQUFNLFlBQVksU0FBUyxjQUFjLHNCQUFzQjtBQUMvRCxJQUFNLENBQUUsS0FBSyxLQUFLLFNBQVUsU0FBUyxpQkFBaUIsaUJBQWlCO0FBRXZFLElBQUksUUFBUSxTQUFTLE1BQU0sSUFBSSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQzdDLGNBQVUsWUFBWSxNQUFNLFNBQVM7QUFFckMsSUFBTSxjQUFjLE1BQU07QUFDeEIsZ0JBQVUsWUFBWSxNQUFNLFNBQVM7QUFDckMsVUFBRyxDQUFDLE9BQU07QUFDUixZQUFJLEVBQUUsTUFBTSxNQUFNO0FBQUEsTUFDcEIsT0FBTztBQUNMLFlBQUksRUFBRSxNQUFNLEtBQUssTUFBTSxTQUFTLENBQUM7QUFBQSxNQUNuQztBQUVBLFVBQUcsUUFBUSxNQUFNLEdBQUc7QUFDbEIsZ0JBQVEsSUFBSSxjQUFjLGFBQWEsQ0FBQztBQUFBLE1BQzFDO0FBQUEsSUFDRjtBQUVBLFFBQUksaUJBQWlCLFNBQVMsTUFBTTtBQUNsQztBQUNBLGtCQUFZO0FBQUEsSUFDZCxDQUFDO0FBRUQsUUFBSSxpQkFBaUIsU0FBUyxNQUFNO0FBQ2xDO0FBQ0Esa0JBQVk7QUFBQSxJQUNkLENBQUM7QUFFRCxVQUFNLGlCQUFpQixTQUFTLE1BQU07QUFDcEMsY0FBUTtBQUNSLGtCQUFZO0FBQUEsSUFDZCxDQUFDO0FBR0QsSUFBTSxnQkFBZ0I7QUFBQSxNQUNwQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQTtBQUFBOzs7QUMzRUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQUE7QUFBQTs7O0FDRkEsSUFBSSxXQUFXLE9BQU87QUFDdEIsSUFBSSxZQUFZLE9BQU87QUFDdkIsSUFBSSxtQkFBbUIsT0FBTztBQUM5QixJQUFJQSxxQkFBb0IsT0FBTztBQUMvQixJQUFJLGVBQWUsT0FBTztBQUMxQixJQUFJLGVBQWUsT0FBTyxVQUFVO0FBQ3BDLElBQUksYUFBYSxDQUFDLElBQUksUUFBUSxTQUFTLFlBQVk7QUFDakQsU0FBTyxRQUFRLEdBQUcsR0FBR0EsbUJBQWtCLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxNQUFNLEVBQUUsU0FBUyxDQUFDLEVBQUUsR0FBRyxTQUFTLEdBQUcsR0FBRyxJQUFJO0FBQzdGO0FBQ0EsSUFBSSxjQUFjLENBQUMsSUFBSSxNQUFNLFFBQVEsU0FBUztBQUM1QyxNQUFJLFFBQVEsT0FBTyxTQUFTLFlBQVksT0FBTyxTQUFTLFlBQVk7QUFDbEUsYUFBUyxPQUFPQSxtQkFBa0IsSUFBSTtBQUNwQyxVQUFJLENBQUMsYUFBYSxLQUFLLElBQUksR0FBRyxLQUFLLFFBQVE7QUFDekMsa0JBQVUsSUFBSSxLQUFLLEVBQUUsS0FBSyxNQUFNLEtBQUssR0FBRyxHQUFHLFlBQVksRUFBRSxPQUFPLGlCQUFpQixNQUFNLEdBQUcsTUFBTSxLQUFLLFdBQVcsQ0FBQztBQUFBLEVBQ3ZIO0FBQ0EsU0FBTztBQUNUO0FBQ0EsSUFBSSxVQUFVLENBQUMsS0FBSyxZQUFZLFlBQVksU0FBUyxPQUFPLE9BQU8sU0FBUyxhQUFhLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLbkcsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLGFBQWEsVUFBVSxRQUFRLFdBQVcsRUFBRSxPQUFPLEtBQUssWUFBWSxLQUFLLENBQUMsSUFBSTtBQUFBLEVBQ3pHO0FBQ0Y7QUFHQSxJQUFJLGlCQUFpQixXQUFXO0FBQUEsRUFDOUIsMkNBQTJDLFNBQVM7QUFDbEQsUUFBSSxlQUFlLG1FQUFtRSxNQUFNLEVBQUU7QUFDOUYsWUFBUSxTQUFTLFNBQVMsUUFBUTtBQUNoQyxVQUFJLEtBQUssVUFBVSxTQUFTLGFBQWEsUUFBUTtBQUMvQyxlQUFPLGFBQWEsTUFBTTtBQUFBLE1BQzVCO0FBQ0EsWUFBTSxJQUFJLFVBQVUsK0JBQStCLE1BQU07QUFBQSxJQUMzRDtBQUNBLFlBQVEsU0FBUyxTQUFTLFVBQVU7QUFDbEMsVUFBSSxPQUFPO0FBQ1gsVUFBSSxPQUFPO0FBQ1gsVUFBSSxVQUFVO0FBQ2QsVUFBSSxVQUFVO0FBQ2QsVUFBSSxPQUFPO0FBQ1gsVUFBSSxPQUFPO0FBQ1gsVUFBSSxPQUFPO0FBQ1gsVUFBSSxRQUFRO0FBQ1osVUFBSSxlQUFlO0FBQ25CLFVBQUksZUFBZTtBQUNuQixVQUFJLFFBQVEsWUFBWSxZQUFZLE1BQU07QUFDeEMsZUFBTyxXQUFXO0FBQUEsTUFDcEI7QUFDQSxVQUFJLFdBQVcsWUFBWSxZQUFZLFNBQVM7QUFDOUMsZUFBTyxXQUFXLFVBQVU7QUFBQSxNQUM5QjtBQUNBLFVBQUksUUFBUSxZQUFZLFlBQVksTUFBTTtBQUN4QyxlQUFPLFdBQVcsT0FBTztBQUFBLE1BQzNCO0FBQ0EsVUFBSSxZQUFZLE1BQU07QUFDcEIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFlBQVksT0FBTztBQUNyQixlQUFPO0FBQUEsTUFDVDtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFHRCxJQUFJLHFCQUFxQixXQUFXO0FBQUEsRUFDbEMsK0NBQStDLFNBQVM7QUFDdEQsUUFBSSxTQUFTLGVBQWU7QUFDNUIsUUFBSSxpQkFBaUI7QUFDckIsUUFBSSxXQUFXLEtBQUs7QUFDcEIsUUFBSSxnQkFBZ0IsV0FBVztBQUMvQixRQUFJLHVCQUF1QjtBQUMzQixhQUFTLFlBQVksUUFBUTtBQUMzQixhQUFPLFNBQVMsS0FBSyxDQUFDLFVBQVUsS0FBSyxLQUFLLFVBQVUsS0FBSztBQUFBLElBQzNEO0FBQ0EsYUFBUyxjQUFjLFFBQVE7QUFDN0IsVUFBSSxjQUFjLFNBQVMsT0FBTztBQUNsQyxVQUFJLFVBQVUsVUFBVTtBQUN4QixhQUFPLGFBQWEsQ0FBQyxVQUFVO0FBQUEsSUFDakM7QUFDQSxZQUFRLFNBQVMsU0FBUyxpQkFBaUIsUUFBUTtBQUNqRCxVQUFJLFVBQVU7QUFDZCxVQUFJO0FBQ0osVUFBSSxNQUFNLFlBQVksTUFBTTtBQUM1QixTQUFHO0FBQ0QsZ0JBQVEsTUFBTTtBQUNkLGlCQUFTO0FBQ1QsWUFBSSxNQUFNLEdBQUc7QUFDWCxtQkFBUztBQUFBLFFBQ1g7QUFDQSxtQkFBVyxPQUFPLE9BQU8sS0FBSztBQUFBLE1BQ2hDLFNBQVMsTUFBTTtBQUNmLGFBQU87QUFBQSxJQUNUO0FBQ0EsWUFBUSxTQUFTLFNBQVMsaUJBQWlCLE1BQU0sUUFBUSxXQUFXO0FBQ2xFLFVBQUksU0FBUyxLQUFLO0FBQ2xCLFVBQUksU0FBUztBQUNiLFVBQUksUUFBUTtBQUNaLFVBQUksY0FBYztBQUNsQixTQUFHO0FBQ0QsWUFBSSxVQUFVLFFBQVE7QUFDcEIsZ0JBQU0sSUFBSSxNQUFNLDRDQUE0QztBQUFBLFFBQzlEO0FBQ0EsZ0JBQVEsT0FBTyxPQUFPLEtBQUssV0FBVyxRQUFRLENBQUM7QUFDL0MsWUFBSSxVQUFVLElBQUk7QUFDaEIsZ0JBQU0sSUFBSSxNQUFNLDJCQUEyQixLQUFLLE9BQU8sU0FBUyxDQUFDLENBQUM7QUFBQSxRQUNwRTtBQUNBLHVCQUFlLENBQUMsRUFBRSxRQUFRO0FBQzFCLGlCQUFTO0FBQ1QsaUJBQVMsVUFBVSxTQUFTO0FBQzVCLGlCQUFTO0FBQUEsTUFDWCxTQUFTO0FBQ1QsZ0JBQVUsUUFBUSxjQUFjLE1BQU07QUFDdEMsZ0JBQVUsT0FBTztBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFHRCxJQUFJLGVBQWUsV0FBVztBQUFBLEVBQzVCLHlDQUF5QyxTQUFTO0FBQ2hELGFBQVMsT0FBTyxPQUFPLE9BQU8sZUFBZTtBQUMzQyxVQUFJLFNBQVMsT0FBTztBQUNsQixlQUFPLE1BQU0sS0FBSztBQUFBLE1BQ3BCLFdBQVcsVUFBVSxXQUFXLEdBQUc7QUFDakMsZUFBTztBQUFBLE1BQ1QsT0FBTztBQUNMLGNBQU0sSUFBSSxNQUFNLE1BQU0sUUFBUSwyQkFBMkI7QUFBQSxNQUMzRDtBQUFBLElBQ0Y7QUFDQSxZQUFRLFNBQVM7QUFDakIsUUFBSSxZQUFZO0FBQ2hCLFFBQUksZ0JBQWdCO0FBQ3BCLGFBQVMsU0FBUyxNQUFNO0FBQ3RCLFVBQUksUUFBUSxLQUFLLE1BQU0sU0FBUztBQUNoQyxVQUFJLENBQUMsT0FBTztBQUNWLGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTztBQUFBLFFBQ0wsUUFBUSxNQUFNLENBQUM7QUFBQSxRQUNmLE1BQU0sTUFBTSxDQUFDO0FBQUEsUUFDYixNQUFNLE1BQU0sQ0FBQztBQUFBLFFBQ2IsTUFBTSxNQUFNLENBQUM7QUFBQSxRQUNiLE1BQU0sTUFBTSxDQUFDO0FBQUEsTUFDZjtBQUFBLElBQ0Y7QUFDQSxZQUFRLFdBQVc7QUFDbkIsYUFBUyxZQUFZLFlBQVk7QUFDL0IsVUFBSSxNQUFNO0FBQ1YsVUFBSSxXQUFXLFFBQVE7QUFDckIsZUFBTyxXQUFXLFNBQVM7QUFBQSxNQUM3QjtBQUNBLGFBQU87QUFDUCxVQUFJLFdBQVcsTUFBTTtBQUNuQixlQUFPLFdBQVcsT0FBTztBQUFBLE1BQzNCO0FBQ0EsVUFBSSxXQUFXLE1BQU07QUFDbkIsZUFBTyxXQUFXO0FBQUEsTUFDcEI7QUFDQSxVQUFJLFdBQVcsTUFBTTtBQUNuQixlQUFPLE1BQU0sV0FBVztBQUFBLE1BQzFCO0FBQ0EsVUFBSSxXQUFXLE1BQU07QUFDbkIsZUFBTyxXQUFXO0FBQUEsTUFDcEI7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLFlBQVEsY0FBYztBQUN0QixRQUFJLG9CQUFvQjtBQUN4QixhQUFTLFdBQVcsR0FBRztBQUNyQixVQUFJLFFBQVEsQ0FBQztBQUNiLGFBQU8sU0FBUyxPQUFPO0FBQ3JCLGlCQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQ3JDLGNBQUksTUFBTSxDQUFDLEVBQUUsVUFBVSxPQUFPO0FBQzVCLGdCQUFJLE9BQU8sTUFBTSxDQUFDO0FBQ2xCLGtCQUFNLENBQUMsSUFBSSxNQUFNLENBQUM7QUFDbEIsa0JBQU0sQ0FBQyxJQUFJO0FBQ1gsbUJBQU8sTUFBTSxDQUFDLEVBQUU7QUFBQSxVQUNsQjtBQUFBLFFBQ0Y7QUFDQSxZQUFJLFNBQVMsRUFBRSxLQUFLO0FBQ3BCLGNBQU0sUUFBUTtBQUFBLFVBQ1o7QUFBQSxVQUNBO0FBQUEsUUFDRixDQUFDO0FBQ0QsWUFBSSxNQUFNLFNBQVMsbUJBQW1CO0FBQ3BDLGdCQUFNLElBQUk7QUFBQSxRQUNaO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQ0EsUUFBSSxZQUFZLFdBQVcsU0FBUyxXQUFXLE9BQU87QUFDcEQsVUFBSSxPQUFPO0FBQ1gsVUFBSSxNQUFNLFNBQVMsS0FBSztBQUN4QixVQUFJLEtBQUs7QUFDUCxZQUFJLENBQUMsSUFBSSxNQUFNO0FBQ2IsaUJBQU87QUFBQSxRQUNUO0FBQ0EsZUFBTyxJQUFJO0FBQUEsTUFDYjtBQUNBLFVBQUksYUFBYSxRQUFRLFdBQVcsSUFBSTtBQUN4QyxVQUFJLFFBQVEsQ0FBQztBQUNiLFVBQUksUUFBUTtBQUNaLFVBQUksSUFBSTtBQUNSLGFBQU8sTUFBTTtBQUNYLGdCQUFRO0FBQ1IsWUFBSSxLQUFLLFFBQVEsS0FBSyxLQUFLO0FBQzNCLFlBQUksTUFBTSxJQUFJO0FBQ1osZ0JBQU0sS0FBSyxLQUFLLE1BQU0sS0FBSyxDQUFDO0FBQzVCO0FBQUEsUUFDRixPQUFPO0FBQ0wsZ0JBQU0sS0FBSyxLQUFLLE1BQU0sT0FBTyxDQUFDLENBQUM7QUFDL0IsaUJBQU8sSUFBSSxLQUFLLFVBQVUsS0FBSyxDQUFDLE1BQU0sS0FBSztBQUN6QztBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLGVBQVMsTUFBTSxLQUFLLEdBQUcsSUFBSSxNQUFNLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztBQUN4RCxlQUFPLE1BQU0sQ0FBQztBQUNkLFlBQUksU0FBUyxLQUFLO0FBQ2hCLGdCQUFNLE9BQU8sR0FBRyxDQUFDO0FBQUEsUUFDbkIsV0FBVyxTQUFTLE1BQU07QUFDeEI7QUFBQSxRQUNGLFdBQVcsS0FBSyxHQUFHO0FBQ2pCLGNBQUksU0FBUyxJQUFJO0FBQ2Ysa0JBQU0sT0FBTyxJQUFJLEdBQUcsRUFBRTtBQUN0QixpQkFBSztBQUFBLFVBQ1AsT0FBTztBQUNMLGtCQUFNLE9BQU8sR0FBRyxDQUFDO0FBQ2pCO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsYUFBTyxNQUFNLEtBQUssR0FBRztBQUNyQixVQUFJLFNBQVMsSUFBSTtBQUNmLGVBQU8sYUFBYSxNQUFNO0FBQUEsTUFDNUI7QUFDQSxVQUFJLEtBQUs7QUFDUCxZQUFJLE9BQU87QUFDWCxlQUFPLFlBQVksR0FBRztBQUFBLE1BQ3hCO0FBQ0EsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUNELFlBQVEsWUFBWTtBQUNwQixhQUFTLEtBQUssT0FBTyxPQUFPO0FBQzFCLFVBQUksVUFBVSxJQUFJO0FBQ2hCLGdCQUFRO0FBQUEsTUFDVjtBQUNBLFVBQUksVUFBVSxJQUFJO0FBQ2hCLGdCQUFRO0FBQUEsTUFDVjtBQUNBLFVBQUksV0FBVyxTQUFTLEtBQUs7QUFDN0IsVUFBSSxXQUFXLFNBQVMsS0FBSztBQUM3QixVQUFJLFVBQVU7QUFDWixnQkFBUSxTQUFTLFFBQVE7QUFBQSxNQUMzQjtBQUNBLFVBQUksWUFBWSxDQUFDLFNBQVMsUUFBUTtBQUNoQyxZQUFJLFVBQVU7QUFDWixtQkFBUyxTQUFTLFNBQVM7QUFBQSxRQUM3QjtBQUNBLGVBQU8sWUFBWSxRQUFRO0FBQUEsTUFDN0I7QUFDQSxVQUFJLFlBQVksTUFBTSxNQUFNLGFBQWEsR0FBRztBQUMxQyxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksWUFBWSxDQUFDLFNBQVMsUUFBUSxDQUFDLFNBQVMsTUFBTTtBQUNoRCxpQkFBUyxPQUFPO0FBQ2hCLGVBQU8sWUFBWSxRQUFRO0FBQUEsTUFDN0I7QUFDQSxVQUFJLFNBQVMsTUFBTSxPQUFPLENBQUMsTUFBTSxNQUFNLFFBQVEsVUFBVSxNQUFNLFFBQVEsUUFBUSxFQUFFLElBQUksTUFBTSxLQUFLO0FBQ2hHLFVBQUksVUFBVTtBQUNaLGlCQUFTLE9BQU87QUFDaEIsZUFBTyxZQUFZLFFBQVE7QUFBQSxNQUM3QjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsWUFBUSxPQUFPO0FBQ2YsWUFBUSxhQUFhLFNBQVMsT0FBTztBQUNuQyxhQUFPLE1BQU0sT0FBTyxDQUFDLE1BQU0sT0FBTyxVQUFVLEtBQUssS0FBSztBQUFBLElBQ3hEO0FBQ0EsYUFBUyxTQUFTLE9BQU8sT0FBTztBQUM5QixVQUFJLFVBQVUsSUFBSTtBQUNoQixnQkFBUTtBQUFBLE1BQ1Y7QUFDQSxjQUFRLE1BQU0sUUFBUSxPQUFPLEVBQUU7QUFDL0IsVUFBSSxRQUFRO0FBQ1osYUFBTyxNQUFNLFFBQVEsUUFBUSxHQUFHLE1BQU0sR0FBRztBQUN2QyxZQUFJLFFBQVEsTUFBTSxZQUFZLEdBQUc7QUFDakMsWUFBSSxRQUFRLEdBQUc7QUFDYixpQkFBTztBQUFBLFFBQ1Q7QUFDQSxnQkFBUSxNQUFNLE1BQU0sR0FBRyxLQUFLO0FBQzVCLFlBQUksTUFBTSxNQUFNLG1CQUFtQixHQUFHO0FBQ3BDLGlCQUFPO0FBQUEsUUFDVDtBQUNBLFVBQUU7QUFBQSxNQUNKO0FBQ0EsYUFBTyxNQUFNLFFBQVEsQ0FBQyxFQUFFLEtBQUssS0FBSyxJQUFJLE1BQU0sT0FBTyxNQUFNLFNBQVMsQ0FBQztBQUFBLElBQ3JFO0FBQ0EsWUFBUSxXQUFXO0FBQ25CLFFBQUksb0JBQW9CLFdBQVc7QUFDakMsVUFBSSxNQUFzQix1QkFBTyxPQUFPLElBQUk7QUFDNUMsYUFBTyxFQUFFLGVBQWU7QUFBQSxJQUMxQixFQUFFO0FBQ0YsYUFBUyxTQUFTLEdBQUc7QUFDbkIsYUFBTztBQUFBLElBQ1Q7QUFDQSxhQUFTLFlBQVksTUFBTTtBQUN6QixVQUFJLGNBQWMsSUFBSSxHQUFHO0FBQ3ZCLGVBQU8sTUFBTTtBQUFBLE1BQ2Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLFlBQVEsY0FBYyxvQkFBb0IsV0FBVztBQUNyRCxhQUFTLGNBQWMsTUFBTTtBQUMzQixVQUFJLGNBQWMsSUFBSSxHQUFHO0FBQ3ZCLGVBQU8sS0FBSyxNQUFNLENBQUM7QUFBQSxNQUNyQjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsWUFBUSxnQkFBZ0Isb0JBQW9CLFdBQVc7QUFDdkQsYUFBUyxjQUFjLEdBQUc7QUFDeEIsVUFBSSxDQUFDLEdBQUc7QUFDTixlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksU0FBUyxFQUFFO0FBQ2YsVUFBSSxTQUFTLEdBQUc7QUFDZCxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksRUFBRSxXQUFXLFNBQVMsQ0FBQyxNQUFNLE1BQU0sRUFBRSxXQUFXLFNBQVMsQ0FBQyxNQUFNLE1BQU0sRUFBRSxXQUFXLFNBQVMsQ0FBQyxNQUFNLE9BQU8sRUFBRSxXQUFXLFNBQVMsQ0FBQyxNQUFNLE9BQU8sRUFBRSxXQUFXLFNBQVMsQ0FBQyxNQUFNLE9BQU8sRUFBRSxXQUFXLFNBQVMsQ0FBQyxNQUFNLE9BQU8sRUFBRSxXQUFXLFNBQVMsQ0FBQyxNQUFNLE9BQU8sRUFBRSxXQUFXLFNBQVMsQ0FBQyxNQUFNLE1BQU0sRUFBRSxXQUFXLFNBQVMsQ0FBQyxNQUFNLElBQUk7QUFDaFUsZUFBTztBQUFBLE1BQ1Q7QUFDQSxlQUFTLElBQUksU0FBUyxJQUFJLEtBQUssR0FBRyxLQUFLO0FBQ3JDLFlBQUksRUFBRSxXQUFXLENBQUMsTUFBTSxJQUFJO0FBQzFCLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLGFBQVMsMkJBQTJCLFVBQVUsVUFBVSxxQkFBcUI7QUFDM0UsVUFBSSxNQUFNLE9BQU8sU0FBUyxRQUFRLFNBQVMsTUFBTTtBQUNqRCxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxTQUFTLGVBQWUsU0FBUztBQUN2QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxTQUFTLGlCQUFpQixTQUFTO0FBQ3pDLFVBQUksUUFBUSxLQUFLLHFCQUFxQjtBQUNwQyxlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sU0FBUyxrQkFBa0IsU0FBUztBQUMxQyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxTQUFTLGdCQUFnQixTQUFTO0FBQ3hDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFDQSxhQUFPLE9BQU8sU0FBUyxNQUFNLFNBQVMsSUFBSTtBQUFBLElBQzVDO0FBQ0EsWUFBUSw2QkFBNkI7QUFDckMsYUFBUyxtQ0FBbUMsVUFBVSxVQUFVLHFCQUFxQjtBQUNuRixVQUFJO0FBQ0osWUFBTSxTQUFTLGVBQWUsU0FBUztBQUN2QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxTQUFTLGlCQUFpQixTQUFTO0FBQ3pDLFVBQUksUUFBUSxLQUFLLHFCQUFxQjtBQUNwQyxlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sU0FBUyxrQkFBa0IsU0FBUztBQUMxQyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxTQUFTLGdCQUFnQixTQUFTO0FBQ3hDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFDQSxhQUFPLE9BQU8sU0FBUyxNQUFNLFNBQVMsSUFBSTtBQUFBLElBQzVDO0FBQ0EsWUFBUSxxQ0FBcUM7QUFDN0MsYUFBUyxvQ0FBb0MsVUFBVSxVQUFVLHNCQUFzQjtBQUNyRixVQUFJLE1BQU0sU0FBUyxnQkFBZ0IsU0FBUztBQUM1QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxTQUFTLGtCQUFrQixTQUFTO0FBQzFDLFVBQUksUUFBUSxLQUFLLHNCQUFzQjtBQUNyQyxlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sT0FBTyxTQUFTLFFBQVEsU0FBUyxNQUFNO0FBQzdDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLFNBQVMsZUFBZSxTQUFTO0FBQ3ZDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLFNBQVMsaUJBQWlCLFNBQVM7QUFDekMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUNBLGFBQU8sT0FBTyxTQUFTLE1BQU0sU0FBUyxJQUFJO0FBQUEsSUFDNUM7QUFDQSxZQUFRLHNDQUFzQztBQUM5QyxhQUFTLDBDQUEwQyxVQUFVLFVBQVUsc0JBQXNCO0FBQzNGLFVBQUksTUFBTSxTQUFTLGtCQUFrQixTQUFTO0FBQzlDLFVBQUksUUFBUSxLQUFLLHNCQUFzQjtBQUNyQyxlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sT0FBTyxTQUFTLFFBQVEsU0FBUyxNQUFNO0FBQzdDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLFNBQVMsZUFBZSxTQUFTO0FBQ3ZDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLFNBQVMsaUJBQWlCLFNBQVM7QUFDekMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUNBLGFBQU8sT0FBTyxTQUFTLE1BQU0sU0FBUyxJQUFJO0FBQUEsSUFDNUM7QUFDQSxZQUFRLDRDQUE0QztBQUNwRCxhQUFTLE9BQU8sT0FBTyxPQUFPO0FBQzVCLFVBQUksVUFBVSxPQUFPO0FBQ25CLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxVQUFVLE1BQU07QUFDbEIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFVBQVUsTUFBTTtBQUNsQixlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksUUFBUSxPQUFPO0FBQ2pCLGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxhQUFTLG9DQUFvQyxVQUFVLFVBQVU7QUFDL0QsVUFBSSxNQUFNLFNBQVMsZ0JBQWdCLFNBQVM7QUFDNUMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sU0FBUyxrQkFBa0IsU0FBUztBQUMxQyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxPQUFPLFNBQVMsUUFBUSxTQUFTLE1BQU07QUFDN0MsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sU0FBUyxlQUFlLFNBQVM7QUFDdkMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sU0FBUyxpQkFBaUIsU0FBUztBQUN6QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTyxPQUFPLFNBQVMsTUFBTSxTQUFTLElBQUk7QUFBQSxJQUM1QztBQUNBLFlBQVEsc0NBQXNDO0FBQzlDLGFBQVMsb0JBQW9CLEtBQUs7QUFDaEMsYUFBTyxLQUFLLE1BQU0sSUFBSSxRQUFRLGtCQUFrQixFQUFFLENBQUM7QUFBQSxJQUNyRDtBQUNBLFlBQVEsc0JBQXNCO0FBQzlCLGFBQVMsaUJBQWlCLFlBQVksV0FBVyxjQUFjO0FBQzdELGtCQUFZLGFBQWE7QUFDekIsVUFBSSxZQUFZO0FBQ2QsWUFBSSxXQUFXLFdBQVcsU0FBUyxDQUFDLE1BQU0sT0FBTyxVQUFVLENBQUMsTUFBTSxLQUFLO0FBQ3JFLHdCQUFjO0FBQUEsUUFDaEI7QUFDQSxvQkFBWSxhQUFhO0FBQUEsTUFDM0I7QUFDQSxVQUFJLGNBQWM7QUFDaEIsWUFBSSxTQUFTLFNBQVMsWUFBWTtBQUNsQyxZQUFJLENBQUMsUUFBUTtBQUNYLGdCQUFNLElBQUksTUFBTSxrQ0FBa0M7QUFBQSxRQUNwRDtBQUNBLFlBQUksT0FBTyxNQUFNO0FBQ2YsY0FBSSxRQUFRLE9BQU8sS0FBSyxZQUFZLEdBQUc7QUFDdkMsY0FBSSxTQUFTLEdBQUc7QUFDZCxtQkFBTyxPQUFPLE9BQU8sS0FBSyxVQUFVLEdBQUcsUUFBUSxDQUFDO0FBQUEsVUFDbEQ7QUFBQSxRQUNGO0FBQ0Esb0JBQVksS0FBSyxZQUFZLE1BQU0sR0FBRyxTQUFTO0FBQUEsTUFDakQ7QUFDQSxhQUFPLFVBQVUsU0FBUztBQUFBLElBQzVCO0FBQ0EsWUFBUSxtQkFBbUI7QUFBQSxFQUM3QjtBQUNGLENBQUM7QUFHRCxJQUFJLG9CQUFvQixXQUFXO0FBQUEsRUFDakMsOENBQThDLFNBQVM7QUFDckQsUUFBSSxPQUFPLGFBQWE7QUFDeEIsUUFBSSxNQUFNLE9BQU8sVUFBVTtBQUMzQixRQUFJLGVBQWUsT0FBTyxRQUFRO0FBQ2xDLGFBQVMsV0FBVztBQUNsQixXQUFLLFNBQVMsQ0FBQztBQUNmLFdBQUssT0FBTyxlQUErQixvQkFBSSxJQUFJLElBQW9CLHVCQUFPLE9BQU8sSUFBSTtBQUFBLElBQzNGO0FBQ0EsYUFBUyxZQUFZLFNBQVMsbUJBQW1CLFFBQVEsa0JBQWtCO0FBQ3pFLFVBQUksTUFBTSxJQUFJLFNBQVM7QUFDdkIsZUFBUyxJQUFJLEdBQUcsTUFBTSxPQUFPLFFBQVEsSUFBSSxLQUFLLEtBQUs7QUFDakQsWUFBSSxJQUFJLE9BQU8sQ0FBQyxHQUFHLGdCQUFnQjtBQUFBLE1BQ3JDO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxhQUFTLFVBQVUsT0FBTyxTQUFTLGdCQUFnQjtBQUNqRCxhQUFPLGVBQWUsS0FBSyxLQUFLLE9BQU8sT0FBTyxvQkFBb0IsS0FBSyxJQUFJLEVBQUU7QUFBQSxJQUMvRTtBQUNBLGFBQVMsVUFBVSxNQUFNLFNBQVMsYUFBYSxNQUFNLGtCQUFrQjtBQUNyRSxVQUFJLE9BQU8sZUFBZSxPQUFPLEtBQUssWUFBWSxJQUFJO0FBQ3RELFVBQUksY0FBYyxlQUFlLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxJQUFJO0FBQzFFLFVBQUksTUFBTSxLQUFLLE9BQU87QUFDdEIsVUFBSSxDQUFDLGVBQWUsa0JBQWtCO0FBQ3BDLGFBQUssT0FBTyxLQUFLLElBQUk7QUFBQSxNQUN2QjtBQUNBLFVBQUksQ0FBQyxhQUFhO0FBQ2hCLFlBQUksY0FBYztBQUNoQixlQUFLLEtBQUssSUFBSSxNQUFNLEdBQUc7QUFBQSxRQUN6QixPQUFPO0FBQ0wsZUFBSyxLQUFLLElBQUksSUFBSTtBQUFBLFFBQ3BCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxhQUFTLFVBQVUsTUFBTSxTQUFTLGFBQWEsTUFBTTtBQUNuRCxVQUFJLGNBQWM7QUFDaEIsZUFBTyxLQUFLLEtBQUssSUFBSSxJQUFJO0FBQUEsTUFDM0IsT0FBTztBQUNMLFlBQUksT0FBTyxLQUFLLFlBQVksSUFBSTtBQUNoQyxlQUFPLElBQUksS0FBSyxLQUFLLE1BQU0sSUFBSTtBQUFBLE1BQ2pDO0FBQUEsSUFDRjtBQUNBLGFBQVMsVUFBVSxVQUFVLFNBQVMsaUJBQWlCLE1BQU07QUFDM0QsVUFBSSxjQUFjO0FBQ2hCLFlBQUksTUFBTSxLQUFLLEtBQUssSUFBSSxJQUFJO0FBQzVCLFlBQUksT0FBTyxHQUFHO0FBQ1osaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRixPQUFPO0FBQ0wsWUFBSSxPQUFPLEtBQUssWUFBWSxJQUFJO0FBQ2hDLFlBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxJQUFJLEdBQUc7QUFDN0IsaUJBQU8sS0FBSyxLQUFLLElBQUk7QUFBQSxRQUN2QjtBQUFBLE1BQ0Y7QUFDQSxZQUFNLElBQUksTUFBTSxNQUFNLE9BQU8sc0JBQXNCO0FBQUEsSUFDckQ7QUFDQSxhQUFTLFVBQVUsS0FBSyxTQUFTLFlBQVksTUFBTTtBQUNqRCxVQUFJLFFBQVEsS0FBSyxPQUFPLEtBQUssT0FBTyxRQUFRO0FBQzFDLGVBQU8sS0FBSyxPQUFPLElBQUk7QUFBQSxNQUN6QjtBQUNBLFlBQU0sSUFBSSxNQUFNLDJCQUEyQixJQUFJO0FBQUEsSUFDakQ7QUFDQSxhQUFTLFVBQVUsVUFBVSxTQUFTLG1CQUFtQjtBQUN2RCxhQUFPLEtBQUssT0FBTyxNQUFNO0FBQUEsSUFDM0I7QUFDQSxZQUFRLFdBQVc7QUFBQSxFQUNyQjtBQUNGLENBQUM7QUFHRCxJQUFJLHVCQUF1QixXQUFXO0FBQUEsRUFDcEMsaURBQWlELFNBQVM7QUFDeEQsUUFBSSxPQUFPLGFBQWE7QUFDeEIsYUFBUyx1QkFBdUIsVUFBVSxVQUFVO0FBQ2xELFVBQUksUUFBUSxTQUFTO0FBQ3JCLFVBQUksUUFBUSxTQUFTO0FBQ3JCLFVBQUksVUFBVSxTQUFTO0FBQ3ZCLFVBQUksVUFBVSxTQUFTO0FBQ3ZCLGFBQU8sUUFBUSxTQUFTLFNBQVMsU0FBUyxXQUFXLFdBQVcsS0FBSyxvQ0FBb0MsVUFBVSxRQUFRLEtBQUs7QUFBQSxJQUNsSTtBQUNBLGFBQVMsY0FBYztBQUNyQixXQUFLLFNBQVMsQ0FBQztBQUNmLFdBQUssVUFBVTtBQUNmLFdBQUssUUFBUSxFQUFFLGVBQWUsSUFBSSxpQkFBaUIsRUFBRTtBQUFBLElBQ3ZEO0FBQ0EsZ0JBQVksVUFBVSxrQkFBa0IsU0FBUyxvQkFBb0IsV0FBVyxVQUFVO0FBQ3hGLFdBQUssT0FBTyxRQUFRLFdBQVcsUUFBUTtBQUFBLElBQ3pDO0FBQ0EsZ0JBQVksVUFBVSxNQUFNLFNBQVMsZ0JBQWdCLFVBQVU7QUFDN0QsVUFBSSx1QkFBdUIsS0FBSyxPQUFPLFFBQVEsR0FBRztBQUNoRCxhQUFLLFFBQVE7QUFDYixhQUFLLE9BQU8sS0FBSyxRQUFRO0FBQUEsTUFDM0IsT0FBTztBQUNMLGFBQUssVUFBVTtBQUNmLGFBQUssT0FBTyxLQUFLLFFBQVE7QUFBQSxNQUMzQjtBQUFBLElBQ0Y7QUFDQSxnQkFBWSxVQUFVLFVBQVUsU0FBUyxzQkFBc0I7QUFDN0QsVUFBSSxDQUFDLEtBQUssU0FBUztBQUNqQixhQUFLLE9BQU8sS0FBSyxLQUFLLG1DQUFtQztBQUN6RCxhQUFLLFVBQVU7QUFBQSxNQUNqQjtBQUNBLGFBQU8sS0FBSztBQUFBLElBQ2Q7QUFDQSxZQUFRLGNBQWM7QUFBQSxFQUN4QjtBQUNGLENBQUM7QUFHRCxJQUFJLCtCQUErQixXQUFXO0FBQUEsRUFDNUMseURBQXlELFNBQVM7QUFDaEUsUUFBSSxZQUFZLG1CQUFtQjtBQUNuQyxRQUFJLE9BQU8sYUFBYTtBQUN4QixRQUFJLFdBQVcsa0JBQWtCLEVBQUU7QUFDbkMsUUFBSSxjQUFjLHFCQUFxQixFQUFFO0FBQ3pDLGFBQVMsbUJBQW1CLE9BQU87QUFDakMsVUFBSSxDQUFDLE9BQU87QUFDVixnQkFBUSxDQUFDO0FBQUEsTUFDWDtBQUNBLFdBQUssUUFBUSxLQUFLLE9BQU8sT0FBTyxRQUFRLElBQUk7QUFDNUMsV0FBSyxjQUFjLEtBQUssT0FBTyxPQUFPLGNBQWMsSUFBSTtBQUN4RCxXQUFLLGtCQUFrQixLQUFLLE9BQU8sT0FBTyxrQkFBa0IsS0FBSztBQUNqRSxXQUFLLFdBQVcsSUFBSSxTQUFTO0FBQzdCLFdBQUssU0FBUyxJQUFJLFNBQVM7QUFDM0IsV0FBSyxZQUFZLElBQUksWUFBWTtBQUNqQyxXQUFLLG1CQUFtQjtBQUFBLElBQzFCO0FBQ0EsdUJBQW1CLFVBQVUsV0FBVztBQUN4Qyx1QkFBbUIsZ0JBQWdCLFNBQVMsaUNBQWlDLG9CQUFvQjtBQUMvRixVQUFJLGFBQWEsbUJBQW1CO0FBQ3BDLFVBQUksWUFBWSxJQUFJLG1CQUFtQjtBQUFBLFFBQ3JDLE1BQU0sbUJBQW1CO0FBQUEsUUFDekI7QUFBQSxNQUNGLENBQUM7QUFDRCx5QkFBbUIsWUFBWSxTQUFTLFNBQVM7QUFDL0MsWUFBSSxhQUFhO0FBQUEsVUFDZixXQUFXO0FBQUEsWUFDVCxNQUFNLFFBQVE7QUFBQSxZQUNkLFFBQVEsUUFBUTtBQUFBLFVBQ2xCO0FBQUEsUUFDRjtBQUNBLFlBQUksUUFBUSxVQUFVLE1BQU07QUFDMUIscUJBQVcsU0FBUyxRQUFRO0FBQzVCLGNBQUksY0FBYyxNQUFNO0FBQ3RCLHVCQUFXLFNBQVMsS0FBSyxTQUFTLFlBQVksV0FBVyxNQUFNO0FBQUEsVUFDakU7QUFDQSxxQkFBVyxXQUFXO0FBQUEsWUFDcEIsTUFBTSxRQUFRO0FBQUEsWUFDZCxRQUFRLFFBQVE7QUFBQSxVQUNsQjtBQUNBLGNBQUksUUFBUSxRQUFRLE1BQU07QUFDeEIsdUJBQVcsT0FBTyxRQUFRO0FBQUEsVUFDNUI7QUFBQSxRQUNGO0FBQ0Esa0JBQVUsV0FBVyxVQUFVO0FBQUEsTUFDakMsQ0FBQztBQUNELHlCQUFtQixRQUFRLFFBQVEsU0FBUyxZQUFZO0FBQ3RELFlBQUksaUJBQWlCO0FBQ3JCLFlBQUksZUFBZSxNQUFNO0FBQ3ZCLDJCQUFpQixLQUFLLFNBQVMsWUFBWSxVQUFVO0FBQUEsUUFDdkQ7QUFDQSxZQUFJLENBQUMsVUFBVSxTQUFTLElBQUksY0FBYyxHQUFHO0FBQzNDLG9CQUFVLFNBQVMsSUFBSSxjQUFjO0FBQUEsUUFDdkM7QUFDQSxZQUFJLFVBQVUsbUJBQW1CLGlCQUFpQixVQUFVO0FBQzVELFlBQUksV0FBVyxNQUFNO0FBQ25CLG9CQUFVLGlCQUFpQixZQUFZLE9BQU87QUFBQSxRQUNoRDtBQUFBLE1BQ0YsQ0FBQztBQUNELGFBQU87QUFBQSxJQUNUO0FBQ0EsdUJBQW1CLFVBQVUsYUFBYSxTQUFTLDhCQUE4QixPQUFPO0FBQ3RGLFVBQUksWUFBWSxLQUFLLE9BQU8sT0FBTyxXQUFXO0FBQzlDLFVBQUksV0FBVyxLQUFLLE9BQU8sT0FBTyxZQUFZLElBQUk7QUFDbEQsVUFBSSxTQUFTLEtBQUssT0FBTyxPQUFPLFVBQVUsSUFBSTtBQUM5QyxVQUFJLE9BQU8sS0FBSyxPQUFPLE9BQU8sUUFBUSxJQUFJO0FBQzFDLFVBQUksQ0FBQyxLQUFLLGlCQUFpQjtBQUN6QixhQUFLLGlCQUFpQixXQUFXLFVBQVUsUUFBUSxJQUFJO0FBQUEsTUFDekQ7QUFDQSxVQUFJLFVBQVUsTUFBTTtBQUNsQixpQkFBUyxPQUFPLE1BQU07QUFDdEIsWUFBSSxDQUFDLEtBQUssU0FBUyxJQUFJLE1BQU0sR0FBRztBQUM5QixlQUFLLFNBQVMsSUFBSSxNQUFNO0FBQUEsUUFDMUI7QUFBQSxNQUNGO0FBQ0EsVUFBSSxRQUFRLE1BQU07QUFDaEIsZUFBTyxPQUFPLElBQUk7QUFDbEIsWUFBSSxDQUFDLEtBQUssT0FBTyxJQUFJLElBQUksR0FBRztBQUMxQixlQUFLLE9BQU8sSUFBSSxJQUFJO0FBQUEsUUFDdEI7QUFBQSxNQUNGO0FBQ0EsV0FBSyxVQUFVLElBQUk7QUFBQSxRQUNqQixlQUFlLFVBQVU7QUFBQSxRQUN6QixpQkFBaUIsVUFBVTtBQUFBLFFBQzNCLGNBQWMsWUFBWSxRQUFRLFNBQVM7QUFBQSxRQUMzQyxnQkFBZ0IsWUFBWSxRQUFRLFNBQVM7QUFBQSxRQUM3QztBQUFBLFFBQ0E7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQ0EsdUJBQW1CLFVBQVUsbUJBQW1CLFNBQVMsb0NBQW9DLGFBQWEsZ0JBQWdCO0FBQ3hILFVBQUksU0FBUztBQUNiLFVBQUksS0FBSyxlQUFlLE1BQU07QUFDNUIsaUJBQVMsS0FBSyxTQUFTLEtBQUssYUFBYSxNQUFNO0FBQUEsTUFDakQ7QUFDQSxVQUFJLGtCQUFrQixNQUFNO0FBQzFCLFlBQUksQ0FBQyxLQUFLLGtCQUFrQjtBQUMxQixlQUFLLG1CQUFtQyx1QkFBTyxPQUFPLElBQUk7QUFBQSxRQUM1RDtBQUNBLGFBQUssaUJBQWlCLEtBQUssWUFBWSxNQUFNLENBQUMsSUFBSTtBQUFBLE1BQ3BELFdBQVcsS0FBSyxrQkFBa0I7QUFDaEMsZUFBTyxLQUFLLGlCQUFpQixLQUFLLFlBQVksTUFBTSxDQUFDO0FBQ3JELFlBQUksT0FBTyxLQUFLLEtBQUssZ0JBQWdCLEVBQUUsV0FBVyxHQUFHO0FBQ25ELGVBQUssbUJBQW1CO0FBQUEsUUFDMUI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLHVCQUFtQixVQUFVLGlCQUFpQixTQUFTLGtDQUFrQyxvQkFBb0IsYUFBYSxnQkFBZ0I7QUFDeEksVUFBSSxhQUFhO0FBQ2pCLFVBQUksZUFBZSxNQUFNO0FBQ3ZCLFlBQUksbUJBQW1CLFFBQVEsTUFBTTtBQUNuQyxnQkFBTSxJQUFJO0FBQUEsWUFDUjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0EscUJBQWEsbUJBQW1CO0FBQUEsTUFDbEM7QUFDQSxVQUFJLGFBQWEsS0FBSztBQUN0QixVQUFJLGNBQWMsTUFBTTtBQUN0QixxQkFBYSxLQUFLLFNBQVMsWUFBWSxVQUFVO0FBQUEsTUFDbkQ7QUFDQSxVQUFJLGFBQWEsSUFBSSxTQUFTO0FBQzlCLFVBQUksV0FBVyxJQUFJLFNBQVM7QUFDNUIsV0FBSyxVQUFVLGdCQUFnQixTQUFTLFNBQVM7QUFDL0MsWUFBSSxRQUFRLFdBQVcsY0FBYyxRQUFRLGdCQUFnQixNQUFNO0FBQ2pFLGNBQUksV0FBVyxtQkFBbUIsb0JBQW9CO0FBQUEsWUFDcEQsTUFBTSxRQUFRO0FBQUEsWUFDZCxRQUFRLFFBQVE7QUFBQSxVQUNsQixDQUFDO0FBQ0QsY0FBSSxTQUFTLFVBQVUsTUFBTTtBQUMzQixvQkFBUSxTQUFTLFNBQVM7QUFDMUIsZ0JBQUksa0JBQWtCLE1BQU07QUFDMUIsc0JBQVEsU0FBUyxLQUFLLEtBQUssZ0JBQWdCLFFBQVEsTUFBTTtBQUFBLFlBQzNEO0FBQ0EsZ0JBQUksY0FBYyxNQUFNO0FBQ3RCLHNCQUFRLFNBQVMsS0FBSyxTQUFTLFlBQVksUUFBUSxNQUFNO0FBQUEsWUFDM0Q7QUFDQSxvQkFBUSxlQUFlLFNBQVM7QUFDaEMsb0JBQVEsaUJBQWlCLFNBQVM7QUFDbEMsZ0JBQUksU0FBUyxRQUFRLE1BQU07QUFDekIsc0JBQVEsT0FBTyxTQUFTO0FBQUEsWUFDMUI7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUNBLFlBQUksU0FBUyxRQUFRO0FBQ3JCLFlBQUksVUFBVSxRQUFRLENBQUMsV0FBVyxJQUFJLE1BQU0sR0FBRztBQUM3QyxxQkFBVyxJQUFJLE1BQU07QUFBQSxRQUN2QjtBQUNBLFlBQUksT0FBTyxRQUFRO0FBQ25CLFlBQUksUUFBUSxRQUFRLENBQUMsU0FBUyxJQUFJLElBQUksR0FBRztBQUN2QyxtQkFBUyxJQUFJLElBQUk7QUFBQSxRQUNuQjtBQUFBLE1BQ0YsR0FBRyxJQUFJO0FBQ1AsV0FBSyxXQUFXO0FBQ2hCLFdBQUssU0FBUztBQUNkLHlCQUFtQixRQUFRLFFBQVEsU0FBUyxhQUFhO0FBQ3ZELFlBQUksVUFBVSxtQkFBbUIsaUJBQWlCLFdBQVc7QUFDN0QsWUFBSSxXQUFXLE1BQU07QUFDbkIsY0FBSSxrQkFBa0IsTUFBTTtBQUMxQiwwQkFBYyxLQUFLLEtBQUssZ0JBQWdCLFdBQVc7QUFBQSxVQUNyRDtBQUNBLGNBQUksY0FBYyxNQUFNO0FBQ3RCLDBCQUFjLEtBQUssU0FBUyxZQUFZLFdBQVc7QUFBQSxVQUNyRDtBQUNBLGVBQUssaUJBQWlCLGFBQWEsT0FBTztBQUFBLFFBQzVDO0FBQUEsTUFDRixHQUFHLElBQUk7QUFBQSxJQUNUO0FBQ0EsdUJBQW1CLFVBQVUsbUJBQW1CLFNBQVMsbUNBQW1DLFlBQVksV0FBVyxTQUFTLE9BQU87QUFDakksVUFBSSxhQUFhLE9BQU8sVUFBVSxTQUFTLFlBQVksT0FBTyxVQUFVLFdBQVcsVUFBVTtBQUMzRixjQUFNLElBQUk7QUFBQSxVQUNSO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLGNBQWMsVUFBVSxjQUFjLFlBQVksY0FBYyxXQUFXLE9BQU8sS0FBSyxXQUFXLFVBQVUsS0FBSyxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsT0FBTztBQUNySjtBQUFBLE1BQ0YsV0FBVyxjQUFjLFVBQVUsY0FBYyxZQUFZLGNBQWMsYUFBYSxVQUFVLGFBQWEsWUFBWSxhQUFhLFdBQVcsT0FBTyxLQUFLLFdBQVcsVUFBVSxLQUFLLFVBQVUsT0FBTyxLQUFLLFVBQVUsVUFBVSxLQUFLLFNBQVM7QUFDL087QUFBQSxNQUNGLE9BQU87QUFDTCxjQUFNLElBQUksTUFBTSxzQkFBc0IsS0FBSyxVQUFVO0FBQUEsVUFDbkQsV0FBVztBQUFBLFVBQ1gsUUFBUTtBQUFBLFVBQ1IsVUFBVTtBQUFBLFVBQ1YsTUFBTTtBQUFBLFFBQ1IsQ0FBQyxDQUFDO0FBQUEsTUFDSjtBQUFBLElBQ0Y7QUFDQSx1QkFBbUIsVUFBVSxxQkFBcUIsU0FBUyx1Q0FBdUM7QUFDaEcsVUFBSSwwQkFBMEI7QUFDOUIsVUFBSSx3QkFBd0I7QUFDNUIsVUFBSSx5QkFBeUI7QUFDN0IsVUFBSSx1QkFBdUI7QUFDM0IsVUFBSSxlQUFlO0FBQ25CLFVBQUksaUJBQWlCO0FBQ3JCLFVBQUksU0FBUztBQUNiLFVBQUk7QUFDSixVQUFJO0FBQ0osVUFBSTtBQUNKLFVBQUk7QUFDSixVQUFJLFdBQVcsS0FBSyxVQUFVLFFBQVE7QUFDdEMsZUFBUyxJQUFJLEdBQUcsTUFBTSxTQUFTLFFBQVEsSUFBSSxLQUFLLEtBQUs7QUFDbkQsa0JBQVUsU0FBUyxDQUFDO0FBQ3BCLGVBQU87QUFDUCxZQUFJLFFBQVEsa0JBQWtCLHVCQUF1QjtBQUNuRCxvQ0FBMEI7QUFDMUIsaUJBQU8sUUFBUSxrQkFBa0IsdUJBQXVCO0FBQ3RELG9CQUFRO0FBQ1I7QUFBQSxVQUNGO0FBQUEsUUFDRixPQUFPO0FBQ0wsY0FBSSxJQUFJLEdBQUc7QUFDVCxnQkFBSSxDQUFDLEtBQUssb0NBQW9DLFNBQVMsU0FBUyxJQUFJLENBQUMsQ0FBQyxHQUFHO0FBQ3ZFO0FBQUEsWUFDRjtBQUNBLG9CQUFRO0FBQUEsVUFDVjtBQUFBLFFBQ0Y7QUFDQSxnQkFBUSxVQUFVLE9BQU8sUUFBUSxrQkFBa0IsdUJBQXVCO0FBQzFFLGtDQUEwQixRQUFRO0FBQ2xDLFlBQUksUUFBUSxVQUFVLE1BQU07QUFDMUIsc0JBQVksS0FBSyxTQUFTLFFBQVEsUUFBUSxNQUFNO0FBQ2hELGtCQUFRLFVBQVUsT0FBTyxZQUFZLGNBQWM7QUFDbkQsMkJBQWlCO0FBQ2pCLGtCQUFRLFVBQVUsT0FBTyxRQUFRLGVBQWUsSUFBSSxvQkFBb0I7QUFDeEUsaUNBQXVCLFFBQVEsZUFBZTtBQUM5QyxrQkFBUSxVQUFVLE9BQU8sUUFBUSxpQkFBaUIsc0JBQXNCO0FBQ3hFLG1DQUF5QixRQUFRO0FBQ2pDLGNBQUksUUFBUSxRQUFRLE1BQU07QUFDeEIsc0JBQVUsS0FBSyxPQUFPLFFBQVEsUUFBUSxJQUFJO0FBQzFDLG9CQUFRLFVBQVUsT0FBTyxVQUFVLFlBQVk7QUFDL0MsMkJBQWU7QUFBQSxVQUNqQjtBQUFBLFFBQ0Y7QUFDQSxrQkFBVTtBQUFBLE1BQ1o7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLHVCQUFtQixVQUFVLDBCQUEwQixTQUFTLDBDQUEwQyxVQUFVLGFBQWE7QUFDL0gsYUFBTyxTQUFTLElBQUksU0FBUyxRQUFRO0FBQ25DLFlBQUksQ0FBQyxLQUFLLGtCQUFrQjtBQUMxQixpQkFBTztBQUFBLFFBQ1Q7QUFDQSxZQUFJLGVBQWUsTUFBTTtBQUN2QixtQkFBUyxLQUFLLFNBQVMsYUFBYSxNQUFNO0FBQUEsUUFDNUM7QUFDQSxZQUFJLE1BQU0sS0FBSyxZQUFZLE1BQU07QUFDakMsZUFBTyxPQUFPLFVBQVUsZUFBZSxLQUFLLEtBQUssa0JBQWtCLEdBQUcsSUFBSSxLQUFLLGlCQUFpQixHQUFHLElBQUk7QUFBQSxNQUN6RyxHQUFHLElBQUk7QUFBQSxJQUNUO0FBQ0EsdUJBQW1CLFVBQVUsU0FBUyxTQUFTLDRCQUE0QjtBQUN6RSxVQUFJLE1BQU07QUFBQSxRQUNSLFNBQVMsS0FBSztBQUFBLFFBQ2QsU0FBUyxLQUFLLFNBQVMsUUFBUTtBQUFBLFFBQy9CLE9BQU8sS0FBSyxPQUFPLFFBQVE7QUFBQSxRQUMzQixVQUFVLEtBQUssbUJBQW1CO0FBQUEsTUFDcEM7QUFDQSxVQUFJLEtBQUssU0FBUyxNQUFNO0FBQ3RCLFlBQUksT0FBTyxLQUFLO0FBQUEsTUFDbEI7QUFDQSxVQUFJLEtBQUssZUFBZSxNQUFNO0FBQzVCLFlBQUksYUFBYSxLQUFLO0FBQUEsTUFDeEI7QUFDQSxVQUFJLEtBQUssa0JBQWtCO0FBQ3pCLFlBQUksaUJBQWlCLEtBQUssd0JBQXdCLElBQUksU0FBUyxJQUFJLFVBQVU7QUFBQSxNQUMvRTtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsdUJBQW1CLFVBQVUsV0FBVyxTQUFTLDhCQUE4QjtBQUM3RSxhQUFPLEtBQUssVUFBVSxLQUFLLE9BQU8sQ0FBQztBQUFBLElBQ3JDO0FBQ0EsWUFBUSxxQkFBcUI7QUFBQSxFQUMvQjtBQUNGLENBQUM7QUFHRCxJQUFJLHdCQUF3QixXQUFXO0FBQUEsRUFDckMsa0RBQWtELFNBQVM7QUFDekQsWUFBUSx1QkFBdUI7QUFDL0IsWUFBUSxvQkFBb0I7QUFDNUIsYUFBUyxnQkFBZ0IsTUFBTSxPQUFPLFNBQVMsV0FBVyxVQUFVLE9BQU87QUFDekUsVUFBSSxNQUFNLEtBQUssT0FBTyxRQUFRLFFBQVEsQ0FBQyxJQUFJO0FBQzNDLFVBQUksTUFBTSxTQUFTLFNBQVMsVUFBVSxHQUFHLEdBQUcsSUFBSTtBQUNoRCxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNULFdBQVcsTUFBTSxHQUFHO0FBQ2xCLFlBQUksUUFBUSxNQUFNLEdBQUc7QUFDbkIsaUJBQU8sZ0JBQWdCLEtBQUssT0FBTyxTQUFTLFdBQVcsVUFBVSxLQUFLO0FBQUEsUUFDeEU7QUFDQSxZQUFJLFNBQVMsUUFBUSxtQkFBbUI7QUFDdEMsaUJBQU8sUUFBUSxVQUFVLFNBQVMsUUFBUTtBQUFBLFFBQzVDLE9BQU87QUFDTCxpQkFBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGLE9BQU87QUFDTCxZQUFJLE1BQU0sT0FBTyxHQUFHO0FBQ2xCLGlCQUFPLGdCQUFnQixNQUFNLEtBQUssU0FBUyxXQUFXLFVBQVUsS0FBSztBQUFBLFFBQ3ZFO0FBQ0EsWUFBSSxTQUFTLFFBQVEsbUJBQW1CO0FBQ3RDLGlCQUFPO0FBQUEsUUFDVCxPQUFPO0FBQ0wsaUJBQU8sT0FBTyxJQUFJLEtBQUs7QUFBQSxRQUN6QjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsWUFBUSxTQUFTLFNBQVMsT0FBTyxTQUFTLFdBQVcsVUFBVSxPQUFPO0FBQ3BFLFVBQUksVUFBVSxXQUFXLEdBQUc7QUFDMUIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFFBQVE7QUFBQSxRQUNWO0FBQUEsUUFDQSxVQUFVO0FBQUEsUUFDVjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxTQUFTLFFBQVE7QUFBQSxNQUNuQjtBQUNBLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFDQSxhQUFPLFFBQVEsS0FBSyxHQUFHO0FBQ3JCLFlBQUksU0FBUyxVQUFVLEtBQUssR0FBRyxVQUFVLFFBQVEsQ0FBQyxHQUFHLElBQUksTUFBTSxHQUFHO0FBQ2hFO0FBQUEsUUFDRjtBQUNBLFVBQUU7QUFBQSxNQUNKO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0YsQ0FBQztBQUdELElBQUkscUJBQXFCLFdBQVc7QUFBQSxFQUNsQywrQ0FBK0MsU0FBUztBQUN0RCxhQUFTLGFBQWEsWUFBWTtBQUNoQyxlQUFTLEtBQUssS0FBSyxHQUFHLEdBQUc7QUFDdkIsWUFBSSxPQUFPLElBQUksQ0FBQztBQUNoQixZQUFJLENBQUMsSUFBSSxJQUFJLENBQUM7QUFDZCxZQUFJLENBQUMsSUFBSTtBQUFBLE1BQ1g7QUFDQSxlQUFTLGlCQUFpQixLQUFLLE1BQU07QUFDbkMsZUFBTyxLQUFLLE1BQU0sTUFBTSxLQUFLLE9BQU8sS0FBSyxPQUFPLElBQUk7QUFBQSxNQUN0RDtBQUNBLGVBQVMsWUFBWSxLQUFLLGFBQWEsR0FBRyxHQUFHO0FBQzNDLFlBQUksSUFBSSxHQUFHO0FBQ1QsY0FBSSxhQUFhLGlCQUFpQixHQUFHLENBQUM7QUFDdEMsY0FBSSxJQUFJLElBQUk7QUFDWixlQUFLLEtBQUssWUFBWSxDQUFDO0FBQ3ZCLGNBQUksUUFBUSxJQUFJLENBQUM7QUFDakIsbUJBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0FBQzFCLGdCQUFJLFlBQVksSUFBSSxDQUFDLEdBQUcsT0FBTyxLQUFLLEtBQUssR0FBRztBQUMxQyxtQkFBSztBQUNMLG1CQUFLLEtBQUssR0FBRyxDQUFDO0FBQUEsWUFDaEI7QUFBQSxVQUNGO0FBQ0EsZUFBSyxLQUFLLElBQUksR0FBRyxDQUFDO0FBQ2xCLGNBQUksSUFBSSxJQUFJO0FBQ1osc0JBQVksS0FBSyxhQUFhLEdBQUcsSUFBSSxDQUFDO0FBQ3RDLHNCQUFZLEtBQUssYUFBYSxJQUFJLEdBQUcsQ0FBQztBQUFBLFFBQ3hDO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsYUFBUyxVQUFVLFlBQVk7QUFDN0IsVUFBSSxXQUFXLGFBQWEsU0FBUztBQUNyQyxVQUFJLGFBQWEsSUFBSSxTQUFTLFVBQVUsUUFBUSxFQUFFLEVBQUU7QUFDcEQsYUFBTyxXQUFXLFVBQVU7QUFBQSxJQUM5QjtBQUNBLFFBQUksWUFBNEIsb0JBQUksUUFBUTtBQUM1QyxZQUFRLFlBQVksU0FBUyxLQUFLLFlBQVksUUFBUSxHQUFHO0FBQ3ZELFVBQUksY0FBYyxVQUFVLElBQUksVUFBVTtBQUMxQyxVQUFJLGdCQUFnQixRQUFRO0FBQzFCLHNCQUFjLFVBQVUsVUFBVTtBQUNsQyxrQkFBVSxJQUFJLFlBQVksV0FBVztBQUFBLE1BQ3ZDO0FBQ0Esa0JBQVksS0FBSyxZQUFZLE9BQU8sSUFBSSxTQUFTLENBQUM7QUFBQSxJQUNwRDtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBR0QsSUFBSSw4QkFBOEIsV0FBVztBQUFBLEVBQzNDLHdEQUF3RCxTQUFTO0FBQy9ELFFBQUksT0FBTyxhQUFhO0FBQ3hCLFFBQUksZUFBZSxzQkFBc0I7QUFDekMsUUFBSSxXQUFXLGtCQUFrQixFQUFFO0FBQ25DLFFBQUksWUFBWSxtQkFBbUI7QUFDbkMsUUFBSSxZQUFZLG1CQUFtQixFQUFFO0FBQ3JDLGFBQVMsbUJBQW1CLFlBQVksZUFBZTtBQUNyRCxVQUFJLFlBQVk7QUFDaEIsVUFBSSxPQUFPLGVBQWUsVUFBVTtBQUNsQyxvQkFBWSxLQUFLLG9CQUFvQixVQUFVO0FBQUEsTUFDakQ7QUFDQSxhQUFPLFVBQVUsWUFBWSxPQUFPLElBQUkseUJBQXlCLFdBQVcsYUFBYSxJQUFJLElBQUksdUJBQXVCLFdBQVcsYUFBYTtBQUFBLElBQ2xKO0FBQ0EsdUJBQW1CLGdCQUFnQixTQUFTLFlBQVksZUFBZTtBQUNyRSxhQUFPLHVCQUF1QixjQUFjLFlBQVksYUFBYTtBQUFBLElBQ3ZFO0FBQ0EsdUJBQW1CLFVBQVUsV0FBVztBQUN4Qyx1QkFBbUIsVUFBVSxzQkFBc0I7QUFDbkQsV0FBTyxlQUFlLG1CQUFtQixXQUFXLHNCQUFzQjtBQUFBLE1BQ3hFLGNBQWM7QUFBQSxNQUNkLFlBQVk7QUFBQSxNQUNaLEtBQUssV0FBVztBQUNkLFlBQUksQ0FBQyxLQUFLLHFCQUFxQjtBQUM3QixlQUFLLGVBQWUsS0FBSyxXQUFXLEtBQUssVUFBVTtBQUFBLFFBQ3JEO0FBQ0EsZUFBTyxLQUFLO0FBQUEsTUFDZDtBQUFBLElBQ0YsQ0FBQztBQUNELHVCQUFtQixVQUFVLHFCQUFxQjtBQUNsRCxXQUFPLGVBQWUsbUJBQW1CLFdBQVcscUJBQXFCO0FBQUEsTUFDdkUsY0FBYztBQUFBLE1BQ2QsWUFBWTtBQUFBLE1BQ1osS0FBSyxXQUFXO0FBQ2QsWUFBSSxDQUFDLEtBQUssb0JBQW9CO0FBQzVCLGVBQUssZUFBZSxLQUFLLFdBQVcsS0FBSyxVQUFVO0FBQUEsUUFDckQ7QUFDQSxlQUFPLEtBQUs7QUFBQSxNQUNkO0FBQUEsSUFDRixDQUFDO0FBQ0QsdUJBQW1CLFVBQVUsMEJBQTBCLFNBQVMseUNBQXlDLE1BQU0sT0FBTztBQUNwSCxVQUFJLElBQUksS0FBSyxPQUFPLEtBQUs7QUFDekIsYUFBTyxNQUFNLE9BQU8sTUFBTTtBQUFBLElBQzVCO0FBQ0EsdUJBQW1CLFVBQVUsaUJBQWlCLFNBQVMsZ0NBQWdDLE1BQU0sYUFBYTtBQUN4RyxZQUFNLElBQUksTUFBTSwwQ0FBMEM7QUFBQSxJQUM1RDtBQUNBLHVCQUFtQixrQkFBa0I7QUFDckMsdUJBQW1CLGlCQUFpQjtBQUNwQyx1QkFBbUIsdUJBQXVCO0FBQzFDLHVCQUFtQixvQkFBb0I7QUFDdkMsdUJBQW1CLFVBQVUsY0FBYyxTQUFTLDhCQUE4QixXQUFXLFVBQVUsUUFBUTtBQUM3RyxVQUFJLFVBQVUsWUFBWTtBQUMxQixVQUFJLFFBQVEsVUFBVSxtQkFBbUI7QUFDekMsVUFBSTtBQUNKLGNBQVEsT0FBTztBQUFBLFFBQ2IsS0FBSyxtQkFBbUI7QUFDdEIscUJBQVcsS0FBSztBQUNoQjtBQUFBLFFBQ0YsS0FBSyxtQkFBbUI7QUFDdEIscUJBQVcsS0FBSztBQUNoQjtBQUFBLFFBQ0Y7QUFDRSxnQkFBTSxJQUFJLE1BQU0sNkJBQTZCO0FBQUEsTUFDakQ7QUFDQSxVQUFJLGFBQWEsS0FBSztBQUN0QixVQUFJLGdCQUFnQixVQUFVLEtBQUssT0FBTztBQUMxQyxVQUFJLFFBQVEsS0FBSztBQUNqQixVQUFJLFVBQVUsS0FBSztBQUNuQixVQUFJLGVBQWUsS0FBSztBQUN4QixlQUFTLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxJQUFJLEdBQUcsS0FBSztBQUMvQyxZQUFJLFVBQVUsU0FBUyxDQUFDO0FBQ3hCLFlBQUksU0FBUyxRQUFRLFdBQVcsT0FBTyxPQUFPLFFBQVEsR0FBRyxRQUFRLE1BQU07QUFDdkUsaUJBQVMsS0FBSyxpQkFBaUIsWUFBWSxRQUFRLFlBQVk7QUFDL0Qsc0JBQWM7QUFBQSxVQUNaO0FBQUEsVUFDQSxlQUFlLFFBQVE7QUFBQSxVQUN2QixpQkFBaUIsUUFBUTtBQUFBLFVBQ3pCLGNBQWMsUUFBUTtBQUFBLFVBQ3RCLGdCQUFnQixRQUFRO0FBQUEsVUFDeEIsTUFBTSxRQUFRLFNBQVMsT0FBTyxPQUFPLE1BQU0sR0FBRyxRQUFRLElBQUk7QUFBQSxRQUM1RCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFDQSx1QkFBbUIsVUFBVSwyQkFBMkIsU0FBUywyQ0FBMkMsT0FBTztBQUNqSCxVQUFJLE9BQU8sS0FBSyxPQUFPLE9BQU8sTUFBTTtBQUNwQyxVQUFJLFNBQVM7QUFBQSxRQUNYLFFBQVEsS0FBSyxPQUFPLE9BQU8sUUFBUTtBQUFBLFFBQ25DLGNBQWM7QUFBQSxRQUNkLGdCQUFnQixLQUFLLE9BQU8sT0FBTyxVQUFVLENBQUM7QUFBQSxNQUNoRDtBQUNBLGFBQU8sU0FBUyxLQUFLLGlCQUFpQixPQUFPLE1BQU07QUFDbkQsVUFBSSxPQUFPLFNBQVMsR0FBRztBQUNyQixlQUFPLENBQUM7QUFBQSxNQUNWO0FBQ0EsVUFBSSxXQUFXLENBQUM7QUFDaEIsVUFBSSxRQUFRLEtBQUs7QUFBQSxRQUNmO0FBQUEsUUFDQSxLQUFLO0FBQUEsUUFDTDtBQUFBLFFBQ0E7QUFBQSxRQUNBLEtBQUs7QUFBQSxRQUNMLGFBQWE7QUFBQSxNQUNmO0FBQ0EsVUFBSSxTQUFTLEdBQUc7QUFDZCxZQUFJLFVBQVUsS0FBSyxrQkFBa0IsS0FBSztBQUMxQyxZQUFJLE1BQU0sV0FBVyxRQUFRO0FBQzNCLGNBQUksZUFBZSxRQUFRO0FBQzNCLGlCQUFPLFdBQVcsUUFBUSxpQkFBaUIsY0FBYztBQUN2RCxxQkFBUyxLQUFLO0FBQUEsY0FDWixNQUFNLEtBQUssT0FBTyxTQUFTLGlCQUFpQixJQUFJO0FBQUEsY0FDaEQsUUFBUSxLQUFLLE9BQU8sU0FBUyxtQkFBbUIsSUFBSTtBQUFBLGNBQ3BELFlBQVksS0FBSyxPQUFPLFNBQVMsdUJBQXVCLElBQUk7QUFBQSxZQUM5RCxDQUFDO0FBQ0Qsc0JBQVUsS0FBSyxrQkFBa0IsRUFBRSxLQUFLO0FBQUEsVUFDMUM7QUFBQSxRQUNGLE9BQU87QUFDTCxjQUFJLGlCQUFpQixRQUFRO0FBQzdCLGlCQUFPLFdBQVcsUUFBUSxpQkFBaUIsUUFBUSxRQUFRLGtCQUFrQixnQkFBZ0I7QUFDM0YscUJBQVMsS0FBSztBQUFBLGNBQ1osTUFBTSxLQUFLLE9BQU8sU0FBUyxpQkFBaUIsSUFBSTtBQUFBLGNBQ2hELFFBQVEsS0FBSyxPQUFPLFNBQVMsbUJBQW1CLElBQUk7QUFBQSxjQUNwRCxZQUFZLEtBQUssT0FBTyxTQUFTLHVCQUF1QixJQUFJO0FBQUEsWUFDOUQsQ0FBQztBQUNELHNCQUFVLEtBQUssa0JBQWtCLEVBQUUsS0FBSztBQUFBLFVBQzFDO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLFlBQVEsb0JBQW9CO0FBQzVCLGFBQVMsdUJBQXVCLFlBQVksZUFBZTtBQUN6RCxVQUFJLFlBQVk7QUFDaEIsVUFBSSxPQUFPLGVBQWUsVUFBVTtBQUNsQyxvQkFBWSxLQUFLLG9CQUFvQixVQUFVO0FBQUEsTUFDakQ7QUFDQSxVQUFJLFVBQVUsS0FBSyxPQUFPLFdBQVcsU0FBUztBQUM5QyxVQUFJLFVBQVUsS0FBSyxPQUFPLFdBQVcsU0FBUztBQUM5QyxVQUFJLFFBQVEsS0FBSyxPQUFPLFdBQVcsU0FBUyxDQUFDLENBQUM7QUFDOUMsVUFBSSxhQUFhLEtBQUssT0FBTyxXQUFXLGNBQWMsSUFBSTtBQUMxRCxVQUFJLGlCQUFpQixLQUFLLE9BQU8sV0FBVyxrQkFBa0IsSUFBSTtBQUNsRSxVQUFJLFdBQVcsS0FBSyxPQUFPLFdBQVcsVUFBVTtBQUNoRCxVQUFJLE9BQU8sS0FBSyxPQUFPLFdBQVcsUUFBUSxJQUFJO0FBQzlDLFVBQUksV0FBVyxLQUFLLFVBQVU7QUFDNUIsY0FBTSxJQUFJLE1BQU0sMEJBQTBCLE9BQU87QUFBQSxNQUNuRDtBQUNBLFVBQUksWUFBWTtBQUNkLHFCQUFhLEtBQUssVUFBVSxVQUFVO0FBQUEsTUFDeEM7QUFDQSxnQkFBVSxRQUFRLElBQUksTUFBTSxFQUFFLElBQUksS0FBSyxTQUFTLEVBQUUsSUFBSSxTQUFTLFFBQVE7QUFDckUsZUFBTyxjQUFjLEtBQUssV0FBVyxVQUFVLEtBQUssS0FBSyxXQUFXLE1BQU0sSUFBSSxLQUFLLFNBQVMsWUFBWSxNQUFNLElBQUk7QUFBQSxNQUNwSCxDQUFDO0FBQ0QsV0FBSyxTQUFTLFNBQVMsVUFBVSxNQUFNLElBQUksTUFBTSxHQUFHLElBQUk7QUFDeEQsV0FBSyxXQUFXLFNBQVMsVUFBVSxTQUFTLElBQUk7QUFDaEQsV0FBSyxtQkFBbUIsS0FBSyxTQUFTLFFBQVEsRUFBRSxJQUFJLFNBQVMsR0FBRztBQUM5RCxlQUFPLEtBQUssaUJBQWlCLFlBQVksR0FBRyxhQUFhO0FBQUEsTUFDM0QsQ0FBQztBQUNELFdBQUssYUFBYTtBQUNsQixXQUFLLGlCQUFpQjtBQUN0QixXQUFLLFlBQVk7QUFDakIsV0FBSyxnQkFBZ0I7QUFDckIsV0FBSyxPQUFPO0FBQUEsSUFDZDtBQUNBLDJCQUF1QixZQUFZLE9BQU8sT0FBTyxtQkFBbUIsU0FBUztBQUM3RSwyQkFBdUIsVUFBVSxXQUFXO0FBQzVDLDJCQUF1QixVQUFVLG1CQUFtQixTQUFTLFNBQVM7QUFDcEUsVUFBSSxpQkFBaUI7QUFDckIsVUFBSSxLQUFLLGNBQWMsTUFBTTtBQUMzQix5QkFBaUIsS0FBSyxTQUFTLEtBQUssWUFBWSxjQUFjO0FBQUEsTUFDaEU7QUFDQSxVQUFJLEtBQUssU0FBUyxJQUFJLGNBQWMsR0FBRztBQUNyQyxlQUFPLEtBQUssU0FBUyxRQUFRLGNBQWM7QUFBQSxNQUM3QztBQUNBLFVBQUk7QUFDSixXQUFLLElBQUksR0FBRyxJQUFJLEtBQUssaUJBQWlCLFFBQVEsRUFBRSxHQUFHO0FBQ2pELFlBQUksS0FBSyxpQkFBaUIsQ0FBQyxLQUFLLFNBQVM7QUFDdkMsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsMkJBQXVCLGdCQUFnQixTQUFTLGdDQUFnQyxZQUFZLGVBQWU7QUFDekcsVUFBSSxNQUFNLE9BQU8sT0FBTyx1QkFBdUIsU0FBUztBQUN4RCxVQUFJLFFBQVEsSUFBSSxTQUFTLFNBQVMsVUFBVSxXQUFXLE9BQU8sUUFBUSxHQUFHLElBQUk7QUFDN0UsVUFBSSxVQUFVLElBQUksV0FBVyxTQUFTLFVBQVUsV0FBVyxTQUFTLFFBQVEsR0FBRyxJQUFJO0FBQ25GLFVBQUksYUFBYSxXQUFXO0FBQzVCLFVBQUksaUJBQWlCLFdBQVc7QUFBQSxRQUM5QixJQUFJLFNBQVMsUUFBUTtBQUFBLFFBQ3JCLElBQUk7QUFBQSxNQUNOO0FBQ0EsVUFBSSxPQUFPLFdBQVc7QUFDdEIsVUFBSSxnQkFBZ0I7QUFDcEIsVUFBSSxtQkFBbUIsSUFBSSxTQUFTLFFBQVEsRUFBRSxJQUFJLFNBQVMsR0FBRztBQUM1RCxlQUFPLEtBQUssaUJBQWlCLElBQUksWUFBWSxHQUFHLGFBQWE7QUFBQSxNQUMvRCxDQUFDO0FBQ0QsVUFBSSxvQkFBb0IsV0FBVyxVQUFVLFFBQVEsRUFBRSxNQUFNO0FBQzdELFVBQUksd0JBQXdCLElBQUksc0JBQXNCLENBQUM7QUFDdkQsVUFBSSx1QkFBdUIsSUFBSSxxQkFBcUIsQ0FBQztBQUNyRCxlQUFTLElBQUksR0FBRyxTQUFTLGtCQUFrQixRQUFRLElBQUksUUFBUSxLQUFLO0FBQ2xFLFlBQUksYUFBYSxrQkFBa0IsQ0FBQztBQUNwQyxZQUFJLGNBQWMsSUFBSSxRQUFRO0FBQzlCLG9CQUFZLGdCQUFnQixXQUFXO0FBQ3ZDLG9CQUFZLGtCQUFrQixXQUFXO0FBQ3pDLFlBQUksV0FBVyxRQUFRO0FBQ3JCLHNCQUFZLFNBQVMsUUFBUSxRQUFRLFdBQVcsTUFBTTtBQUN0RCxzQkFBWSxlQUFlLFdBQVc7QUFDdEMsc0JBQVksaUJBQWlCLFdBQVc7QUFDeEMsY0FBSSxXQUFXLE1BQU07QUFDbkIsd0JBQVksT0FBTyxNQUFNLFFBQVEsV0FBVyxJQUFJO0FBQUEsVUFDbEQ7QUFDQSwrQkFBcUIsS0FBSyxXQUFXO0FBQUEsUUFDdkM7QUFDQSw4QkFBc0IsS0FBSyxXQUFXO0FBQUEsTUFDeEM7QUFDQSxnQkFBVSxJQUFJLG9CQUFvQixLQUFLLDBCQUEwQjtBQUNqRSxhQUFPO0FBQUEsSUFDVDtBQUNBLDJCQUF1QixVQUFVLFdBQVc7QUFDNUMsV0FBTyxlQUFlLHVCQUF1QixXQUFXLFdBQVc7QUFBQSxNQUNqRSxLQUFLLFdBQVc7QUFDZCxlQUFPLEtBQUssaUJBQWlCLE1BQU07QUFBQSxNQUNyQztBQUFBLElBQ0YsQ0FBQztBQUNELGFBQVMsVUFBVTtBQUNqQixXQUFLLGdCQUFnQjtBQUNyQixXQUFLLGtCQUFrQjtBQUN2QixXQUFLLFNBQVM7QUFDZCxXQUFLLGVBQWU7QUFDcEIsV0FBSyxpQkFBaUI7QUFDdEIsV0FBSyxPQUFPO0FBQUEsSUFDZDtBQUNBLFFBQUksbUJBQW1CLEtBQUs7QUFDNUIsYUFBUyxjQUFjLE9BQU8sT0FBTztBQUNuQyxVQUFJLElBQUksTUFBTTtBQUNkLFVBQUksSUFBSSxNQUFNLFNBQVM7QUFDdkIsVUFBSSxLQUFLLEdBQUc7QUFDVjtBQUFBLE1BQ0YsV0FBVyxLQUFLLEdBQUc7QUFDakIsWUFBSSxJQUFJLE1BQU0sS0FBSztBQUNuQixZQUFJLElBQUksTUFBTSxRQUFRLENBQUM7QUFDdkIsWUFBSSxpQkFBaUIsR0FBRyxDQUFDLElBQUksR0FBRztBQUM5QixnQkFBTSxLQUFLLElBQUk7QUFDZixnQkFBTSxRQUFRLENBQUMsSUFBSTtBQUFBLFFBQ3JCO0FBQUEsTUFDRixXQUFXLElBQUksSUFBSTtBQUNqQixpQkFBUyxJQUFJLE9BQU8sSUFBSSxHQUFHLEtBQUs7QUFDOUIsbUJBQVMsSUFBSSxHQUFHLElBQUksT0FBTyxLQUFLO0FBQzlCLGdCQUFJLElBQUksTUFBTSxJQUFJLENBQUM7QUFDbkIsZ0JBQUksSUFBSSxNQUFNLENBQUM7QUFDZixnQkFBSSxpQkFBaUIsR0FBRyxDQUFDLEtBQUssR0FBRztBQUMvQjtBQUFBLFlBQ0Y7QUFDQSxrQkFBTSxJQUFJLENBQUMsSUFBSTtBQUNmLGtCQUFNLENBQUMsSUFBSTtBQUFBLFVBQ2I7QUFBQSxRQUNGO0FBQUEsTUFDRixPQUFPO0FBQ0wsa0JBQVUsT0FBTyxrQkFBa0IsS0FBSztBQUFBLE1BQzFDO0FBQUEsSUFDRjtBQUNBLDJCQUF1QixVQUFVLGlCQUFpQixTQUFTLGdDQUFnQyxNQUFNLGFBQWE7QUFDNUcsVUFBSSxnQkFBZ0I7QUFDcEIsVUFBSSwwQkFBMEI7QUFDOUIsVUFBSSx1QkFBdUI7QUFDM0IsVUFBSSx5QkFBeUI7QUFDN0IsVUFBSSxpQkFBaUI7QUFDckIsVUFBSSxlQUFlO0FBQ25CLFVBQUksU0FBUyxLQUFLO0FBQ2xCLFVBQUksUUFBUTtBQUNaLFVBQUksaUJBQWlCLENBQUM7QUFDdEIsVUFBSSxPQUFPLENBQUM7QUFDWixVQUFJLG1CQUFtQixDQUFDO0FBQ3hCLFVBQUksb0JBQW9CLENBQUM7QUFDekIsVUFBSSxTQUFTLEtBQUssU0FBUyxLQUFLO0FBQ2hDLFVBQUksZ0JBQWdCO0FBQ3BCLGFBQU8sUUFBUSxRQUFRO0FBQ3JCLFlBQUksS0FBSyxPQUFPLEtBQUssTUFBTSxLQUFLO0FBQzlCO0FBQ0E7QUFDQSxvQ0FBMEI7QUFDMUIsd0JBQWMsbUJBQW1CLGFBQWE7QUFDOUMsMEJBQWdCLGtCQUFrQjtBQUFBLFFBQ3BDLFdBQVcsS0FBSyxPQUFPLEtBQUssTUFBTSxLQUFLO0FBQ3JDO0FBQUEsUUFDRixPQUFPO0FBQ0wsb0JBQVUsSUFBSSxRQUFRO0FBQ3RCLGtCQUFRLGdCQUFnQjtBQUN4QixlQUFLLE1BQU0sT0FBTyxNQUFNLFFBQVEsT0FBTztBQUNyQyxnQkFBSSxLQUFLLHdCQUF3QixNQUFNLEdBQUcsR0FBRztBQUMzQztBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQ0EsZ0JBQU0sS0FBSyxNQUFNLE9BQU8sR0FBRztBQUMzQixvQkFBVSxDQUFDO0FBQ1gsaUJBQU8sUUFBUSxLQUFLO0FBQ2xCLHNCQUFVLE9BQU8sTUFBTSxPQUFPLElBQUk7QUFDbEMsb0JBQVEsS0FBSztBQUNiLG9CQUFRLEtBQUs7QUFDYixvQkFBUSxLQUFLLEtBQUs7QUFBQSxVQUNwQjtBQUNBLGNBQUksUUFBUSxXQUFXLEdBQUc7QUFDeEIsa0JBQU0sSUFBSSxNQUFNLHdDQUF3QztBQUFBLFVBQzFEO0FBQ0EsY0FBSSxRQUFRLFdBQVcsR0FBRztBQUN4QixrQkFBTSxJQUFJLE1BQU0sd0NBQXdDO0FBQUEsVUFDMUQ7QUFDQSxrQkFBUSxrQkFBa0IsMEJBQTBCLFFBQVEsQ0FBQztBQUM3RCxvQ0FBMEIsUUFBUTtBQUNsQyxjQUFJLFFBQVEsU0FBUyxHQUFHO0FBQ3RCLG9CQUFRLFNBQVMsaUJBQWlCLFFBQVEsQ0FBQztBQUMzQyw4QkFBa0IsUUFBUSxDQUFDO0FBQzNCLG9CQUFRLGVBQWUsdUJBQXVCLFFBQVEsQ0FBQztBQUN2RCxtQ0FBdUIsUUFBUTtBQUMvQixvQkFBUSxnQkFBZ0I7QUFDeEIsb0JBQVEsaUJBQWlCLHlCQUF5QixRQUFRLENBQUM7QUFDM0QscUNBQXlCLFFBQVE7QUFDakMsZ0JBQUksUUFBUSxTQUFTLEdBQUc7QUFDdEIsc0JBQVEsT0FBTyxlQUFlLFFBQVEsQ0FBQztBQUN2Qyw4QkFBZ0IsUUFBUSxDQUFDO0FBQUEsWUFDM0I7QUFBQSxVQUNGO0FBQ0EsNEJBQWtCLEtBQUssT0FBTztBQUM5QixjQUFJLE9BQU8sUUFBUSxpQkFBaUIsVUFBVTtBQUM1QyxnQkFBSSxnQkFBZ0IsUUFBUTtBQUM1QixtQkFBTyxpQkFBaUIsVUFBVSxlQUFlO0FBQy9DLCtCQUFpQixLQUFLLElBQUk7QUFBQSxZQUM1QjtBQUNBLGdCQUFJLGlCQUFpQixhQUFhLE1BQU0sTUFBTTtBQUM1QywrQkFBaUIsYUFBYSxJQUFJLENBQUM7QUFBQSxZQUNyQztBQUNBLDZCQUFpQixhQUFhLEVBQUUsS0FBSyxPQUFPO0FBQUEsVUFDOUM7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLG9CQUFjLG1CQUFtQixhQUFhO0FBQzlDLFdBQUssc0JBQXNCO0FBQzNCLGVBQVMsSUFBSSxHQUFHLElBQUksaUJBQWlCLFFBQVEsS0FBSztBQUNoRCxZQUFJLGlCQUFpQixDQUFDLEtBQUssTUFBTTtBQUMvQixvQkFBVSxpQkFBaUIsQ0FBQyxHQUFHLEtBQUssa0NBQWtDO0FBQUEsUUFDeEU7QUFBQSxNQUNGO0FBQ0EsV0FBSyxxQkFBcUIsQ0FBQyxFQUFFLE9BQU8sR0FBRyxnQkFBZ0I7QUFBQSxJQUN6RDtBQUNBLDJCQUF1QixVQUFVLGVBQWUsU0FBUyw4QkFBOEIsU0FBUyxXQUFXLFdBQVcsYUFBYSxhQUFhLE9BQU87QUFDckosVUFBSSxRQUFRLFNBQVMsS0FBSyxHQUFHO0FBQzNCLGNBQU0sSUFBSSxVQUFVLGtEQUFrRCxRQUFRLFNBQVMsQ0FBQztBQUFBLE1BQzFGO0FBQ0EsVUFBSSxRQUFRLFdBQVcsSUFBSSxHQUFHO0FBQzVCLGNBQU0sSUFBSSxVQUFVLG9EQUFvRCxRQUFRLFdBQVcsQ0FBQztBQUFBLE1BQzlGO0FBQ0EsYUFBTyxhQUFhLE9BQU8sU0FBUyxXQUFXLGFBQWEsS0FBSztBQUFBLElBQ25FO0FBQ0EsMkJBQXVCLFVBQVUscUJBQXFCLFNBQVMsdUNBQXVDO0FBQ3BHLGVBQVMsUUFBUSxHQUFHLFFBQVEsS0FBSyxtQkFBbUIsUUFBUSxFQUFFLE9BQU87QUFDbkUsWUFBSSxVQUFVLEtBQUssbUJBQW1CLEtBQUs7QUFDM0MsWUFBSSxRQUFRLElBQUksS0FBSyxtQkFBbUIsUUFBUTtBQUM5QyxjQUFJLGNBQWMsS0FBSyxtQkFBbUIsUUFBUSxDQUFDO0FBQ25ELGNBQUksUUFBUSxrQkFBa0IsWUFBWSxlQUFlO0FBQ3ZELG9CQUFRLHNCQUFzQixZQUFZLGtCQUFrQjtBQUM1RDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0EsZ0JBQVEsc0JBQXNCO0FBQUEsTUFDaEM7QUFBQSxJQUNGO0FBQ0EsMkJBQXVCLFVBQVUsc0JBQXNCLFNBQVMsc0NBQXNDLE9BQU87QUFDM0csVUFBSSxTQUFTO0FBQUEsUUFDWCxlQUFlLEtBQUssT0FBTyxPQUFPLE1BQU07QUFBQSxRQUN4QyxpQkFBaUIsS0FBSyxPQUFPLE9BQU8sUUFBUTtBQUFBLE1BQzlDO0FBQ0EsVUFBSSxRQUFRLEtBQUs7QUFBQSxRQUNmO0FBQUEsUUFDQSxLQUFLO0FBQUEsUUFDTDtBQUFBLFFBQ0E7QUFBQSxRQUNBLEtBQUs7QUFBQSxRQUNMLEtBQUssT0FBTyxPQUFPLFFBQVEsbUJBQW1CLG9CQUFvQjtBQUFBLE1BQ3BFO0FBQ0EsVUFBSSxTQUFTLEdBQUc7QUFDZCxZQUFJLFVBQVUsS0FBSyxtQkFBbUIsS0FBSztBQUMzQyxZQUFJLFFBQVEsa0JBQWtCLE9BQU8sZUFBZTtBQUNsRCxjQUFJLFNBQVMsS0FBSyxPQUFPLFNBQVMsVUFBVSxJQUFJO0FBQ2hELGNBQUksV0FBVyxNQUFNO0FBQ25CLHFCQUFTLEtBQUssU0FBUyxHQUFHLE1BQU07QUFDaEMscUJBQVMsS0FBSyxpQkFBaUIsS0FBSyxZQUFZLFFBQVEsS0FBSyxhQUFhO0FBQUEsVUFDNUU7QUFDQSxjQUFJLE9BQU8sS0FBSyxPQUFPLFNBQVMsUUFBUSxJQUFJO0FBQzVDLGNBQUksU0FBUyxNQUFNO0FBQ2pCLG1CQUFPLEtBQUssT0FBTyxHQUFHLElBQUk7QUFBQSxVQUM1QjtBQUNBLGlCQUFPO0FBQUEsWUFDTDtBQUFBLFlBQ0EsTUFBTSxLQUFLLE9BQU8sU0FBUyxnQkFBZ0IsSUFBSTtBQUFBLFlBQy9DLFFBQVEsS0FBSyxPQUFPLFNBQVMsa0JBQWtCLElBQUk7QUFBQSxZQUNuRDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxRQUNMLFFBQVE7QUFBQSxRQUNSLE1BQU07QUFBQSxRQUNOLFFBQVE7QUFBQSxRQUNSLE1BQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUNBLDJCQUF1QixVQUFVLDBCQUEwQixTQUFTLGlEQUFpRDtBQUNuSCxVQUFJLENBQUMsS0FBSyxnQkFBZ0I7QUFDeEIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxhQUFPLEtBQUssZUFBZSxVQUFVLEtBQUssU0FBUyxLQUFLLEtBQUssQ0FBQyxLQUFLLGVBQWUsS0FBSyxTQUFTLElBQUk7QUFDbEcsZUFBTyxNQUFNO0FBQUEsTUFDZixDQUFDO0FBQUEsSUFDSDtBQUNBLDJCQUF1QixVQUFVLG1CQUFtQixTQUFTLG1DQUFtQyxTQUFTLGVBQWU7QUFDdEgsVUFBSSxDQUFDLEtBQUssZ0JBQWdCO0FBQ3hCLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxRQUFRLEtBQUssaUJBQWlCLE9BQU87QUFDekMsVUFBSSxTQUFTLEdBQUc7QUFDZCxlQUFPLEtBQUssZUFBZSxLQUFLO0FBQUEsTUFDbEM7QUFDQSxVQUFJLGlCQUFpQjtBQUNyQixVQUFJLEtBQUssY0FBYyxNQUFNO0FBQzNCLHlCQUFpQixLQUFLLFNBQVMsS0FBSyxZQUFZLGNBQWM7QUFBQSxNQUNoRTtBQUNBLFVBQUk7QUFDSixVQUFJLEtBQUssY0FBYyxTQUFTLE1BQU0sS0FBSyxTQUFTLEtBQUssVUFBVSxJQUFJO0FBQ3JFLFlBQUksaUJBQWlCLGVBQWUsUUFBUSxjQUFjLEVBQUU7QUFDNUQsWUFBSSxJQUFJLFVBQVUsVUFBVSxLQUFLLFNBQVMsSUFBSSxjQUFjLEdBQUc7QUFDN0QsaUJBQU8sS0FBSyxlQUFlLEtBQUssU0FBUyxRQUFRLGNBQWMsQ0FBQztBQUFBLFFBQ2xFO0FBQ0EsYUFBSyxDQUFDLElBQUksUUFBUSxJQUFJLFFBQVEsUUFBUSxLQUFLLFNBQVMsSUFBSSxNQUFNLGNBQWMsR0FBRztBQUM3RSxpQkFBTyxLQUFLLGVBQWUsS0FBSyxTQUFTLFFBQVEsTUFBTSxjQUFjLENBQUM7QUFBQSxRQUN4RTtBQUFBLE1BQ0Y7QUFDQSxVQUFJLGVBQWU7QUFDakIsZUFBTztBQUFBLE1BQ1QsT0FBTztBQUNMLGNBQU0sSUFBSSxNQUFNLE1BQU0saUJBQWlCLDRCQUE0QjtBQUFBLE1BQ3JFO0FBQUEsSUFDRjtBQUNBLDJCQUF1QixVQUFVLHVCQUF1QixTQUFTLHVDQUF1QyxPQUFPO0FBQzdHLFVBQUksU0FBUyxLQUFLLE9BQU8sT0FBTyxRQUFRO0FBQ3hDLGVBQVMsS0FBSyxpQkFBaUIsTUFBTTtBQUNyQyxVQUFJLFNBQVMsR0FBRztBQUNkLGVBQU87QUFBQSxVQUNMLE1BQU07QUFBQSxVQUNOLFFBQVE7QUFBQSxVQUNSLFlBQVk7QUFBQSxRQUNkO0FBQUEsTUFDRjtBQUNBLFVBQUksU0FBUztBQUFBLFFBQ1g7QUFBQSxRQUNBLGNBQWMsS0FBSyxPQUFPLE9BQU8sTUFBTTtBQUFBLFFBQ3ZDLGdCQUFnQixLQUFLLE9BQU8sT0FBTyxRQUFRO0FBQUEsTUFDN0M7QUFDQSxVQUFJLFFBQVEsS0FBSztBQUFBLFFBQ2Y7QUFBQSxRQUNBLEtBQUs7QUFBQSxRQUNMO0FBQUEsUUFDQTtBQUFBLFFBQ0EsS0FBSztBQUFBLFFBQ0wsS0FBSyxPQUFPLE9BQU8sUUFBUSxtQkFBbUIsb0JBQW9CO0FBQUEsTUFDcEU7QUFDQSxVQUFJLFNBQVMsR0FBRztBQUNkLFlBQUksVUFBVSxLQUFLLGtCQUFrQixLQUFLO0FBQzFDLFlBQUksUUFBUSxXQUFXLE9BQU8sUUFBUTtBQUNwQyxpQkFBTztBQUFBLFlBQ0wsTUFBTSxLQUFLLE9BQU8sU0FBUyxpQkFBaUIsSUFBSTtBQUFBLFlBQ2hELFFBQVEsS0FBSyxPQUFPLFNBQVMsbUJBQW1CLElBQUk7QUFBQSxZQUNwRCxZQUFZLEtBQUssT0FBTyxTQUFTLHVCQUF1QixJQUFJO0FBQUEsVUFDOUQ7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxRQUNMLE1BQU07QUFBQSxRQUNOLFFBQVE7QUFBQSxRQUNSLFlBQVk7QUFBQSxNQUNkO0FBQUEsSUFDRjtBQUNBLFlBQVEseUJBQXlCO0FBQ2pDLGFBQVMseUJBQXlCLFlBQVksZUFBZTtBQUMzRCxVQUFJLFlBQVk7QUFDaEIsVUFBSSxPQUFPLGVBQWUsVUFBVTtBQUNsQyxvQkFBWSxLQUFLLG9CQUFvQixVQUFVO0FBQUEsTUFDakQ7QUFDQSxVQUFJLFVBQVUsS0FBSyxPQUFPLFdBQVcsU0FBUztBQUM5QyxVQUFJLFdBQVcsS0FBSyxPQUFPLFdBQVcsVUFBVTtBQUNoRCxVQUFJLFdBQVcsS0FBSyxVQUFVO0FBQzVCLGNBQU0sSUFBSSxNQUFNLDBCQUEwQixPQUFPO0FBQUEsTUFDbkQ7QUFDQSxXQUFLLFdBQVcsSUFBSSxTQUFTO0FBQzdCLFdBQUssU0FBUyxJQUFJLFNBQVM7QUFDM0IsVUFBSSxhQUFhO0FBQUEsUUFDZixNQUFNO0FBQUEsUUFDTixRQUFRO0FBQUEsTUFDVjtBQUNBLFdBQUssWUFBWSxTQUFTLElBQUksU0FBUyxHQUFHO0FBQ3hDLFlBQUksRUFBRSxLQUFLO0FBQ1QsZ0JBQU0sSUFBSSxNQUFNLG9EQUFvRDtBQUFBLFFBQ3RFO0FBQ0EsWUFBSSxTQUFTLEtBQUssT0FBTyxHQUFHLFFBQVE7QUFDcEMsWUFBSSxhQUFhLEtBQUssT0FBTyxRQUFRLE1BQU07QUFDM0MsWUFBSSxlQUFlLEtBQUssT0FBTyxRQUFRLFFBQVE7QUFDL0MsWUFBSSxhQUFhLFdBQVcsUUFBUSxlQUFlLFdBQVcsUUFBUSxlQUFlLFdBQVcsUUFBUTtBQUN0RyxnQkFBTSxJQUFJLE1BQU0sc0RBQXNEO0FBQUEsUUFDeEU7QUFDQSxxQkFBYTtBQUNiLGVBQU87QUFBQSxVQUNMLGlCQUFpQjtBQUFBO0FBQUE7QUFBQSxZQUdmLGVBQWUsYUFBYTtBQUFBLFlBQzVCLGlCQUFpQixlQUFlO0FBQUEsVUFDbEM7QUFBQSxVQUNBLFVBQVUsSUFBSSxtQkFBbUIsS0FBSyxPQUFPLEdBQUcsS0FBSyxHQUFHLGFBQWE7QUFBQSxRQUN2RTtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFDQSw2QkFBeUIsWUFBWSxPQUFPLE9BQU8sbUJBQW1CLFNBQVM7QUFDL0UsNkJBQXlCLFVBQVUsY0FBYztBQUNqRCw2QkFBeUIsVUFBVSxXQUFXO0FBQzlDLFdBQU8sZUFBZSx5QkFBeUIsV0FBVyxXQUFXO0FBQUEsTUFDbkUsS0FBSyxXQUFXO0FBQ2QsWUFBSSxVQUFVLENBQUM7QUFDZixpQkFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLFVBQVUsUUFBUSxLQUFLO0FBQzlDLG1CQUFTLElBQUksR0FBRyxJQUFJLEtBQUssVUFBVSxDQUFDLEVBQUUsU0FBUyxRQUFRLFFBQVEsS0FBSztBQUNsRSxvQkFBUSxLQUFLLEtBQUssVUFBVSxDQUFDLEVBQUUsU0FBUyxRQUFRLENBQUMsQ0FBQztBQUFBLFVBQ3BEO0FBQUEsUUFDRjtBQUNBLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRixDQUFDO0FBQ0QsNkJBQXlCLFVBQVUsc0JBQXNCLFNBQVMsNkNBQTZDLE9BQU87QUFDcEgsVUFBSSxTQUFTO0FBQUEsUUFDWCxlQUFlLEtBQUssT0FBTyxPQUFPLE1BQU07QUFBQSxRQUN4QyxpQkFBaUIsS0FBSyxPQUFPLE9BQU8sUUFBUTtBQUFBLE1BQzlDO0FBQ0EsVUFBSSxlQUFlLGFBQWE7QUFBQSxRQUM5QjtBQUFBLFFBQ0EsS0FBSztBQUFBLFFBQ0wsU0FBUyxTQUFTLFVBQVU7QUFDMUIsY0FBSSxNQUFNLFFBQVEsZ0JBQWdCLFNBQVMsZ0JBQWdCO0FBQzNELGNBQUksS0FBSztBQUNQLG1CQUFPO0FBQUEsVUFDVDtBQUNBLGlCQUFPLFFBQVEsa0JBQWtCLFNBQVMsZ0JBQWdCO0FBQUEsUUFDNUQ7QUFBQSxNQUNGO0FBQ0EsVUFBSSxVQUFVLEtBQUssVUFBVSxZQUFZO0FBQ3pDLFVBQUksQ0FBQyxTQUFTO0FBQ1osZUFBTztBQUFBLFVBQ0wsUUFBUTtBQUFBLFVBQ1IsTUFBTTtBQUFBLFVBQ04sUUFBUTtBQUFBLFVBQ1IsTUFBTTtBQUFBLFFBQ1I7QUFBQSxNQUNGO0FBQ0EsYUFBTyxRQUFRLFNBQVMsb0JBQW9CO0FBQUEsUUFDMUMsTUFBTSxPQUFPLGlCQUFpQixRQUFRLGdCQUFnQixnQkFBZ0I7QUFBQSxRQUN0RSxRQUFRLE9BQU8sbUJBQW1CLFFBQVEsZ0JBQWdCLGtCQUFrQixPQUFPLGdCQUFnQixRQUFRLGdCQUFnQixrQkFBa0IsSUFBSTtBQUFBLFFBQ2pKLE1BQU0sTUFBTTtBQUFBLE1BQ2QsQ0FBQztBQUFBLElBQ0g7QUFDQSw2QkFBeUIsVUFBVSwwQkFBMEIsU0FBUyxtREFBbUQ7QUFDdkgsYUFBTyxLQUFLLFVBQVUsTUFBTSxTQUFTLEdBQUc7QUFDdEMsZUFBTyxFQUFFLFNBQVMsd0JBQXdCO0FBQUEsTUFDNUMsQ0FBQztBQUFBLElBQ0g7QUFDQSw2QkFBeUIsVUFBVSxtQkFBbUIsU0FBUywwQ0FBMEMsU0FBUyxlQUFlO0FBQy9ILGVBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxVQUFVLFFBQVEsS0FBSztBQUM5QyxZQUFJLFVBQVUsS0FBSyxVQUFVLENBQUM7QUFDOUIsWUFBSSxVQUFVLFFBQVEsU0FBUyxpQkFBaUIsU0FBUyxJQUFJO0FBQzdELFlBQUksU0FBUztBQUNYLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFDQSxVQUFJLGVBQWU7QUFDakIsZUFBTztBQUFBLE1BQ1QsT0FBTztBQUNMLGNBQU0sSUFBSSxNQUFNLE1BQU0sVUFBVSw0QkFBNEI7QUFBQSxNQUM5RDtBQUFBLElBQ0Y7QUFDQSw2QkFBeUIsVUFBVSx1QkFBdUIsU0FBUyw4Q0FBOEMsT0FBTztBQUN0SCxlQUFTLElBQUksR0FBRyxJQUFJLEtBQUssVUFBVSxRQUFRLEtBQUs7QUFDOUMsWUFBSSxVQUFVLEtBQUssVUFBVSxDQUFDO0FBQzlCLFlBQUksUUFBUSxTQUFTLGlCQUFpQixLQUFLLE9BQU8sT0FBTyxRQUFRLENBQUMsTUFBTSxJQUFJO0FBQzFFO0FBQUEsUUFDRjtBQUNBLFlBQUksb0JBQW9CLFFBQVEsU0FBUyxxQkFBcUIsS0FBSztBQUNuRSxZQUFJLG1CQUFtQjtBQUNyQixjQUFJLE1BQU07QUFBQSxZQUNSLE1BQU0sa0JBQWtCLFFBQVEsUUFBUSxnQkFBZ0IsZ0JBQWdCO0FBQUEsWUFDeEUsUUFBUSxrQkFBa0IsVUFBVSxRQUFRLGdCQUFnQixrQkFBa0Isa0JBQWtCLE9BQU8sUUFBUSxnQkFBZ0Isa0JBQWtCLElBQUk7QUFBQSxVQUN2SjtBQUNBLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsUUFDTCxNQUFNO0FBQUEsUUFDTixRQUFRO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFDQSw2QkFBeUIsVUFBVSxpQkFBaUIsU0FBUyx1Q0FBdUMsTUFBTSxhQUFhO0FBQ3JILFdBQUssc0JBQXNCLENBQUM7QUFDNUIsV0FBSyxxQkFBcUIsQ0FBQztBQUMzQixlQUFTLElBQUksR0FBRyxJQUFJLEtBQUssVUFBVSxRQUFRLEtBQUs7QUFDOUMsWUFBSSxVQUFVLEtBQUssVUFBVSxDQUFDO0FBQzlCLFlBQUksa0JBQWtCLFFBQVEsU0FBUztBQUN2QyxpQkFBUyxJQUFJLEdBQUcsSUFBSSxnQkFBZ0IsUUFBUSxLQUFLO0FBQy9DLGNBQUksVUFBVSxnQkFBZ0IsQ0FBQztBQUMvQixjQUFJLFNBQVMsUUFBUSxTQUFTLFNBQVMsR0FBRyxRQUFRLE1BQU07QUFDeEQsbUJBQVMsS0FBSyxpQkFBaUIsUUFBUSxTQUFTLFlBQVksUUFBUSxLQUFLLGFBQWE7QUFDdEYsZUFBSyxTQUFTLElBQUksTUFBTTtBQUN4QixtQkFBUyxLQUFLLFNBQVMsUUFBUSxNQUFNO0FBQ3JDLGNBQUksT0FBTztBQUNYLGNBQUksUUFBUSxNQUFNO0FBQ2hCLG1CQUFPLFFBQVEsU0FBUyxPQUFPLEdBQUcsUUFBUSxJQUFJO0FBQzlDLGlCQUFLLE9BQU8sSUFBSSxJQUFJO0FBQ3BCLG1CQUFPLEtBQUssT0FBTyxRQUFRLElBQUk7QUFBQSxVQUNqQztBQUNBLGNBQUksa0JBQWtCO0FBQUEsWUFDcEI7QUFBQSxZQUNBLGVBQWUsUUFBUSxpQkFBaUIsUUFBUSxnQkFBZ0IsZ0JBQWdCO0FBQUEsWUFDaEYsaUJBQWlCLFFBQVEsbUJBQW1CLFFBQVEsZ0JBQWdCLGtCQUFrQixRQUFRLGdCQUFnQixRQUFRLGdCQUFnQixrQkFBa0IsSUFBSTtBQUFBLFlBQzVKLGNBQWMsUUFBUTtBQUFBLFlBQ3RCLGdCQUFnQixRQUFRO0FBQUEsWUFDeEI7QUFBQSxVQUNGO0FBQ0EsZUFBSyxvQkFBb0IsS0FBSyxlQUFlO0FBQzdDLGNBQUksT0FBTyxnQkFBZ0IsaUJBQWlCLFVBQVU7QUFDcEQsaUJBQUssbUJBQW1CLEtBQUssZUFBZTtBQUFBLFVBQzlDO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxnQkFBVSxLQUFLLHFCQUFxQixLQUFLLG1DQUFtQztBQUM1RSxnQkFBVSxLQUFLLG9CQUFvQixLQUFLLDBCQUEwQjtBQUFBLElBQ3BFO0FBQ0EsWUFBUSwyQkFBMkI7QUFBQSxFQUNyQztBQUNGLENBQUM7QUFHRCxJQUFJLHNCQUFzQixXQUFXO0FBQUEsRUFDbkMsZ0RBQWdELFNBQVM7QUFDdkQsUUFBSSxxQkFBcUIsNkJBQTZCLEVBQUU7QUFDeEQsUUFBSSxPQUFPLGFBQWE7QUFDeEIsUUFBSSxnQkFBZ0I7QUFDcEIsUUFBSSxlQUFlO0FBQ25CLFFBQUksZUFBZTtBQUNuQixhQUFTLFdBQVcsT0FBTyxTQUFTLFNBQVMsU0FBUyxPQUFPO0FBQzNELFdBQUssV0FBVyxDQUFDO0FBQ2pCLFdBQUssaUJBQWlCLENBQUM7QUFDdkIsV0FBSyxPQUFPLFNBQVMsT0FBTyxPQUFPO0FBQ25DLFdBQUssU0FBUyxXQUFXLE9BQU8sT0FBTztBQUN2QyxXQUFLLFNBQVMsV0FBVyxPQUFPLE9BQU87QUFDdkMsV0FBSyxPQUFPLFNBQVMsT0FBTyxPQUFPO0FBQ25DLFdBQUssWUFBWSxJQUFJO0FBQ3JCLFVBQUksV0FBVztBQUNiLGFBQUssSUFBSSxPQUFPO0FBQUEsSUFDcEI7QUFDQSxlQUFXLDBCQUEwQixTQUFTLG1DQUFtQyxnQkFBZ0Isb0JBQW9CLGVBQWU7QUFDbEksVUFBSSxPQUFPLElBQUksV0FBVztBQUMxQixVQUFJLGlCQUFpQixlQUFlLE1BQU0sYUFBYTtBQUN2RCxVQUFJLHNCQUFzQjtBQUMxQixVQUFJLGdCQUFnQixXQUFXO0FBQzdCLFlBQUksZUFBZSxZQUFZO0FBQy9CLFlBQUksVUFBVSxZQUFZLEtBQUs7QUFDL0IsZUFBTyxlQUFlO0FBQ3RCLGlCQUFTLGNBQWM7QUFDckIsaUJBQU8sc0JBQXNCLGVBQWUsU0FBUyxlQUFlLHFCQUFxQixJQUFJO0FBQUEsUUFDL0Y7QUFBQSxNQUNGO0FBQ0EsVUFBSSxvQkFBb0IsR0FBRyxzQkFBc0I7QUFDakQsVUFBSSxjQUFjO0FBQ2xCLHlCQUFtQixZQUFZLFNBQVMsU0FBUztBQUMvQyxZQUFJLGdCQUFnQixNQUFNO0FBQ3hCLGNBQUksb0JBQW9CLFFBQVEsZUFBZTtBQUM3QywrQkFBbUIsYUFBYSxjQUFjLENBQUM7QUFDL0M7QUFDQSxrQ0FBc0I7QUFBQSxVQUN4QixPQUFPO0FBQ0wsZ0JBQUksV0FBVyxlQUFlLG1CQUFtQixLQUFLO0FBQ3RELGdCQUFJLE9BQU8sU0FBUyxPQUFPLEdBQUcsUUFBUSxrQkFBa0IsbUJBQW1CO0FBQzNFLDJCQUFlLG1CQUFtQixJQUFJLFNBQVMsT0FBTyxRQUFRLGtCQUFrQixtQkFBbUI7QUFDbkcsa0NBQXNCLFFBQVE7QUFDOUIsK0JBQW1CLGFBQWEsSUFBSTtBQUNwQywwQkFBYztBQUNkO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQSxlQUFPLG9CQUFvQixRQUFRLGVBQWU7QUFDaEQsZUFBSyxJQUFJLGNBQWMsQ0FBQztBQUN4QjtBQUFBLFFBQ0Y7QUFDQSxZQUFJLHNCQUFzQixRQUFRLGlCQUFpQjtBQUNqRCxjQUFJLFdBQVcsZUFBZSxtQkFBbUIsS0FBSztBQUN0RCxlQUFLLElBQUksU0FBUyxPQUFPLEdBQUcsUUFBUSxlQUFlLENBQUM7QUFDcEQseUJBQWUsbUJBQW1CLElBQUksU0FBUyxPQUFPLFFBQVEsZUFBZTtBQUM3RSxnQ0FBc0IsUUFBUTtBQUFBLFFBQ2hDO0FBQ0Esc0JBQWM7QUFBQSxNQUNoQixHQUFHLElBQUk7QUFDUCxVQUFJLHNCQUFzQixlQUFlLFFBQVE7QUFDL0MsWUFBSSxhQUFhO0FBQ2YsNkJBQW1CLGFBQWEsY0FBYyxDQUFDO0FBQUEsUUFDakQ7QUFDQSxhQUFLLElBQUksZUFBZSxPQUFPLG1CQUFtQixFQUFFLEtBQUssRUFBRSxDQUFDO0FBQUEsTUFDOUQ7QUFDQSx5QkFBbUIsUUFBUSxRQUFRLFNBQVMsWUFBWTtBQUN0RCxZQUFJLFVBQVUsbUJBQW1CLGlCQUFpQixVQUFVO0FBQzVELFlBQUksV0FBVyxNQUFNO0FBQ25CLGNBQUksaUJBQWlCLE1BQU07QUFDekIseUJBQWEsS0FBSyxLQUFLLGVBQWUsVUFBVTtBQUFBLFVBQ2xEO0FBQ0EsZUFBSyxpQkFBaUIsWUFBWSxPQUFPO0FBQUEsUUFDM0M7QUFBQSxNQUNGLENBQUM7QUFDRCxhQUFPO0FBQ1AsZUFBUyxtQkFBbUIsU0FBUyxNQUFNO0FBQ3pDLFlBQUksWUFBWSxRQUFRLFFBQVEsV0FBVyxRQUFRO0FBQ2pELGVBQUssSUFBSSxJQUFJO0FBQUEsUUFDZixPQUFPO0FBQ0wsY0FBSSxTQUFTLGdCQUFnQixLQUFLLEtBQUssZUFBZSxRQUFRLE1BQU0sSUFBSSxRQUFRO0FBQ2hGLGVBQUssSUFBSSxJQUFJO0FBQUEsWUFDWCxRQUFRO0FBQUEsWUFDUixRQUFRO0FBQUEsWUFDUjtBQUFBLFlBQ0E7QUFBQSxZQUNBLFFBQVE7QUFBQSxVQUNWLENBQUM7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxlQUFXLFVBQVUsTUFBTSxTQUFTLGVBQWUsUUFBUTtBQUN6RCxVQUFJLE1BQU0sUUFBUSxNQUFNLEdBQUc7QUFDekIsZUFBTyxRQUFRLFNBQVMsT0FBTztBQUM3QixlQUFLLElBQUksS0FBSztBQUFBLFFBQ2hCLEdBQUcsSUFBSTtBQUFBLE1BQ1QsV0FBVyxPQUFPLFlBQVksS0FBSyxPQUFPLFdBQVcsVUFBVTtBQUM3RCxZQUFJLFFBQVE7QUFDVixlQUFLLFNBQVMsS0FBSyxNQUFNO0FBQUEsUUFDM0I7QUFBQSxNQUNGLE9BQU87QUFDTCxjQUFNLElBQUk7QUFBQSxVQUNSLGdGQUFnRjtBQUFBLFFBQ2xGO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsZUFBVyxVQUFVLFVBQVUsU0FBUyxtQkFBbUIsUUFBUTtBQUNqRSxVQUFJLE1BQU0sUUFBUSxNQUFNLEdBQUc7QUFDekIsaUJBQVMsSUFBSSxPQUFPLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztBQUMzQyxlQUFLLFFBQVEsT0FBTyxDQUFDLENBQUM7QUFBQSxRQUN4QjtBQUFBLE1BQ0YsV0FBVyxPQUFPLFlBQVksS0FBSyxPQUFPLFdBQVcsVUFBVTtBQUM3RCxhQUFLLFNBQVMsUUFBUSxNQUFNO0FBQUEsTUFDOUIsT0FBTztBQUNMLGNBQU0sSUFBSTtBQUFBLFVBQ1IsZ0ZBQWdGO0FBQUEsUUFDbEY7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxlQUFXLFVBQVUsT0FBTyxTQUFTLGdCQUFnQixLQUFLO0FBQ3hELFVBQUk7QUFDSixlQUFTLElBQUksR0FBRyxNQUFNLEtBQUssU0FBUyxRQUFRLElBQUksS0FBSyxLQUFLO0FBQ3hELGdCQUFRLEtBQUssU0FBUyxDQUFDO0FBQ3ZCLFlBQUksTUFBTSxZQUFZLEdBQUc7QUFDdkIsZ0JBQU0sS0FBSyxHQUFHO0FBQUEsUUFDaEIsT0FBTztBQUNMLGNBQUksVUFBVSxJQUFJO0FBQ2hCLGdCQUFJLE9BQU87QUFBQSxjQUNULFFBQVEsS0FBSztBQUFBLGNBQ2IsTUFBTSxLQUFLO0FBQUEsY0FDWCxRQUFRLEtBQUs7QUFBQSxjQUNiLE1BQU0sS0FBSztBQUFBLFlBQ2IsQ0FBQztBQUFBLFVBQ0g7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxlQUFXLFVBQVUsT0FBTyxTQUFTLGdCQUFnQixNQUFNO0FBQ3pELFVBQUk7QUFDSixVQUFJO0FBQ0osVUFBSSxNQUFNLEtBQUssU0FBUztBQUN4QixVQUFJLE1BQU0sR0FBRztBQUNYLHNCQUFjLENBQUM7QUFDZixhQUFLLElBQUksR0FBRyxJQUFJLE1BQU0sR0FBRyxLQUFLO0FBQzVCLHNCQUFZLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQztBQUNqQyxzQkFBWSxLQUFLLElBQUk7QUFBQSxRQUN2QjtBQUNBLG9CQUFZLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQztBQUNqQyxhQUFLLFdBQVc7QUFBQSxNQUNsQjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsZUFBVyxVQUFVLGVBQWUsU0FBUyx3QkFBd0IsVUFBVSxjQUFjO0FBQzNGLFVBQUksWUFBWSxLQUFLLFNBQVMsS0FBSyxTQUFTLFNBQVMsQ0FBQztBQUN0RCxVQUFJLFVBQVUsWUFBWSxHQUFHO0FBQzNCLGtCQUFVLGFBQWEsVUFBVSxZQUFZO0FBQUEsTUFDL0MsV0FBVyxPQUFPLGNBQWMsVUFBVTtBQUN4QyxhQUFLLFNBQVMsS0FBSyxTQUFTLFNBQVMsQ0FBQyxJQUFJLFVBQVUsUUFBUSxVQUFVLFlBQVk7QUFBQSxNQUNwRixPQUFPO0FBQ0wsYUFBSyxTQUFTLEtBQUssR0FBRyxRQUFRLFVBQVUsWUFBWSxDQUFDO0FBQUEsTUFDdkQ7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLGVBQVcsVUFBVSxtQkFBbUIsU0FBUyw0QkFBNEIsYUFBYSxnQkFBZ0I7QUFDeEcsV0FBSyxlQUFlLEtBQUssWUFBWSxXQUFXLENBQUMsSUFBSTtBQUFBLElBQ3ZEO0FBQ0EsZUFBVyxVQUFVLHFCQUFxQixTQUFTLDhCQUE4QixLQUFLO0FBQ3BGLGVBQVMsSUFBSSxHQUFHLE1BQU0sS0FBSyxTQUFTLFFBQVEsSUFBSSxLQUFLLEtBQUs7QUFDeEQsWUFBSSxLQUFLLFNBQVMsQ0FBQyxFQUFFLFlBQVksR0FBRztBQUNsQyxlQUFLLFNBQVMsQ0FBQyxFQUFFLG1CQUFtQixHQUFHO0FBQUEsUUFDekM7QUFBQSxNQUNGO0FBQ0EsVUFBSSxVQUFVLE9BQU8sS0FBSyxLQUFLLGNBQWM7QUFDN0MsZUFBUyxJQUFJLEdBQUcsTUFBTSxRQUFRLFFBQVEsSUFBSSxLQUFLLEtBQUs7QUFDbEQsWUFBSSxLQUFLLGNBQWMsUUFBUSxDQUFDLENBQUMsR0FBRyxLQUFLLGVBQWUsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUFBLE1BQ3JFO0FBQUEsSUFDRjtBQUNBLGVBQVcsVUFBVSxXQUFXLFNBQVMsc0JBQXNCO0FBQzdELFVBQUksTUFBTTtBQUNWLFdBQUssS0FBSyxTQUFTLE9BQU87QUFDeEIsZUFBTztBQUFBLE1BQ1QsQ0FBQztBQUNELGFBQU87QUFBQSxJQUNUO0FBQ0EsZUFBVyxVQUFVLHdCQUF3QixTQUFTLGlDQUFpQyxPQUFPO0FBQzVGLFVBQUksWUFBWTtBQUFBLFFBQ2QsTUFBTTtBQUFBLFFBQ04sTUFBTTtBQUFBLFFBQ04sUUFBUTtBQUFBLE1BQ1Y7QUFDQSxVQUFJLE1BQU0sSUFBSSxtQkFBbUIsS0FBSztBQUN0QyxVQUFJLHNCQUFzQjtBQUMxQixVQUFJLHFCQUFxQjtBQUN6QixVQUFJLG1CQUFtQjtBQUN2QixVQUFJLHFCQUFxQjtBQUN6QixVQUFJLG1CQUFtQjtBQUN2QixXQUFLLEtBQUssU0FBUyxPQUFPLFVBQVU7QUFDbEMsa0JBQVUsUUFBUTtBQUNsQixZQUFJLFNBQVMsV0FBVyxRQUFRLFNBQVMsU0FBUyxRQUFRLFNBQVMsV0FBVyxNQUFNO0FBQ2xGLGNBQUksdUJBQXVCLFNBQVMsVUFBVSxxQkFBcUIsU0FBUyxRQUFRLHVCQUF1QixTQUFTLFVBQVUscUJBQXFCLFNBQVMsTUFBTTtBQUNoSyxnQkFBSSxXQUFXO0FBQUEsY0FDYixRQUFRLFNBQVM7QUFBQSxjQUNqQixVQUFVO0FBQUEsZ0JBQ1IsTUFBTSxTQUFTO0FBQUEsZ0JBQ2YsUUFBUSxTQUFTO0FBQUEsY0FDbkI7QUFBQSxjQUNBLFdBQVc7QUFBQSxnQkFDVCxNQUFNLFVBQVU7QUFBQSxnQkFDaEIsUUFBUSxVQUFVO0FBQUEsY0FDcEI7QUFBQSxjQUNBLE1BQU0sU0FBUztBQUFBLFlBQ2pCLENBQUM7QUFBQSxVQUNIO0FBQ0EsK0JBQXFCLFNBQVM7QUFDOUIsNkJBQW1CLFNBQVM7QUFDNUIsK0JBQXFCLFNBQVM7QUFDOUIsNkJBQW1CLFNBQVM7QUFDNUIsZ0NBQXNCO0FBQUEsUUFDeEIsV0FBVyxxQkFBcUI7QUFDOUIsY0FBSSxXQUFXO0FBQUEsWUFDYixXQUFXO0FBQUEsY0FDVCxNQUFNLFVBQVU7QUFBQSxjQUNoQixRQUFRLFVBQVU7QUFBQSxZQUNwQjtBQUFBLFVBQ0YsQ0FBQztBQUNELCtCQUFxQjtBQUNyQixnQ0FBc0I7QUFBQSxRQUN4QjtBQUNBLGlCQUFTLE1BQU0sR0FBRyxTQUFTLE1BQU0sUUFBUSxNQUFNLFFBQVEsT0FBTztBQUM1RCxjQUFJLE1BQU0sV0FBVyxHQUFHLE1BQU0sY0FBYztBQUMxQyxzQkFBVTtBQUNWLHNCQUFVLFNBQVM7QUFDbkIsZ0JBQUksTUFBTSxNQUFNLFFBQVE7QUFDdEIsbUNBQXFCO0FBQ3JCLG9DQUFzQjtBQUFBLFlBQ3hCLFdBQVcscUJBQXFCO0FBQzlCLGtCQUFJLFdBQVc7QUFBQSxnQkFDYixRQUFRLFNBQVM7QUFBQSxnQkFDakIsVUFBVTtBQUFBLGtCQUNSLE1BQU0sU0FBUztBQUFBLGtCQUNmLFFBQVEsU0FBUztBQUFBLGdCQUNuQjtBQUFBLGdCQUNBLFdBQVc7QUFBQSxrQkFDVCxNQUFNLFVBQVU7QUFBQSxrQkFDaEIsUUFBUSxVQUFVO0FBQUEsZ0JBQ3BCO0FBQUEsZ0JBQ0EsTUFBTSxTQUFTO0FBQUEsY0FDakIsQ0FBQztBQUFBLFlBQ0g7QUFBQSxVQUNGLE9BQU87QUFDTCxzQkFBVTtBQUFBLFVBQ1o7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBQ0QsV0FBSyxtQkFBbUIsU0FBUyxZQUFZLGVBQWU7QUFDMUQsWUFBSSxpQkFBaUIsWUFBWSxhQUFhO0FBQUEsTUFDaEQsQ0FBQztBQUNELGFBQU8sRUFBRSxNQUFNLFVBQVUsTUFBTSxJQUFJO0FBQUEsSUFDckM7QUFDQSxZQUFRLGFBQWE7QUFBQSxFQUN2QjtBQUNGLENBQUM7QUFHRCxJQUFJLHFCQUFxQixXQUFXO0FBQUEsRUFDbEMsMkNBQTJDLFNBQVM7QUFDbEQsWUFBUSxxQkFBcUIsNkJBQTZCLEVBQUU7QUFDNUQsWUFBUSxvQkFBb0IsNEJBQTRCLEVBQUU7QUFDMUQsWUFBUSxhQUFhLG9CQUFvQixFQUFFO0FBQUEsRUFDN0M7QUFDRixDQUFDO0FBR0QsSUFBSSx1QkFBdUIsUUFBUSxtQkFBbUIsR0FBRyxDQUFDO0FBQzFELGVBQWUsVUFBVSxtQkFBbUIsTUFBTTtBQUNoRCxRQUFNLE1BQU0sSUFBSSxJQUFJLE9BQU8sU0FBUyxNQUFNO0FBQzFDLE1BQUksV0FBVyxlQUFlLEtBQUssR0FBRztBQUN0QyxRQUFNLFdBQVcsTUFBTSxNQUFNLElBQUksU0FBUyxHQUFHO0FBQUEsSUFDM0MsUUFBUTtBQUFBLElBQ1IsTUFBTSxLQUFLLFVBQVUsSUFBSTtBQUFBLEVBQzNCLENBQUM7QUFDRCxTQUFPLFNBQVMsUUFBUSxJQUFJLGNBQWMsR0FBRyxXQUFXLGtCQUFrQixJQUFJLFNBQVMsS0FBSyxJQUFJLFNBQVMsS0FBSztBQUNoSDtBQUNBLFNBQVMsZUFBZSxRQUFRLGlCQUFpQixDQUFDLEdBQUc7QUFDbkQsU0FBTyxJQUFJLE1BQU0sUUFBUTtBQUFBLElBQ3ZCLE9BQU8sQ0FBQyxTQUFTLEdBQUcsYUFBYTtBQUMvQixhQUFPLFFBQVEsZ0JBQWdCLEdBQUcsUUFBUTtBQUFBLElBQzVDO0FBQUEsSUFDQSxLQUFLLENBQUMsR0FBRyxNQUFNO0FBQ2IscUJBQWUsS0FBSyxDQUFDO0FBQ3JCLGFBQU8sZUFBZSxRQUFRLGNBQWM7QUFBQSxJQUM5QztBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBQ0EsU0FBU0MsT0FBTTtBQUNiLFNBQU8sZUFBZSxTQUFTO0FBQ2pDO0FBQ0EsT0FBTyxNQUFNQTtBQUNiLE9BQU8sU0FBUyxDQUFDO0FBQ2pCLE9BQU8sT0FBTyxDQUFDLGFBQWEsWUFBWTtBQUN0QyxRQUFNLFdBQVcsT0FBTyxPQUFPLFdBQVc7QUFDMUMsTUFBSSxDQUFDO0FBQ0gsVUFBTSx3Q0FBd0MsV0FBVyx3QkFBd0IsT0FBTztBQUMxRixXQUFTLE9BQU87QUFDbEI7QUFDQSxJQUFJLFdBQVcsTUFBTUEsS0FBSSxFQUFFLFNBQVM7QUFDcEMsSUFBSSxhQUFhLFFBQVE7QUFDdkIsUUFBTSxPQUFPLE9BQU8sU0FBUyxhQUFhLFVBQVUsUUFBUSxVQUFVLE9BQU8sT0FBTyxTQUFTO0FBQzdGLFFBQU0sS0FBSyxJQUFJLFVBQVUsR0FBRztBQUM1QixLQUFHLFlBQVksQ0FBQyxFQUFFLEtBQUssTUFBTTtBQUMzQixVQUFNLEVBQUUsYUFBYSxRQUFRLElBQUksS0FBSyxNQUFNLElBQUk7QUFDaEQsV0FBTyxLQUFLLGFBQWEsT0FBTztBQUFBLEVBQ2xDO0FBQ0Y7QUFDQSxPQUFPLG9CQUFvQixxQkFBcUI7QUFLaEQ7IiwKICAibmFtZXMiOiBbIl9fZ2V0T3duUHJvcE5hbWVzIiwgInJwYyJdCn0K
