var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};

// Users/cplepage/Desktop/Demo/webview/icons.js
var init_icons = __esm({
  "Users/cplepage/Desktop/Demo/webview/icons.js"() {
    document.querySelectorAll(".icon").forEach(async (icon) => {
      const iconName = Array.from(icon.classList.values()).filter((iconClass) => iconClass !== "icon").at(0);
      icon.innerHTML = await (await fetch(`webview/assets/images/${iconName}.svg`)).text();
    });
  }
});

// Users/cplepage/Desktop/Demo/webview/theme.js
var themeSwitch, startDark;
var init_theme = __esm({
  async "Users/cplepage/Desktop/Demo/webview/theme.js"() {
    themeSwitch = document.querySelector("#theme-switch input");
    startDark = !!parseInt(await rpc().theme.isDark());
    if (startDark) {
      document.documentElement.classList.add("dark");
      themeSwitch.checked = false;
    }
    themeSwitch.addEventListener("change", (e) => {
      const isDark = !e.currentTarget.checked;
      if (isDark) {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
      rpc().theme.saveDark(isDark ? "1" : "0");
    });
  }
});

// Users/cplepage/Desktop/Demo/random-log.js
function randomLog(quotes) {
  const index = Math.floor(Math.random() * quotes.length);
  console.log(quotes[index]);
}
var init_random_log = __esm({
  "Users/cplepage/Desktop/Demo/random-log.js"() {
  }
});

// Users/cplepage/Desktop/Demo/webview/counter.js
var countView, sub, add, reset, count, updateCount, chatGPTQuotes;
var init_counter = __esm({
  async "Users/cplepage/Desktop/Demo/webview/counter.js"() {
    init_random_log();
    countView = document.querySelector("#counter > div > div");
    [sub, add, reset] = document.querySelectorAll("#counter button");
    count = parseInt(await rpc().count.load());
    countView.innerText = count.toString();
    updateCount = () => {
      countView.innerText = count.toString();
      if (!count) {
        rpc().count.reset();
      } else {
        rpc().count.save(count.toString());
      }
      if (count % 3 === 1) {
        randomLog(chatGPTQuotes);
      }
    };
    sub.addEventListener("click", () => {
      count--;
      updateCount();
    });
    add.addEventListener("click", () => {
      count++;
      updateCount();
    });
    reset.addEventListener("click", () => {
      count = 0;
      updateCount();
    });
    chatGPTQuotes = [
      "Clicking that button like a boss \u2013 one press at a time!",
      "You're on fire! Keep clicking, and let the counting games begin.",
      "Clicking away like a champion. You're the true counter extraordinaire!",
      "Counting with precision \u2013 one click at a time. You've got this!",
      "Clicking faster than a caffeinated hummingbird. You're unstoppable!",
      "Clickity-click! You're the maestro of the counter symphony.",
      "Counting clicks like it's an Olympic sport. Gold medal vibes!",
      "Keep calm and click on. You're making history, one button at a time.",
      "Click, click, hooray! You're the click master, no doubt.",
      "You've got the Midas touch \u2013 but with a counter button. Click it all to gold!",
      "Clicking like it's going out of style. Spoiler: it's not!",
      "Counting clicks like a mathematician with a sense of humor. Go, you!",
      "Clicking with the precision of a ninja \u2013 silent but deadly accurate.",
      "Button-clicking virtuoso in action! Encore, encore!",
      "Clicking away, leaving a trail of smiles and counting triumphs.",
      "Clicking so fast, you might break the internet. Proceed with awesomeness!",
      "Counting clicks like a rockstar. Your fans are cheering!",
      "Clicking like there's no tomorrow. Spoiler alert: Tomorrow, you'll still be clicking!",
      "You're not just clicking; you're creating a masterpiece of counts!",
      "Clicking so smoothly, it's like butter \u2013 but without the mess.",
      "Clicking brilliance in progress! The world needs more counters like you.",
      "Counting clicks like a pro \u2013 because amateurs are for the faint-hearted.",
      "Clicking with finesse and style. You're the James Bond of counters!",
      "Click, click, hooray! The world is a better place with your counting skills.",
      "Clicking through life with flair and humor. Keep it up!",
      "Counting clicks like it's a dance. You've got the perfect moves!",
      "Click, click, hooray! The world is a better place with your counting skills.",
      "Counting clicks like a boss. Your finger must be in training!",
      "Clicking like it's the coolest thing you'll do today. Spoiler: it is!",
      "Click, laugh, repeat. Your clicking journey is pure joy!",
      "Counting clicks with the enthusiasm of a kid in a candy store. Keep that joy alive!",
      "Clicking like a pro \u2013 because amateurs are for beginners.",
      "Button clicking level: Expert. You're acing this game!",
      "Clicking away, making numbers look good. Keep up the fantastic work!",
      "Counting clicks like it's an art form. Picasso would be proud!",
      "Clicking with style, grace, and a touch of humor. That's how it's done!",
      "Clicking buttons with the precision of a surgeon. You're saving lives, one click at a time!"
    ];
  }
});

// Users/cplepage/Desktop/Demo/webview/index.js
var webview_exports = {};
var init_webview = __esm({
  async "Users/cplepage/Desktop/Demo/webview/index.js"() {
    init_icons();
    await init_theme();
    await init_counter();
  }
});

// Users/cplepage/.cache/fullstacked/tmp-1708491946012.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames2 = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames2(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames2(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var require_base64 = __commonJS({
  "node_modules/source-map-js/lib/base64.js"(exports) {
    var intToCharMap = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("");
    exports.encode = function(number) {
      if (0 <= number && number < intToCharMap.length) {
        return intToCharMap[number];
      }
      throw new TypeError("Must be between 0 and 63: " + number);
    };
    exports.decode = function(charCode) {
      var bigA = 65;
      var bigZ = 90;
      var littleA = 97;
      var littleZ = 122;
      var zero = 48;
      var nine = 57;
      var plus = 43;
      var slash = 47;
      var littleOffset = 26;
      var numberOffset = 52;
      if (bigA <= charCode && charCode <= bigZ) {
        return charCode - bigA;
      }
      if (littleA <= charCode && charCode <= littleZ) {
        return charCode - littleA + littleOffset;
      }
      if (zero <= charCode && charCode <= nine) {
        return charCode - zero + numberOffset;
      }
      if (charCode == plus) {
        return 62;
      }
      if (charCode == slash) {
        return 63;
      }
      return -1;
    };
  }
});
var require_base64_vlq = __commonJS({
  "node_modules/source-map-js/lib/base64-vlq.js"(exports) {
    var base64 = require_base64();
    var VLQ_BASE_SHIFT = 5;
    var VLQ_BASE = 1 << VLQ_BASE_SHIFT;
    var VLQ_BASE_MASK = VLQ_BASE - 1;
    var VLQ_CONTINUATION_BIT = VLQ_BASE;
    function toVLQSigned(aValue) {
      return aValue < 0 ? (-aValue << 1) + 1 : (aValue << 1) + 0;
    }
    function fromVLQSigned(aValue) {
      var isNegative = (aValue & 1) === 1;
      var shifted = aValue >> 1;
      return isNegative ? -shifted : shifted;
    }
    exports.encode = function base64VLQ_encode(aValue) {
      var encoded = "";
      var digit;
      var vlq = toVLQSigned(aValue);
      do {
        digit = vlq & VLQ_BASE_MASK;
        vlq >>>= VLQ_BASE_SHIFT;
        if (vlq > 0) {
          digit |= VLQ_CONTINUATION_BIT;
        }
        encoded += base64.encode(digit);
      } while (vlq > 0);
      return encoded;
    };
    exports.decode = function base64VLQ_decode(aStr, aIndex, aOutParam) {
      var strLen = aStr.length;
      var result = 0;
      var shift = 0;
      var continuation, digit;
      do {
        if (aIndex >= strLen) {
          throw new Error("Expected more digits in base 64 VLQ value.");
        }
        digit = base64.decode(aStr.charCodeAt(aIndex++));
        if (digit === -1) {
          throw new Error("Invalid base64 digit: " + aStr.charAt(aIndex - 1));
        }
        continuation = !!(digit & VLQ_CONTINUATION_BIT);
        digit &= VLQ_BASE_MASK;
        result = result + (digit << shift);
        shift += VLQ_BASE_SHIFT;
      } while (continuation);
      aOutParam.value = fromVLQSigned(result);
      aOutParam.rest = aIndex;
    };
  }
});
var require_util = __commonJS({
  "node_modules/source-map-js/lib/util.js"(exports) {
    function getArg(aArgs, aName, aDefaultValue) {
      if (aName in aArgs) {
        return aArgs[aName];
      } else if (arguments.length === 3) {
        return aDefaultValue;
      } else {
        throw new Error('"' + aName + '" is a required argument.');
      }
    }
    exports.getArg = getArg;
    var urlRegexp = /^(?:([\w+\-.]+):)?\/\/(?:(\w+:\w+)@)?([\w.-]*)(?::(\d+))?(.*)$/;
    var dataUrlRegexp = /^data:.+\,.+$/;
    function urlParse(aUrl) {
      var match = aUrl.match(urlRegexp);
      if (!match) {
        return null;
      }
      return {
        scheme: match[1],
        auth: match[2],
        host: match[3],
        port: match[4],
        path: match[5]
      };
    }
    exports.urlParse = urlParse;
    function urlGenerate(aParsedUrl) {
      var url = "";
      if (aParsedUrl.scheme) {
        url += aParsedUrl.scheme + ":";
      }
      url += "//";
      if (aParsedUrl.auth) {
        url += aParsedUrl.auth + "@";
      }
      if (aParsedUrl.host) {
        url += aParsedUrl.host;
      }
      if (aParsedUrl.port) {
        url += ":" + aParsedUrl.port;
      }
      if (aParsedUrl.path) {
        url += aParsedUrl.path;
      }
      return url;
    }
    exports.urlGenerate = urlGenerate;
    var MAX_CACHED_INPUTS = 32;
    function lruMemoize(f) {
      var cache = [];
      return function(input) {
        for (var i = 0; i < cache.length; i++) {
          if (cache[i].input === input) {
            var temp = cache[0];
            cache[0] = cache[i];
            cache[i] = temp;
            return cache[0].result;
          }
        }
        var result = f(input);
        cache.unshift({
          input,
          result
        });
        if (cache.length > MAX_CACHED_INPUTS) {
          cache.pop();
        }
        return result;
      };
    }
    var normalize = lruMemoize(function normalize2(aPath) {
      var path = aPath;
      var url = urlParse(aPath);
      if (url) {
        if (!url.path) {
          return aPath;
        }
        path = url.path;
      }
      var isAbsolute = exports.isAbsolute(path);
      var parts = [];
      var start = 0;
      var i = 0;
      while (true) {
        start = i;
        i = path.indexOf("/", start);
        if (i === -1) {
          parts.push(path.slice(start));
          break;
        } else {
          parts.push(path.slice(start, i));
          while (i < path.length && path[i] === "/") {
            i++;
          }
        }
      }
      for (var part, up = 0, i = parts.length - 1; i >= 0; i--) {
        part = parts[i];
        if (part === ".") {
          parts.splice(i, 1);
        } else if (part === "..") {
          up++;
        } else if (up > 0) {
          if (part === "") {
            parts.splice(i + 1, up);
            up = 0;
          } else {
            parts.splice(i, 2);
            up--;
          }
        }
      }
      path = parts.join("/");
      if (path === "") {
        path = isAbsolute ? "/" : ".";
      }
      if (url) {
        url.path = path;
        return urlGenerate(url);
      }
      return path;
    });
    exports.normalize = normalize;
    function join(aRoot, aPath) {
      if (aRoot === "") {
        aRoot = ".";
      }
      if (aPath === "") {
        aPath = ".";
      }
      var aPathUrl = urlParse(aPath);
      var aRootUrl = urlParse(aRoot);
      if (aRootUrl) {
        aRoot = aRootUrl.path || "/";
      }
      if (aPathUrl && !aPathUrl.scheme) {
        if (aRootUrl) {
          aPathUrl.scheme = aRootUrl.scheme;
        }
        return urlGenerate(aPathUrl);
      }
      if (aPathUrl || aPath.match(dataUrlRegexp)) {
        return aPath;
      }
      if (aRootUrl && !aRootUrl.host && !aRootUrl.path) {
        aRootUrl.host = aPath;
        return urlGenerate(aRootUrl);
      }
      var joined = aPath.charAt(0) === "/" ? aPath : normalize(aRoot.replace(/\/+$/, "") + "/" + aPath);
      if (aRootUrl) {
        aRootUrl.path = joined;
        return urlGenerate(aRootUrl);
      }
      return joined;
    }
    exports.join = join;
    exports.isAbsolute = function(aPath) {
      return aPath.charAt(0) === "/" || urlRegexp.test(aPath);
    };
    function relative(aRoot, aPath) {
      if (aRoot === "") {
        aRoot = ".";
      }
      aRoot = aRoot.replace(/\/$/, "");
      var level = 0;
      while (aPath.indexOf(aRoot + "/") !== 0) {
        var index = aRoot.lastIndexOf("/");
        if (index < 0) {
          return aPath;
        }
        aRoot = aRoot.slice(0, index);
        if (aRoot.match(/^([^\/]+:\/)?\/*$/)) {
          return aPath;
        }
        ++level;
      }
      return Array(level + 1).join("../") + aPath.substr(aRoot.length + 1);
    }
    exports.relative = relative;
    var supportsNullProto = function() {
      var obj = /* @__PURE__ */ Object.create(null);
      return !("__proto__" in obj);
    }();
    function identity(s) {
      return s;
    }
    function toSetString(aStr) {
      if (isProtoString(aStr)) {
        return "$" + aStr;
      }
      return aStr;
    }
    exports.toSetString = supportsNullProto ? identity : toSetString;
    function fromSetString(aStr) {
      if (isProtoString(aStr)) {
        return aStr.slice(1);
      }
      return aStr;
    }
    exports.fromSetString = supportsNullProto ? identity : fromSetString;
    function isProtoString(s) {
      if (!s) {
        return false;
      }
      var length = s.length;
      if (length < 9) {
        return false;
      }
      if (s.charCodeAt(length - 1) !== 95 || s.charCodeAt(length - 2) !== 95 || s.charCodeAt(length - 3) !== 111 || s.charCodeAt(length - 4) !== 116 || s.charCodeAt(length - 5) !== 111 || s.charCodeAt(length - 6) !== 114 || s.charCodeAt(length - 7) !== 112 || s.charCodeAt(length - 8) !== 95 || s.charCodeAt(length - 9) !== 95) {
        return false;
      }
      for (var i = length - 10; i >= 0; i--) {
        if (s.charCodeAt(i) !== 36) {
          return false;
        }
      }
      return true;
    }
    function compareByOriginalPositions(mappingA, mappingB, onlyCompareOriginal) {
      var cmp = strcmp(mappingA.source, mappingB.source);
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalLine - mappingB.originalLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalColumn - mappingB.originalColumn;
      if (cmp !== 0 || onlyCompareOriginal) {
        return cmp;
      }
      cmp = mappingA.generatedColumn - mappingB.generatedColumn;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.generatedLine - mappingB.generatedLine;
      if (cmp !== 0) {
        return cmp;
      }
      return strcmp(mappingA.name, mappingB.name);
    }
    exports.compareByOriginalPositions = compareByOriginalPositions;
    function compareByOriginalPositionsNoSource(mappingA, mappingB, onlyCompareOriginal) {
      var cmp;
      cmp = mappingA.originalLine - mappingB.originalLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalColumn - mappingB.originalColumn;
      if (cmp !== 0 || onlyCompareOriginal) {
        return cmp;
      }
      cmp = mappingA.generatedColumn - mappingB.generatedColumn;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.generatedLine - mappingB.generatedLine;
      if (cmp !== 0) {
        return cmp;
      }
      return strcmp(mappingA.name, mappingB.name);
    }
    exports.compareByOriginalPositionsNoSource = compareByOriginalPositionsNoSource;
    function compareByGeneratedPositionsDeflated(mappingA, mappingB, onlyCompareGenerated) {
      var cmp = mappingA.generatedLine - mappingB.generatedLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.generatedColumn - mappingB.generatedColumn;
      if (cmp !== 0 || onlyCompareGenerated) {
        return cmp;
      }
      cmp = strcmp(mappingA.source, mappingB.source);
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalLine - mappingB.originalLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalColumn - mappingB.originalColumn;
      if (cmp !== 0) {
        return cmp;
      }
      return strcmp(mappingA.name, mappingB.name);
    }
    exports.compareByGeneratedPositionsDeflated = compareByGeneratedPositionsDeflated;
    function compareByGeneratedPositionsDeflatedNoLine(mappingA, mappingB, onlyCompareGenerated) {
      var cmp = mappingA.generatedColumn - mappingB.generatedColumn;
      if (cmp !== 0 || onlyCompareGenerated) {
        return cmp;
      }
      cmp = strcmp(mappingA.source, mappingB.source);
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalLine - mappingB.originalLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalColumn - mappingB.originalColumn;
      if (cmp !== 0) {
        return cmp;
      }
      return strcmp(mappingA.name, mappingB.name);
    }
    exports.compareByGeneratedPositionsDeflatedNoLine = compareByGeneratedPositionsDeflatedNoLine;
    function strcmp(aStr1, aStr2) {
      if (aStr1 === aStr2) {
        return 0;
      }
      if (aStr1 === null) {
        return 1;
      }
      if (aStr2 === null) {
        return -1;
      }
      if (aStr1 > aStr2) {
        return 1;
      }
      return -1;
    }
    function compareByGeneratedPositionsInflated(mappingA, mappingB) {
      var cmp = mappingA.generatedLine - mappingB.generatedLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.generatedColumn - mappingB.generatedColumn;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = strcmp(mappingA.source, mappingB.source);
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalLine - mappingB.originalLine;
      if (cmp !== 0) {
        return cmp;
      }
      cmp = mappingA.originalColumn - mappingB.originalColumn;
      if (cmp !== 0) {
        return cmp;
      }
      return strcmp(mappingA.name, mappingB.name);
    }
    exports.compareByGeneratedPositionsInflated = compareByGeneratedPositionsInflated;
    function parseSourceMapInput(str) {
      return JSON.parse(str.replace(/^\)]}'[^\n]*\n/, ""));
    }
    exports.parseSourceMapInput = parseSourceMapInput;
    function computeSourceURL(sourceRoot, sourceURL, sourceMapURL) {
      sourceURL = sourceURL || "";
      if (sourceRoot) {
        if (sourceRoot[sourceRoot.length - 1] !== "/" && sourceURL[0] !== "/") {
          sourceRoot += "/";
        }
        sourceURL = sourceRoot + sourceURL;
      }
      if (sourceMapURL) {
        var parsed = urlParse(sourceMapURL);
        if (!parsed) {
          throw new Error("sourceMapURL could not be parsed");
        }
        if (parsed.path) {
          var index = parsed.path.lastIndexOf("/");
          if (index >= 0) {
            parsed.path = parsed.path.substring(0, index + 1);
          }
        }
        sourceURL = join(urlGenerate(parsed), sourceURL);
      }
      return normalize(sourceURL);
    }
    exports.computeSourceURL = computeSourceURL;
  }
});
var require_array_set = __commonJS({
  "node_modules/source-map-js/lib/array-set.js"(exports) {
    var util = require_util();
    var has = Object.prototype.hasOwnProperty;
    var hasNativeMap = typeof Map !== "undefined";
    function ArraySet() {
      this._array = [];
      this._set = hasNativeMap ? /* @__PURE__ */ new Map() : /* @__PURE__ */ Object.create(null);
    }
    ArraySet.fromArray = function ArraySet_fromArray(aArray, aAllowDuplicates) {
      var set = new ArraySet();
      for (var i = 0, len = aArray.length; i < len; i++) {
        set.add(aArray[i], aAllowDuplicates);
      }
      return set;
    };
    ArraySet.prototype.size = function ArraySet_size() {
      return hasNativeMap ? this._set.size : Object.getOwnPropertyNames(this._set).length;
    };
    ArraySet.prototype.add = function ArraySet_add(aStr, aAllowDuplicates) {
      var sStr = hasNativeMap ? aStr : util.toSetString(aStr);
      var isDuplicate = hasNativeMap ? this.has(aStr) : has.call(this._set, sStr);
      var idx = this._array.length;
      if (!isDuplicate || aAllowDuplicates) {
        this._array.push(aStr);
      }
      if (!isDuplicate) {
        if (hasNativeMap) {
          this._set.set(aStr, idx);
        } else {
          this._set[sStr] = idx;
        }
      }
    };
    ArraySet.prototype.has = function ArraySet_has(aStr) {
      if (hasNativeMap) {
        return this._set.has(aStr);
      } else {
        var sStr = util.toSetString(aStr);
        return has.call(this._set, sStr);
      }
    };
    ArraySet.prototype.indexOf = function ArraySet_indexOf(aStr) {
      if (hasNativeMap) {
        var idx = this._set.get(aStr);
        if (idx >= 0) {
          return idx;
        }
      } else {
        var sStr = util.toSetString(aStr);
        if (has.call(this._set, sStr)) {
          return this._set[sStr];
        }
      }
      throw new Error('"' + aStr + '" is not in the set.');
    };
    ArraySet.prototype.at = function ArraySet_at(aIdx) {
      if (aIdx >= 0 && aIdx < this._array.length) {
        return this._array[aIdx];
      }
      throw new Error("No element indexed by " + aIdx);
    };
    ArraySet.prototype.toArray = function ArraySet_toArray() {
      return this._array.slice();
    };
    exports.ArraySet = ArraySet;
  }
});
var require_mapping_list = __commonJS({
  "node_modules/source-map-js/lib/mapping-list.js"(exports) {
    var util = require_util();
    function generatedPositionAfter(mappingA, mappingB) {
      var lineA = mappingA.generatedLine;
      var lineB = mappingB.generatedLine;
      var columnA = mappingA.generatedColumn;
      var columnB = mappingB.generatedColumn;
      return lineB > lineA || lineB == lineA && columnB >= columnA || util.compareByGeneratedPositionsInflated(mappingA, mappingB) <= 0;
    }
    function MappingList() {
      this._array = [];
      this._sorted = true;
      this._last = { generatedLine: -1, generatedColumn: 0 };
    }
    MappingList.prototype.unsortedForEach = function MappingList_forEach(aCallback, aThisArg) {
      this._array.forEach(aCallback, aThisArg);
    };
    MappingList.prototype.add = function MappingList_add(aMapping) {
      if (generatedPositionAfter(this._last, aMapping)) {
        this._last = aMapping;
        this._array.push(aMapping);
      } else {
        this._sorted = false;
        this._array.push(aMapping);
      }
    };
    MappingList.prototype.toArray = function MappingList_toArray() {
      if (!this._sorted) {
        this._array.sort(util.compareByGeneratedPositionsInflated);
        this._sorted = true;
      }
      return this._array;
    };
    exports.MappingList = MappingList;
  }
});
var require_source_map_generator = __commonJS({
  "node_modules/source-map-js/lib/source-map-generator.js"(exports) {
    var base64VLQ = require_base64_vlq();
    var util = require_util();
    var ArraySet = require_array_set().ArraySet;
    var MappingList = require_mapping_list().MappingList;
    function SourceMapGenerator(aArgs) {
      if (!aArgs) {
        aArgs = {};
      }
      this._file = util.getArg(aArgs, "file", null);
      this._sourceRoot = util.getArg(aArgs, "sourceRoot", null);
      this._skipValidation = util.getArg(aArgs, "skipValidation", false);
      this._sources = new ArraySet();
      this._names = new ArraySet();
      this._mappings = new MappingList();
      this._sourcesContents = null;
    }
    SourceMapGenerator.prototype._version = 3;
    SourceMapGenerator.fromSourceMap = function SourceMapGenerator_fromSourceMap(aSourceMapConsumer) {
      var sourceRoot = aSourceMapConsumer.sourceRoot;
      var generator = new SourceMapGenerator({
        file: aSourceMapConsumer.file,
        sourceRoot
      });
      aSourceMapConsumer.eachMapping(function(mapping) {
        var newMapping = {
          generated: {
            line: mapping.generatedLine,
            column: mapping.generatedColumn
          }
        };
        if (mapping.source != null) {
          newMapping.source = mapping.source;
          if (sourceRoot != null) {
            newMapping.source = util.relative(sourceRoot, newMapping.source);
          }
          newMapping.original = {
            line: mapping.originalLine,
            column: mapping.originalColumn
          };
          if (mapping.name != null) {
            newMapping.name = mapping.name;
          }
        }
        generator.addMapping(newMapping);
      });
      aSourceMapConsumer.sources.forEach(function(sourceFile) {
        var sourceRelative = sourceFile;
        if (sourceRoot !== null) {
          sourceRelative = util.relative(sourceRoot, sourceFile);
        }
        if (!generator._sources.has(sourceRelative)) {
          generator._sources.add(sourceRelative);
        }
        var content = aSourceMapConsumer.sourceContentFor(sourceFile);
        if (content != null) {
          generator.setSourceContent(sourceFile, content);
        }
      });
      return generator;
    };
    SourceMapGenerator.prototype.addMapping = function SourceMapGenerator_addMapping(aArgs) {
      var generated = util.getArg(aArgs, "generated");
      var original = util.getArg(aArgs, "original", null);
      var source = util.getArg(aArgs, "source", null);
      var name = util.getArg(aArgs, "name", null);
      if (!this._skipValidation) {
        this._validateMapping(generated, original, source, name);
      }
      if (source != null) {
        source = String(source);
        if (!this._sources.has(source)) {
          this._sources.add(source);
        }
      }
      if (name != null) {
        name = String(name);
        if (!this._names.has(name)) {
          this._names.add(name);
        }
      }
      this._mappings.add({
        generatedLine: generated.line,
        generatedColumn: generated.column,
        originalLine: original != null && original.line,
        originalColumn: original != null && original.column,
        source,
        name
      });
    };
    SourceMapGenerator.prototype.setSourceContent = function SourceMapGenerator_setSourceContent(aSourceFile, aSourceContent) {
      var source = aSourceFile;
      if (this._sourceRoot != null) {
        source = util.relative(this._sourceRoot, source);
      }
      if (aSourceContent != null) {
        if (!this._sourcesContents) {
          this._sourcesContents = /* @__PURE__ */ Object.create(null);
        }
        this._sourcesContents[util.toSetString(source)] = aSourceContent;
      } else if (this._sourcesContents) {
        delete this._sourcesContents[util.toSetString(source)];
        if (Object.keys(this._sourcesContents).length === 0) {
          this._sourcesContents = null;
        }
      }
    };
    SourceMapGenerator.prototype.applySourceMap = function SourceMapGenerator_applySourceMap(aSourceMapConsumer, aSourceFile, aSourceMapPath) {
      var sourceFile = aSourceFile;
      if (aSourceFile == null) {
        if (aSourceMapConsumer.file == null) {
          throw new Error(
            `SourceMapGenerator.prototype.applySourceMap requires either an explicit source file, or the source map's "file" property. Both were omitted.`
          );
        }
        sourceFile = aSourceMapConsumer.file;
      }
      var sourceRoot = this._sourceRoot;
      if (sourceRoot != null) {
        sourceFile = util.relative(sourceRoot, sourceFile);
      }
      var newSources = new ArraySet();
      var newNames = new ArraySet();
      this._mappings.unsortedForEach(function(mapping) {
        if (mapping.source === sourceFile && mapping.originalLine != null) {
          var original = aSourceMapConsumer.originalPositionFor({
            line: mapping.originalLine,
            column: mapping.originalColumn
          });
          if (original.source != null) {
            mapping.source = original.source;
            if (aSourceMapPath != null) {
              mapping.source = util.join(aSourceMapPath, mapping.source);
            }
            if (sourceRoot != null) {
              mapping.source = util.relative(sourceRoot, mapping.source);
            }
            mapping.originalLine = original.line;
            mapping.originalColumn = original.column;
            if (original.name != null) {
              mapping.name = original.name;
            }
          }
        }
        var source = mapping.source;
        if (source != null && !newSources.has(source)) {
          newSources.add(source);
        }
        var name = mapping.name;
        if (name != null && !newNames.has(name)) {
          newNames.add(name);
        }
      }, this);
      this._sources = newSources;
      this._names = newNames;
      aSourceMapConsumer.sources.forEach(function(sourceFile2) {
        var content = aSourceMapConsumer.sourceContentFor(sourceFile2);
        if (content != null) {
          if (aSourceMapPath != null) {
            sourceFile2 = util.join(aSourceMapPath, sourceFile2);
          }
          if (sourceRoot != null) {
            sourceFile2 = util.relative(sourceRoot, sourceFile2);
          }
          this.setSourceContent(sourceFile2, content);
        }
      }, this);
    };
    SourceMapGenerator.prototype._validateMapping = function SourceMapGenerator_validateMapping(aGenerated, aOriginal, aSource, aName) {
      if (aOriginal && typeof aOriginal.line !== "number" && typeof aOriginal.column !== "number") {
        throw new Error(
          "original.line and original.column are not numbers -- you probably meant to omit the original mapping entirely and only map the generated position. If so, pass null for the original mapping instead of an object with empty or null values."
        );
      }
      if (aGenerated && "line" in aGenerated && "column" in aGenerated && aGenerated.line > 0 && aGenerated.column >= 0 && !aOriginal && !aSource && !aName) {
        return;
      } else if (aGenerated && "line" in aGenerated && "column" in aGenerated && aOriginal && "line" in aOriginal && "column" in aOriginal && aGenerated.line > 0 && aGenerated.column >= 0 && aOriginal.line > 0 && aOriginal.column >= 0 && aSource) {
        return;
      } else {
        throw new Error("Invalid mapping: " + JSON.stringify({
          generated: aGenerated,
          source: aSource,
          original: aOriginal,
          name: aName
        }));
      }
    };
    SourceMapGenerator.prototype._serializeMappings = function SourceMapGenerator_serializeMappings() {
      var previousGeneratedColumn = 0;
      var previousGeneratedLine = 1;
      var previousOriginalColumn = 0;
      var previousOriginalLine = 0;
      var previousName = 0;
      var previousSource = 0;
      var result = "";
      var next;
      var mapping;
      var nameIdx;
      var sourceIdx;
      var mappings = this._mappings.toArray();
      for (var i = 0, len = mappings.length; i < len; i++) {
        mapping = mappings[i];
        next = "";
        if (mapping.generatedLine !== previousGeneratedLine) {
          previousGeneratedColumn = 0;
          while (mapping.generatedLine !== previousGeneratedLine) {
            next += ";";
            previousGeneratedLine++;
          }
        } else {
          if (i > 0) {
            if (!util.compareByGeneratedPositionsInflated(mapping, mappings[i - 1])) {
              continue;
            }
            next += ",";
          }
        }
        next += base64VLQ.encode(mapping.generatedColumn - previousGeneratedColumn);
        previousGeneratedColumn = mapping.generatedColumn;
        if (mapping.source != null) {
          sourceIdx = this._sources.indexOf(mapping.source);
          next += base64VLQ.encode(sourceIdx - previousSource);
          previousSource = sourceIdx;
          next += base64VLQ.encode(mapping.originalLine - 1 - previousOriginalLine);
          previousOriginalLine = mapping.originalLine - 1;
          next += base64VLQ.encode(mapping.originalColumn - previousOriginalColumn);
          previousOriginalColumn = mapping.originalColumn;
          if (mapping.name != null) {
            nameIdx = this._names.indexOf(mapping.name);
            next += base64VLQ.encode(nameIdx - previousName);
            previousName = nameIdx;
          }
        }
        result += next;
      }
      return result;
    };
    SourceMapGenerator.prototype._generateSourcesContent = function SourceMapGenerator_generateSourcesContent(aSources, aSourceRoot) {
      return aSources.map(function(source) {
        if (!this._sourcesContents) {
          return null;
        }
        if (aSourceRoot != null) {
          source = util.relative(aSourceRoot, source);
        }
        var key = util.toSetString(source);
        return Object.prototype.hasOwnProperty.call(this._sourcesContents, key) ? this._sourcesContents[key] : null;
      }, this);
    };
    SourceMapGenerator.prototype.toJSON = function SourceMapGenerator_toJSON() {
      var map = {
        version: this._version,
        sources: this._sources.toArray(),
        names: this._names.toArray(),
        mappings: this._serializeMappings()
      };
      if (this._file != null) {
        map.file = this._file;
      }
      if (this._sourceRoot != null) {
        map.sourceRoot = this._sourceRoot;
      }
      if (this._sourcesContents) {
        map.sourcesContent = this._generateSourcesContent(map.sources, map.sourceRoot);
      }
      return map;
    };
    SourceMapGenerator.prototype.toString = function SourceMapGenerator_toString() {
      return JSON.stringify(this.toJSON());
    };
    exports.SourceMapGenerator = SourceMapGenerator;
  }
});
var require_binary_search = __commonJS({
  "node_modules/source-map-js/lib/binary-search.js"(exports) {
    exports.GREATEST_LOWER_BOUND = 1;
    exports.LEAST_UPPER_BOUND = 2;
    function recursiveSearch(aLow, aHigh, aNeedle, aHaystack, aCompare, aBias) {
      var mid = Math.floor((aHigh - aLow) / 2) + aLow;
      var cmp = aCompare(aNeedle, aHaystack[mid], true);
      if (cmp === 0) {
        return mid;
      } else if (cmp > 0) {
        if (aHigh - mid > 1) {
          return recursiveSearch(mid, aHigh, aNeedle, aHaystack, aCompare, aBias);
        }
        if (aBias == exports.LEAST_UPPER_BOUND) {
          return aHigh < aHaystack.length ? aHigh : -1;
        } else {
          return mid;
        }
      } else {
        if (mid - aLow > 1) {
          return recursiveSearch(aLow, mid, aNeedle, aHaystack, aCompare, aBias);
        }
        if (aBias == exports.LEAST_UPPER_BOUND) {
          return mid;
        } else {
          return aLow < 0 ? -1 : aLow;
        }
      }
    }
    exports.search = function search(aNeedle, aHaystack, aCompare, aBias) {
      if (aHaystack.length === 0) {
        return -1;
      }
      var index = recursiveSearch(
        -1,
        aHaystack.length,
        aNeedle,
        aHaystack,
        aCompare,
        aBias || exports.GREATEST_LOWER_BOUND
      );
      if (index < 0) {
        return -1;
      }
      while (index - 1 >= 0) {
        if (aCompare(aHaystack[index], aHaystack[index - 1], true) !== 0) {
          break;
        }
        --index;
      }
      return index;
    };
  }
});
var require_quick_sort = __commonJS({
  "node_modules/source-map-js/lib/quick-sort.js"(exports) {
    function SortTemplate(comparator) {
      function swap(ary, x, y) {
        var temp = ary[x];
        ary[x] = ary[y];
        ary[y] = temp;
      }
      function randomIntInRange(low, high) {
        return Math.round(low + Math.random() * (high - low));
      }
      function doQuickSort(ary, comparator2, p, r) {
        if (p < r) {
          var pivotIndex = randomIntInRange(p, r);
          var i = p - 1;
          swap(ary, pivotIndex, r);
          var pivot = ary[r];
          for (var j = p; j < r; j++) {
            if (comparator2(ary[j], pivot, false) <= 0) {
              i += 1;
              swap(ary, i, j);
            }
          }
          swap(ary, i + 1, j);
          var q = i + 1;
          doQuickSort(ary, comparator2, p, q - 1);
          doQuickSort(ary, comparator2, q + 1, r);
        }
      }
      return doQuickSort;
    }
    function cloneSort(comparator) {
      let template = SortTemplate.toString();
      let templateFn = new Function(`return ${template}`)();
      return templateFn(comparator);
    }
    var sortCache = /* @__PURE__ */ new WeakMap();
    exports.quickSort = function(ary, comparator, start = 0) {
      let doQuickSort = sortCache.get(comparator);
      if (doQuickSort === void 0) {
        doQuickSort = cloneSort(comparator);
        sortCache.set(comparator, doQuickSort);
      }
      doQuickSort(ary, comparator, start, ary.length - 1);
    };
  }
});
var require_source_map_consumer = __commonJS({
  "node_modules/source-map-js/lib/source-map-consumer.js"(exports) {
    var util = require_util();
    var binarySearch = require_binary_search();
    var ArraySet = require_array_set().ArraySet;
    var base64VLQ = require_base64_vlq();
    var quickSort = require_quick_sort().quickSort;
    function SourceMapConsumer2(aSourceMap, aSourceMapURL) {
      var sourceMap = aSourceMap;
      if (typeof aSourceMap === "string") {
        sourceMap = util.parseSourceMapInput(aSourceMap);
      }
      return sourceMap.sections != null ? new IndexedSourceMapConsumer(sourceMap, aSourceMapURL) : new BasicSourceMapConsumer(sourceMap, aSourceMapURL);
    }
    SourceMapConsumer2.fromSourceMap = function(aSourceMap, aSourceMapURL) {
      return BasicSourceMapConsumer.fromSourceMap(aSourceMap, aSourceMapURL);
    };
    SourceMapConsumer2.prototype._version = 3;
    SourceMapConsumer2.prototype.__generatedMappings = null;
    Object.defineProperty(SourceMapConsumer2.prototype, "_generatedMappings", {
      configurable: true,
      enumerable: true,
      get: function() {
        if (!this.__generatedMappings) {
          this._parseMappings(this._mappings, this.sourceRoot);
        }
        return this.__generatedMappings;
      }
    });
    SourceMapConsumer2.prototype.__originalMappings = null;
    Object.defineProperty(SourceMapConsumer2.prototype, "_originalMappings", {
      configurable: true,
      enumerable: true,
      get: function() {
        if (!this.__originalMappings) {
          this._parseMappings(this._mappings, this.sourceRoot);
        }
        return this.__originalMappings;
      }
    });
    SourceMapConsumer2.prototype._charIsMappingSeparator = function SourceMapConsumer_charIsMappingSeparator(aStr, index) {
      var c = aStr.charAt(index);
      return c === ";" || c === ",";
    };
    SourceMapConsumer2.prototype._parseMappings = function SourceMapConsumer_parseMappings(aStr, aSourceRoot) {
      throw new Error("Subclasses must implement _parseMappings");
    };
    SourceMapConsumer2.GENERATED_ORDER = 1;
    SourceMapConsumer2.ORIGINAL_ORDER = 2;
    SourceMapConsumer2.GREATEST_LOWER_BOUND = 1;
    SourceMapConsumer2.LEAST_UPPER_BOUND = 2;
    SourceMapConsumer2.prototype.eachMapping = function SourceMapConsumer_eachMapping(aCallback, aContext, aOrder) {
      var context = aContext || null;
      var order = aOrder || SourceMapConsumer2.GENERATED_ORDER;
      var mappings;
      switch (order) {
        case SourceMapConsumer2.GENERATED_ORDER:
          mappings = this._generatedMappings;
          break;
        case SourceMapConsumer2.ORIGINAL_ORDER:
          mappings = this._originalMappings;
          break;
        default:
          throw new Error("Unknown order of iteration.");
      }
      var sourceRoot = this.sourceRoot;
      var boundCallback = aCallback.bind(context);
      var names = this._names;
      var sources = this._sources;
      var sourceMapURL = this._sourceMapURL;
      for (var i = 0, n = mappings.length; i < n; i++) {
        var mapping = mappings[i];
        var source = mapping.source === null ? null : sources.at(mapping.source);
        source = util.computeSourceURL(sourceRoot, source, sourceMapURL);
        boundCallback({
          source,
          generatedLine: mapping.generatedLine,
          generatedColumn: mapping.generatedColumn,
          originalLine: mapping.originalLine,
          originalColumn: mapping.originalColumn,
          name: mapping.name === null ? null : names.at(mapping.name)
        });
      }
    };
    SourceMapConsumer2.prototype.allGeneratedPositionsFor = function SourceMapConsumer_allGeneratedPositionsFor(aArgs) {
      var line = util.getArg(aArgs, "line");
      var needle = {
        source: util.getArg(aArgs, "source"),
        originalLine: line,
        originalColumn: util.getArg(aArgs, "column", 0)
      };
      needle.source = this._findSourceIndex(needle.source);
      if (needle.source < 0) {
        return [];
      }
      var mappings = [];
      var index = this._findMapping(
        needle,
        this._originalMappings,
        "originalLine",
        "originalColumn",
        util.compareByOriginalPositions,
        binarySearch.LEAST_UPPER_BOUND
      );
      if (index >= 0) {
        var mapping = this._originalMappings[index];
        if (aArgs.column === void 0) {
          var originalLine = mapping.originalLine;
          while (mapping && mapping.originalLine === originalLine) {
            mappings.push({
              line: util.getArg(mapping, "generatedLine", null),
              column: util.getArg(mapping, "generatedColumn", null),
              lastColumn: util.getArg(mapping, "lastGeneratedColumn", null)
            });
            mapping = this._originalMappings[++index];
          }
        } else {
          var originalColumn = mapping.originalColumn;
          while (mapping && mapping.originalLine === line && mapping.originalColumn == originalColumn) {
            mappings.push({
              line: util.getArg(mapping, "generatedLine", null),
              column: util.getArg(mapping, "generatedColumn", null),
              lastColumn: util.getArg(mapping, "lastGeneratedColumn", null)
            });
            mapping = this._originalMappings[++index];
          }
        }
      }
      return mappings;
    };
    exports.SourceMapConsumer = SourceMapConsumer2;
    function BasicSourceMapConsumer(aSourceMap, aSourceMapURL) {
      var sourceMap = aSourceMap;
      if (typeof aSourceMap === "string") {
        sourceMap = util.parseSourceMapInput(aSourceMap);
      }
      var version = util.getArg(sourceMap, "version");
      var sources = util.getArg(sourceMap, "sources");
      var names = util.getArg(sourceMap, "names", []);
      var sourceRoot = util.getArg(sourceMap, "sourceRoot", null);
      var sourcesContent = util.getArg(sourceMap, "sourcesContent", null);
      var mappings = util.getArg(sourceMap, "mappings");
      var file = util.getArg(sourceMap, "file", null);
      if (version != this._version) {
        throw new Error("Unsupported version: " + version);
      }
      if (sourceRoot) {
        sourceRoot = util.normalize(sourceRoot);
      }
      sources = sources.map(String).map(util.normalize).map(function(source) {
        return sourceRoot && util.isAbsolute(sourceRoot) && util.isAbsolute(source) ? util.relative(sourceRoot, source) : source;
      });
      this._names = ArraySet.fromArray(names.map(String), true);
      this._sources = ArraySet.fromArray(sources, true);
      this._absoluteSources = this._sources.toArray().map(function(s) {
        return util.computeSourceURL(sourceRoot, s, aSourceMapURL);
      });
      this.sourceRoot = sourceRoot;
      this.sourcesContent = sourcesContent;
      this._mappings = mappings;
      this._sourceMapURL = aSourceMapURL;
      this.file = file;
    }
    BasicSourceMapConsumer.prototype = Object.create(SourceMapConsumer2.prototype);
    BasicSourceMapConsumer.prototype.consumer = SourceMapConsumer2;
    BasicSourceMapConsumer.prototype._findSourceIndex = function(aSource) {
      var relativeSource = aSource;
      if (this.sourceRoot != null) {
        relativeSource = util.relative(this.sourceRoot, relativeSource);
      }
      if (this._sources.has(relativeSource)) {
        return this._sources.indexOf(relativeSource);
      }
      var i;
      for (i = 0; i < this._absoluteSources.length; ++i) {
        if (this._absoluteSources[i] == aSource) {
          return i;
        }
      }
      return -1;
    };
    BasicSourceMapConsumer.fromSourceMap = function SourceMapConsumer_fromSourceMap(aSourceMap, aSourceMapURL) {
      var smc = Object.create(BasicSourceMapConsumer.prototype);
      var names = smc._names = ArraySet.fromArray(aSourceMap._names.toArray(), true);
      var sources = smc._sources = ArraySet.fromArray(aSourceMap._sources.toArray(), true);
      smc.sourceRoot = aSourceMap._sourceRoot;
      smc.sourcesContent = aSourceMap._generateSourcesContent(
        smc._sources.toArray(),
        smc.sourceRoot
      );
      smc.file = aSourceMap._file;
      smc._sourceMapURL = aSourceMapURL;
      smc._absoluteSources = smc._sources.toArray().map(function(s) {
        return util.computeSourceURL(smc.sourceRoot, s, aSourceMapURL);
      });
      var generatedMappings = aSourceMap._mappings.toArray().slice();
      var destGeneratedMappings = smc.__generatedMappings = [];
      var destOriginalMappings = smc.__originalMappings = [];
      for (var i = 0, length = generatedMappings.length; i < length; i++) {
        var srcMapping = generatedMappings[i];
        var destMapping = new Mapping();
        destMapping.generatedLine = srcMapping.generatedLine;
        destMapping.generatedColumn = srcMapping.generatedColumn;
        if (srcMapping.source) {
          destMapping.source = sources.indexOf(srcMapping.source);
          destMapping.originalLine = srcMapping.originalLine;
          destMapping.originalColumn = srcMapping.originalColumn;
          if (srcMapping.name) {
            destMapping.name = names.indexOf(srcMapping.name);
          }
          destOriginalMappings.push(destMapping);
        }
        destGeneratedMappings.push(destMapping);
      }
      quickSort(smc.__originalMappings, util.compareByOriginalPositions);
      return smc;
    };
    BasicSourceMapConsumer.prototype._version = 3;
    Object.defineProperty(BasicSourceMapConsumer.prototype, "sources", {
      get: function() {
        return this._absoluteSources.slice();
      }
    });
    function Mapping() {
      this.generatedLine = 0;
      this.generatedColumn = 0;
      this.source = null;
      this.originalLine = null;
      this.originalColumn = null;
      this.name = null;
    }
    var compareGenerated = util.compareByGeneratedPositionsDeflatedNoLine;
    function sortGenerated(array, start) {
      let l = array.length;
      let n = array.length - start;
      if (n <= 1) {
        return;
      } else if (n == 2) {
        let a = array[start];
        let b = array[start + 1];
        if (compareGenerated(a, b) > 0) {
          array[start] = b;
          array[start + 1] = a;
        }
      } else if (n < 20) {
        for (let i = start; i < l; i++) {
          for (let j = i; j > start; j--) {
            let a = array[j - 1];
            let b = array[j];
            if (compareGenerated(a, b) <= 0) {
              break;
            }
            array[j - 1] = b;
            array[j] = a;
          }
        }
      } else {
        quickSort(array, compareGenerated, start);
      }
    }
    BasicSourceMapConsumer.prototype._parseMappings = function SourceMapConsumer_parseMappings(aStr, aSourceRoot) {
      var generatedLine = 1;
      var previousGeneratedColumn = 0;
      var previousOriginalLine = 0;
      var previousOriginalColumn = 0;
      var previousSource = 0;
      var previousName = 0;
      var length = aStr.length;
      var index = 0;
      var cachedSegments = {};
      var temp = {};
      var originalMappings = [];
      var generatedMappings = [];
      var mapping, str, segment, end, value;
      let subarrayStart = 0;
      while (index < length) {
        if (aStr.charAt(index) === ";") {
          generatedLine++;
          index++;
          previousGeneratedColumn = 0;
          sortGenerated(generatedMappings, subarrayStart);
          subarrayStart = generatedMappings.length;
        } else if (aStr.charAt(index) === ",") {
          index++;
        } else {
          mapping = new Mapping();
          mapping.generatedLine = generatedLine;
          for (end = index; end < length; end++) {
            if (this._charIsMappingSeparator(aStr, end)) {
              break;
            }
          }
          str = aStr.slice(index, end);
          segment = [];
          while (index < end) {
            base64VLQ.decode(aStr, index, temp);
            value = temp.value;
            index = temp.rest;
            segment.push(value);
          }
          if (segment.length === 2) {
            throw new Error("Found a source, but no line and column");
          }
          if (segment.length === 3) {
            throw new Error("Found a source and line, but no column");
          }
          mapping.generatedColumn = previousGeneratedColumn + segment[0];
          previousGeneratedColumn = mapping.generatedColumn;
          if (segment.length > 1) {
            mapping.source = previousSource + segment[1];
            previousSource += segment[1];
            mapping.originalLine = previousOriginalLine + segment[2];
            previousOriginalLine = mapping.originalLine;
            mapping.originalLine += 1;
            mapping.originalColumn = previousOriginalColumn + segment[3];
            previousOriginalColumn = mapping.originalColumn;
            if (segment.length > 4) {
              mapping.name = previousName + segment[4];
              previousName += segment[4];
            }
          }
          generatedMappings.push(mapping);
          if (typeof mapping.originalLine === "number") {
            let currentSource = mapping.source;
            while (originalMappings.length <= currentSource) {
              originalMappings.push(null);
            }
            if (originalMappings[currentSource] === null) {
              originalMappings[currentSource] = [];
            }
            originalMappings[currentSource].push(mapping);
          }
        }
      }
      sortGenerated(generatedMappings, subarrayStart);
      this.__generatedMappings = generatedMappings;
      for (var i = 0; i < originalMappings.length; i++) {
        if (originalMappings[i] != null) {
          quickSort(originalMappings[i], util.compareByOriginalPositionsNoSource);
        }
      }
      this.__originalMappings = [].concat(...originalMappings);
    };
    BasicSourceMapConsumer.prototype._findMapping = function SourceMapConsumer_findMapping(aNeedle, aMappings, aLineName, aColumnName, aComparator, aBias) {
      if (aNeedle[aLineName] <= 0) {
        throw new TypeError("Line must be greater than or equal to 1, got " + aNeedle[aLineName]);
      }
      if (aNeedle[aColumnName] < 0) {
        throw new TypeError("Column must be greater than or equal to 0, got " + aNeedle[aColumnName]);
      }
      return binarySearch.search(aNeedle, aMappings, aComparator, aBias);
    };
    BasicSourceMapConsumer.prototype.computeColumnSpans = function SourceMapConsumer_computeColumnSpans() {
      for (var index = 0; index < this._generatedMappings.length; ++index) {
        var mapping = this._generatedMappings[index];
        if (index + 1 < this._generatedMappings.length) {
          var nextMapping = this._generatedMappings[index + 1];
          if (mapping.generatedLine === nextMapping.generatedLine) {
            mapping.lastGeneratedColumn = nextMapping.generatedColumn - 1;
            continue;
          }
        }
        mapping.lastGeneratedColumn = Infinity;
      }
    };
    BasicSourceMapConsumer.prototype.originalPositionFor = function SourceMapConsumer_originalPositionFor(aArgs) {
      var needle = {
        generatedLine: util.getArg(aArgs, "line"),
        generatedColumn: util.getArg(aArgs, "column")
      };
      var index = this._findMapping(
        needle,
        this._generatedMappings,
        "generatedLine",
        "generatedColumn",
        util.compareByGeneratedPositionsDeflated,
        util.getArg(aArgs, "bias", SourceMapConsumer2.GREATEST_LOWER_BOUND)
      );
      if (index >= 0) {
        var mapping = this._generatedMappings[index];
        if (mapping.generatedLine === needle.generatedLine) {
          var source = util.getArg(mapping, "source", null);
          if (source !== null) {
            source = this._sources.at(source);
            source = util.computeSourceURL(this.sourceRoot, source, this._sourceMapURL);
          }
          var name = util.getArg(mapping, "name", null);
          if (name !== null) {
            name = this._names.at(name);
          }
          return {
            source,
            line: util.getArg(mapping, "originalLine", null),
            column: util.getArg(mapping, "originalColumn", null),
            name
          };
        }
      }
      return {
        source: null,
        line: null,
        column: null,
        name: null
      };
    };
    BasicSourceMapConsumer.prototype.hasContentsOfAllSources = function BasicSourceMapConsumer_hasContentsOfAllSources() {
      if (!this.sourcesContent) {
        return false;
      }
      return this.sourcesContent.length >= this._sources.size() && !this.sourcesContent.some(function(sc) {
        return sc == null;
      });
    };
    BasicSourceMapConsumer.prototype.sourceContentFor = function SourceMapConsumer_sourceContentFor(aSource, nullOnMissing) {
      if (!this.sourcesContent) {
        return null;
      }
      var index = this._findSourceIndex(aSource);
      if (index >= 0) {
        return this.sourcesContent[index];
      }
      var relativeSource = aSource;
      if (this.sourceRoot != null) {
        relativeSource = util.relative(this.sourceRoot, relativeSource);
      }
      var url;
      if (this.sourceRoot != null && (url = util.urlParse(this.sourceRoot))) {
        var fileUriAbsPath = relativeSource.replace(/^file:\/\//, "");
        if (url.scheme == "file" && this._sources.has(fileUriAbsPath)) {
          return this.sourcesContent[this._sources.indexOf(fileUriAbsPath)];
        }
        if ((!url.path || url.path == "/") && this._sources.has("/" + relativeSource)) {
          return this.sourcesContent[this._sources.indexOf("/" + relativeSource)];
        }
      }
      if (nullOnMissing) {
        return null;
      } else {
        throw new Error('"' + relativeSource + '" is not in the SourceMap.');
      }
    };
    BasicSourceMapConsumer.prototype.generatedPositionFor = function SourceMapConsumer_generatedPositionFor(aArgs) {
      var source = util.getArg(aArgs, "source");
      source = this._findSourceIndex(source);
      if (source < 0) {
        return {
          line: null,
          column: null,
          lastColumn: null
        };
      }
      var needle = {
        source,
        originalLine: util.getArg(aArgs, "line"),
        originalColumn: util.getArg(aArgs, "column")
      };
      var index = this._findMapping(
        needle,
        this._originalMappings,
        "originalLine",
        "originalColumn",
        util.compareByOriginalPositions,
        util.getArg(aArgs, "bias", SourceMapConsumer2.GREATEST_LOWER_BOUND)
      );
      if (index >= 0) {
        var mapping = this._originalMappings[index];
        if (mapping.source === needle.source) {
          return {
            line: util.getArg(mapping, "generatedLine", null),
            column: util.getArg(mapping, "generatedColumn", null),
            lastColumn: util.getArg(mapping, "lastGeneratedColumn", null)
          };
        }
      }
      return {
        line: null,
        column: null,
        lastColumn: null
      };
    };
    exports.BasicSourceMapConsumer = BasicSourceMapConsumer;
    function IndexedSourceMapConsumer(aSourceMap, aSourceMapURL) {
      var sourceMap = aSourceMap;
      if (typeof aSourceMap === "string") {
        sourceMap = util.parseSourceMapInput(aSourceMap);
      }
      var version = util.getArg(sourceMap, "version");
      var sections = util.getArg(sourceMap, "sections");
      if (version != this._version) {
        throw new Error("Unsupported version: " + version);
      }
      this._sources = new ArraySet();
      this._names = new ArraySet();
      var lastOffset = {
        line: -1,
        column: 0
      };
      this._sections = sections.map(function(s) {
        if (s.url) {
          throw new Error("Support for url field in sections not implemented.");
        }
        var offset = util.getArg(s, "offset");
        var offsetLine = util.getArg(offset, "line");
        var offsetColumn = util.getArg(offset, "column");
        if (offsetLine < lastOffset.line || offsetLine === lastOffset.line && offsetColumn < lastOffset.column) {
          throw new Error("Section offsets must be ordered and non-overlapping.");
        }
        lastOffset = offset;
        return {
          generatedOffset: {
            // The offset fields are 0-based, but we use 1-based indices when
            // encoding/decoding from VLQ.
            generatedLine: offsetLine + 1,
            generatedColumn: offsetColumn + 1
          },
          consumer: new SourceMapConsumer2(util.getArg(s, "map"), aSourceMapURL)
        };
      });
    }
    IndexedSourceMapConsumer.prototype = Object.create(SourceMapConsumer2.prototype);
    IndexedSourceMapConsumer.prototype.constructor = SourceMapConsumer2;
    IndexedSourceMapConsumer.prototype._version = 3;
    Object.defineProperty(IndexedSourceMapConsumer.prototype, "sources", {
      get: function() {
        var sources = [];
        for (var i = 0; i < this._sections.length; i++) {
          for (var j = 0; j < this._sections[i].consumer.sources.length; j++) {
            sources.push(this._sections[i].consumer.sources[j]);
          }
        }
        return sources;
      }
    });
    IndexedSourceMapConsumer.prototype.originalPositionFor = function IndexedSourceMapConsumer_originalPositionFor(aArgs) {
      var needle = {
        generatedLine: util.getArg(aArgs, "line"),
        generatedColumn: util.getArg(aArgs, "column")
      };
      var sectionIndex = binarySearch.search(
        needle,
        this._sections,
        function(needle2, section2) {
          var cmp = needle2.generatedLine - section2.generatedOffset.generatedLine;
          if (cmp) {
            return cmp;
          }
          return needle2.generatedColumn - section2.generatedOffset.generatedColumn;
        }
      );
      var section = this._sections[sectionIndex];
      if (!section) {
        return {
          source: null,
          line: null,
          column: null,
          name: null
        };
      }
      return section.consumer.originalPositionFor({
        line: needle.generatedLine - (section.generatedOffset.generatedLine - 1),
        column: needle.generatedColumn - (section.generatedOffset.generatedLine === needle.generatedLine ? section.generatedOffset.generatedColumn - 1 : 0),
        bias: aArgs.bias
      });
    };
    IndexedSourceMapConsumer.prototype.hasContentsOfAllSources = function IndexedSourceMapConsumer_hasContentsOfAllSources() {
      return this._sections.every(function(s) {
        return s.consumer.hasContentsOfAllSources();
      });
    };
    IndexedSourceMapConsumer.prototype.sourceContentFor = function IndexedSourceMapConsumer_sourceContentFor(aSource, nullOnMissing) {
      for (var i = 0; i < this._sections.length; i++) {
        var section = this._sections[i];
        var content = section.consumer.sourceContentFor(aSource, true);
        if (content) {
          return content;
        }
      }
      if (nullOnMissing) {
        return null;
      } else {
        throw new Error('"' + aSource + '" is not in the SourceMap.');
      }
    };
    IndexedSourceMapConsumer.prototype.generatedPositionFor = function IndexedSourceMapConsumer_generatedPositionFor(aArgs) {
      for (var i = 0; i < this._sections.length; i++) {
        var section = this._sections[i];
        if (section.consumer._findSourceIndex(util.getArg(aArgs, "source")) === -1) {
          continue;
        }
        var generatedPosition = section.consumer.generatedPositionFor(aArgs);
        if (generatedPosition) {
          var ret = {
            line: generatedPosition.line + (section.generatedOffset.generatedLine - 1),
            column: generatedPosition.column + (section.generatedOffset.generatedLine === generatedPosition.line ? section.generatedOffset.generatedColumn - 1 : 0)
          };
          return ret;
        }
      }
      return {
        line: null,
        column: null
      };
    };
    IndexedSourceMapConsumer.prototype._parseMappings = function IndexedSourceMapConsumer_parseMappings(aStr, aSourceRoot) {
      this.__generatedMappings = [];
      this.__originalMappings = [];
      for (var i = 0; i < this._sections.length; i++) {
        var section = this._sections[i];
        var sectionMappings = section.consumer._generatedMappings;
        for (var j = 0; j < sectionMappings.length; j++) {
          var mapping = sectionMappings[j];
          var source = section.consumer._sources.at(mapping.source);
          source = util.computeSourceURL(section.consumer.sourceRoot, source, this._sourceMapURL);
          this._sources.add(source);
          source = this._sources.indexOf(source);
          var name = null;
          if (mapping.name) {
            name = section.consumer._names.at(mapping.name);
            this._names.add(name);
            name = this._names.indexOf(name);
          }
          var adjustedMapping = {
            source,
            generatedLine: mapping.generatedLine + (section.generatedOffset.generatedLine - 1),
            generatedColumn: mapping.generatedColumn + (section.generatedOffset.generatedLine === mapping.generatedLine ? section.generatedOffset.generatedColumn - 1 : 0),
            originalLine: mapping.originalLine,
            originalColumn: mapping.originalColumn,
            name
          };
          this.__generatedMappings.push(adjustedMapping);
          if (typeof adjustedMapping.originalLine === "number") {
            this.__originalMappings.push(adjustedMapping);
          }
        }
      }
      quickSort(this.__generatedMappings, util.compareByGeneratedPositionsDeflated);
      quickSort(this.__originalMappings, util.compareByOriginalPositions);
    };
    exports.IndexedSourceMapConsumer = IndexedSourceMapConsumer;
  }
});
var require_source_node = __commonJS({
  "node_modules/source-map-js/lib/source-node.js"(exports) {
    var SourceMapGenerator = require_source_map_generator().SourceMapGenerator;
    var util = require_util();
    var REGEX_NEWLINE = /(\r?\n)/;
    var NEWLINE_CODE = 10;
    var isSourceNode = "$$$isSourceNode$$$";
    function SourceNode(aLine, aColumn, aSource, aChunks, aName) {
      this.children = [];
      this.sourceContents = {};
      this.line = aLine == null ? null : aLine;
      this.column = aColumn == null ? null : aColumn;
      this.source = aSource == null ? null : aSource;
      this.name = aName == null ? null : aName;
      this[isSourceNode] = true;
      if (aChunks != null)
        this.add(aChunks);
    }
    SourceNode.fromStringWithSourceMap = function SourceNode_fromStringWithSourceMap(aGeneratedCode, aSourceMapConsumer, aRelativePath) {
      var node = new SourceNode();
      var remainingLines = aGeneratedCode.split(REGEX_NEWLINE);
      var remainingLinesIndex = 0;
      var shiftNextLine = function() {
        var lineContents = getNextLine();
        var newLine = getNextLine() || "";
        return lineContents + newLine;
        function getNextLine() {
          return remainingLinesIndex < remainingLines.length ? remainingLines[remainingLinesIndex++] : void 0;
        }
      };
      var lastGeneratedLine = 1, lastGeneratedColumn = 0;
      var lastMapping = null;
      aSourceMapConsumer.eachMapping(function(mapping) {
        if (lastMapping !== null) {
          if (lastGeneratedLine < mapping.generatedLine) {
            addMappingWithCode(lastMapping, shiftNextLine());
            lastGeneratedLine++;
            lastGeneratedColumn = 0;
          } else {
            var nextLine = remainingLines[remainingLinesIndex] || "";
            var code = nextLine.substr(0, mapping.generatedColumn - lastGeneratedColumn);
            remainingLines[remainingLinesIndex] = nextLine.substr(mapping.generatedColumn - lastGeneratedColumn);
            lastGeneratedColumn = mapping.generatedColumn;
            addMappingWithCode(lastMapping, code);
            lastMapping = mapping;
            return;
          }
        }
        while (lastGeneratedLine < mapping.generatedLine) {
          node.add(shiftNextLine());
          lastGeneratedLine++;
        }
        if (lastGeneratedColumn < mapping.generatedColumn) {
          var nextLine = remainingLines[remainingLinesIndex] || "";
          node.add(nextLine.substr(0, mapping.generatedColumn));
          remainingLines[remainingLinesIndex] = nextLine.substr(mapping.generatedColumn);
          lastGeneratedColumn = mapping.generatedColumn;
        }
        lastMapping = mapping;
      }, this);
      if (remainingLinesIndex < remainingLines.length) {
        if (lastMapping) {
          addMappingWithCode(lastMapping, shiftNextLine());
        }
        node.add(remainingLines.splice(remainingLinesIndex).join(""));
      }
      aSourceMapConsumer.sources.forEach(function(sourceFile) {
        var content = aSourceMapConsumer.sourceContentFor(sourceFile);
        if (content != null) {
          if (aRelativePath != null) {
            sourceFile = util.join(aRelativePath, sourceFile);
          }
          node.setSourceContent(sourceFile, content);
        }
      });
      return node;
      function addMappingWithCode(mapping, code) {
        if (mapping === null || mapping.source === void 0) {
          node.add(code);
        } else {
          var source = aRelativePath ? util.join(aRelativePath, mapping.source) : mapping.source;
          node.add(new SourceNode(
            mapping.originalLine,
            mapping.originalColumn,
            source,
            code,
            mapping.name
          ));
        }
      }
    };
    SourceNode.prototype.add = function SourceNode_add(aChunk) {
      if (Array.isArray(aChunk)) {
        aChunk.forEach(function(chunk) {
          this.add(chunk);
        }, this);
      } else if (aChunk[isSourceNode] || typeof aChunk === "string") {
        if (aChunk) {
          this.children.push(aChunk);
        }
      } else {
        throw new TypeError(
          "Expected a SourceNode, string, or an array of SourceNodes and strings. Got " + aChunk
        );
      }
      return this;
    };
    SourceNode.prototype.prepend = function SourceNode_prepend(aChunk) {
      if (Array.isArray(aChunk)) {
        for (var i = aChunk.length - 1; i >= 0; i--) {
          this.prepend(aChunk[i]);
        }
      } else if (aChunk[isSourceNode] || typeof aChunk === "string") {
        this.children.unshift(aChunk);
      } else {
        throw new TypeError(
          "Expected a SourceNode, string, or an array of SourceNodes and strings. Got " + aChunk
        );
      }
      return this;
    };
    SourceNode.prototype.walk = function SourceNode_walk(aFn) {
      var chunk;
      for (var i = 0, len = this.children.length; i < len; i++) {
        chunk = this.children[i];
        if (chunk[isSourceNode]) {
          chunk.walk(aFn);
        } else {
          if (chunk !== "") {
            aFn(chunk, {
              source: this.source,
              line: this.line,
              column: this.column,
              name: this.name
            });
          }
        }
      }
    };
    SourceNode.prototype.join = function SourceNode_join(aSep) {
      var newChildren;
      var i;
      var len = this.children.length;
      if (len > 0) {
        newChildren = [];
        for (i = 0; i < len - 1; i++) {
          newChildren.push(this.children[i]);
          newChildren.push(aSep);
        }
        newChildren.push(this.children[i]);
        this.children = newChildren;
      }
      return this;
    };
    SourceNode.prototype.replaceRight = function SourceNode_replaceRight(aPattern, aReplacement) {
      var lastChild = this.children[this.children.length - 1];
      if (lastChild[isSourceNode]) {
        lastChild.replaceRight(aPattern, aReplacement);
      } else if (typeof lastChild === "string") {
        this.children[this.children.length - 1] = lastChild.replace(aPattern, aReplacement);
      } else {
        this.children.push("".replace(aPattern, aReplacement));
      }
      return this;
    };
    SourceNode.prototype.setSourceContent = function SourceNode_setSourceContent(aSourceFile, aSourceContent) {
      this.sourceContents[util.toSetString(aSourceFile)] = aSourceContent;
    };
    SourceNode.prototype.walkSourceContents = function SourceNode_walkSourceContents(aFn) {
      for (var i = 0, len = this.children.length; i < len; i++) {
        if (this.children[i][isSourceNode]) {
          this.children[i].walkSourceContents(aFn);
        }
      }
      var sources = Object.keys(this.sourceContents);
      for (var i = 0, len = sources.length; i < len; i++) {
        aFn(util.fromSetString(sources[i]), this.sourceContents[sources[i]]);
      }
    };
    SourceNode.prototype.toString = function SourceNode_toString() {
      var str = "";
      this.walk(function(chunk) {
        str += chunk;
      });
      return str;
    };
    SourceNode.prototype.toStringWithSourceMap = function SourceNode_toStringWithSourceMap(aArgs) {
      var generated = {
        code: "",
        line: 1,
        column: 0
      };
      var map = new SourceMapGenerator(aArgs);
      var sourceMappingActive = false;
      var lastOriginalSource = null;
      var lastOriginalLine = null;
      var lastOriginalColumn = null;
      var lastOriginalName = null;
      this.walk(function(chunk, original) {
        generated.code += chunk;
        if (original.source !== null && original.line !== null && original.column !== null) {
          if (lastOriginalSource !== original.source || lastOriginalLine !== original.line || lastOriginalColumn !== original.column || lastOriginalName !== original.name) {
            map.addMapping({
              source: original.source,
              original: {
                line: original.line,
                column: original.column
              },
              generated: {
                line: generated.line,
                column: generated.column
              },
              name: original.name
            });
          }
          lastOriginalSource = original.source;
          lastOriginalLine = original.line;
          lastOriginalColumn = original.column;
          lastOriginalName = original.name;
          sourceMappingActive = true;
        } else if (sourceMappingActive) {
          map.addMapping({
            generated: {
              line: generated.line,
              column: generated.column
            }
          });
          lastOriginalSource = null;
          sourceMappingActive = false;
        }
        for (var idx = 0, length = chunk.length; idx < length; idx++) {
          if (chunk.charCodeAt(idx) === NEWLINE_CODE) {
            generated.line++;
            generated.column = 0;
            if (idx + 1 === length) {
              lastOriginalSource = null;
              sourceMappingActive = false;
            } else if (sourceMappingActive) {
              map.addMapping({
                source: original.source,
                original: {
                  line: original.line,
                  column: original.column
                },
                generated: {
                  line: generated.line,
                  column: generated.column
                },
                name: original.name
              });
            }
          } else {
            generated.column++;
          }
        }
      });
      this.walkSourceContents(function(sourceFile, sourceContent) {
        map.setSourceContent(sourceFile, sourceContent);
      });
      return { code: generated.code, map };
    };
    exports.SourceNode = SourceNode;
  }
});
var require_source_map = __commonJS({
  "node_modules/source-map-js/source-map.js"(exports) {
    exports.SourceMapGenerator = require_source_map_generator().SourceMapGenerator;
    exports.SourceMapConsumer = require_source_map_consumer().SourceMapConsumer;
    exports.SourceNode = require_source_node().SourceNode;
  }
});
var import_source_map_js = __toESM(require_source_map(), 1);
async function fetchCall(pathComponents, ...args) {
  const url = new URL(window.location.origin);
  url.pathname = pathComponents.join("/");
  const response = await fetch(url.toString(), {
    method: "POST",
    body: JSON.stringify(args)
  });
  return response.headers.get("content-type")?.startsWith("application/json") ? response.json() : response.text();
}
function recurseInProxy(target, pathComponents = []) {
  return new Proxy(target, {
    apply: (target2, _, argArray) => {
      return target2(pathComponents, ...argArray);
    },
    get: (_, p) => {
      pathComponents.push(p);
      return recurseInProxy(target, pathComponents);
    }
  });
}
function rpc2() {
  return recurseInProxy(fetchCall);
}
window.rpc = rpc2;
window.onPush = {};
window.push = (messageType, message) => {
  const callback = window.onPush[messageType];
  if (!callback)
    throw `No onPush callback for message type [${messageType}]. Received message [${message}]`;
  callback(message);
};
var platform = await rpc2().platform();
if (platform === "node") {
  const url = (window.location.protocol === "http:" ? "ws:" : "wss:") + "//" + window.location.host;
  const ws = new WebSocket(url);
  ws.onmessage = ({ data }) => {
    const { messageType, message } = JSON.parse(data);
    window.push(messageType, message);
  };
}
window.sourceMapConsumer = import_source_map_js.SourceMapConsumer;
init_webview();
export {
  rpc2 as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vd2Vidmlldy9pY29ucy5qcyIsICIuLi8uLi93ZWJ2aWV3L3RoZW1lLmpzIiwgIi4uLy4uL3JhbmRvbS1sb2cuanMiLCAiLi4vLi4vd2Vidmlldy9jb3VudGVyLmpzIiwgIi4uLy4uL3dlYnZpZXcvaW5kZXguanMiLCAiLi4vLi4vLi4vLi4vLmNhY2hlL2Z1bGxzdGFja2VkL3RtcC0xNzA4NDkxOTQ2MDEyLmpzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLmljb25cIikuZm9yRWFjaChhc3luYyBpY29uID0+IHtcbiAgY29uc3QgaWNvbk5hbWUgPSBBcnJheS5mcm9tKGljb24uY2xhc3NMaXN0LnZhbHVlcygpKS5maWx0ZXIoaWNvbkNsYXNzID0+IGljb25DbGFzcyAhPT0gXCJpY29uXCIpLmF0KDApO1xuICBpY29uLmlubmVySFRNTCA9IGF3YWl0IChhd2FpdCBmZXRjaChgd2Vidmlldy9hc3NldHMvaW1hZ2VzLyR7aWNvbk5hbWV9LnN2Z2ApKS50ZXh0KClcbn0pO1xuXG4iLCAiY29uc3QgdGhlbWVTd2l0Y2ggPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3RoZW1lLXN3aXRjaCBpbnB1dFwiKTtcblxuY29uc3Qgc3RhcnREYXJrID0gISFwYXJzZUludChhd2FpdCBycGMoKS50aGVtZS5pc0RhcmsoKSk7XG5pZihzdGFydERhcmspe1xuICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xhc3NMaXN0LmFkZChcImRhcmtcIik7XG4gIHRoZW1lU3dpdGNoLmNoZWNrZWQgPSBmYWxzZTtcbn1cblxudGhlbWVTd2l0Y2guYWRkRXZlbnRMaXN0ZW5lcihcImNoYW5nZVwiLCBlID0+IHtcbiAgY29uc3QgaXNEYXJrID0gIWUuY3VycmVudFRhcmdldC5jaGVja2VkO1xuICBpZihpc0Rhcmspe1xuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGFzc0xpc3QuYWRkKFwiZGFya1wiKVxuICB9IGVsc2Uge1xuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKFwiZGFya1wiKVxuICB9XG5cbiAgcnBjKCkudGhlbWUuc2F2ZURhcmsoaXNEYXJrID8gXCIxXCIgOiBcIjBcIilcbn0pXG4iLCAiZXhwb3J0IGZ1bmN0aW9uIHJhbmRvbUxvZyhxdW90ZXMpIHtcbiAgY29uc3QgaW5kZXggPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBxdW90ZXMubGVuZ3RoKTtcbiAgY29uc29sZS5sb2cocXVvdGVzW2luZGV4XSk7XG59XG4iLCAiaW1wb3J0IHsgcmFuZG9tTG9nIH0gZnJvbSBcIi4uL3JhbmRvbS1sb2cuanNcIjtcblxuY29uc3QgY291bnRWaWV3ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIiNjb3VudGVyID4gZGl2ID4gZGl2XCIpO1xuY29uc3QgWyBzdWIsIGFkZCwgcmVzZXQgXSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIjY291bnRlciBidXR0b25cIik7XG5cbmxldCBjb3VudCA9IHBhcnNlSW50KGF3YWl0IHJwYygpLmNvdW50LmxvYWQoKSk7XG5jb3VudFZpZXcuaW5uZXJUZXh0ID0gY291bnQudG9TdHJpbmcoKTtcblxuY29uc3QgdXBkYXRlQ291bnQgPSAoKSA9PiB7XG4gIGNvdW50Vmlldy5pbm5lclRleHQgPSBjb3VudC50b1N0cmluZygpO1xuICBpZighY291bnQpe1xuICAgIHJwYygpLmNvdW50LnJlc2V0KCk7XG4gIH0gZWxzZSB7XG4gICAgcnBjKCkuY291bnQuc2F2ZShjb3VudC50b1N0cmluZygpKTtcbiAgfVxuXG4gIGlmKGNvdW50ICUgMyA9PT0gMSkge1xuICAgIHJhbmRvbUxvZyhjaGF0R1BUUXVvdGVzKVxuICB9XG59XG5cbnN1Yi5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICBjb3VudC0tO1xuICB1cGRhdGVDb3VudCgpO1xufSk7XG5cbmFkZC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICBjb3VudCsrO1xuICB1cGRhdGVDb3VudCgpXG59KTtcblxucmVzZXQuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgY291bnQgPSAwO1xuICB1cGRhdGVDb3VudCgpO1xufSk7XG5cblxuY29uc3QgY2hhdEdQVFF1b3RlcyA9IFtcbiAgXCJDbGlja2luZyB0aGF0IGJ1dHRvbiBsaWtlIGEgYm9zcyBcdTIwMTMgb25lIHByZXNzIGF0IGEgdGltZSFcIixcbiAgXCJZb3UncmUgb24gZmlyZSEgS2VlcCBjbGlja2luZywgYW5kIGxldCB0aGUgY291bnRpbmcgZ2FtZXMgYmVnaW4uXCIsXG4gIFwiQ2xpY2tpbmcgYXdheSBsaWtlIGEgY2hhbXBpb24uIFlvdSdyZSB0aGUgdHJ1ZSBjb3VudGVyIGV4dHJhb3JkaW5haXJlIVwiLFxuICBcIkNvdW50aW5nIHdpdGggcHJlY2lzaW9uIFx1MjAxMyBvbmUgY2xpY2sgYXQgYSB0aW1lLiBZb3UndmUgZ290IHRoaXMhXCIsXG4gIFwiQ2xpY2tpbmcgZmFzdGVyIHRoYW4gYSBjYWZmZWluYXRlZCBodW1taW5nYmlyZC4gWW91J3JlIHVuc3RvcHBhYmxlIVwiLFxuICBcIkNsaWNraXR5LWNsaWNrISBZb3UncmUgdGhlIG1hZXN0cm8gb2YgdGhlIGNvdW50ZXIgc3ltcGhvbnkuXCIsXG4gIFwiQ291bnRpbmcgY2xpY2tzIGxpa2UgaXQncyBhbiBPbHltcGljIHNwb3J0LiBHb2xkIG1lZGFsIHZpYmVzIVwiLFxuICBcIktlZXAgY2FsbSBhbmQgY2xpY2sgb24uIFlvdSdyZSBtYWtpbmcgaGlzdG9yeSwgb25lIGJ1dHRvbiBhdCBhIHRpbWUuXCIsXG4gIFwiQ2xpY2ssIGNsaWNrLCBob29yYXkhIFlvdSdyZSB0aGUgY2xpY2sgbWFzdGVyLCBubyBkb3VidC5cIixcbiAgXCJZb3UndmUgZ290IHRoZSBNaWRhcyB0b3VjaCBcdTIwMTMgYnV0IHdpdGggYSBjb3VudGVyIGJ1dHRvbi4gQ2xpY2sgaXQgYWxsIHRvIGdvbGQhXCIsXG4gIFwiQ2xpY2tpbmcgbGlrZSBpdCdzIGdvaW5nIG91dCBvZiBzdHlsZS4gU3BvaWxlcjogaXQncyBub3QhXCIsXG4gIFwiQ291bnRpbmcgY2xpY2tzIGxpa2UgYSBtYXRoZW1hdGljaWFuIHdpdGggYSBzZW5zZSBvZiBodW1vci4gR28sIHlvdSFcIixcbiAgXCJDbGlja2luZyB3aXRoIHRoZSBwcmVjaXNpb24gb2YgYSBuaW5qYSBcdTIwMTMgc2lsZW50IGJ1dCBkZWFkbHkgYWNjdXJhdGUuXCIsXG4gIFwiQnV0dG9uLWNsaWNraW5nIHZpcnR1b3NvIGluIGFjdGlvbiEgRW5jb3JlLCBlbmNvcmUhXCIsXG4gIFwiQ2xpY2tpbmcgYXdheSwgbGVhdmluZyBhIHRyYWlsIG9mIHNtaWxlcyBhbmQgY291bnRpbmcgdHJpdW1waHMuXCIsXG4gIFwiQ2xpY2tpbmcgc28gZmFzdCwgeW91IG1pZ2h0IGJyZWFrIHRoZSBpbnRlcm5ldC4gUHJvY2VlZCB3aXRoIGF3ZXNvbWVuZXNzIVwiLFxuICBcIkNvdW50aW5nIGNsaWNrcyBsaWtlIGEgcm9ja3N0YXIuIFlvdXIgZmFucyBhcmUgY2hlZXJpbmchXCIsXG4gIFwiQ2xpY2tpbmcgbGlrZSB0aGVyZSdzIG5vIHRvbW9ycm93LiBTcG9pbGVyIGFsZXJ0OiBUb21vcnJvdywgeW91J2xsIHN0aWxsIGJlIGNsaWNraW5nIVwiLFxuICBcIllvdSdyZSBub3QganVzdCBjbGlja2luZzsgeW91J3JlIGNyZWF0aW5nIGEgbWFzdGVycGllY2Ugb2YgY291bnRzIVwiLFxuICBcIkNsaWNraW5nIHNvIHNtb290aGx5LCBpdCdzIGxpa2UgYnV0dGVyIFx1MjAxMyBidXQgd2l0aG91dCB0aGUgbWVzcy5cIixcbiAgXCJDbGlja2luZyBicmlsbGlhbmNlIGluIHByb2dyZXNzISBUaGUgd29ybGQgbmVlZHMgbW9yZSBjb3VudGVycyBsaWtlIHlvdS5cIixcbiAgXCJDb3VudGluZyBjbGlja3MgbGlrZSBhIHBybyBcdTIwMTMgYmVjYXVzZSBhbWF0ZXVycyBhcmUgZm9yIHRoZSBmYWludC1oZWFydGVkLlwiLFxuICBcIkNsaWNraW5nIHdpdGggZmluZXNzZSBhbmQgc3R5bGUuIFlvdSdyZSB0aGUgSmFtZXMgQm9uZCBvZiBjb3VudGVycyFcIixcbiAgXCJDbGljaywgY2xpY2ssIGhvb3JheSEgVGhlIHdvcmxkIGlzIGEgYmV0dGVyIHBsYWNlIHdpdGggeW91ciBjb3VudGluZyBza2lsbHMuXCIsXG4gIFwiQ2xpY2tpbmcgdGhyb3VnaCBsaWZlIHdpdGggZmxhaXIgYW5kIGh1bW9yLiBLZWVwIGl0IHVwIVwiLFxuICBcIkNvdW50aW5nIGNsaWNrcyBsaWtlIGl0J3MgYSBkYW5jZS4gWW91J3ZlIGdvdCB0aGUgcGVyZmVjdCBtb3ZlcyFcIixcbiAgXCJDbGljaywgY2xpY2ssIGhvb3JheSEgVGhlIHdvcmxkIGlzIGEgYmV0dGVyIHBsYWNlIHdpdGggeW91ciBjb3VudGluZyBza2lsbHMuXCIsXG4gIFwiQ291bnRpbmcgY2xpY2tzIGxpa2UgYSBib3NzLiBZb3VyIGZpbmdlciBtdXN0IGJlIGluIHRyYWluaW5nIVwiLFxuICBcIkNsaWNraW5nIGxpa2UgaXQncyB0aGUgY29vbGVzdCB0aGluZyB5b3UnbGwgZG8gdG9kYXkuIFNwb2lsZXI6IGl0IGlzIVwiLFxuICBcIkNsaWNrLCBsYXVnaCwgcmVwZWF0LiBZb3VyIGNsaWNraW5nIGpvdXJuZXkgaXMgcHVyZSBqb3khXCIsXG4gIFwiQ291bnRpbmcgY2xpY2tzIHdpdGggdGhlIGVudGh1c2lhc20gb2YgYSBraWQgaW4gYSBjYW5keSBzdG9yZS4gS2VlcCB0aGF0IGpveSBhbGl2ZSFcIixcbiAgXCJDbGlja2luZyBsaWtlIGEgcHJvIFx1MjAxMyBiZWNhdXNlIGFtYXRldXJzIGFyZSBmb3IgYmVnaW5uZXJzLlwiLFxuICBcIkJ1dHRvbiBjbGlja2luZyBsZXZlbDogRXhwZXJ0LiBZb3UncmUgYWNpbmcgdGhpcyBnYW1lIVwiLFxuICBcIkNsaWNraW5nIGF3YXksIG1ha2luZyBudW1iZXJzIGxvb2sgZ29vZC4gS2VlcCB1cCB0aGUgZmFudGFzdGljIHdvcmshXCIsXG4gIFwiQ291bnRpbmcgY2xpY2tzIGxpa2UgaXQncyBhbiBhcnQgZm9ybS4gUGljYXNzbyB3b3VsZCBiZSBwcm91ZCFcIixcbiAgXCJDbGlja2luZyB3aXRoIHN0eWxlLCBncmFjZSwgYW5kIGEgdG91Y2ggb2YgaHVtb3IuIFRoYXQncyBob3cgaXQncyBkb25lIVwiLFxuICBcIkNsaWNraW5nIGJ1dHRvbnMgd2l0aCB0aGUgcHJlY2lzaW9uIG9mIGEgc3VyZ2Vvbi4gWW91J3JlIHNhdmluZyBsaXZlcywgb25lIGNsaWNrIGF0IGEgdGltZSFcIlxuXTsiLCAiaW1wb3J0IFwiLi9pY29ucy5qc1wiO1xuaW1wb3J0IFwiLi90aGVtZS5qc1wiO1xuaW1wb3J0IFwiLi9jb3VudGVyLmpzXCI7IiwgInZhciBfX2NyZWF0ZSA9IE9iamVjdC5jcmVhdGU7XG52YXIgX19kZWZQcm9wID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fZ2V0T3duUHJvcERlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO1xudmFyIF9fZ2V0T3duUHJvcE5hbWVzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXM7XG52YXIgX19nZXRQcm90b09mID0gT2JqZWN0LmdldFByb3RvdHlwZU9mO1xudmFyIF9faGFzT3duUHJvcCA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG52YXIgX19jb21tb25KUyA9IChjYiwgbW9kKSA9PiBmdW5jdGlvbiBfX3JlcXVpcmUoKSB7XG4gIHJldHVybiBtb2QgfHwgKDAsIGNiW19fZ2V0T3duUHJvcE5hbWVzKGNiKVswXV0pKChtb2QgPSB7IGV4cG9ydHM6IHt9IH0pLmV4cG9ydHMsIG1vZCksIG1vZC5leHBvcnRzO1xufTtcbnZhciBfX2NvcHlQcm9wcyA9ICh0bywgZnJvbSwgZXhjZXB0LCBkZXNjKSA9PiB7XG4gIGlmIChmcm9tICYmIHR5cGVvZiBmcm9tID09PSBcIm9iamVjdFwiIHx8IHR5cGVvZiBmcm9tID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICBmb3IgKGxldCBrZXkgb2YgX19nZXRPd25Qcm9wTmFtZXMoZnJvbSkpXG4gICAgICBpZiAoIV9faGFzT3duUHJvcC5jYWxsKHRvLCBrZXkpICYmIGtleSAhPT0gZXhjZXB0KVxuICAgICAgICBfX2RlZlByb3AodG8sIGtleSwgeyBnZXQ6ICgpID0+IGZyb21ba2V5XSwgZW51bWVyYWJsZTogIShkZXNjID0gX19nZXRPd25Qcm9wRGVzYyhmcm9tLCBrZXkpKSB8fCBkZXNjLmVudW1lcmFibGUgfSk7XG4gIH1cbiAgcmV0dXJuIHRvO1xufTtcbnZhciBfX3RvRVNNID0gKG1vZCwgaXNOb2RlTW9kZSwgdGFyZ2V0KSA9PiAodGFyZ2V0ID0gbW9kICE9IG51bGwgPyBfX2NyZWF0ZShfX2dldFByb3RvT2YobW9kKSkgOiB7fSwgX19jb3B5UHJvcHMoXG4gIC8vIElmIHRoZSBpbXBvcnRlciBpcyBpbiBub2RlIGNvbXBhdGliaWxpdHkgbW9kZSBvciB0aGlzIGlzIG5vdCBhbiBFU01cbiAgLy8gZmlsZSB0aGF0IGhhcyBiZWVuIGNvbnZlcnRlZCB0byBhIENvbW1vbkpTIGZpbGUgdXNpbmcgYSBCYWJlbC1cbiAgLy8gY29tcGF0aWJsZSB0cmFuc2Zvcm0gKGkuZS4gXCJfX2VzTW9kdWxlXCIgaGFzIG5vdCBiZWVuIHNldCksIHRoZW4gc2V0XG4gIC8vIFwiZGVmYXVsdFwiIHRvIHRoZSBDb21tb25KUyBcIm1vZHVsZS5leHBvcnRzXCIgZm9yIG5vZGUgY29tcGF0aWJpbGl0eS5cbiAgaXNOb2RlTW9kZSB8fCAhbW9kIHx8ICFtb2QuX19lc01vZHVsZSA/IF9fZGVmUHJvcCh0YXJnZXQsIFwiZGVmYXVsdFwiLCB7IHZhbHVlOiBtb2QsIGVudW1lcmFibGU6IHRydWUgfSkgOiB0YXJnZXQsXG4gIG1vZFxuKSk7XG5cbi8vIG5vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi9iYXNlNjQuanNcbnZhciByZXF1aXJlX2Jhc2U2NCA9IF9fY29tbW9uSlMoe1xuICBcIm5vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi9iYXNlNjQuanNcIihleHBvcnRzKSB7XG4gICAgdmFyIGludFRvQ2hhck1hcCA9IFwiQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrL1wiLnNwbGl0KFwiXCIpO1xuICAgIGV4cG9ydHMuZW5jb2RlID0gZnVuY3Rpb24obnVtYmVyKSB7XG4gICAgICBpZiAoMCA8PSBudW1iZXIgJiYgbnVtYmVyIDwgaW50VG9DaGFyTWFwLmxlbmd0aCkge1xuICAgICAgICByZXR1cm4gaW50VG9DaGFyTWFwW251bWJlcl07XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiTXVzdCBiZSBiZXR3ZWVuIDAgYW5kIDYzOiBcIiArIG51bWJlcik7XG4gICAgfTtcbiAgICBleHBvcnRzLmRlY29kZSA9IGZ1bmN0aW9uKGNoYXJDb2RlKSB7XG4gICAgICB2YXIgYmlnQSA9IDY1O1xuICAgICAgdmFyIGJpZ1ogPSA5MDtcbiAgICAgIHZhciBsaXR0bGVBID0gOTc7XG4gICAgICB2YXIgbGl0dGxlWiA9IDEyMjtcbiAgICAgIHZhciB6ZXJvID0gNDg7XG4gICAgICB2YXIgbmluZSA9IDU3O1xuICAgICAgdmFyIHBsdXMgPSA0MztcbiAgICAgIHZhciBzbGFzaCA9IDQ3O1xuICAgICAgdmFyIGxpdHRsZU9mZnNldCA9IDI2O1xuICAgICAgdmFyIG51bWJlck9mZnNldCA9IDUyO1xuICAgICAgaWYgKGJpZ0EgPD0gY2hhckNvZGUgJiYgY2hhckNvZGUgPD0gYmlnWikge1xuICAgICAgICByZXR1cm4gY2hhckNvZGUgLSBiaWdBO1xuICAgICAgfVxuICAgICAgaWYgKGxpdHRsZUEgPD0gY2hhckNvZGUgJiYgY2hhckNvZGUgPD0gbGl0dGxlWikge1xuICAgICAgICByZXR1cm4gY2hhckNvZGUgLSBsaXR0bGVBICsgbGl0dGxlT2Zmc2V0O1xuICAgICAgfVxuICAgICAgaWYgKHplcm8gPD0gY2hhckNvZGUgJiYgY2hhckNvZGUgPD0gbmluZSkge1xuICAgICAgICByZXR1cm4gY2hhckNvZGUgLSB6ZXJvICsgbnVtYmVyT2Zmc2V0O1xuICAgICAgfVxuICAgICAgaWYgKGNoYXJDb2RlID09IHBsdXMpIHtcbiAgICAgICAgcmV0dXJuIDYyO1xuICAgICAgfVxuICAgICAgaWYgKGNoYXJDb2RlID09IHNsYXNoKSB7XG4gICAgICAgIHJldHVybiA2MztcbiAgICAgIH1cbiAgICAgIHJldHVybiAtMTtcbiAgICB9O1xuICB9XG59KTtcblxuLy8gbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvbGliL2Jhc2U2NC12bHEuanNcbnZhciByZXF1aXJlX2Jhc2U2NF92bHEgPSBfX2NvbW1vbkpTKHtcbiAgXCJub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvYmFzZTY0LXZscS5qc1wiKGV4cG9ydHMpIHtcbiAgICB2YXIgYmFzZTY0ID0gcmVxdWlyZV9iYXNlNjQoKTtcbiAgICB2YXIgVkxRX0JBU0VfU0hJRlQgPSA1O1xuICAgIHZhciBWTFFfQkFTRSA9IDEgPDwgVkxRX0JBU0VfU0hJRlQ7XG4gICAgdmFyIFZMUV9CQVNFX01BU0sgPSBWTFFfQkFTRSAtIDE7XG4gICAgdmFyIFZMUV9DT05USU5VQVRJT05fQklUID0gVkxRX0JBU0U7XG4gICAgZnVuY3Rpb24gdG9WTFFTaWduZWQoYVZhbHVlKSB7XG4gICAgICByZXR1cm4gYVZhbHVlIDwgMCA/ICgtYVZhbHVlIDw8IDEpICsgMSA6IChhVmFsdWUgPDwgMSkgKyAwO1xuICAgIH1cbiAgICBmdW5jdGlvbiBmcm9tVkxRU2lnbmVkKGFWYWx1ZSkge1xuICAgICAgdmFyIGlzTmVnYXRpdmUgPSAoYVZhbHVlICYgMSkgPT09IDE7XG4gICAgICB2YXIgc2hpZnRlZCA9IGFWYWx1ZSA+PiAxO1xuICAgICAgcmV0dXJuIGlzTmVnYXRpdmUgPyAtc2hpZnRlZCA6IHNoaWZ0ZWQ7XG4gICAgfVxuICAgIGV4cG9ydHMuZW5jb2RlID0gZnVuY3Rpb24gYmFzZTY0VkxRX2VuY29kZShhVmFsdWUpIHtcbiAgICAgIHZhciBlbmNvZGVkID0gXCJcIjtcbiAgICAgIHZhciBkaWdpdDtcbiAgICAgIHZhciB2bHEgPSB0b1ZMUVNpZ25lZChhVmFsdWUpO1xuICAgICAgZG8ge1xuICAgICAgICBkaWdpdCA9IHZscSAmIFZMUV9CQVNFX01BU0s7XG4gICAgICAgIHZscSA+Pj49IFZMUV9CQVNFX1NISUZUO1xuICAgICAgICBpZiAodmxxID4gMCkge1xuICAgICAgICAgIGRpZ2l0IHw9IFZMUV9DT05USU5VQVRJT05fQklUO1xuICAgICAgICB9XG4gICAgICAgIGVuY29kZWQgKz0gYmFzZTY0LmVuY29kZShkaWdpdCk7XG4gICAgICB9IHdoaWxlICh2bHEgPiAwKTtcbiAgICAgIHJldHVybiBlbmNvZGVkO1xuICAgIH07XG4gICAgZXhwb3J0cy5kZWNvZGUgPSBmdW5jdGlvbiBiYXNlNjRWTFFfZGVjb2RlKGFTdHIsIGFJbmRleCwgYU91dFBhcmFtKSB7XG4gICAgICB2YXIgc3RyTGVuID0gYVN0ci5sZW5ndGg7XG4gICAgICB2YXIgcmVzdWx0ID0gMDtcbiAgICAgIHZhciBzaGlmdCA9IDA7XG4gICAgICB2YXIgY29udGludWF0aW9uLCBkaWdpdDtcbiAgICAgIGRvIHtcbiAgICAgICAgaWYgKGFJbmRleCA+PSBzdHJMZW4pIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJFeHBlY3RlZCBtb3JlIGRpZ2l0cyBpbiBiYXNlIDY0IFZMUSB2YWx1ZS5cIik7XG4gICAgICAgIH1cbiAgICAgICAgZGlnaXQgPSBiYXNlNjQuZGVjb2RlKGFTdHIuY2hhckNvZGVBdChhSW5kZXgrKykpO1xuICAgICAgICBpZiAoZGlnaXQgPT09IC0xKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCBiYXNlNjQgZGlnaXQ6IFwiICsgYVN0ci5jaGFyQXQoYUluZGV4IC0gMSkpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnRpbnVhdGlvbiA9ICEhKGRpZ2l0ICYgVkxRX0NPTlRJTlVBVElPTl9CSVQpO1xuICAgICAgICBkaWdpdCAmPSBWTFFfQkFTRV9NQVNLO1xuICAgICAgICByZXN1bHQgPSByZXN1bHQgKyAoZGlnaXQgPDwgc2hpZnQpO1xuICAgICAgICBzaGlmdCArPSBWTFFfQkFTRV9TSElGVDtcbiAgICAgIH0gd2hpbGUgKGNvbnRpbnVhdGlvbik7XG4gICAgICBhT3V0UGFyYW0udmFsdWUgPSBmcm9tVkxRU2lnbmVkKHJlc3VsdCk7XG4gICAgICBhT3V0UGFyYW0ucmVzdCA9IGFJbmRleDtcbiAgICB9O1xuICB9XG59KTtcblxuLy8gbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvbGliL3V0aWwuanNcbnZhciByZXF1aXJlX3V0aWwgPSBfX2NvbW1vbkpTKHtcbiAgXCJub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvdXRpbC5qc1wiKGV4cG9ydHMpIHtcbiAgICBmdW5jdGlvbiBnZXRBcmcoYUFyZ3MsIGFOYW1lLCBhRGVmYXVsdFZhbHVlKSB7XG4gICAgICBpZiAoYU5hbWUgaW4gYUFyZ3MpIHtcbiAgICAgICAgcmV0dXJuIGFBcmdzW2FOYW1lXTtcbiAgICAgIH0gZWxzZSBpZiAoYXJndW1lbnRzLmxlbmd0aCA9PT0gMykge1xuICAgICAgICByZXR1cm4gYURlZmF1bHRWYWx1ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignXCInICsgYU5hbWUgKyAnXCIgaXMgYSByZXF1aXJlZCBhcmd1bWVudC4nKTtcbiAgICAgIH1cbiAgICB9XG4gICAgZXhwb3J0cy5nZXRBcmcgPSBnZXRBcmc7XG4gICAgdmFyIHVybFJlZ2V4cCA9IC9eKD86KFtcXHcrXFwtLl0rKTopP1xcL1xcLyg/OihcXHcrOlxcdyspQCk/KFtcXHcuLV0qKSg/OjooXFxkKykpPyguKikkLztcbiAgICB2YXIgZGF0YVVybFJlZ2V4cCA9IC9eZGF0YTouK1xcLC4rJC87XG4gICAgZnVuY3Rpb24gdXJsUGFyc2UoYVVybCkge1xuICAgICAgdmFyIG1hdGNoID0gYVVybC5tYXRjaCh1cmxSZWdleHApO1xuICAgICAgaWYgKCFtYXRjaCkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7XG4gICAgICAgIHNjaGVtZTogbWF0Y2hbMV0sXG4gICAgICAgIGF1dGg6IG1hdGNoWzJdLFxuICAgICAgICBob3N0OiBtYXRjaFszXSxcbiAgICAgICAgcG9ydDogbWF0Y2hbNF0sXG4gICAgICAgIHBhdGg6IG1hdGNoWzVdXG4gICAgICB9O1xuICAgIH1cbiAgICBleHBvcnRzLnVybFBhcnNlID0gdXJsUGFyc2U7XG4gICAgZnVuY3Rpb24gdXJsR2VuZXJhdGUoYVBhcnNlZFVybCkge1xuICAgICAgdmFyIHVybCA9IFwiXCI7XG4gICAgICBpZiAoYVBhcnNlZFVybC5zY2hlbWUpIHtcbiAgICAgICAgdXJsICs9IGFQYXJzZWRVcmwuc2NoZW1lICsgXCI6XCI7XG4gICAgICB9XG4gICAgICB1cmwgKz0gXCIvL1wiO1xuICAgICAgaWYgKGFQYXJzZWRVcmwuYXV0aCkge1xuICAgICAgICB1cmwgKz0gYVBhcnNlZFVybC5hdXRoICsgXCJAXCI7XG4gICAgICB9XG4gICAgICBpZiAoYVBhcnNlZFVybC5ob3N0KSB7XG4gICAgICAgIHVybCArPSBhUGFyc2VkVXJsLmhvc3Q7XG4gICAgICB9XG4gICAgICBpZiAoYVBhcnNlZFVybC5wb3J0KSB7XG4gICAgICAgIHVybCArPSBcIjpcIiArIGFQYXJzZWRVcmwucG9ydDtcbiAgICAgIH1cbiAgICAgIGlmIChhUGFyc2VkVXJsLnBhdGgpIHtcbiAgICAgICAgdXJsICs9IGFQYXJzZWRVcmwucGF0aDtcbiAgICAgIH1cbiAgICAgIHJldHVybiB1cmw7XG4gICAgfVxuICAgIGV4cG9ydHMudXJsR2VuZXJhdGUgPSB1cmxHZW5lcmF0ZTtcbiAgICB2YXIgTUFYX0NBQ0hFRF9JTlBVVFMgPSAzMjtcbiAgICBmdW5jdGlvbiBscnVNZW1vaXplKGYpIHtcbiAgICAgIHZhciBjYWNoZSA9IFtdO1xuICAgICAgcmV0dXJuIGZ1bmN0aW9uKGlucHV0KSB7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY2FjaGUubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBpZiAoY2FjaGVbaV0uaW5wdXQgPT09IGlucHV0KSB7XG4gICAgICAgICAgICB2YXIgdGVtcCA9IGNhY2hlWzBdO1xuICAgICAgICAgICAgY2FjaGVbMF0gPSBjYWNoZVtpXTtcbiAgICAgICAgICAgIGNhY2hlW2ldID0gdGVtcDtcbiAgICAgICAgICAgIHJldHVybiBjYWNoZVswXS5yZXN1bHQ7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHZhciByZXN1bHQgPSBmKGlucHV0KTtcbiAgICAgICAgY2FjaGUudW5zaGlmdCh7XG4gICAgICAgICAgaW5wdXQsXG4gICAgICAgICAgcmVzdWx0XG4gICAgICAgIH0pO1xuICAgICAgICBpZiAoY2FjaGUubGVuZ3RoID4gTUFYX0NBQ0hFRF9JTlBVVFMpIHtcbiAgICAgICAgICBjYWNoZS5wb3AoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgfTtcbiAgICB9XG4gICAgdmFyIG5vcm1hbGl6ZSA9IGxydU1lbW9pemUoZnVuY3Rpb24gbm9ybWFsaXplMihhUGF0aCkge1xuICAgICAgdmFyIHBhdGggPSBhUGF0aDtcbiAgICAgIHZhciB1cmwgPSB1cmxQYXJzZShhUGF0aCk7XG4gICAgICBpZiAodXJsKSB7XG4gICAgICAgIGlmICghdXJsLnBhdGgpIHtcbiAgICAgICAgICByZXR1cm4gYVBhdGg7XG4gICAgICAgIH1cbiAgICAgICAgcGF0aCA9IHVybC5wYXRoO1xuICAgICAgfVxuICAgICAgdmFyIGlzQWJzb2x1dGUgPSBleHBvcnRzLmlzQWJzb2x1dGUocGF0aCk7XG4gICAgICB2YXIgcGFydHMgPSBbXTtcbiAgICAgIHZhciBzdGFydCA9IDA7XG4gICAgICB2YXIgaSA9IDA7XG4gICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICBzdGFydCA9IGk7XG4gICAgICAgIGkgPSBwYXRoLmluZGV4T2YoXCIvXCIsIHN0YXJ0KTtcbiAgICAgICAgaWYgKGkgPT09IC0xKSB7XG4gICAgICAgICAgcGFydHMucHVzaChwYXRoLnNsaWNlKHN0YXJ0KSk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcGFydHMucHVzaChwYXRoLnNsaWNlKHN0YXJ0LCBpKSk7XG4gICAgICAgICAgd2hpbGUgKGkgPCBwYXRoLmxlbmd0aCAmJiBwYXRoW2ldID09PSBcIi9cIikge1xuICAgICAgICAgICAgaSsrO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgZm9yICh2YXIgcGFydCwgdXAgPSAwLCBpID0gcGFydHMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgcGFydCA9IHBhcnRzW2ldO1xuICAgICAgICBpZiAocGFydCA9PT0gXCIuXCIpIHtcbiAgICAgICAgICBwYXJ0cy5zcGxpY2UoaSwgMSk7XG4gICAgICAgIH0gZWxzZSBpZiAocGFydCA9PT0gXCIuLlwiKSB7XG4gICAgICAgICAgdXArKztcbiAgICAgICAgfSBlbHNlIGlmICh1cCA+IDApIHtcbiAgICAgICAgICBpZiAocGFydCA9PT0gXCJcIikge1xuICAgICAgICAgICAgcGFydHMuc3BsaWNlKGkgKyAxLCB1cCk7XG4gICAgICAgICAgICB1cCA9IDA7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHBhcnRzLnNwbGljZShpLCAyKTtcbiAgICAgICAgICAgIHVwLS07XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBwYXRoID0gcGFydHMuam9pbihcIi9cIik7XG4gICAgICBpZiAocGF0aCA9PT0gXCJcIikge1xuICAgICAgICBwYXRoID0gaXNBYnNvbHV0ZSA/IFwiL1wiIDogXCIuXCI7XG4gICAgICB9XG4gICAgICBpZiAodXJsKSB7XG4gICAgICAgIHVybC5wYXRoID0gcGF0aDtcbiAgICAgICAgcmV0dXJuIHVybEdlbmVyYXRlKHVybCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcGF0aDtcbiAgICB9KTtcbiAgICBleHBvcnRzLm5vcm1hbGl6ZSA9IG5vcm1hbGl6ZTtcbiAgICBmdW5jdGlvbiBqb2luKGFSb290LCBhUGF0aCkge1xuICAgICAgaWYgKGFSb290ID09PSBcIlwiKSB7XG4gICAgICAgIGFSb290ID0gXCIuXCI7XG4gICAgICB9XG4gICAgICBpZiAoYVBhdGggPT09IFwiXCIpIHtcbiAgICAgICAgYVBhdGggPSBcIi5cIjtcbiAgICAgIH1cbiAgICAgIHZhciBhUGF0aFVybCA9IHVybFBhcnNlKGFQYXRoKTtcbiAgICAgIHZhciBhUm9vdFVybCA9IHVybFBhcnNlKGFSb290KTtcbiAgICAgIGlmIChhUm9vdFVybCkge1xuICAgICAgICBhUm9vdCA9IGFSb290VXJsLnBhdGggfHwgXCIvXCI7XG4gICAgICB9XG4gICAgICBpZiAoYVBhdGhVcmwgJiYgIWFQYXRoVXJsLnNjaGVtZSkge1xuICAgICAgICBpZiAoYVJvb3RVcmwpIHtcbiAgICAgICAgICBhUGF0aFVybC5zY2hlbWUgPSBhUm9vdFVybC5zY2hlbWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHVybEdlbmVyYXRlKGFQYXRoVXJsKTtcbiAgICAgIH1cbiAgICAgIGlmIChhUGF0aFVybCB8fCBhUGF0aC5tYXRjaChkYXRhVXJsUmVnZXhwKSkge1xuICAgICAgICByZXR1cm4gYVBhdGg7XG4gICAgICB9XG4gICAgICBpZiAoYVJvb3RVcmwgJiYgIWFSb290VXJsLmhvc3QgJiYgIWFSb290VXJsLnBhdGgpIHtcbiAgICAgICAgYVJvb3RVcmwuaG9zdCA9IGFQYXRoO1xuICAgICAgICByZXR1cm4gdXJsR2VuZXJhdGUoYVJvb3RVcmwpO1xuICAgICAgfVxuICAgICAgdmFyIGpvaW5lZCA9IGFQYXRoLmNoYXJBdCgwKSA9PT0gXCIvXCIgPyBhUGF0aCA6IG5vcm1hbGl6ZShhUm9vdC5yZXBsYWNlKC9cXC8rJC8sIFwiXCIpICsgXCIvXCIgKyBhUGF0aCk7XG4gICAgICBpZiAoYVJvb3RVcmwpIHtcbiAgICAgICAgYVJvb3RVcmwucGF0aCA9IGpvaW5lZDtcbiAgICAgICAgcmV0dXJuIHVybEdlbmVyYXRlKGFSb290VXJsKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBqb2luZWQ7XG4gICAgfVxuICAgIGV4cG9ydHMuam9pbiA9IGpvaW47XG4gICAgZXhwb3J0cy5pc0Fic29sdXRlID0gZnVuY3Rpb24oYVBhdGgpIHtcbiAgICAgIHJldHVybiBhUGF0aC5jaGFyQXQoMCkgPT09IFwiL1wiIHx8IHVybFJlZ2V4cC50ZXN0KGFQYXRoKTtcbiAgICB9O1xuICAgIGZ1bmN0aW9uIHJlbGF0aXZlKGFSb290LCBhUGF0aCkge1xuICAgICAgaWYgKGFSb290ID09PSBcIlwiKSB7XG4gICAgICAgIGFSb290ID0gXCIuXCI7XG4gICAgICB9XG4gICAgICBhUm9vdCA9IGFSb290LnJlcGxhY2UoL1xcLyQvLCBcIlwiKTtcbiAgICAgIHZhciBsZXZlbCA9IDA7XG4gICAgICB3aGlsZSAoYVBhdGguaW5kZXhPZihhUm9vdCArIFwiL1wiKSAhPT0gMCkge1xuICAgICAgICB2YXIgaW5kZXggPSBhUm9vdC5sYXN0SW5kZXhPZihcIi9cIik7XG4gICAgICAgIGlmIChpbmRleCA8IDApIHtcbiAgICAgICAgICByZXR1cm4gYVBhdGg7XG4gICAgICAgIH1cbiAgICAgICAgYVJvb3QgPSBhUm9vdC5zbGljZSgwLCBpbmRleCk7XG4gICAgICAgIGlmIChhUm9vdC5tYXRjaCgvXihbXlxcL10rOlxcLyk/XFwvKiQvKSkge1xuICAgICAgICAgIHJldHVybiBhUGF0aDtcbiAgICAgICAgfVxuICAgICAgICArK2xldmVsO1xuICAgICAgfVxuICAgICAgcmV0dXJuIEFycmF5KGxldmVsICsgMSkuam9pbihcIi4uL1wiKSArIGFQYXRoLnN1YnN0cihhUm9vdC5sZW5ndGggKyAxKTtcbiAgICB9XG4gICAgZXhwb3J0cy5yZWxhdGl2ZSA9IHJlbGF0aXZlO1xuICAgIHZhciBzdXBwb3J0c051bGxQcm90byA9IGZ1bmN0aW9uKCkge1xuICAgICAgdmFyIG9iaiA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgICAgcmV0dXJuICEoXCJfX3Byb3RvX19cIiBpbiBvYmopO1xuICAgIH0oKTtcbiAgICBmdW5jdGlvbiBpZGVudGl0eShzKSB7XG4gICAgICByZXR1cm4gcztcbiAgICB9XG4gICAgZnVuY3Rpb24gdG9TZXRTdHJpbmcoYVN0cikge1xuICAgICAgaWYgKGlzUHJvdG9TdHJpbmcoYVN0cikpIHtcbiAgICAgICAgcmV0dXJuIFwiJFwiICsgYVN0cjtcbiAgICAgIH1cbiAgICAgIHJldHVybiBhU3RyO1xuICAgIH1cbiAgICBleHBvcnRzLnRvU2V0U3RyaW5nID0gc3VwcG9ydHNOdWxsUHJvdG8gPyBpZGVudGl0eSA6IHRvU2V0U3RyaW5nO1xuICAgIGZ1bmN0aW9uIGZyb21TZXRTdHJpbmcoYVN0cikge1xuICAgICAgaWYgKGlzUHJvdG9TdHJpbmcoYVN0cikpIHtcbiAgICAgICAgcmV0dXJuIGFTdHIuc2xpY2UoMSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gYVN0cjtcbiAgICB9XG4gICAgZXhwb3J0cy5mcm9tU2V0U3RyaW5nID0gc3VwcG9ydHNOdWxsUHJvdG8gPyBpZGVudGl0eSA6IGZyb21TZXRTdHJpbmc7XG4gICAgZnVuY3Rpb24gaXNQcm90b1N0cmluZyhzKSB7XG4gICAgICBpZiAoIXMpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgdmFyIGxlbmd0aCA9IHMubGVuZ3RoO1xuICAgICAgaWYgKGxlbmd0aCA8IDkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgaWYgKHMuY2hhckNvZGVBdChsZW5ndGggLSAxKSAhPT0gOTUgfHwgcy5jaGFyQ29kZUF0KGxlbmd0aCAtIDIpICE9PSA5NSB8fCBzLmNoYXJDb2RlQXQobGVuZ3RoIC0gMykgIT09IDExMSB8fCBzLmNoYXJDb2RlQXQobGVuZ3RoIC0gNCkgIT09IDExNiB8fCBzLmNoYXJDb2RlQXQobGVuZ3RoIC0gNSkgIT09IDExMSB8fCBzLmNoYXJDb2RlQXQobGVuZ3RoIC0gNikgIT09IDExNCB8fCBzLmNoYXJDb2RlQXQobGVuZ3RoIC0gNykgIT09IDExMiB8fCBzLmNoYXJDb2RlQXQobGVuZ3RoIC0gOCkgIT09IDk1IHx8IHMuY2hhckNvZGVBdChsZW5ndGggLSA5KSAhPT0gOTUpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgZm9yICh2YXIgaSA9IGxlbmd0aCAtIDEwOyBpID49IDA7IGktLSkge1xuICAgICAgICBpZiAocy5jaGFyQ29kZUF0KGkpICE9PSAzNikge1xuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNvbXBhcmVCeU9yaWdpbmFsUG9zaXRpb25zKG1hcHBpbmdBLCBtYXBwaW5nQiwgb25seUNvbXBhcmVPcmlnaW5hbCkge1xuICAgICAgdmFyIGNtcCA9IHN0cmNtcChtYXBwaW5nQS5zb3VyY2UsIG1hcHBpbmdCLnNvdXJjZSk7XG4gICAgICBpZiAoY21wICE9PSAwKSB7XG4gICAgICAgIHJldHVybiBjbXA7XG4gICAgICB9XG4gICAgICBjbXAgPSBtYXBwaW5nQS5vcmlnaW5hbExpbmUgLSBtYXBwaW5nQi5vcmlnaW5hbExpbmU7XG4gICAgICBpZiAoY21wICE9PSAwKSB7XG4gICAgICAgIHJldHVybiBjbXA7XG4gICAgICB9XG4gICAgICBjbXAgPSBtYXBwaW5nQS5vcmlnaW5hbENvbHVtbiAtIG1hcHBpbmdCLm9yaWdpbmFsQ29sdW1uO1xuICAgICAgaWYgKGNtcCAhPT0gMCB8fCBvbmx5Q29tcGFyZU9yaWdpbmFsKSB7XG4gICAgICAgIHJldHVybiBjbXA7XG4gICAgICB9XG4gICAgICBjbXAgPSBtYXBwaW5nQS5nZW5lcmF0ZWRDb2x1bW4gLSBtYXBwaW5nQi5nZW5lcmF0ZWRDb2x1bW47XG4gICAgICBpZiAoY21wICE9PSAwKSB7XG4gICAgICAgIHJldHVybiBjbXA7XG4gICAgICB9XG4gICAgICBjbXAgPSBtYXBwaW5nQS5nZW5lcmF0ZWRMaW5lIC0gbWFwcGluZ0IuZ2VuZXJhdGVkTGluZTtcbiAgICAgIGlmIChjbXAgIT09IDApIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzdHJjbXAobWFwcGluZ0EubmFtZSwgbWFwcGluZ0IubmFtZSk7XG4gICAgfVxuICAgIGV4cG9ydHMuY29tcGFyZUJ5T3JpZ2luYWxQb3NpdGlvbnMgPSBjb21wYXJlQnlPcmlnaW5hbFBvc2l0aW9ucztcbiAgICBmdW5jdGlvbiBjb21wYXJlQnlPcmlnaW5hbFBvc2l0aW9uc05vU291cmNlKG1hcHBpbmdBLCBtYXBwaW5nQiwgb25seUNvbXBhcmVPcmlnaW5hbCkge1xuICAgICAgdmFyIGNtcDtcbiAgICAgIGNtcCA9IG1hcHBpbmdBLm9yaWdpbmFsTGluZSAtIG1hcHBpbmdCLm9yaWdpbmFsTGluZTtcbiAgICAgIGlmIChjbXAgIT09IDApIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIGNtcCA9IG1hcHBpbmdBLm9yaWdpbmFsQ29sdW1uIC0gbWFwcGluZ0Iub3JpZ2luYWxDb2x1bW47XG4gICAgICBpZiAoY21wICE9PSAwIHx8IG9ubHlDb21wYXJlT3JpZ2luYWwpIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIGNtcCA9IG1hcHBpbmdBLmdlbmVyYXRlZENvbHVtbiAtIG1hcHBpbmdCLmdlbmVyYXRlZENvbHVtbjtcbiAgICAgIGlmIChjbXAgIT09IDApIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIGNtcCA9IG1hcHBpbmdBLmdlbmVyYXRlZExpbmUgLSBtYXBwaW5nQi5nZW5lcmF0ZWRMaW5lO1xuICAgICAgaWYgKGNtcCAhPT0gMCkge1xuICAgICAgICByZXR1cm4gY21wO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHN0cmNtcChtYXBwaW5nQS5uYW1lLCBtYXBwaW5nQi5uYW1lKTtcbiAgICB9XG4gICAgZXhwb3J0cy5jb21wYXJlQnlPcmlnaW5hbFBvc2l0aW9uc05vU291cmNlID0gY29tcGFyZUJ5T3JpZ2luYWxQb3NpdGlvbnNOb1NvdXJjZTtcbiAgICBmdW5jdGlvbiBjb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNEZWZsYXRlZChtYXBwaW5nQSwgbWFwcGluZ0IsIG9ubHlDb21wYXJlR2VuZXJhdGVkKSB7XG4gICAgICB2YXIgY21wID0gbWFwcGluZ0EuZ2VuZXJhdGVkTGluZSAtIG1hcHBpbmdCLmdlbmVyYXRlZExpbmU7XG4gICAgICBpZiAoY21wICE9PSAwKSB7XG4gICAgICAgIHJldHVybiBjbXA7XG4gICAgICB9XG4gICAgICBjbXAgPSBtYXBwaW5nQS5nZW5lcmF0ZWRDb2x1bW4gLSBtYXBwaW5nQi5nZW5lcmF0ZWRDb2x1bW47XG4gICAgICBpZiAoY21wICE9PSAwIHx8IG9ubHlDb21wYXJlR2VuZXJhdGVkKSB7XG4gICAgICAgIHJldHVybiBjbXA7XG4gICAgICB9XG4gICAgICBjbXAgPSBzdHJjbXAobWFwcGluZ0Euc291cmNlLCBtYXBwaW5nQi5zb3VyY2UpO1xuICAgICAgaWYgKGNtcCAhPT0gMCkge1xuICAgICAgICByZXR1cm4gY21wO1xuICAgICAgfVxuICAgICAgY21wID0gbWFwcGluZ0Eub3JpZ2luYWxMaW5lIC0gbWFwcGluZ0Iub3JpZ2luYWxMaW5lO1xuICAgICAgaWYgKGNtcCAhPT0gMCkge1xuICAgICAgICByZXR1cm4gY21wO1xuICAgICAgfVxuICAgICAgY21wID0gbWFwcGluZ0Eub3JpZ2luYWxDb2x1bW4gLSBtYXBwaW5nQi5vcmlnaW5hbENvbHVtbjtcbiAgICAgIGlmIChjbXAgIT09IDApIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzdHJjbXAobWFwcGluZ0EubmFtZSwgbWFwcGluZ0IubmFtZSk7XG4gICAgfVxuICAgIGV4cG9ydHMuY29tcGFyZUJ5R2VuZXJhdGVkUG9zaXRpb25zRGVmbGF0ZWQgPSBjb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNEZWZsYXRlZDtcbiAgICBmdW5jdGlvbiBjb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNEZWZsYXRlZE5vTGluZShtYXBwaW5nQSwgbWFwcGluZ0IsIG9ubHlDb21wYXJlR2VuZXJhdGVkKSB7XG4gICAgICB2YXIgY21wID0gbWFwcGluZ0EuZ2VuZXJhdGVkQ29sdW1uIC0gbWFwcGluZ0IuZ2VuZXJhdGVkQ29sdW1uO1xuICAgICAgaWYgKGNtcCAhPT0gMCB8fCBvbmx5Q29tcGFyZUdlbmVyYXRlZCkge1xuICAgICAgICByZXR1cm4gY21wO1xuICAgICAgfVxuICAgICAgY21wID0gc3RyY21wKG1hcHBpbmdBLnNvdXJjZSwgbWFwcGluZ0Iuc291cmNlKTtcbiAgICAgIGlmIChjbXAgIT09IDApIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIGNtcCA9IG1hcHBpbmdBLm9yaWdpbmFsTGluZSAtIG1hcHBpbmdCLm9yaWdpbmFsTGluZTtcbiAgICAgIGlmIChjbXAgIT09IDApIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIGNtcCA9IG1hcHBpbmdBLm9yaWdpbmFsQ29sdW1uIC0gbWFwcGluZ0Iub3JpZ2luYWxDb2x1bW47XG4gICAgICBpZiAoY21wICE9PSAwKSB7XG4gICAgICAgIHJldHVybiBjbXA7XG4gICAgICB9XG4gICAgICByZXR1cm4gc3RyY21wKG1hcHBpbmdBLm5hbWUsIG1hcHBpbmdCLm5hbWUpO1xuICAgIH1cbiAgICBleHBvcnRzLmNvbXBhcmVCeUdlbmVyYXRlZFBvc2l0aW9uc0RlZmxhdGVkTm9MaW5lID0gY29tcGFyZUJ5R2VuZXJhdGVkUG9zaXRpb25zRGVmbGF0ZWROb0xpbmU7XG4gICAgZnVuY3Rpb24gc3RyY21wKGFTdHIxLCBhU3RyMikge1xuICAgICAgaWYgKGFTdHIxID09PSBhU3RyMikge1xuICAgICAgICByZXR1cm4gMDtcbiAgICAgIH1cbiAgICAgIGlmIChhU3RyMSA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gMTtcbiAgICAgIH1cbiAgICAgIGlmIChhU3RyMiA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gLTE7XG4gICAgICB9XG4gICAgICBpZiAoYVN0cjEgPiBhU3RyMikge1xuICAgICAgICByZXR1cm4gMTtcbiAgICAgIH1cbiAgICAgIHJldHVybiAtMTtcbiAgICB9XG4gICAgZnVuY3Rpb24gY29tcGFyZUJ5R2VuZXJhdGVkUG9zaXRpb25zSW5mbGF0ZWQobWFwcGluZ0EsIG1hcHBpbmdCKSB7XG4gICAgICB2YXIgY21wID0gbWFwcGluZ0EuZ2VuZXJhdGVkTGluZSAtIG1hcHBpbmdCLmdlbmVyYXRlZExpbmU7XG4gICAgICBpZiAoY21wICE9PSAwKSB7XG4gICAgICAgIHJldHVybiBjbXA7XG4gICAgICB9XG4gICAgICBjbXAgPSBtYXBwaW5nQS5nZW5lcmF0ZWRDb2x1bW4gLSBtYXBwaW5nQi5nZW5lcmF0ZWRDb2x1bW47XG4gICAgICBpZiAoY21wICE9PSAwKSB7XG4gICAgICAgIHJldHVybiBjbXA7XG4gICAgICB9XG4gICAgICBjbXAgPSBzdHJjbXAobWFwcGluZ0Euc291cmNlLCBtYXBwaW5nQi5zb3VyY2UpO1xuICAgICAgaWYgKGNtcCAhPT0gMCkge1xuICAgICAgICByZXR1cm4gY21wO1xuICAgICAgfVxuICAgICAgY21wID0gbWFwcGluZ0Eub3JpZ2luYWxMaW5lIC0gbWFwcGluZ0Iub3JpZ2luYWxMaW5lO1xuICAgICAgaWYgKGNtcCAhPT0gMCkge1xuICAgICAgICByZXR1cm4gY21wO1xuICAgICAgfVxuICAgICAgY21wID0gbWFwcGluZ0Eub3JpZ2luYWxDb2x1bW4gLSBtYXBwaW5nQi5vcmlnaW5hbENvbHVtbjtcbiAgICAgIGlmIChjbXAgIT09IDApIHtcbiAgICAgICAgcmV0dXJuIGNtcDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzdHJjbXAobWFwcGluZ0EubmFtZSwgbWFwcGluZ0IubmFtZSk7XG4gICAgfVxuICAgIGV4cG9ydHMuY29tcGFyZUJ5R2VuZXJhdGVkUG9zaXRpb25zSW5mbGF0ZWQgPSBjb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNJbmZsYXRlZDtcbiAgICBmdW5jdGlvbiBwYXJzZVNvdXJjZU1hcElucHV0KHN0cikge1xuICAgICAgcmV0dXJuIEpTT04ucGFyc2Uoc3RyLnJlcGxhY2UoL15cXCldfSdbXlxcbl0qXFxuLywgXCJcIikpO1xuICAgIH1cbiAgICBleHBvcnRzLnBhcnNlU291cmNlTWFwSW5wdXQgPSBwYXJzZVNvdXJjZU1hcElucHV0O1xuICAgIGZ1bmN0aW9uIGNvbXB1dGVTb3VyY2VVUkwoc291cmNlUm9vdCwgc291cmNlVVJMLCBzb3VyY2VNYXBVUkwpIHtcbiAgICAgIHNvdXJjZVVSTCA9IHNvdXJjZVVSTCB8fCBcIlwiO1xuICAgICAgaWYgKHNvdXJjZVJvb3QpIHtcbiAgICAgICAgaWYgKHNvdXJjZVJvb3Rbc291cmNlUm9vdC5sZW5ndGggLSAxXSAhPT0gXCIvXCIgJiYgc291cmNlVVJMWzBdICE9PSBcIi9cIikge1xuICAgICAgICAgIHNvdXJjZVJvb3QgKz0gXCIvXCI7XG4gICAgICAgIH1cbiAgICAgICAgc291cmNlVVJMID0gc291cmNlUm9vdCArIHNvdXJjZVVSTDtcbiAgICAgIH1cbiAgICAgIGlmIChzb3VyY2VNYXBVUkwpIHtcbiAgICAgICAgdmFyIHBhcnNlZCA9IHVybFBhcnNlKHNvdXJjZU1hcFVSTCk7XG4gICAgICAgIGlmICghcGFyc2VkKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwic291cmNlTWFwVVJMIGNvdWxkIG5vdCBiZSBwYXJzZWRcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHBhcnNlZC5wYXRoKSB7XG4gICAgICAgICAgdmFyIGluZGV4ID0gcGFyc2VkLnBhdGgubGFzdEluZGV4T2YoXCIvXCIpO1xuICAgICAgICAgIGlmIChpbmRleCA+PSAwKSB7XG4gICAgICAgICAgICBwYXJzZWQucGF0aCA9IHBhcnNlZC5wYXRoLnN1YnN0cmluZygwLCBpbmRleCArIDEpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBzb3VyY2VVUkwgPSBqb2luKHVybEdlbmVyYXRlKHBhcnNlZCksIHNvdXJjZVVSTCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gbm9ybWFsaXplKHNvdXJjZVVSTCk7XG4gICAgfVxuICAgIGV4cG9ydHMuY29tcHV0ZVNvdXJjZVVSTCA9IGNvbXB1dGVTb3VyY2VVUkw7XG4gIH1cbn0pO1xuXG4vLyBub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvYXJyYXktc2V0LmpzXG52YXIgcmVxdWlyZV9hcnJheV9zZXQgPSBfX2NvbW1vbkpTKHtcbiAgXCJub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvYXJyYXktc2V0LmpzXCIoZXhwb3J0cykge1xuICAgIHZhciB1dGlsID0gcmVxdWlyZV91dGlsKCk7XG4gICAgdmFyIGhhcyA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG4gICAgdmFyIGhhc05hdGl2ZU1hcCA9IHR5cGVvZiBNYXAgIT09IFwidW5kZWZpbmVkXCI7XG4gICAgZnVuY3Rpb24gQXJyYXlTZXQoKSB7XG4gICAgICB0aGlzLl9hcnJheSA9IFtdO1xuICAgICAgdGhpcy5fc2V0ID0gaGFzTmF0aXZlTWFwID8gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSA6IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIH1cbiAgICBBcnJheVNldC5mcm9tQXJyYXkgPSBmdW5jdGlvbiBBcnJheVNldF9mcm9tQXJyYXkoYUFycmF5LCBhQWxsb3dEdXBsaWNhdGVzKSB7XG4gICAgICB2YXIgc2V0ID0gbmV3IEFycmF5U2V0KCk7XG4gICAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gYUFycmF5Lmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgIHNldC5hZGQoYUFycmF5W2ldLCBhQWxsb3dEdXBsaWNhdGVzKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzZXQ7XG4gICAgfTtcbiAgICBBcnJheVNldC5wcm90b3R5cGUuc2l6ZSA9IGZ1bmN0aW9uIEFycmF5U2V0X3NpemUoKSB7XG4gICAgICByZXR1cm4gaGFzTmF0aXZlTWFwID8gdGhpcy5fc2V0LnNpemUgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyh0aGlzLl9zZXQpLmxlbmd0aDtcbiAgICB9O1xuICAgIEFycmF5U2V0LnByb3RvdHlwZS5hZGQgPSBmdW5jdGlvbiBBcnJheVNldF9hZGQoYVN0ciwgYUFsbG93RHVwbGljYXRlcykge1xuICAgICAgdmFyIHNTdHIgPSBoYXNOYXRpdmVNYXAgPyBhU3RyIDogdXRpbC50b1NldFN0cmluZyhhU3RyKTtcbiAgICAgIHZhciBpc0R1cGxpY2F0ZSA9IGhhc05hdGl2ZU1hcCA/IHRoaXMuaGFzKGFTdHIpIDogaGFzLmNhbGwodGhpcy5fc2V0LCBzU3RyKTtcbiAgICAgIHZhciBpZHggPSB0aGlzLl9hcnJheS5sZW5ndGg7XG4gICAgICBpZiAoIWlzRHVwbGljYXRlIHx8IGFBbGxvd0R1cGxpY2F0ZXMpIHtcbiAgICAgICAgdGhpcy5fYXJyYXkucHVzaChhU3RyKTtcbiAgICAgIH1cbiAgICAgIGlmICghaXNEdXBsaWNhdGUpIHtcbiAgICAgICAgaWYgKGhhc05hdGl2ZU1hcCkge1xuICAgICAgICAgIHRoaXMuX3NldC5zZXQoYVN0ciwgaWR4KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aGlzLl9zZXRbc1N0cl0gPSBpZHg7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICAgIEFycmF5U2V0LnByb3RvdHlwZS5oYXMgPSBmdW5jdGlvbiBBcnJheVNldF9oYXMoYVN0cikge1xuICAgICAgaWYgKGhhc05hdGl2ZU1hcCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fc2V0LmhhcyhhU3RyKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHZhciBzU3RyID0gdXRpbC50b1NldFN0cmluZyhhU3RyKTtcbiAgICAgICAgcmV0dXJuIGhhcy5jYWxsKHRoaXMuX3NldCwgc1N0cik7XG4gICAgICB9XG4gICAgfTtcbiAgICBBcnJheVNldC5wcm90b3R5cGUuaW5kZXhPZiA9IGZ1bmN0aW9uIEFycmF5U2V0X2luZGV4T2YoYVN0cikge1xuICAgICAgaWYgKGhhc05hdGl2ZU1hcCkge1xuICAgICAgICB2YXIgaWR4ID0gdGhpcy5fc2V0LmdldChhU3RyKTtcbiAgICAgICAgaWYgKGlkeCA+PSAwKSB7XG4gICAgICAgICAgcmV0dXJuIGlkeDtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdmFyIHNTdHIgPSB1dGlsLnRvU2V0U3RyaW5nKGFTdHIpO1xuICAgICAgICBpZiAoaGFzLmNhbGwodGhpcy5fc2V0LCBzU3RyKSkge1xuICAgICAgICAgIHJldHVybiB0aGlzLl9zZXRbc1N0cl07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRocm93IG5ldyBFcnJvcignXCInICsgYVN0ciArICdcIiBpcyBub3QgaW4gdGhlIHNldC4nKTtcbiAgICB9O1xuICAgIEFycmF5U2V0LnByb3RvdHlwZS5hdCA9IGZ1bmN0aW9uIEFycmF5U2V0X2F0KGFJZHgpIHtcbiAgICAgIGlmIChhSWR4ID49IDAgJiYgYUlkeCA8IHRoaXMuX2FycmF5Lmxlbmd0aCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fYXJyYXlbYUlkeF07XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBlbGVtZW50IGluZGV4ZWQgYnkgXCIgKyBhSWR4KTtcbiAgICB9O1xuICAgIEFycmF5U2V0LnByb3RvdHlwZS50b0FycmF5ID0gZnVuY3Rpb24gQXJyYXlTZXRfdG9BcnJheSgpIHtcbiAgICAgIHJldHVybiB0aGlzLl9hcnJheS5zbGljZSgpO1xuICAgIH07XG4gICAgZXhwb3J0cy5BcnJheVNldCA9IEFycmF5U2V0O1xuICB9XG59KTtcblxuLy8gbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvbGliL21hcHBpbmctbGlzdC5qc1xudmFyIHJlcXVpcmVfbWFwcGluZ19saXN0ID0gX19jb21tb25KUyh7XG4gIFwibm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvbGliL21hcHBpbmctbGlzdC5qc1wiKGV4cG9ydHMpIHtcbiAgICB2YXIgdXRpbCA9IHJlcXVpcmVfdXRpbCgpO1xuICAgIGZ1bmN0aW9uIGdlbmVyYXRlZFBvc2l0aW9uQWZ0ZXIobWFwcGluZ0EsIG1hcHBpbmdCKSB7XG4gICAgICB2YXIgbGluZUEgPSBtYXBwaW5nQS5nZW5lcmF0ZWRMaW5lO1xuICAgICAgdmFyIGxpbmVCID0gbWFwcGluZ0IuZ2VuZXJhdGVkTGluZTtcbiAgICAgIHZhciBjb2x1bW5BID0gbWFwcGluZ0EuZ2VuZXJhdGVkQ29sdW1uO1xuICAgICAgdmFyIGNvbHVtbkIgPSBtYXBwaW5nQi5nZW5lcmF0ZWRDb2x1bW47XG4gICAgICByZXR1cm4gbGluZUIgPiBsaW5lQSB8fCBsaW5lQiA9PSBsaW5lQSAmJiBjb2x1bW5CID49IGNvbHVtbkEgfHwgdXRpbC5jb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNJbmZsYXRlZChtYXBwaW5nQSwgbWFwcGluZ0IpIDw9IDA7XG4gICAgfVxuICAgIGZ1bmN0aW9uIE1hcHBpbmdMaXN0KCkge1xuICAgICAgdGhpcy5fYXJyYXkgPSBbXTtcbiAgICAgIHRoaXMuX3NvcnRlZCA9IHRydWU7XG4gICAgICB0aGlzLl9sYXN0ID0geyBnZW5lcmF0ZWRMaW5lOiAtMSwgZ2VuZXJhdGVkQ29sdW1uOiAwIH07XG4gICAgfVxuICAgIE1hcHBpbmdMaXN0LnByb3RvdHlwZS51bnNvcnRlZEZvckVhY2ggPSBmdW5jdGlvbiBNYXBwaW5nTGlzdF9mb3JFYWNoKGFDYWxsYmFjaywgYVRoaXNBcmcpIHtcbiAgICAgIHRoaXMuX2FycmF5LmZvckVhY2goYUNhbGxiYWNrLCBhVGhpc0FyZyk7XG4gICAgfTtcbiAgICBNYXBwaW5nTGlzdC5wcm90b3R5cGUuYWRkID0gZnVuY3Rpb24gTWFwcGluZ0xpc3RfYWRkKGFNYXBwaW5nKSB7XG4gICAgICBpZiAoZ2VuZXJhdGVkUG9zaXRpb25BZnRlcih0aGlzLl9sYXN0LCBhTWFwcGluZykpIHtcbiAgICAgICAgdGhpcy5fbGFzdCA9IGFNYXBwaW5nO1xuICAgICAgICB0aGlzLl9hcnJheS5wdXNoKGFNYXBwaW5nKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX3NvcnRlZCA9IGZhbHNlO1xuICAgICAgICB0aGlzLl9hcnJheS5wdXNoKGFNYXBwaW5nKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIE1hcHBpbmdMaXN0LnByb3RvdHlwZS50b0FycmF5ID0gZnVuY3Rpb24gTWFwcGluZ0xpc3RfdG9BcnJheSgpIHtcbiAgICAgIGlmICghdGhpcy5fc29ydGVkKSB7XG4gICAgICAgIHRoaXMuX2FycmF5LnNvcnQodXRpbC5jb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNJbmZsYXRlZCk7XG4gICAgICAgIHRoaXMuX3NvcnRlZCA9IHRydWU7XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy5fYXJyYXk7XG4gICAgfTtcbiAgICBleHBvcnRzLk1hcHBpbmdMaXN0ID0gTWFwcGluZ0xpc3Q7XG4gIH1cbn0pO1xuXG4vLyBub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvc291cmNlLW1hcC1nZW5lcmF0b3IuanNcbnZhciByZXF1aXJlX3NvdXJjZV9tYXBfZ2VuZXJhdG9yID0gX19jb21tb25KUyh7XG4gIFwibm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvbGliL3NvdXJjZS1tYXAtZ2VuZXJhdG9yLmpzXCIoZXhwb3J0cykge1xuICAgIHZhciBiYXNlNjRWTFEgPSByZXF1aXJlX2Jhc2U2NF92bHEoKTtcbiAgICB2YXIgdXRpbCA9IHJlcXVpcmVfdXRpbCgpO1xuICAgIHZhciBBcnJheVNldCA9IHJlcXVpcmVfYXJyYXlfc2V0KCkuQXJyYXlTZXQ7XG4gICAgdmFyIE1hcHBpbmdMaXN0ID0gcmVxdWlyZV9tYXBwaW5nX2xpc3QoKS5NYXBwaW5nTGlzdDtcbiAgICBmdW5jdGlvbiBTb3VyY2VNYXBHZW5lcmF0b3IoYUFyZ3MpIHtcbiAgICAgIGlmICghYUFyZ3MpIHtcbiAgICAgICAgYUFyZ3MgPSB7fTtcbiAgICAgIH1cbiAgICAgIHRoaXMuX2ZpbGUgPSB1dGlsLmdldEFyZyhhQXJncywgXCJmaWxlXCIsIG51bGwpO1xuICAgICAgdGhpcy5fc291cmNlUm9vdCA9IHV0aWwuZ2V0QXJnKGFBcmdzLCBcInNvdXJjZVJvb3RcIiwgbnVsbCk7XG4gICAgICB0aGlzLl9za2lwVmFsaWRhdGlvbiA9IHV0aWwuZ2V0QXJnKGFBcmdzLCBcInNraXBWYWxpZGF0aW9uXCIsIGZhbHNlKTtcbiAgICAgIHRoaXMuX3NvdXJjZXMgPSBuZXcgQXJyYXlTZXQoKTtcbiAgICAgIHRoaXMuX25hbWVzID0gbmV3IEFycmF5U2V0KCk7XG4gICAgICB0aGlzLl9tYXBwaW5ncyA9IG5ldyBNYXBwaW5nTGlzdCgpO1xuICAgICAgdGhpcy5fc291cmNlc0NvbnRlbnRzID0gbnVsbDtcbiAgICB9XG4gICAgU291cmNlTWFwR2VuZXJhdG9yLnByb3RvdHlwZS5fdmVyc2lvbiA9IDM7XG4gICAgU291cmNlTWFwR2VuZXJhdG9yLmZyb21Tb3VyY2VNYXAgPSBmdW5jdGlvbiBTb3VyY2VNYXBHZW5lcmF0b3JfZnJvbVNvdXJjZU1hcChhU291cmNlTWFwQ29uc3VtZXIpIHtcbiAgICAgIHZhciBzb3VyY2VSb290ID0gYVNvdXJjZU1hcENvbnN1bWVyLnNvdXJjZVJvb3Q7XG4gICAgICB2YXIgZ2VuZXJhdG9yID0gbmV3IFNvdXJjZU1hcEdlbmVyYXRvcih7XG4gICAgICAgIGZpbGU6IGFTb3VyY2VNYXBDb25zdW1lci5maWxlLFxuICAgICAgICBzb3VyY2VSb290XG4gICAgICB9KTtcbiAgICAgIGFTb3VyY2VNYXBDb25zdW1lci5lYWNoTWFwcGluZyhmdW5jdGlvbihtYXBwaW5nKSB7XG4gICAgICAgIHZhciBuZXdNYXBwaW5nID0ge1xuICAgICAgICAgIGdlbmVyYXRlZDoge1xuICAgICAgICAgICAgbGluZTogbWFwcGluZy5nZW5lcmF0ZWRMaW5lLFxuICAgICAgICAgICAgY29sdW1uOiBtYXBwaW5nLmdlbmVyYXRlZENvbHVtblxuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgaWYgKG1hcHBpbmcuc291cmNlICE9IG51bGwpIHtcbiAgICAgICAgICBuZXdNYXBwaW5nLnNvdXJjZSA9IG1hcHBpbmcuc291cmNlO1xuICAgICAgICAgIGlmIChzb3VyY2VSb290ICE9IG51bGwpIHtcbiAgICAgICAgICAgIG5ld01hcHBpbmcuc291cmNlID0gdXRpbC5yZWxhdGl2ZShzb3VyY2VSb290LCBuZXdNYXBwaW5nLnNvdXJjZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIG5ld01hcHBpbmcub3JpZ2luYWwgPSB7XG4gICAgICAgICAgICBsaW5lOiBtYXBwaW5nLm9yaWdpbmFsTGluZSxcbiAgICAgICAgICAgIGNvbHVtbjogbWFwcGluZy5vcmlnaW5hbENvbHVtblxuICAgICAgICAgIH07XG4gICAgICAgICAgaWYgKG1hcHBpbmcubmFtZSAhPSBudWxsKSB7XG4gICAgICAgICAgICBuZXdNYXBwaW5nLm5hbWUgPSBtYXBwaW5nLm5hbWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGdlbmVyYXRvci5hZGRNYXBwaW5nKG5ld01hcHBpbmcpO1xuICAgICAgfSk7XG4gICAgICBhU291cmNlTWFwQ29uc3VtZXIuc291cmNlcy5mb3JFYWNoKGZ1bmN0aW9uKHNvdXJjZUZpbGUpIHtcbiAgICAgICAgdmFyIHNvdXJjZVJlbGF0aXZlID0gc291cmNlRmlsZTtcbiAgICAgICAgaWYgKHNvdXJjZVJvb3QgIT09IG51bGwpIHtcbiAgICAgICAgICBzb3VyY2VSZWxhdGl2ZSA9IHV0aWwucmVsYXRpdmUoc291cmNlUm9vdCwgc291cmNlRmlsZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFnZW5lcmF0b3IuX3NvdXJjZXMuaGFzKHNvdXJjZVJlbGF0aXZlKSkge1xuICAgICAgICAgIGdlbmVyYXRvci5fc291cmNlcy5hZGQoc291cmNlUmVsYXRpdmUpO1xuICAgICAgICB9XG4gICAgICAgIHZhciBjb250ZW50ID0gYVNvdXJjZU1hcENvbnN1bWVyLnNvdXJjZUNvbnRlbnRGb3Ioc291cmNlRmlsZSk7XG4gICAgICAgIGlmIChjb250ZW50ICE9IG51bGwpIHtcbiAgICAgICAgICBnZW5lcmF0b3Iuc2V0U291cmNlQ29udGVudChzb3VyY2VGaWxlLCBjb250ZW50KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICByZXR1cm4gZ2VuZXJhdG9yO1xuICAgIH07XG4gICAgU291cmNlTWFwR2VuZXJhdG9yLnByb3RvdHlwZS5hZGRNYXBwaW5nID0gZnVuY3Rpb24gU291cmNlTWFwR2VuZXJhdG9yX2FkZE1hcHBpbmcoYUFyZ3MpIHtcbiAgICAgIHZhciBnZW5lcmF0ZWQgPSB1dGlsLmdldEFyZyhhQXJncywgXCJnZW5lcmF0ZWRcIik7XG4gICAgICB2YXIgb3JpZ2luYWwgPSB1dGlsLmdldEFyZyhhQXJncywgXCJvcmlnaW5hbFwiLCBudWxsKTtcbiAgICAgIHZhciBzb3VyY2UgPSB1dGlsLmdldEFyZyhhQXJncywgXCJzb3VyY2VcIiwgbnVsbCk7XG4gICAgICB2YXIgbmFtZSA9IHV0aWwuZ2V0QXJnKGFBcmdzLCBcIm5hbWVcIiwgbnVsbCk7XG4gICAgICBpZiAoIXRoaXMuX3NraXBWYWxpZGF0aW9uKSB7XG4gICAgICAgIHRoaXMuX3ZhbGlkYXRlTWFwcGluZyhnZW5lcmF0ZWQsIG9yaWdpbmFsLCBzb3VyY2UsIG5hbWUpO1xuICAgICAgfVxuICAgICAgaWYgKHNvdXJjZSAhPSBudWxsKSB7XG4gICAgICAgIHNvdXJjZSA9IFN0cmluZyhzb3VyY2UpO1xuICAgICAgICBpZiAoIXRoaXMuX3NvdXJjZXMuaGFzKHNvdXJjZSkpIHtcbiAgICAgICAgICB0aGlzLl9zb3VyY2VzLmFkZChzb3VyY2UpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAobmFtZSAhPSBudWxsKSB7XG4gICAgICAgIG5hbWUgPSBTdHJpbmcobmFtZSk7XG4gICAgICAgIGlmICghdGhpcy5fbmFtZXMuaGFzKG5hbWUpKSB7XG4gICAgICAgICAgdGhpcy5fbmFtZXMuYWRkKG5hbWUpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLl9tYXBwaW5ncy5hZGQoe1xuICAgICAgICBnZW5lcmF0ZWRMaW5lOiBnZW5lcmF0ZWQubGluZSxcbiAgICAgICAgZ2VuZXJhdGVkQ29sdW1uOiBnZW5lcmF0ZWQuY29sdW1uLFxuICAgICAgICBvcmlnaW5hbExpbmU6IG9yaWdpbmFsICE9IG51bGwgJiYgb3JpZ2luYWwubGluZSxcbiAgICAgICAgb3JpZ2luYWxDb2x1bW46IG9yaWdpbmFsICE9IG51bGwgJiYgb3JpZ2luYWwuY29sdW1uLFxuICAgICAgICBzb3VyY2UsXG4gICAgICAgIG5hbWVcbiAgICAgIH0pO1xuICAgIH07XG4gICAgU291cmNlTWFwR2VuZXJhdG9yLnByb3RvdHlwZS5zZXRTb3VyY2VDb250ZW50ID0gZnVuY3Rpb24gU291cmNlTWFwR2VuZXJhdG9yX3NldFNvdXJjZUNvbnRlbnQoYVNvdXJjZUZpbGUsIGFTb3VyY2VDb250ZW50KSB7XG4gICAgICB2YXIgc291cmNlID0gYVNvdXJjZUZpbGU7XG4gICAgICBpZiAodGhpcy5fc291cmNlUm9vdCAhPSBudWxsKSB7XG4gICAgICAgIHNvdXJjZSA9IHV0aWwucmVsYXRpdmUodGhpcy5fc291cmNlUm9vdCwgc291cmNlKTtcbiAgICAgIH1cbiAgICAgIGlmIChhU291cmNlQ29udGVudCAhPSBudWxsKSB7XG4gICAgICAgIGlmICghdGhpcy5fc291cmNlc0NvbnRlbnRzKSB7XG4gICAgICAgICAgdGhpcy5fc291cmNlc0NvbnRlbnRzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5fc291cmNlc0NvbnRlbnRzW3V0aWwudG9TZXRTdHJpbmcoc291cmNlKV0gPSBhU291cmNlQ29udGVudDtcbiAgICAgIH0gZWxzZSBpZiAodGhpcy5fc291cmNlc0NvbnRlbnRzKSB7XG4gICAgICAgIGRlbGV0ZSB0aGlzLl9zb3VyY2VzQ29udGVudHNbdXRpbC50b1NldFN0cmluZyhzb3VyY2UpXTtcbiAgICAgICAgaWYgKE9iamVjdC5rZXlzKHRoaXMuX3NvdXJjZXNDb250ZW50cykubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgdGhpcy5fc291cmNlc0NvbnRlbnRzID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgU291cmNlTWFwR2VuZXJhdG9yLnByb3RvdHlwZS5hcHBseVNvdXJjZU1hcCA9IGZ1bmN0aW9uIFNvdXJjZU1hcEdlbmVyYXRvcl9hcHBseVNvdXJjZU1hcChhU291cmNlTWFwQ29uc3VtZXIsIGFTb3VyY2VGaWxlLCBhU291cmNlTWFwUGF0aCkge1xuICAgICAgdmFyIHNvdXJjZUZpbGUgPSBhU291cmNlRmlsZTtcbiAgICAgIGlmIChhU291cmNlRmlsZSA9PSBudWxsKSB7XG4gICAgICAgIGlmIChhU291cmNlTWFwQ29uc3VtZXIuZmlsZSA9PSBudWxsKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgYFNvdXJjZU1hcEdlbmVyYXRvci5wcm90b3R5cGUuYXBwbHlTb3VyY2VNYXAgcmVxdWlyZXMgZWl0aGVyIGFuIGV4cGxpY2l0IHNvdXJjZSBmaWxlLCBvciB0aGUgc291cmNlIG1hcCdzIFwiZmlsZVwiIHByb3BlcnR5LiBCb3RoIHdlcmUgb21pdHRlZC5gXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBzb3VyY2VGaWxlID0gYVNvdXJjZU1hcENvbnN1bWVyLmZpbGU7XG4gICAgICB9XG4gICAgICB2YXIgc291cmNlUm9vdCA9IHRoaXMuX3NvdXJjZVJvb3Q7XG4gICAgICBpZiAoc291cmNlUm9vdCAhPSBudWxsKSB7XG4gICAgICAgIHNvdXJjZUZpbGUgPSB1dGlsLnJlbGF0aXZlKHNvdXJjZVJvb3QsIHNvdXJjZUZpbGUpO1xuICAgICAgfVxuICAgICAgdmFyIG5ld1NvdXJjZXMgPSBuZXcgQXJyYXlTZXQoKTtcbiAgICAgIHZhciBuZXdOYW1lcyA9IG5ldyBBcnJheVNldCgpO1xuICAgICAgdGhpcy5fbWFwcGluZ3MudW5zb3J0ZWRGb3JFYWNoKGZ1bmN0aW9uKG1hcHBpbmcpIHtcbiAgICAgICAgaWYgKG1hcHBpbmcuc291cmNlID09PSBzb3VyY2VGaWxlICYmIG1hcHBpbmcub3JpZ2luYWxMaW5lICE9IG51bGwpIHtcbiAgICAgICAgICB2YXIgb3JpZ2luYWwgPSBhU291cmNlTWFwQ29uc3VtZXIub3JpZ2luYWxQb3NpdGlvbkZvcih7XG4gICAgICAgICAgICBsaW5lOiBtYXBwaW5nLm9yaWdpbmFsTGluZSxcbiAgICAgICAgICAgIGNvbHVtbjogbWFwcGluZy5vcmlnaW5hbENvbHVtblxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGlmIChvcmlnaW5hbC5zb3VyY2UgIT0gbnVsbCkge1xuICAgICAgICAgICAgbWFwcGluZy5zb3VyY2UgPSBvcmlnaW5hbC5zb3VyY2U7XG4gICAgICAgICAgICBpZiAoYVNvdXJjZU1hcFBhdGggIT0gbnVsbCkge1xuICAgICAgICAgICAgICBtYXBwaW5nLnNvdXJjZSA9IHV0aWwuam9pbihhU291cmNlTWFwUGF0aCwgbWFwcGluZy5zb3VyY2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHNvdXJjZVJvb3QgIT0gbnVsbCkge1xuICAgICAgICAgICAgICBtYXBwaW5nLnNvdXJjZSA9IHV0aWwucmVsYXRpdmUoc291cmNlUm9vdCwgbWFwcGluZy5zb3VyY2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbWFwcGluZy5vcmlnaW5hbExpbmUgPSBvcmlnaW5hbC5saW5lO1xuICAgICAgICAgICAgbWFwcGluZy5vcmlnaW5hbENvbHVtbiA9IG9yaWdpbmFsLmNvbHVtbjtcbiAgICAgICAgICAgIGlmIChvcmlnaW5hbC5uYW1lICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgbWFwcGluZy5uYW1lID0gb3JpZ2luYWwubmFtZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHNvdXJjZSA9IG1hcHBpbmcuc291cmNlO1xuICAgICAgICBpZiAoc291cmNlICE9IG51bGwgJiYgIW5ld1NvdXJjZXMuaGFzKHNvdXJjZSkpIHtcbiAgICAgICAgICBuZXdTb3VyY2VzLmFkZChzb3VyY2UpO1xuICAgICAgICB9XG4gICAgICAgIHZhciBuYW1lID0gbWFwcGluZy5uYW1lO1xuICAgICAgICBpZiAobmFtZSAhPSBudWxsICYmICFuZXdOYW1lcy5oYXMobmFtZSkpIHtcbiAgICAgICAgICBuZXdOYW1lcy5hZGQobmFtZSk7XG4gICAgICAgIH1cbiAgICAgIH0sIHRoaXMpO1xuICAgICAgdGhpcy5fc291cmNlcyA9IG5ld1NvdXJjZXM7XG4gICAgICB0aGlzLl9uYW1lcyA9IG5ld05hbWVzO1xuICAgICAgYVNvdXJjZU1hcENvbnN1bWVyLnNvdXJjZXMuZm9yRWFjaChmdW5jdGlvbihzb3VyY2VGaWxlMikge1xuICAgICAgICB2YXIgY29udGVudCA9IGFTb3VyY2VNYXBDb25zdW1lci5zb3VyY2VDb250ZW50Rm9yKHNvdXJjZUZpbGUyKTtcbiAgICAgICAgaWYgKGNvbnRlbnQgIT0gbnVsbCkge1xuICAgICAgICAgIGlmIChhU291cmNlTWFwUGF0aCAhPSBudWxsKSB7XG4gICAgICAgICAgICBzb3VyY2VGaWxlMiA9IHV0aWwuam9pbihhU291cmNlTWFwUGF0aCwgc291cmNlRmlsZTIpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoc291cmNlUm9vdCAhPSBudWxsKSB7XG4gICAgICAgICAgICBzb3VyY2VGaWxlMiA9IHV0aWwucmVsYXRpdmUoc291cmNlUm9vdCwgc291cmNlRmlsZTIpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLnNldFNvdXJjZUNvbnRlbnQoc291cmNlRmlsZTIsIGNvbnRlbnQpO1xuICAgICAgICB9XG4gICAgICB9LCB0aGlzKTtcbiAgICB9O1xuICAgIFNvdXJjZU1hcEdlbmVyYXRvci5wcm90b3R5cGUuX3ZhbGlkYXRlTWFwcGluZyA9IGZ1bmN0aW9uIFNvdXJjZU1hcEdlbmVyYXRvcl92YWxpZGF0ZU1hcHBpbmcoYUdlbmVyYXRlZCwgYU9yaWdpbmFsLCBhU291cmNlLCBhTmFtZSkge1xuICAgICAgaWYgKGFPcmlnaW5hbCAmJiB0eXBlb2YgYU9yaWdpbmFsLmxpbmUgIT09IFwibnVtYmVyXCIgJiYgdHlwZW9mIGFPcmlnaW5hbC5jb2x1bW4gIT09IFwibnVtYmVyXCIpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgIFwib3JpZ2luYWwubGluZSBhbmQgb3JpZ2luYWwuY29sdW1uIGFyZSBub3QgbnVtYmVycyAtLSB5b3UgcHJvYmFibHkgbWVhbnQgdG8gb21pdCB0aGUgb3JpZ2luYWwgbWFwcGluZyBlbnRpcmVseSBhbmQgb25seSBtYXAgdGhlIGdlbmVyYXRlZCBwb3NpdGlvbi4gSWYgc28sIHBhc3MgbnVsbCBmb3IgdGhlIG9yaWdpbmFsIG1hcHBpbmcgaW5zdGVhZCBvZiBhbiBvYmplY3Qgd2l0aCBlbXB0eSBvciBudWxsIHZhbHVlcy5cIlxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgaWYgKGFHZW5lcmF0ZWQgJiYgXCJsaW5lXCIgaW4gYUdlbmVyYXRlZCAmJiBcImNvbHVtblwiIGluIGFHZW5lcmF0ZWQgJiYgYUdlbmVyYXRlZC5saW5lID4gMCAmJiBhR2VuZXJhdGVkLmNvbHVtbiA+PSAwICYmICFhT3JpZ2luYWwgJiYgIWFTb3VyY2UgJiYgIWFOYW1lKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH0gZWxzZSBpZiAoYUdlbmVyYXRlZCAmJiBcImxpbmVcIiBpbiBhR2VuZXJhdGVkICYmIFwiY29sdW1uXCIgaW4gYUdlbmVyYXRlZCAmJiBhT3JpZ2luYWwgJiYgXCJsaW5lXCIgaW4gYU9yaWdpbmFsICYmIFwiY29sdW1uXCIgaW4gYU9yaWdpbmFsICYmIGFHZW5lcmF0ZWQubGluZSA+IDAgJiYgYUdlbmVyYXRlZC5jb2x1bW4gPj0gMCAmJiBhT3JpZ2luYWwubGluZSA+IDAgJiYgYU9yaWdpbmFsLmNvbHVtbiA+PSAwICYmIGFTb3VyY2UpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCBtYXBwaW5nOiBcIiArIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBnZW5lcmF0ZWQ6IGFHZW5lcmF0ZWQsXG4gICAgICAgICAgc291cmNlOiBhU291cmNlLFxuICAgICAgICAgIG9yaWdpbmFsOiBhT3JpZ2luYWwsXG4gICAgICAgICAgbmFtZTogYU5hbWVcbiAgICAgICAgfSkpO1xuICAgICAgfVxuICAgIH07XG4gICAgU291cmNlTWFwR2VuZXJhdG9yLnByb3RvdHlwZS5fc2VyaWFsaXplTWFwcGluZ3MgPSBmdW5jdGlvbiBTb3VyY2VNYXBHZW5lcmF0b3Jfc2VyaWFsaXplTWFwcGluZ3MoKSB7XG4gICAgICB2YXIgcHJldmlvdXNHZW5lcmF0ZWRDb2x1bW4gPSAwO1xuICAgICAgdmFyIHByZXZpb3VzR2VuZXJhdGVkTGluZSA9IDE7XG4gICAgICB2YXIgcHJldmlvdXNPcmlnaW5hbENvbHVtbiA9IDA7XG4gICAgICB2YXIgcHJldmlvdXNPcmlnaW5hbExpbmUgPSAwO1xuICAgICAgdmFyIHByZXZpb3VzTmFtZSA9IDA7XG4gICAgICB2YXIgcHJldmlvdXNTb3VyY2UgPSAwO1xuICAgICAgdmFyIHJlc3VsdCA9IFwiXCI7XG4gICAgICB2YXIgbmV4dDtcbiAgICAgIHZhciBtYXBwaW5nO1xuICAgICAgdmFyIG5hbWVJZHg7XG4gICAgICB2YXIgc291cmNlSWR4O1xuICAgICAgdmFyIG1hcHBpbmdzID0gdGhpcy5fbWFwcGluZ3MudG9BcnJheSgpO1xuICAgICAgZm9yICh2YXIgaSA9IDAsIGxlbiA9IG1hcHBpbmdzLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgIG1hcHBpbmcgPSBtYXBwaW5nc1tpXTtcbiAgICAgICAgbmV4dCA9IFwiXCI7XG4gICAgICAgIGlmIChtYXBwaW5nLmdlbmVyYXRlZExpbmUgIT09IHByZXZpb3VzR2VuZXJhdGVkTGluZSkge1xuICAgICAgICAgIHByZXZpb3VzR2VuZXJhdGVkQ29sdW1uID0gMDtcbiAgICAgICAgICB3aGlsZSAobWFwcGluZy5nZW5lcmF0ZWRMaW5lICE9PSBwcmV2aW91c0dlbmVyYXRlZExpbmUpIHtcbiAgICAgICAgICAgIG5leHQgKz0gXCI7XCI7XG4gICAgICAgICAgICBwcmV2aW91c0dlbmVyYXRlZExpbmUrKztcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKGkgPiAwKSB7XG4gICAgICAgICAgICBpZiAoIXV0aWwuY29tcGFyZUJ5R2VuZXJhdGVkUG9zaXRpb25zSW5mbGF0ZWQobWFwcGluZywgbWFwcGluZ3NbaSAtIDFdKSkge1xuICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG5leHQgKz0gXCIsXCI7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIG5leHQgKz0gYmFzZTY0VkxRLmVuY29kZShtYXBwaW5nLmdlbmVyYXRlZENvbHVtbiAtIHByZXZpb3VzR2VuZXJhdGVkQ29sdW1uKTtcbiAgICAgICAgcHJldmlvdXNHZW5lcmF0ZWRDb2x1bW4gPSBtYXBwaW5nLmdlbmVyYXRlZENvbHVtbjtcbiAgICAgICAgaWYgKG1hcHBpbmcuc291cmNlICE9IG51bGwpIHtcbiAgICAgICAgICBzb3VyY2VJZHggPSB0aGlzLl9zb3VyY2VzLmluZGV4T2YobWFwcGluZy5zb3VyY2UpO1xuICAgICAgICAgIG5leHQgKz0gYmFzZTY0VkxRLmVuY29kZShzb3VyY2VJZHggLSBwcmV2aW91c1NvdXJjZSk7XG4gICAgICAgICAgcHJldmlvdXNTb3VyY2UgPSBzb3VyY2VJZHg7XG4gICAgICAgICAgbmV4dCArPSBiYXNlNjRWTFEuZW5jb2RlKG1hcHBpbmcub3JpZ2luYWxMaW5lIC0gMSAtIHByZXZpb3VzT3JpZ2luYWxMaW5lKTtcbiAgICAgICAgICBwcmV2aW91c09yaWdpbmFsTGluZSA9IG1hcHBpbmcub3JpZ2luYWxMaW5lIC0gMTtcbiAgICAgICAgICBuZXh0ICs9IGJhc2U2NFZMUS5lbmNvZGUobWFwcGluZy5vcmlnaW5hbENvbHVtbiAtIHByZXZpb3VzT3JpZ2luYWxDb2x1bW4pO1xuICAgICAgICAgIHByZXZpb3VzT3JpZ2luYWxDb2x1bW4gPSBtYXBwaW5nLm9yaWdpbmFsQ29sdW1uO1xuICAgICAgICAgIGlmIChtYXBwaW5nLm5hbWUgIT0gbnVsbCkge1xuICAgICAgICAgICAgbmFtZUlkeCA9IHRoaXMuX25hbWVzLmluZGV4T2YobWFwcGluZy5uYW1lKTtcbiAgICAgICAgICAgIG5leHQgKz0gYmFzZTY0VkxRLmVuY29kZShuYW1lSWR4IC0gcHJldmlvdXNOYW1lKTtcbiAgICAgICAgICAgIHByZXZpb3VzTmFtZSA9IG5hbWVJZHg7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJlc3VsdCArPSBuZXh0O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9O1xuICAgIFNvdXJjZU1hcEdlbmVyYXRvci5wcm90b3R5cGUuX2dlbmVyYXRlU291cmNlc0NvbnRlbnQgPSBmdW5jdGlvbiBTb3VyY2VNYXBHZW5lcmF0b3JfZ2VuZXJhdGVTb3VyY2VzQ29udGVudChhU291cmNlcywgYVNvdXJjZVJvb3QpIHtcbiAgICAgIHJldHVybiBhU291cmNlcy5tYXAoZnVuY3Rpb24oc291cmNlKSB7XG4gICAgICAgIGlmICghdGhpcy5fc291cmNlc0NvbnRlbnRzKSB7XG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGFTb3VyY2VSb290ICE9IG51bGwpIHtcbiAgICAgICAgICBzb3VyY2UgPSB1dGlsLnJlbGF0aXZlKGFTb3VyY2VSb290LCBzb3VyY2UpO1xuICAgICAgICB9XG4gICAgICAgIHZhciBrZXkgPSB1dGlsLnRvU2V0U3RyaW5nKHNvdXJjZSk7XG4gICAgICAgIHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwodGhpcy5fc291cmNlc0NvbnRlbnRzLCBrZXkpID8gdGhpcy5fc291cmNlc0NvbnRlbnRzW2tleV0gOiBudWxsO1xuICAgICAgfSwgdGhpcyk7XG4gICAgfTtcbiAgICBTb3VyY2VNYXBHZW5lcmF0b3IucHJvdG90eXBlLnRvSlNPTiA9IGZ1bmN0aW9uIFNvdXJjZU1hcEdlbmVyYXRvcl90b0pTT04oKSB7XG4gICAgICB2YXIgbWFwID0ge1xuICAgICAgICB2ZXJzaW9uOiB0aGlzLl92ZXJzaW9uLFxuICAgICAgICBzb3VyY2VzOiB0aGlzLl9zb3VyY2VzLnRvQXJyYXkoKSxcbiAgICAgICAgbmFtZXM6IHRoaXMuX25hbWVzLnRvQXJyYXkoKSxcbiAgICAgICAgbWFwcGluZ3M6IHRoaXMuX3NlcmlhbGl6ZU1hcHBpbmdzKClcbiAgICAgIH07XG4gICAgICBpZiAodGhpcy5fZmlsZSAhPSBudWxsKSB7XG4gICAgICAgIG1hcC5maWxlID0gdGhpcy5fZmlsZTtcbiAgICAgIH1cbiAgICAgIGlmICh0aGlzLl9zb3VyY2VSb290ICE9IG51bGwpIHtcbiAgICAgICAgbWFwLnNvdXJjZVJvb3QgPSB0aGlzLl9zb3VyY2VSb290O1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMuX3NvdXJjZXNDb250ZW50cykge1xuICAgICAgICBtYXAuc291cmNlc0NvbnRlbnQgPSB0aGlzLl9nZW5lcmF0ZVNvdXJjZXNDb250ZW50KG1hcC5zb3VyY2VzLCBtYXAuc291cmNlUm9vdCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gbWFwO1xuICAgIH07XG4gICAgU291cmNlTWFwR2VuZXJhdG9yLnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uIFNvdXJjZU1hcEdlbmVyYXRvcl90b1N0cmluZygpIHtcbiAgICAgIHJldHVybiBKU09OLnN0cmluZ2lmeSh0aGlzLnRvSlNPTigpKTtcbiAgICB9O1xuICAgIGV4cG9ydHMuU291cmNlTWFwR2VuZXJhdG9yID0gU291cmNlTWFwR2VuZXJhdG9yO1xuICB9XG59KTtcblxuLy8gbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvbGliL2JpbmFyeS1zZWFyY2guanNcbnZhciByZXF1aXJlX2JpbmFyeV9zZWFyY2ggPSBfX2NvbW1vbkpTKHtcbiAgXCJub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvYmluYXJ5LXNlYXJjaC5qc1wiKGV4cG9ydHMpIHtcbiAgICBleHBvcnRzLkdSRUFURVNUX0xPV0VSX0JPVU5EID0gMTtcbiAgICBleHBvcnRzLkxFQVNUX1VQUEVSX0JPVU5EID0gMjtcbiAgICBmdW5jdGlvbiByZWN1cnNpdmVTZWFyY2goYUxvdywgYUhpZ2gsIGFOZWVkbGUsIGFIYXlzdGFjaywgYUNvbXBhcmUsIGFCaWFzKSB7XG4gICAgICB2YXIgbWlkID0gTWF0aC5mbG9vcigoYUhpZ2ggLSBhTG93KSAvIDIpICsgYUxvdztcbiAgICAgIHZhciBjbXAgPSBhQ29tcGFyZShhTmVlZGxlLCBhSGF5c3RhY2tbbWlkXSwgdHJ1ZSk7XG4gICAgICBpZiAoY21wID09PSAwKSB7XG4gICAgICAgIHJldHVybiBtaWQ7XG4gICAgICB9IGVsc2UgaWYgKGNtcCA+IDApIHtcbiAgICAgICAgaWYgKGFIaWdoIC0gbWlkID4gMSkge1xuICAgICAgICAgIHJldHVybiByZWN1cnNpdmVTZWFyY2gobWlkLCBhSGlnaCwgYU5lZWRsZSwgYUhheXN0YWNrLCBhQ29tcGFyZSwgYUJpYXMpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChhQmlhcyA9PSBleHBvcnRzLkxFQVNUX1VQUEVSX0JPVU5EKSB7XG4gICAgICAgICAgcmV0dXJuIGFIaWdoIDwgYUhheXN0YWNrLmxlbmd0aCA/IGFIaWdoIDogLTE7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIG1pZDtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKG1pZCAtIGFMb3cgPiAxKSB7XG4gICAgICAgICAgcmV0dXJuIHJlY3Vyc2l2ZVNlYXJjaChhTG93LCBtaWQsIGFOZWVkbGUsIGFIYXlzdGFjaywgYUNvbXBhcmUsIGFCaWFzKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoYUJpYXMgPT0gZXhwb3J0cy5MRUFTVF9VUFBFUl9CT1VORCkge1xuICAgICAgICAgIHJldHVybiBtaWQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIGFMb3cgPCAwID8gLTEgOiBhTG93O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGV4cG9ydHMuc2VhcmNoID0gZnVuY3Rpb24gc2VhcmNoKGFOZWVkbGUsIGFIYXlzdGFjaywgYUNvbXBhcmUsIGFCaWFzKSB7XG4gICAgICBpZiAoYUhheXN0YWNrLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4gLTE7XG4gICAgICB9XG4gICAgICB2YXIgaW5kZXggPSByZWN1cnNpdmVTZWFyY2goXG4gICAgICAgIC0xLFxuICAgICAgICBhSGF5c3RhY2subGVuZ3RoLFxuICAgICAgICBhTmVlZGxlLFxuICAgICAgICBhSGF5c3RhY2ssXG4gICAgICAgIGFDb21wYXJlLFxuICAgICAgICBhQmlhcyB8fCBleHBvcnRzLkdSRUFURVNUX0xPV0VSX0JPVU5EXG4gICAgICApO1xuICAgICAgaWYgKGluZGV4IDwgMCkge1xuICAgICAgICByZXR1cm4gLTE7XG4gICAgICB9XG4gICAgICB3aGlsZSAoaW5kZXggLSAxID49IDApIHtcbiAgICAgICAgaWYgKGFDb21wYXJlKGFIYXlzdGFja1tpbmRleF0sIGFIYXlzdGFja1tpbmRleCAtIDFdLCB0cnVlKSAhPT0gMCkge1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIC0taW5kZXg7XG4gICAgICB9XG4gICAgICByZXR1cm4gaW5kZXg7XG4gICAgfTtcbiAgfVxufSk7XG5cbi8vIG5vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL2xpYi9xdWljay1zb3J0LmpzXG52YXIgcmVxdWlyZV9xdWlja19zb3J0ID0gX19jb21tb25KUyh7XG4gIFwibm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvbGliL3F1aWNrLXNvcnQuanNcIihleHBvcnRzKSB7XG4gICAgZnVuY3Rpb24gU29ydFRlbXBsYXRlKGNvbXBhcmF0b3IpIHtcbiAgICAgIGZ1bmN0aW9uIHN3YXAoYXJ5LCB4LCB5KSB7XG4gICAgICAgIHZhciB0ZW1wID0gYXJ5W3hdO1xuICAgICAgICBhcnlbeF0gPSBhcnlbeV07XG4gICAgICAgIGFyeVt5XSA9IHRlbXA7XG4gICAgICB9XG4gICAgICBmdW5jdGlvbiByYW5kb21JbnRJblJhbmdlKGxvdywgaGlnaCkge1xuICAgICAgICByZXR1cm4gTWF0aC5yb3VuZChsb3cgKyBNYXRoLnJhbmRvbSgpICogKGhpZ2ggLSBsb3cpKTtcbiAgICAgIH1cbiAgICAgIGZ1bmN0aW9uIGRvUXVpY2tTb3J0KGFyeSwgY29tcGFyYXRvcjIsIHAsIHIpIHtcbiAgICAgICAgaWYgKHAgPCByKSB7XG4gICAgICAgICAgdmFyIHBpdm90SW5kZXggPSByYW5kb21JbnRJblJhbmdlKHAsIHIpO1xuICAgICAgICAgIHZhciBpID0gcCAtIDE7XG4gICAgICAgICAgc3dhcChhcnksIHBpdm90SW5kZXgsIHIpO1xuICAgICAgICAgIHZhciBwaXZvdCA9IGFyeVtyXTtcbiAgICAgICAgICBmb3IgKHZhciBqID0gcDsgaiA8IHI7IGorKykge1xuICAgICAgICAgICAgaWYgKGNvbXBhcmF0b3IyKGFyeVtqXSwgcGl2b3QsIGZhbHNlKSA8PSAwKSB7XG4gICAgICAgICAgICAgIGkgKz0gMTtcbiAgICAgICAgICAgICAgc3dhcChhcnksIGksIGopO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBzd2FwKGFyeSwgaSArIDEsIGopO1xuICAgICAgICAgIHZhciBxID0gaSArIDE7XG4gICAgICAgICAgZG9RdWlja1NvcnQoYXJ5LCBjb21wYXJhdG9yMiwgcCwgcSAtIDEpO1xuICAgICAgICAgIGRvUXVpY2tTb3J0KGFyeSwgY29tcGFyYXRvcjIsIHEgKyAxLCByKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIGRvUXVpY2tTb3J0O1xuICAgIH1cbiAgICBmdW5jdGlvbiBjbG9uZVNvcnQoY29tcGFyYXRvcikge1xuICAgICAgbGV0IHRlbXBsYXRlID0gU29ydFRlbXBsYXRlLnRvU3RyaW5nKCk7XG4gICAgICBsZXQgdGVtcGxhdGVGbiA9IG5ldyBGdW5jdGlvbihgcmV0dXJuICR7dGVtcGxhdGV9YCkoKTtcbiAgICAgIHJldHVybiB0ZW1wbGF0ZUZuKGNvbXBhcmF0b3IpO1xuICAgIH1cbiAgICB2YXIgc29ydENhY2hlID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG4gICAgZXhwb3J0cy5xdWlja1NvcnQgPSBmdW5jdGlvbihhcnksIGNvbXBhcmF0b3IsIHN0YXJ0ID0gMCkge1xuICAgICAgbGV0IGRvUXVpY2tTb3J0ID0gc29ydENhY2hlLmdldChjb21wYXJhdG9yKTtcbiAgICAgIGlmIChkb1F1aWNrU29ydCA9PT0gdm9pZCAwKSB7XG4gICAgICAgIGRvUXVpY2tTb3J0ID0gY2xvbmVTb3J0KGNvbXBhcmF0b3IpO1xuICAgICAgICBzb3J0Q2FjaGUuc2V0KGNvbXBhcmF0b3IsIGRvUXVpY2tTb3J0KTtcbiAgICAgIH1cbiAgICAgIGRvUXVpY2tTb3J0KGFyeSwgY29tcGFyYXRvciwgc3RhcnQsIGFyeS5sZW5ndGggLSAxKTtcbiAgICB9O1xuICB9XG59KTtcblxuLy8gbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvbGliL3NvdXJjZS1tYXAtY29uc3VtZXIuanNcbnZhciByZXF1aXJlX3NvdXJjZV9tYXBfY29uc3VtZXIgPSBfX2NvbW1vbkpTKHtcbiAgXCJub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvc291cmNlLW1hcC1jb25zdW1lci5qc1wiKGV4cG9ydHMpIHtcbiAgICB2YXIgdXRpbCA9IHJlcXVpcmVfdXRpbCgpO1xuICAgIHZhciBiaW5hcnlTZWFyY2ggPSByZXF1aXJlX2JpbmFyeV9zZWFyY2goKTtcbiAgICB2YXIgQXJyYXlTZXQgPSByZXF1aXJlX2FycmF5X3NldCgpLkFycmF5U2V0O1xuICAgIHZhciBiYXNlNjRWTFEgPSByZXF1aXJlX2Jhc2U2NF92bHEoKTtcbiAgICB2YXIgcXVpY2tTb3J0ID0gcmVxdWlyZV9xdWlja19zb3J0KCkucXVpY2tTb3J0O1xuICAgIGZ1bmN0aW9uIFNvdXJjZU1hcENvbnN1bWVyMihhU291cmNlTWFwLCBhU291cmNlTWFwVVJMKSB7XG4gICAgICB2YXIgc291cmNlTWFwID0gYVNvdXJjZU1hcDtcbiAgICAgIGlmICh0eXBlb2YgYVNvdXJjZU1hcCA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICBzb3VyY2VNYXAgPSB1dGlsLnBhcnNlU291cmNlTWFwSW5wdXQoYVNvdXJjZU1hcCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gc291cmNlTWFwLnNlY3Rpb25zICE9IG51bGwgPyBuZXcgSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyKHNvdXJjZU1hcCwgYVNvdXJjZU1hcFVSTCkgOiBuZXcgQmFzaWNTb3VyY2VNYXBDb25zdW1lcihzb3VyY2VNYXAsIGFTb3VyY2VNYXBVUkwpO1xuICAgIH1cbiAgICBTb3VyY2VNYXBDb25zdW1lcjIuZnJvbVNvdXJjZU1hcCA9IGZ1bmN0aW9uKGFTb3VyY2VNYXAsIGFTb3VyY2VNYXBVUkwpIHtcbiAgICAgIHJldHVybiBCYXNpY1NvdXJjZU1hcENvbnN1bWVyLmZyb21Tb3VyY2VNYXAoYVNvdXJjZU1hcCwgYVNvdXJjZU1hcFVSTCk7XG4gICAgfTtcbiAgICBTb3VyY2VNYXBDb25zdW1lcjIucHJvdG90eXBlLl92ZXJzaW9uID0gMztcbiAgICBTb3VyY2VNYXBDb25zdW1lcjIucHJvdG90eXBlLl9fZ2VuZXJhdGVkTWFwcGluZ3MgPSBudWxsO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShTb3VyY2VNYXBDb25zdW1lcjIucHJvdG90eXBlLCBcIl9nZW5lcmF0ZWRNYXBwaW5nc1wiLCB7XG4gICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgZ2V0OiBmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKCF0aGlzLl9fZ2VuZXJhdGVkTWFwcGluZ3MpIHtcbiAgICAgICAgICB0aGlzLl9wYXJzZU1hcHBpbmdzKHRoaXMuX21hcHBpbmdzLCB0aGlzLnNvdXJjZVJvb3QpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLl9fZ2VuZXJhdGVkTWFwcGluZ3M7XG4gICAgICB9XG4gICAgfSk7XG4gICAgU291cmNlTWFwQ29uc3VtZXIyLnByb3RvdHlwZS5fX29yaWdpbmFsTWFwcGluZ3MgPSBudWxsO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShTb3VyY2VNYXBDb25zdW1lcjIucHJvdG90eXBlLCBcIl9vcmlnaW5hbE1hcHBpbmdzXCIsIHtcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBnZXQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICBpZiAoIXRoaXMuX19vcmlnaW5hbE1hcHBpbmdzKSB7XG4gICAgICAgICAgdGhpcy5fcGFyc2VNYXBwaW5ncyh0aGlzLl9tYXBwaW5ncywgdGhpcy5zb3VyY2VSb290KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5fX29yaWdpbmFsTWFwcGluZ3M7XG4gICAgICB9XG4gICAgfSk7XG4gICAgU291cmNlTWFwQ29uc3VtZXIyLnByb3RvdHlwZS5fY2hhcklzTWFwcGluZ1NlcGFyYXRvciA9IGZ1bmN0aW9uIFNvdXJjZU1hcENvbnN1bWVyX2NoYXJJc01hcHBpbmdTZXBhcmF0b3IoYVN0ciwgaW5kZXgpIHtcbiAgICAgIHZhciBjID0gYVN0ci5jaGFyQXQoaW5kZXgpO1xuICAgICAgcmV0dXJuIGMgPT09IFwiO1wiIHx8IGMgPT09IFwiLFwiO1xuICAgIH07XG4gICAgU291cmNlTWFwQ29uc3VtZXIyLnByb3RvdHlwZS5fcGFyc2VNYXBwaW5ncyA9IGZ1bmN0aW9uIFNvdXJjZU1hcENvbnN1bWVyX3BhcnNlTWFwcGluZ3MoYVN0ciwgYVNvdXJjZVJvb3QpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlN1YmNsYXNzZXMgbXVzdCBpbXBsZW1lbnQgX3BhcnNlTWFwcGluZ3NcIik7XG4gICAgfTtcbiAgICBTb3VyY2VNYXBDb25zdW1lcjIuR0VORVJBVEVEX09SREVSID0gMTtcbiAgICBTb3VyY2VNYXBDb25zdW1lcjIuT1JJR0lOQUxfT1JERVIgPSAyO1xuICAgIFNvdXJjZU1hcENvbnN1bWVyMi5HUkVBVEVTVF9MT1dFUl9CT1VORCA9IDE7XG4gICAgU291cmNlTWFwQ29uc3VtZXIyLkxFQVNUX1VQUEVSX0JPVU5EID0gMjtcbiAgICBTb3VyY2VNYXBDb25zdW1lcjIucHJvdG90eXBlLmVhY2hNYXBwaW5nID0gZnVuY3Rpb24gU291cmNlTWFwQ29uc3VtZXJfZWFjaE1hcHBpbmcoYUNhbGxiYWNrLCBhQ29udGV4dCwgYU9yZGVyKSB7XG4gICAgICB2YXIgY29udGV4dCA9IGFDb250ZXh0IHx8IG51bGw7XG4gICAgICB2YXIgb3JkZXIgPSBhT3JkZXIgfHwgU291cmNlTWFwQ29uc3VtZXIyLkdFTkVSQVRFRF9PUkRFUjtcbiAgICAgIHZhciBtYXBwaW5ncztcbiAgICAgIHN3aXRjaCAob3JkZXIpIHtcbiAgICAgICAgY2FzZSBTb3VyY2VNYXBDb25zdW1lcjIuR0VORVJBVEVEX09SREVSOlxuICAgICAgICAgIG1hcHBpbmdzID0gdGhpcy5fZ2VuZXJhdGVkTWFwcGluZ3M7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgU291cmNlTWFwQ29uc3VtZXIyLk9SSUdJTkFMX09SREVSOlxuICAgICAgICAgIG1hcHBpbmdzID0gdGhpcy5fb3JpZ2luYWxNYXBwaW5ncztcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJVbmtub3duIG9yZGVyIG9mIGl0ZXJhdGlvbi5cIik7XG4gICAgICB9XG4gICAgICB2YXIgc291cmNlUm9vdCA9IHRoaXMuc291cmNlUm9vdDtcbiAgICAgIHZhciBib3VuZENhbGxiYWNrID0gYUNhbGxiYWNrLmJpbmQoY29udGV4dCk7XG4gICAgICB2YXIgbmFtZXMgPSB0aGlzLl9uYW1lcztcbiAgICAgIHZhciBzb3VyY2VzID0gdGhpcy5fc291cmNlcztcbiAgICAgIHZhciBzb3VyY2VNYXBVUkwgPSB0aGlzLl9zb3VyY2VNYXBVUkw7XG4gICAgICBmb3IgKHZhciBpID0gMCwgbiA9IG1hcHBpbmdzLmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICB2YXIgbWFwcGluZyA9IG1hcHBpbmdzW2ldO1xuICAgICAgICB2YXIgc291cmNlID0gbWFwcGluZy5zb3VyY2UgPT09IG51bGwgPyBudWxsIDogc291cmNlcy5hdChtYXBwaW5nLnNvdXJjZSk7XG4gICAgICAgIHNvdXJjZSA9IHV0aWwuY29tcHV0ZVNvdXJjZVVSTChzb3VyY2VSb290LCBzb3VyY2UsIHNvdXJjZU1hcFVSTCk7XG4gICAgICAgIGJvdW5kQ2FsbGJhY2soe1xuICAgICAgICAgIHNvdXJjZSxcbiAgICAgICAgICBnZW5lcmF0ZWRMaW5lOiBtYXBwaW5nLmdlbmVyYXRlZExpbmUsXG4gICAgICAgICAgZ2VuZXJhdGVkQ29sdW1uOiBtYXBwaW5nLmdlbmVyYXRlZENvbHVtbixcbiAgICAgICAgICBvcmlnaW5hbExpbmU6IG1hcHBpbmcub3JpZ2luYWxMaW5lLFxuICAgICAgICAgIG9yaWdpbmFsQ29sdW1uOiBtYXBwaW5nLm9yaWdpbmFsQ29sdW1uLFxuICAgICAgICAgIG5hbWU6IG1hcHBpbmcubmFtZSA9PT0gbnVsbCA/IG51bGwgOiBuYW1lcy5hdChtYXBwaW5nLm5hbWUpXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH07XG4gICAgU291cmNlTWFwQ29uc3VtZXIyLnByb3RvdHlwZS5hbGxHZW5lcmF0ZWRQb3NpdGlvbnNGb3IgPSBmdW5jdGlvbiBTb3VyY2VNYXBDb25zdW1lcl9hbGxHZW5lcmF0ZWRQb3NpdGlvbnNGb3IoYUFyZ3MpIHtcbiAgICAgIHZhciBsaW5lID0gdXRpbC5nZXRBcmcoYUFyZ3MsIFwibGluZVwiKTtcbiAgICAgIHZhciBuZWVkbGUgPSB7XG4gICAgICAgIHNvdXJjZTogdXRpbC5nZXRBcmcoYUFyZ3MsIFwic291cmNlXCIpLFxuICAgICAgICBvcmlnaW5hbExpbmU6IGxpbmUsXG4gICAgICAgIG9yaWdpbmFsQ29sdW1uOiB1dGlsLmdldEFyZyhhQXJncywgXCJjb2x1bW5cIiwgMClcbiAgICAgIH07XG4gICAgICBuZWVkbGUuc291cmNlID0gdGhpcy5fZmluZFNvdXJjZUluZGV4KG5lZWRsZS5zb3VyY2UpO1xuICAgICAgaWYgKG5lZWRsZS5zb3VyY2UgPCAwKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICAgIH1cbiAgICAgIHZhciBtYXBwaW5ncyA9IFtdO1xuICAgICAgdmFyIGluZGV4ID0gdGhpcy5fZmluZE1hcHBpbmcoXG4gICAgICAgIG5lZWRsZSxcbiAgICAgICAgdGhpcy5fb3JpZ2luYWxNYXBwaW5ncyxcbiAgICAgICAgXCJvcmlnaW5hbExpbmVcIixcbiAgICAgICAgXCJvcmlnaW5hbENvbHVtblwiLFxuICAgICAgICB1dGlsLmNvbXBhcmVCeU9yaWdpbmFsUG9zaXRpb25zLFxuICAgICAgICBiaW5hcnlTZWFyY2guTEVBU1RfVVBQRVJfQk9VTkRcbiAgICAgICk7XG4gICAgICBpZiAoaW5kZXggPj0gMCkge1xuICAgICAgICB2YXIgbWFwcGluZyA9IHRoaXMuX29yaWdpbmFsTWFwcGluZ3NbaW5kZXhdO1xuICAgICAgICBpZiAoYUFyZ3MuY29sdW1uID09PSB2b2lkIDApIHtcbiAgICAgICAgICB2YXIgb3JpZ2luYWxMaW5lID0gbWFwcGluZy5vcmlnaW5hbExpbmU7XG4gICAgICAgICAgd2hpbGUgKG1hcHBpbmcgJiYgbWFwcGluZy5vcmlnaW5hbExpbmUgPT09IG9yaWdpbmFsTGluZSkge1xuICAgICAgICAgICAgbWFwcGluZ3MucHVzaCh7XG4gICAgICAgICAgICAgIGxpbmU6IHV0aWwuZ2V0QXJnKG1hcHBpbmcsIFwiZ2VuZXJhdGVkTGluZVwiLCBudWxsKSxcbiAgICAgICAgICAgICAgY29sdW1uOiB1dGlsLmdldEFyZyhtYXBwaW5nLCBcImdlbmVyYXRlZENvbHVtblwiLCBudWxsKSxcbiAgICAgICAgICAgICAgbGFzdENvbHVtbjogdXRpbC5nZXRBcmcobWFwcGluZywgXCJsYXN0R2VuZXJhdGVkQ29sdW1uXCIsIG51bGwpXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIG1hcHBpbmcgPSB0aGlzLl9vcmlnaW5hbE1hcHBpbmdzWysraW5kZXhdO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB2YXIgb3JpZ2luYWxDb2x1bW4gPSBtYXBwaW5nLm9yaWdpbmFsQ29sdW1uO1xuICAgICAgICAgIHdoaWxlIChtYXBwaW5nICYmIG1hcHBpbmcub3JpZ2luYWxMaW5lID09PSBsaW5lICYmIG1hcHBpbmcub3JpZ2luYWxDb2x1bW4gPT0gb3JpZ2luYWxDb2x1bW4pIHtcbiAgICAgICAgICAgIG1hcHBpbmdzLnB1c2goe1xuICAgICAgICAgICAgICBsaW5lOiB1dGlsLmdldEFyZyhtYXBwaW5nLCBcImdlbmVyYXRlZExpbmVcIiwgbnVsbCksXG4gICAgICAgICAgICAgIGNvbHVtbjogdXRpbC5nZXRBcmcobWFwcGluZywgXCJnZW5lcmF0ZWRDb2x1bW5cIiwgbnVsbCksXG4gICAgICAgICAgICAgIGxhc3RDb2x1bW46IHV0aWwuZ2V0QXJnKG1hcHBpbmcsIFwibGFzdEdlbmVyYXRlZENvbHVtblwiLCBudWxsKVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBtYXBwaW5nID0gdGhpcy5fb3JpZ2luYWxNYXBwaW5nc1srK2luZGV4XTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBtYXBwaW5ncztcbiAgICB9O1xuICAgIGV4cG9ydHMuU291cmNlTWFwQ29uc3VtZXIgPSBTb3VyY2VNYXBDb25zdW1lcjI7XG4gICAgZnVuY3Rpb24gQmFzaWNTb3VyY2VNYXBDb25zdW1lcihhU291cmNlTWFwLCBhU291cmNlTWFwVVJMKSB7XG4gICAgICB2YXIgc291cmNlTWFwID0gYVNvdXJjZU1hcDtcbiAgICAgIGlmICh0eXBlb2YgYVNvdXJjZU1hcCA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICBzb3VyY2VNYXAgPSB1dGlsLnBhcnNlU291cmNlTWFwSW5wdXQoYVNvdXJjZU1hcCk7XG4gICAgICB9XG4gICAgICB2YXIgdmVyc2lvbiA9IHV0aWwuZ2V0QXJnKHNvdXJjZU1hcCwgXCJ2ZXJzaW9uXCIpO1xuICAgICAgdmFyIHNvdXJjZXMgPSB1dGlsLmdldEFyZyhzb3VyY2VNYXAsIFwic291cmNlc1wiKTtcbiAgICAgIHZhciBuYW1lcyA9IHV0aWwuZ2V0QXJnKHNvdXJjZU1hcCwgXCJuYW1lc1wiLCBbXSk7XG4gICAgICB2YXIgc291cmNlUm9vdCA9IHV0aWwuZ2V0QXJnKHNvdXJjZU1hcCwgXCJzb3VyY2VSb290XCIsIG51bGwpO1xuICAgICAgdmFyIHNvdXJjZXNDb250ZW50ID0gdXRpbC5nZXRBcmcoc291cmNlTWFwLCBcInNvdXJjZXNDb250ZW50XCIsIG51bGwpO1xuICAgICAgdmFyIG1hcHBpbmdzID0gdXRpbC5nZXRBcmcoc291cmNlTWFwLCBcIm1hcHBpbmdzXCIpO1xuICAgICAgdmFyIGZpbGUgPSB1dGlsLmdldEFyZyhzb3VyY2VNYXAsIFwiZmlsZVwiLCBudWxsKTtcbiAgICAgIGlmICh2ZXJzaW9uICE9IHRoaXMuX3ZlcnNpb24pIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVW5zdXBwb3J0ZWQgdmVyc2lvbjogXCIgKyB2ZXJzaW9uKTtcbiAgICAgIH1cbiAgICAgIGlmIChzb3VyY2VSb290KSB7XG4gICAgICAgIHNvdXJjZVJvb3QgPSB1dGlsLm5vcm1hbGl6ZShzb3VyY2VSb290KTtcbiAgICAgIH1cbiAgICAgIHNvdXJjZXMgPSBzb3VyY2VzLm1hcChTdHJpbmcpLm1hcCh1dGlsLm5vcm1hbGl6ZSkubWFwKGZ1bmN0aW9uKHNvdXJjZSkge1xuICAgICAgICByZXR1cm4gc291cmNlUm9vdCAmJiB1dGlsLmlzQWJzb2x1dGUoc291cmNlUm9vdCkgJiYgdXRpbC5pc0Fic29sdXRlKHNvdXJjZSkgPyB1dGlsLnJlbGF0aXZlKHNvdXJjZVJvb3QsIHNvdXJjZSkgOiBzb3VyY2U7XG4gICAgICB9KTtcbiAgICAgIHRoaXMuX25hbWVzID0gQXJyYXlTZXQuZnJvbUFycmF5KG5hbWVzLm1hcChTdHJpbmcpLCB0cnVlKTtcbiAgICAgIHRoaXMuX3NvdXJjZXMgPSBBcnJheVNldC5mcm9tQXJyYXkoc291cmNlcywgdHJ1ZSk7XG4gICAgICB0aGlzLl9hYnNvbHV0ZVNvdXJjZXMgPSB0aGlzLl9zb3VyY2VzLnRvQXJyYXkoKS5tYXAoZnVuY3Rpb24ocykge1xuICAgICAgICByZXR1cm4gdXRpbC5jb21wdXRlU291cmNlVVJMKHNvdXJjZVJvb3QsIHMsIGFTb3VyY2VNYXBVUkwpO1xuICAgICAgfSk7XG4gICAgICB0aGlzLnNvdXJjZVJvb3QgPSBzb3VyY2VSb290O1xuICAgICAgdGhpcy5zb3VyY2VzQ29udGVudCA9IHNvdXJjZXNDb250ZW50O1xuICAgICAgdGhpcy5fbWFwcGluZ3MgPSBtYXBwaW5ncztcbiAgICAgIHRoaXMuX3NvdXJjZU1hcFVSTCA9IGFTb3VyY2VNYXBVUkw7XG4gICAgICB0aGlzLmZpbGUgPSBmaWxlO1xuICAgIH1cbiAgICBCYXNpY1NvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUoU291cmNlTWFwQ29uc3VtZXIyLnByb3RvdHlwZSk7XG4gICAgQmFzaWNTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuY29uc3VtZXIgPSBTb3VyY2VNYXBDb25zdW1lcjI7XG4gICAgQmFzaWNTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuX2ZpbmRTb3VyY2VJbmRleCA9IGZ1bmN0aW9uKGFTb3VyY2UpIHtcbiAgICAgIHZhciByZWxhdGl2ZVNvdXJjZSA9IGFTb3VyY2U7XG4gICAgICBpZiAodGhpcy5zb3VyY2VSb290ICE9IG51bGwpIHtcbiAgICAgICAgcmVsYXRpdmVTb3VyY2UgPSB1dGlsLnJlbGF0aXZlKHRoaXMuc291cmNlUm9vdCwgcmVsYXRpdmVTb3VyY2UpO1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMuX3NvdXJjZXMuaGFzKHJlbGF0aXZlU291cmNlKSkge1xuICAgICAgICByZXR1cm4gdGhpcy5fc291cmNlcy5pbmRleE9mKHJlbGF0aXZlU291cmNlKTtcbiAgICAgIH1cbiAgICAgIHZhciBpO1xuICAgICAgZm9yIChpID0gMDsgaSA8IHRoaXMuX2Fic29sdXRlU291cmNlcy5sZW5ndGg7ICsraSkge1xuICAgICAgICBpZiAodGhpcy5fYWJzb2x1dGVTb3VyY2VzW2ldID09IGFTb3VyY2UpIHtcbiAgICAgICAgICByZXR1cm4gaTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIC0xO1xuICAgIH07XG4gICAgQmFzaWNTb3VyY2VNYXBDb25zdW1lci5mcm9tU291cmNlTWFwID0gZnVuY3Rpb24gU291cmNlTWFwQ29uc3VtZXJfZnJvbVNvdXJjZU1hcChhU291cmNlTWFwLCBhU291cmNlTWFwVVJMKSB7XG4gICAgICB2YXIgc21jID0gT2JqZWN0LmNyZWF0ZShCYXNpY1NvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZSk7XG4gICAgICB2YXIgbmFtZXMgPSBzbWMuX25hbWVzID0gQXJyYXlTZXQuZnJvbUFycmF5KGFTb3VyY2VNYXAuX25hbWVzLnRvQXJyYXkoKSwgdHJ1ZSk7XG4gICAgICB2YXIgc291cmNlcyA9IHNtYy5fc291cmNlcyA9IEFycmF5U2V0LmZyb21BcnJheShhU291cmNlTWFwLl9zb3VyY2VzLnRvQXJyYXkoKSwgdHJ1ZSk7XG4gICAgICBzbWMuc291cmNlUm9vdCA9IGFTb3VyY2VNYXAuX3NvdXJjZVJvb3Q7XG4gICAgICBzbWMuc291cmNlc0NvbnRlbnQgPSBhU291cmNlTWFwLl9nZW5lcmF0ZVNvdXJjZXNDb250ZW50KFxuICAgICAgICBzbWMuX3NvdXJjZXMudG9BcnJheSgpLFxuICAgICAgICBzbWMuc291cmNlUm9vdFxuICAgICAgKTtcbiAgICAgIHNtYy5maWxlID0gYVNvdXJjZU1hcC5fZmlsZTtcbiAgICAgIHNtYy5fc291cmNlTWFwVVJMID0gYVNvdXJjZU1hcFVSTDtcbiAgICAgIHNtYy5fYWJzb2x1dGVTb3VyY2VzID0gc21jLl9zb3VyY2VzLnRvQXJyYXkoKS5tYXAoZnVuY3Rpb24ocykge1xuICAgICAgICByZXR1cm4gdXRpbC5jb21wdXRlU291cmNlVVJMKHNtYy5zb3VyY2VSb290LCBzLCBhU291cmNlTWFwVVJMKTtcbiAgICAgIH0pO1xuICAgICAgdmFyIGdlbmVyYXRlZE1hcHBpbmdzID0gYVNvdXJjZU1hcC5fbWFwcGluZ3MudG9BcnJheSgpLnNsaWNlKCk7XG4gICAgICB2YXIgZGVzdEdlbmVyYXRlZE1hcHBpbmdzID0gc21jLl9fZ2VuZXJhdGVkTWFwcGluZ3MgPSBbXTtcbiAgICAgIHZhciBkZXN0T3JpZ2luYWxNYXBwaW5ncyA9IHNtYy5fX29yaWdpbmFsTWFwcGluZ3MgPSBbXTtcbiAgICAgIGZvciAodmFyIGkgPSAwLCBsZW5ndGggPSBnZW5lcmF0ZWRNYXBwaW5ncy5sZW5ndGg7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgICAgICB2YXIgc3JjTWFwcGluZyA9IGdlbmVyYXRlZE1hcHBpbmdzW2ldO1xuICAgICAgICB2YXIgZGVzdE1hcHBpbmcgPSBuZXcgTWFwcGluZygpO1xuICAgICAgICBkZXN0TWFwcGluZy5nZW5lcmF0ZWRMaW5lID0gc3JjTWFwcGluZy5nZW5lcmF0ZWRMaW5lO1xuICAgICAgICBkZXN0TWFwcGluZy5nZW5lcmF0ZWRDb2x1bW4gPSBzcmNNYXBwaW5nLmdlbmVyYXRlZENvbHVtbjtcbiAgICAgICAgaWYgKHNyY01hcHBpbmcuc291cmNlKSB7XG4gICAgICAgICAgZGVzdE1hcHBpbmcuc291cmNlID0gc291cmNlcy5pbmRleE9mKHNyY01hcHBpbmcuc291cmNlKTtcbiAgICAgICAgICBkZXN0TWFwcGluZy5vcmlnaW5hbExpbmUgPSBzcmNNYXBwaW5nLm9yaWdpbmFsTGluZTtcbiAgICAgICAgICBkZXN0TWFwcGluZy5vcmlnaW5hbENvbHVtbiA9IHNyY01hcHBpbmcub3JpZ2luYWxDb2x1bW47XG4gICAgICAgICAgaWYgKHNyY01hcHBpbmcubmFtZSkge1xuICAgICAgICAgICAgZGVzdE1hcHBpbmcubmFtZSA9IG5hbWVzLmluZGV4T2Yoc3JjTWFwcGluZy5uYW1lKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgZGVzdE9yaWdpbmFsTWFwcGluZ3MucHVzaChkZXN0TWFwcGluZyk7XG4gICAgICAgIH1cbiAgICAgICAgZGVzdEdlbmVyYXRlZE1hcHBpbmdzLnB1c2goZGVzdE1hcHBpbmcpO1xuICAgICAgfVxuICAgICAgcXVpY2tTb3J0KHNtYy5fX29yaWdpbmFsTWFwcGluZ3MsIHV0aWwuY29tcGFyZUJ5T3JpZ2luYWxQb3NpdGlvbnMpO1xuICAgICAgcmV0dXJuIHNtYztcbiAgICB9O1xuICAgIEJhc2ljU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLl92ZXJzaW9uID0gMztcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoQmFzaWNTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUsIFwic291cmNlc1wiLCB7XG4gICAgICBnZXQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fYWJzb2x1dGVTb3VyY2VzLnNsaWNlKCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgZnVuY3Rpb24gTWFwcGluZygpIHtcbiAgICAgIHRoaXMuZ2VuZXJhdGVkTGluZSA9IDA7XG4gICAgICB0aGlzLmdlbmVyYXRlZENvbHVtbiA9IDA7XG4gICAgICB0aGlzLnNvdXJjZSA9IG51bGw7XG4gICAgICB0aGlzLm9yaWdpbmFsTGluZSA9IG51bGw7XG4gICAgICB0aGlzLm9yaWdpbmFsQ29sdW1uID0gbnVsbDtcbiAgICAgIHRoaXMubmFtZSA9IG51bGw7XG4gICAgfVxuICAgIHZhciBjb21wYXJlR2VuZXJhdGVkID0gdXRpbC5jb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNEZWZsYXRlZE5vTGluZTtcbiAgICBmdW5jdGlvbiBzb3J0R2VuZXJhdGVkKGFycmF5LCBzdGFydCkge1xuICAgICAgbGV0IGwgPSBhcnJheS5sZW5ndGg7XG4gICAgICBsZXQgbiA9IGFycmF5Lmxlbmd0aCAtIHN0YXJ0O1xuICAgICAgaWYgKG4gPD0gMSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9IGVsc2UgaWYgKG4gPT0gMikge1xuICAgICAgICBsZXQgYSA9IGFycmF5W3N0YXJ0XTtcbiAgICAgICAgbGV0IGIgPSBhcnJheVtzdGFydCArIDFdO1xuICAgICAgICBpZiAoY29tcGFyZUdlbmVyYXRlZChhLCBiKSA+IDApIHtcbiAgICAgICAgICBhcnJheVtzdGFydF0gPSBiO1xuICAgICAgICAgIGFycmF5W3N0YXJ0ICsgMV0gPSBhO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKG4gPCAyMCkge1xuICAgICAgICBmb3IgKGxldCBpID0gc3RhcnQ7IGkgPCBsOyBpKyspIHtcbiAgICAgICAgICBmb3IgKGxldCBqID0gaTsgaiA+IHN0YXJ0OyBqLS0pIHtcbiAgICAgICAgICAgIGxldCBhID0gYXJyYXlbaiAtIDFdO1xuICAgICAgICAgICAgbGV0IGIgPSBhcnJheVtqXTtcbiAgICAgICAgICAgIGlmIChjb21wYXJlR2VuZXJhdGVkKGEsIGIpIDw9IDApIHtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhcnJheVtqIC0gMV0gPSBiO1xuICAgICAgICAgICAgYXJyYXlbal0gPSBhO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcXVpY2tTb3J0KGFycmF5LCBjb21wYXJlR2VuZXJhdGVkLCBzdGFydCk7XG4gICAgICB9XG4gICAgfVxuICAgIEJhc2ljU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLl9wYXJzZU1hcHBpbmdzID0gZnVuY3Rpb24gU291cmNlTWFwQ29uc3VtZXJfcGFyc2VNYXBwaW5ncyhhU3RyLCBhU291cmNlUm9vdCkge1xuICAgICAgdmFyIGdlbmVyYXRlZExpbmUgPSAxO1xuICAgICAgdmFyIHByZXZpb3VzR2VuZXJhdGVkQ29sdW1uID0gMDtcbiAgICAgIHZhciBwcmV2aW91c09yaWdpbmFsTGluZSA9IDA7XG4gICAgICB2YXIgcHJldmlvdXNPcmlnaW5hbENvbHVtbiA9IDA7XG4gICAgICB2YXIgcHJldmlvdXNTb3VyY2UgPSAwO1xuICAgICAgdmFyIHByZXZpb3VzTmFtZSA9IDA7XG4gICAgICB2YXIgbGVuZ3RoID0gYVN0ci5sZW5ndGg7XG4gICAgICB2YXIgaW5kZXggPSAwO1xuICAgICAgdmFyIGNhY2hlZFNlZ21lbnRzID0ge307XG4gICAgICB2YXIgdGVtcCA9IHt9O1xuICAgICAgdmFyIG9yaWdpbmFsTWFwcGluZ3MgPSBbXTtcbiAgICAgIHZhciBnZW5lcmF0ZWRNYXBwaW5ncyA9IFtdO1xuICAgICAgdmFyIG1hcHBpbmcsIHN0ciwgc2VnbWVudCwgZW5kLCB2YWx1ZTtcbiAgICAgIGxldCBzdWJhcnJheVN0YXJ0ID0gMDtcbiAgICAgIHdoaWxlIChpbmRleCA8IGxlbmd0aCkge1xuICAgICAgICBpZiAoYVN0ci5jaGFyQXQoaW5kZXgpID09PSBcIjtcIikge1xuICAgICAgICAgIGdlbmVyYXRlZExpbmUrKztcbiAgICAgICAgICBpbmRleCsrO1xuICAgICAgICAgIHByZXZpb3VzR2VuZXJhdGVkQ29sdW1uID0gMDtcbiAgICAgICAgICBzb3J0R2VuZXJhdGVkKGdlbmVyYXRlZE1hcHBpbmdzLCBzdWJhcnJheVN0YXJ0KTtcbiAgICAgICAgICBzdWJhcnJheVN0YXJ0ID0gZ2VuZXJhdGVkTWFwcGluZ3MubGVuZ3RoO1xuICAgICAgICB9IGVsc2UgaWYgKGFTdHIuY2hhckF0KGluZGV4KSA9PT0gXCIsXCIpIHtcbiAgICAgICAgICBpbmRleCsrO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG1hcHBpbmcgPSBuZXcgTWFwcGluZygpO1xuICAgICAgICAgIG1hcHBpbmcuZ2VuZXJhdGVkTGluZSA9IGdlbmVyYXRlZExpbmU7XG4gICAgICAgICAgZm9yIChlbmQgPSBpbmRleDsgZW5kIDwgbGVuZ3RoOyBlbmQrKykge1xuICAgICAgICAgICAgaWYgKHRoaXMuX2NoYXJJc01hcHBpbmdTZXBhcmF0b3IoYVN0ciwgZW5kKSkge1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgc3RyID0gYVN0ci5zbGljZShpbmRleCwgZW5kKTtcbiAgICAgICAgICBzZWdtZW50ID0gW107XG4gICAgICAgICAgd2hpbGUgKGluZGV4IDwgZW5kKSB7XG4gICAgICAgICAgICBiYXNlNjRWTFEuZGVjb2RlKGFTdHIsIGluZGV4LCB0ZW1wKTtcbiAgICAgICAgICAgIHZhbHVlID0gdGVtcC52YWx1ZTtcbiAgICAgICAgICAgIGluZGV4ID0gdGVtcC5yZXN0O1xuICAgICAgICAgICAgc2VnbWVudC5wdXNoKHZhbHVlKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHNlZ21lbnQubGVuZ3RoID09PSAyKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGb3VuZCBhIHNvdXJjZSwgYnV0IG5vIGxpbmUgYW5kIGNvbHVtblwiKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHNlZ21lbnQubGVuZ3RoID09PSAzKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGb3VuZCBhIHNvdXJjZSBhbmQgbGluZSwgYnV0IG5vIGNvbHVtblwiKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgbWFwcGluZy5nZW5lcmF0ZWRDb2x1bW4gPSBwcmV2aW91c0dlbmVyYXRlZENvbHVtbiArIHNlZ21lbnRbMF07XG4gICAgICAgICAgcHJldmlvdXNHZW5lcmF0ZWRDb2x1bW4gPSBtYXBwaW5nLmdlbmVyYXRlZENvbHVtbjtcbiAgICAgICAgICBpZiAoc2VnbWVudC5sZW5ndGggPiAxKSB7XG4gICAgICAgICAgICBtYXBwaW5nLnNvdXJjZSA9IHByZXZpb3VzU291cmNlICsgc2VnbWVudFsxXTtcbiAgICAgICAgICAgIHByZXZpb3VzU291cmNlICs9IHNlZ21lbnRbMV07XG4gICAgICAgICAgICBtYXBwaW5nLm9yaWdpbmFsTGluZSA9IHByZXZpb3VzT3JpZ2luYWxMaW5lICsgc2VnbWVudFsyXTtcbiAgICAgICAgICAgIHByZXZpb3VzT3JpZ2luYWxMaW5lID0gbWFwcGluZy5vcmlnaW5hbExpbmU7XG4gICAgICAgICAgICBtYXBwaW5nLm9yaWdpbmFsTGluZSArPSAxO1xuICAgICAgICAgICAgbWFwcGluZy5vcmlnaW5hbENvbHVtbiA9IHByZXZpb3VzT3JpZ2luYWxDb2x1bW4gKyBzZWdtZW50WzNdO1xuICAgICAgICAgICAgcHJldmlvdXNPcmlnaW5hbENvbHVtbiA9IG1hcHBpbmcub3JpZ2luYWxDb2x1bW47XG4gICAgICAgICAgICBpZiAoc2VnbWVudC5sZW5ndGggPiA0KSB7XG4gICAgICAgICAgICAgIG1hcHBpbmcubmFtZSA9IHByZXZpb3VzTmFtZSArIHNlZ21lbnRbNF07XG4gICAgICAgICAgICAgIHByZXZpb3VzTmFtZSArPSBzZWdtZW50WzRdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBnZW5lcmF0ZWRNYXBwaW5ncy5wdXNoKG1hcHBpbmcpO1xuICAgICAgICAgIGlmICh0eXBlb2YgbWFwcGluZy5vcmlnaW5hbExpbmUgPT09IFwibnVtYmVyXCIpIHtcbiAgICAgICAgICAgIGxldCBjdXJyZW50U291cmNlID0gbWFwcGluZy5zb3VyY2U7XG4gICAgICAgICAgICB3aGlsZSAob3JpZ2luYWxNYXBwaW5ncy5sZW5ndGggPD0gY3VycmVudFNvdXJjZSkge1xuICAgICAgICAgICAgICBvcmlnaW5hbE1hcHBpbmdzLnB1c2gobnVsbCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAob3JpZ2luYWxNYXBwaW5nc1tjdXJyZW50U291cmNlXSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgICBvcmlnaW5hbE1hcHBpbmdzW2N1cnJlbnRTb3VyY2VdID0gW107XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvcmlnaW5hbE1hcHBpbmdzW2N1cnJlbnRTb3VyY2VdLnB1c2gobWFwcGluZyk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBzb3J0R2VuZXJhdGVkKGdlbmVyYXRlZE1hcHBpbmdzLCBzdWJhcnJheVN0YXJ0KTtcbiAgICAgIHRoaXMuX19nZW5lcmF0ZWRNYXBwaW5ncyA9IGdlbmVyYXRlZE1hcHBpbmdzO1xuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBvcmlnaW5hbE1hcHBpbmdzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGlmIChvcmlnaW5hbE1hcHBpbmdzW2ldICE9IG51bGwpIHtcbiAgICAgICAgICBxdWlja1NvcnQob3JpZ2luYWxNYXBwaW5nc1tpXSwgdXRpbC5jb21wYXJlQnlPcmlnaW5hbFBvc2l0aW9uc05vU291cmNlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhpcy5fX29yaWdpbmFsTWFwcGluZ3MgPSBbXS5jb25jYXQoLi4ub3JpZ2luYWxNYXBwaW5ncyk7XG4gICAgfTtcbiAgICBCYXNpY1NvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5fZmluZE1hcHBpbmcgPSBmdW5jdGlvbiBTb3VyY2VNYXBDb25zdW1lcl9maW5kTWFwcGluZyhhTmVlZGxlLCBhTWFwcGluZ3MsIGFMaW5lTmFtZSwgYUNvbHVtbk5hbWUsIGFDb21wYXJhdG9yLCBhQmlhcykge1xuICAgICAgaWYgKGFOZWVkbGVbYUxpbmVOYW1lXSA8PSAwKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJMaW5lIG11c3QgYmUgZ3JlYXRlciB0aGFuIG9yIGVxdWFsIHRvIDEsIGdvdCBcIiArIGFOZWVkbGVbYUxpbmVOYW1lXSk7XG4gICAgICB9XG4gICAgICBpZiAoYU5lZWRsZVthQ29sdW1uTmFtZV0gPCAwKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDb2x1bW4gbXVzdCBiZSBncmVhdGVyIHRoYW4gb3IgZXF1YWwgdG8gMCwgZ290IFwiICsgYU5lZWRsZVthQ29sdW1uTmFtZV0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGJpbmFyeVNlYXJjaC5zZWFyY2goYU5lZWRsZSwgYU1hcHBpbmdzLCBhQ29tcGFyYXRvciwgYUJpYXMpO1xuICAgIH07XG4gICAgQmFzaWNTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuY29tcHV0ZUNvbHVtblNwYW5zID0gZnVuY3Rpb24gU291cmNlTWFwQ29uc3VtZXJfY29tcHV0ZUNvbHVtblNwYW5zKCkge1xuICAgICAgZm9yICh2YXIgaW5kZXggPSAwOyBpbmRleCA8IHRoaXMuX2dlbmVyYXRlZE1hcHBpbmdzLmxlbmd0aDsgKytpbmRleCkge1xuICAgICAgICB2YXIgbWFwcGluZyA9IHRoaXMuX2dlbmVyYXRlZE1hcHBpbmdzW2luZGV4XTtcbiAgICAgICAgaWYgKGluZGV4ICsgMSA8IHRoaXMuX2dlbmVyYXRlZE1hcHBpbmdzLmxlbmd0aCkge1xuICAgICAgICAgIHZhciBuZXh0TWFwcGluZyA9IHRoaXMuX2dlbmVyYXRlZE1hcHBpbmdzW2luZGV4ICsgMV07XG4gICAgICAgICAgaWYgKG1hcHBpbmcuZ2VuZXJhdGVkTGluZSA9PT0gbmV4dE1hcHBpbmcuZ2VuZXJhdGVkTGluZSkge1xuICAgICAgICAgICAgbWFwcGluZy5sYXN0R2VuZXJhdGVkQ29sdW1uID0gbmV4dE1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uIC0gMTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBtYXBwaW5nLmxhc3RHZW5lcmF0ZWRDb2x1bW4gPSBJbmZpbml0eTtcbiAgICAgIH1cbiAgICB9O1xuICAgIEJhc2ljU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLm9yaWdpbmFsUG9zaXRpb25Gb3IgPSBmdW5jdGlvbiBTb3VyY2VNYXBDb25zdW1lcl9vcmlnaW5hbFBvc2l0aW9uRm9yKGFBcmdzKSB7XG4gICAgICB2YXIgbmVlZGxlID0ge1xuICAgICAgICBnZW5lcmF0ZWRMaW5lOiB1dGlsLmdldEFyZyhhQXJncywgXCJsaW5lXCIpLFxuICAgICAgICBnZW5lcmF0ZWRDb2x1bW46IHV0aWwuZ2V0QXJnKGFBcmdzLCBcImNvbHVtblwiKVxuICAgICAgfTtcbiAgICAgIHZhciBpbmRleCA9IHRoaXMuX2ZpbmRNYXBwaW5nKFxuICAgICAgICBuZWVkbGUsXG4gICAgICAgIHRoaXMuX2dlbmVyYXRlZE1hcHBpbmdzLFxuICAgICAgICBcImdlbmVyYXRlZExpbmVcIixcbiAgICAgICAgXCJnZW5lcmF0ZWRDb2x1bW5cIixcbiAgICAgICAgdXRpbC5jb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNEZWZsYXRlZCxcbiAgICAgICAgdXRpbC5nZXRBcmcoYUFyZ3MsIFwiYmlhc1wiLCBTb3VyY2VNYXBDb25zdW1lcjIuR1JFQVRFU1RfTE9XRVJfQk9VTkQpXG4gICAgICApO1xuICAgICAgaWYgKGluZGV4ID49IDApIHtcbiAgICAgICAgdmFyIG1hcHBpbmcgPSB0aGlzLl9nZW5lcmF0ZWRNYXBwaW5nc1tpbmRleF07XG4gICAgICAgIGlmIChtYXBwaW5nLmdlbmVyYXRlZExpbmUgPT09IG5lZWRsZS5nZW5lcmF0ZWRMaW5lKSB7XG4gICAgICAgICAgdmFyIHNvdXJjZSA9IHV0aWwuZ2V0QXJnKG1hcHBpbmcsIFwic291cmNlXCIsIG51bGwpO1xuICAgICAgICAgIGlmIChzb3VyY2UgIT09IG51bGwpIHtcbiAgICAgICAgICAgIHNvdXJjZSA9IHRoaXMuX3NvdXJjZXMuYXQoc291cmNlKTtcbiAgICAgICAgICAgIHNvdXJjZSA9IHV0aWwuY29tcHV0ZVNvdXJjZVVSTCh0aGlzLnNvdXJjZVJvb3QsIHNvdXJjZSwgdGhpcy5fc291cmNlTWFwVVJMKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIG5hbWUgPSB1dGlsLmdldEFyZyhtYXBwaW5nLCBcIm5hbWVcIiwgbnVsbCk7XG4gICAgICAgICAgaWYgKG5hbWUgIT09IG51bGwpIHtcbiAgICAgICAgICAgIG5hbWUgPSB0aGlzLl9uYW1lcy5hdChuYW1lKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHNvdXJjZSxcbiAgICAgICAgICAgIGxpbmU6IHV0aWwuZ2V0QXJnKG1hcHBpbmcsIFwib3JpZ2luYWxMaW5lXCIsIG51bGwpLFxuICAgICAgICAgICAgY29sdW1uOiB1dGlsLmdldEFyZyhtYXBwaW5nLCBcIm9yaWdpbmFsQ29sdW1uXCIsIG51bGwpLFxuICAgICAgICAgICAgbmFtZVxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiB7XG4gICAgICAgIHNvdXJjZTogbnVsbCxcbiAgICAgICAgbGluZTogbnVsbCxcbiAgICAgICAgY29sdW1uOiBudWxsLFxuICAgICAgICBuYW1lOiBudWxsXG4gICAgICB9O1xuICAgIH07XG4gICAgQmFzaWNTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuaGFzQ29udGVudHNPZkFsbFNvdXJjZXMgPSBmdW5jdGlvbiBCYXNpY1NvdXJjZU1hcENvbnN1bWVyX2hhc0NvbnRlbnRzT2ZBbGxTb3VyY2VzKCkge1xuICAgICAgaWYgKCF0aGlzLnNvdXJjZXNDb250ZW50KSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzLnNvdXJjZXNDb250ZW50Lmxlbmd0aCA+PSB0aGlzLl9zb3VyY2VzLnNpemUoKSAmJiAhdGhpcy5zb3VyY2VzQ29udGVudC5zb21lKGZ1bmN0aW9uKHNjKSB7XG4gICAgICAgIHJldHVybiBzYyA9PSBudWxsO1xuICAgICAgfSk7XG4gICAgfTtcbiAgICBCYXNpY1NvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5zb3VyY2VDb250ZW50Rm9yID0gZnVuY3Rpb24gU291cmNlTWFwQ29uc3VtZXJfc291cmNlQ29udGVudEZvcihhU291cmNlLCBudWxsT25NaXNzaW5nKSB7XG4gICAgICBpZiAoIXRoaXMuc291cmNlc0NvbnRlbnQpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgICB2YXIgaW5kZXggPSB0aGlzLl9maW5kU291cmNlSW5kZXgoYVNvdXJjZSk7XG4gICAgICBpZiAoaW5kZXggPj0gMCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zb3VyY2VzQ29udGVudFtpbmRleF07XG4gICAgICB9XG4gICAgICB2YXIgcmVsYXRpdmVTb3VyY2UgPSBhU291cmNlO1xuICAgICAgaWYgKHRoaXMuc291cmNlUm9vdCAhPSBudWxsKSB7XG4gICAgICAgIHJlbGF0aXZlU291cmNlID0gdXRpbC5yZWxhdGl2ZSh0aGlzLnNvdXJjZVJvb3QsIHJlbGF0aXZlU291cmNlKTtcbiAgICAgIH1cbiAgICAgIHZhciB1cmw7XG4gICAgICBpZiAodGhpcy5zb3VyY2VSb290ICE9IG51bGwgJiYgKHVybCA9IHV0aWwudXJsUGFyc2UodGhpcy5zb3VyY2VSb290KSkpIHtcbiAgICAgICAgdmFyIGZpbGVVcmlBYnNQYXRoID0gcmVsYXRpdmVTb3VyY2UucmVwbGFjZSgvXmZpbGU6XFwvXFwvLywgXCJcIik7XG4gICAgICAgIGlmICh1cmwuc2NoZW1lID09IFwiZmlsZVwiICYmIHRoaXMuX3NvdXJjZXMuaGFzKGZpbGVVcmlBYnNQYXRoKSkge1xuICAgICAgICAgIHJldHVybiB0aGlzLnNvdXJjZXNDb250ZW50W3RoaXMuX3NvdXJjZXMuaW5kZXhPZihmaWxlVXJpQWJzUGF0aCldO1xuICAgICAgICB9XG4gICAgICAgIGlmICgoIXVybC5wYXRoIHx8IHVybC5wYXRoID09IFwiL1wiKSAmJiB0aGlzLl9zb3VyY2VzLmhhcyhcIi9cIiArIHJlbGF0aXZlU291cmNlKSkge1xuICAgICAgICAgIHJldHVybiB0aGlzLnNvdXJjZXNDb250ZW50W3RoaXMuX3NvdXJjZXMuaW5kZXhPZihcIi9cIiArIHJlbGF0aXZlU291cmNlKV07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChudWxsT25NaXNzaW5nKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdcIicgKyByZWxhdGl2ZVNvdXJjZSArICdcIiBpcyBub3QgaW4gdGhlIFNvdXJjZU1hcC4nKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIEJhc2ljU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLmdlbmVyYXRlZFBvc2l0aW9uRm9yID0gZnVuY3Rpb24gU291cmNlTWFwQ29uc3VtZXJfZ2VuZXJhdGVkUG9zaXRpb25Gb3IoYUFyZ3MpIHtcbiAgICAgIHZhciBzb3VyY2UgPSB1dGlsLmdldEFyZyhhQXJncywgXCJzb3VyY2VcIik7XG4gICAgICBzb3VyY2UgPSB0aGlzLl9maW5kU291cmNlSW5kZXgoc291cmNlKTtcbiAgICAgIGlmIChzb3VyY2UgPCAwKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgbGluZTogbnVsbCxcbiAgICAgICAgICBjb2x1bW46IG51bGwsXG4gICAgICAgICAgbGFzdENvbHVtbjogbnVsbFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgdmFyIG5lZWRsZSA9IHtcbiAgICAgICAgc291cmNlLFxuICAgICAgICBvcmlnaW5hbExpbmU6IHV0aWwuZ2V0QXJnKGFBcmdzLCBcImxpbmVcIiksXG4gICAgICAgIG9yaWdpbmFsQ29sdW1uOiB1dGlsLmdldEFyZyhhQXJncywgXCJjb2x1bW5cIilcbiAgICAgIH07XG4gICAgICB2YXIgaW5kZXggPSB0aGlzLl9maW5kTWFwcGluZyhcbiAgICAgICAgbmVlZGxlLFxuICAgICAgICB0aGlzLl9vcmlnaW5hbE1hcHBpbmdzLFxuICAgICAgICBcIm9yaWdpbmFsTGluZVwiLFxuICAgICAgICBcIm9yaWdpbmFsQ29sdW1uXCIsXG4gICAgICAgIHV0aWwuY29tcGFyZUJ5T3JpZ2luYWxQb3NpdGlvbnMsXG4gICAgICAgIHV0aWwuZ2V0QXJnKGFBcmdzLCBcImJpYXNcIiwgU291cmNlTWFwQ29uc3VtZXIyLkdSRUFURVNUX0xPV0VSX0JPVU5EKVxuICAgICAgKTtcbiAgICAgIGlmIChpbmRleCA+PSAwKSB7XG4gICAgICAgIHZhciBtYXBwaW5nID0gdGhpcy5fb3JpZ2luYWxNYXBwaW5nc1tpbmRleF07XG4gICAgICAgIGlmIChtYXBwaW5nLnNvdXJjZSA9PT0gbmVlZGxlLnNvdXJjZSkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBsaW5lOiB1dGlsLmdldEFyZyhtYXBwaW5nLCBcImdlbmVyYXRlZExpbmVcIiwgbnVsbCksXG4gICAgICAgICAgICBjb2x1bW46IHV0aWwuZ2V0QXJnKG1hcHBpbmcsIFwiZ2VuZXJhdGVkQ29sdW1uXCIsIG51bGwpLFxuICAgICAgICAgICAgbGFzdENvbHVtbjogdXRpbC5nZXRBcmcobWFwcGluZywgXCJsYXN0R2VuZXJhdGVkQ29sdW1uXCIsIG51bGwpXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbGluZTogbnVsbCxcbiAgICAgICAgY29sdW1uOiBudWxsLFxuICAgICAgICBsYXN0Q29sdW1uOiBudWxsXG4gICAgICB9O1xuICAgIH07XG4gICAgZXhwb3J0cy5CYXNpY1NvdXJjZU1hcENvbnN1bWVyID0gQmFzaWNTb3VyY2VNYXBDb25zdW1lcjtcbiAgICBmdW5jdGlvbiBJbmRleGVkU291cmNlTWFwQ29uc3VtZXIoYVNvdXJjZU1hcCwgYVNvdXJjZU1hcFVSTCkge1xuICAgICAgdmFyIHNvdXJjZU1hcCA9IGFTb3VyY2VNYXA7XG4gICAgICBpZiAodHlwZW9mIGFTb3VyY2VNYXAgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgc291cmNlTWFwID0gdXRpbC5wYXJzZVNvdXJjZU1hcElucHV0KGFTb3VyY2VNYXApO1xuICAgICAgfVxuICAgICAgdmFyIHZlcnNpb24gPSB1dGlsLmdldEFyZyhzb3VyY2VNYXAsIFwidmVyc2lvblwiKTtcbiAgICAgIHZhciBzZWN0aW9ucyA9IHV0aWwuZ2V0QXJnKHNvdXJjZU1hcCwgXCJzZWN0aW9uc1wiKTtcbiAgICAgIGlmICh2ZXJzaW9uICE9IHRoaXMuX3ZlcnNpb24pIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVW5zdXBwb3J0ZWQgdmVyc2lvbjogXCIgKyB2ZXJzaW9uKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuX3NvdXJjZXMgPSBuZXcgQXJyYXlTZXQoKTtcbiAgICAgIHRoaXMuX25hbWVzID0gbmV3IEFycmF5U2V0KCk7XG4gICAgICB2YXIgbGFzdE9mZnNldCA9IHtcbiAgICAgICAgbGluZTogLTEsXG4gICAgICAgIGNvbHVtbjogMFxuICAgICAgfTtcbiAgICAgIHRoaXMuX3NlY3Rpb25zID0gc2VjdGlvbnMubWFwKGZ1bmN0aW9uKHMpIHtcbiAgICAgICAgaWYgKHMudXJsKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiU3VwcG9ydCBmb3IgdXJsIGZpZWxkIGluIHNlY3Rpb25zIG5vdCBpbXBsZW1lbnRlZC5cIik7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIG9mZnNldCA9IHV0aWwuZ2V0QXJnKHMsIFwib2Zmc2V0XCIpO1xuICAgICAgICB2YXIgb2Zmc2V0TGluZSA9IHV0aWwuZ2V0QXJnKG9mZnNldCwgXCJsaW5lXCIpO1xuICAgICAgICB2YXIgb2Zmc2V0Q29sdW1uID0gdXRpbC5nZXRBcmcob2Zmc2V0LCBcImNvbHVtblwiKTtcbiAgICAgICAgaWYgKG9mZnNldExpbmUgPCBsYXN0T2Zmc2V0LmxpbmUgfHwgb2Zmc2V0TGluZSA9PT0gbGFzdE9mZnNldC5saW5lICYmIG9mZnNldENvbHVtbiA8IGxhc3RPZmZzZXQuY29sdW1uKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiU2VjdGlvbiBvZmZzZXRzIG11c3QgYmUgb3JkZXJlZCBhbmQgbm9uLW92ZXJsYXBwaW5nLlwiKTtcbiAgICAgICAgfVxuICAgICAgICBsYXN0T2Zmc2V0ID0gb2Zmc2V0O1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGdlbmVyYXRlZE9mZnNldDoge1xuICAgICAgICAgICAgLy8gVGhlIG9mZnNldCBmaWVsZHMgYXJlIDAtYmFzZWQsIGJ1dCB3ZSB1c2UgMS1iYXNlZCBpbmRpY2VzIHdoZW5cbiAgICAgICAgICAgIC8vIGVuY29kaW5nL2RlY29kaW5nIGZyb20gVkxRLlxuICAgICAgICAgICAgZ2VuZXJhdGVkTGluZTogb2Zmc2V0TGluZSArIDEsXG4gICAgICAgICAgICBnZW5lcmF0ZWRDb2x1bW46IG9mZnNldENvbHVtbiArIDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIGNvbnN1bWVyOiBuZXcgU291cmNlTWFwQ29uc3VtZXIyKHV0aWwuZ2V0QXJnKHMsIFwibWFwXCIpLCBhU291cmNlTWFwVVJMKVxuICAgICAgICB9O1xuICAgICAgfSk7XG4gICAgfVxuICAgIEluZGV4ZWRTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKFNvdXJjZU1hcENvbnN1bWVyMi5wcm90b3R5cGUpO1xuICAgIEluZGV4ZWRTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUuY29uc3RydWN0b3IgPSBTb3VyY2VNYXBDb25zdW1lcjI7XG4gICAgSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5fdmVyc2lvbiA9IDM7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KEluZGV4ZWRTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUsIFwic291cmNlc1wiLCB7XG4gICAgICBnZXQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgc291cmNlcyA9IFtdO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuX3NlY3Rpb25zLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCB0aGlzLl9zZWN0aW9uc1tpXS5jb25zdW1lci5zb3VyY2VzLmxlbmd0aDsgaisrKSB7XG4gICAgICAgICAgICBzb3VyY2VzLnB1c2godGhpcy5fc2VjdGlvbnNbaV0uY29uc3VtZXIuc291cmNlc1tqXSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzb3VyY2VzO1xuICAgICAgfVxuICAgIH0pO1xuICAgIEluZGV4ZWRTb3VyY2VNYXBDb25zdW1lci5wcm90b3R5cGUub3JpZ2luYWxQb3NpdGlvbkZvciA9IGZ1bmN0aW9uIEluZGV4ZWRTb3VyY2VNYXBDb25zdW1lcl9vcmlnaW5hbFBvc2l0aW9uRm9yKGFBcmdzKSB7XG4gICAgICB2YXIgbmVlZGxlID0ge1xuICAgICAgICBnZW5lcmF0ZWRMaW5lOiB1dGlsLmdldEFyZyhhQXJncywgXCJsaW5lXCIpLFxuICAgICAgICBnZW5lcmF0ZWRDb2x1bW46IHV0aWwuZ2V0QXJnKGFBcmdzLCBcImNvbHVtblwiKVxuICAgICAgfTtcbiAgICAgIHZhciBzZWN0aW9uSW5kZXggPSBiaW5hcnlTZWFyY2guc2VhcmNoKFxuICAgICAgICBuZWVkbGUsXG4gICAgICAgIHRoaXMuX3NlY3Rpb25zLFxuICAgICAgICBmdW5jdGlvbihuZWVkbGUyLCBzZWN0aW9uMikge1xuICAgICAgICAgIHZhciBjbXAgPSBuZWVkbGUyLmdlbmVyYXRlZExpbmUgLSBzZWN0aW9uMi5nZW5lcmF0ZWRPZmZzZXQuZ2VuZXJhdGVkTGluZTtcbiAgICAgICAgICBpZiAoY21wKSB7XG4gICAgICAgICAgICByZXR1cm4gY21wO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gbmVlZGxlMi5nZW5lcmF0ZWRDb2x1bW4gLSBzZWN0aW9uMi5nZW5lcmF0ZWRPZmZzZXQuZ2VuZXJhdGVkQ29sdW1uO1xuICAgICAgICB9XG4gICAgICApO1xuICAgICAgdmFyIHNlY3Rpb24gPSB0aGlzLl9zZWN0aW9uc1tzZWN0aW9uSW5kZXhdO1xuICAgICAgaWYgKCFzZWN0aW9uKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgc291cmNlOiBudWxsLFxuICAgICAgICAgIGxpbmU6IG51bGwsXG4gICAgICAgICAgY29sdW1uOiBudWxsLFxuICAgICAgICAgIG5hbWU6IG51bGxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzZWN0aW9uLmNvbnN1bWVyLm9yaWdpbmFsUG9zaXRpb25Gb3Ioe1xuICAgICAgICBsaW5lOiBuZWVkbGUuZ2VuZXJhdGVkTGluZSAtIChzZWN0aW9uLmdlbmVyYXRlZE9mZnNldC5nZW5lcmF0ZWRMaW5lIC0gMSksXG4gICAgICAgIGNvbHVtbjogbmVlZGxlLmdlbmVyYXRlZENvbHVtbiAtIChzZWN0aW9uLmdlbmVyYXRlZE9mZnNldC5nZW5lcmF0ZWRMaW5lID09PSBuZWVkbGUuZ2VuZXJhdGVkTGluZSA/IHNlY3Rpb24uZ2VuZXJhdGVkT2Zmc2V0LmdlbmVyYXRlZENvbHVtbiAtIDEgOiAwKSxcbiAgICAgICAgYmlhczogYUFyZ3MuYmlhc1xuICAgICAgfSk7XG4gICAgfTtcbiAgICBJbmRleGVkU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLmhhc0NvbnRlbnRzT2ZBbGxTb3VyY2VzID0gZnVuY3Rpb24gSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyX2hhc0NvbnRlbnRzT2ZBbGxTb3VyY2VzKCkge1xuICAgICAgcmV0dXJuIHRoaXMuX3NlY3Rpb25zLmV2ZXJ5KGZ1bmN0aW9uKHMpIHtcbiAgICAgICAgcmV0dXJuIHMuY29uc3VtZXIuaGFzQ29udGVudHNPZkFsbFNvdXJjZXMoKTtcbiAgICAgIH0pO1xuICAgIH07XG4gICAgSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5zb3VyY2VDb250ZW50Rm9yID0gZnVuY3Rpb24gSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyX3NvdXJjZUNvbnRlbnRGb3IoYVNvdXJjZSwgbnVsbE9uTWlzc2luZykge1xuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0aGlzLl9zZWN0aW9ucy5sZW5ndGg7IGkrKykge1xuICAgICAgICB2YXIgc2VjdGlvbiA9IHRoaXMuX3NlY3Rpb25zW2ldO1xuICAgICAgICB2YXIgY29udGVudCA9IHNlY3Rpb24uY29uc3VtZXIuc291cmNlQ29udGVudEZvcihhU291cmNlLCB0cnVlKTtcbiAgICAgICAgaWYgKGNvbnRlbnQpIHtcbiAgICAgICAgICByZXR1cm4gY29udGVudDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKG51bGxPbk1pc3NpbmcpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1wiJyArIGFTb3VyY2UgKyAnXCIgaXMgbm90IGluIHRoZSBTb3VyY2VNYXAuJyk7XG4gICAgICB9XG4gICAgfTtcbiAgICBJbmRleGVkU291cmNlTWFwQ29uc3VtZXIucHJvdG90eXBlLmdlbmVyYXRlZFBvc2l0aW9uRm9yID0gZnVuY3Rpb24gSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyX2dlbmVyYXRlZFBvc2l0aW9uRm9yKGFBcmdzKSB7XG4gICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuX3NlY3Rpb25zLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHZhciBzZWN0aW9uID0gdGhpcy5fc2VjdGlvbnNbaV07XG4gICAgICAgIGlmIChzZWN0aW9uLmNvbnN1bWVyLl9maW5kU291cmNlSW5kZXgodXRpbC5nZXRBcmcoYUFyZ3MsIFwic291cmNlXCIpKSA9PT0gLTEpIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgZ2VuZXJhdGVkUG9zaXRpb24gPSBzZWN0aW9uLmNvbnN1bWVyLmdlbmVyYXRlZFBvc2l0aW9uRm9yKGFBcmdzKTtcbiAgICAgICAgaWYgKGdlbmVyYXRlZFBvc2l0aW9uKSB7XG4gICAgICAgICAgdmFyIHJldCA9IHtcbiAgICAgICAgICAgIGxpbmU6IGdlbmVyYXRlZFBvc2l0aW9uLmxpbmUgKyAoc2VjdGlvbi5nZW5lcmF0ZWRPZmZzZXQuZ2VuZXJhdGVkTGluZSAtIDEpLFxuICAgICAgICAgICAgY29sdW1uOiBnZW5lcmF0ZWRQb3NpdGlvbi5jb2x1bW4gKyAoc2VjdGlvbi5nZW5lcmF0ZWRPZmZzZXQuZ2VuZXJhdGVkTGluZSA9PT0gZ2VuZXJhdGVkUG9zaXRpb24ubGluZSA/IHNlY3Rpb24uZ2VuZXJhdGVkT2Zmc2V0LmdlbmVyYXRlZENvbHVtbiAtIDEgOiAwKVxuICAgICAgICAgIH07XG4gICAgICAgICAgcmV0dXJuIHJldDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbGluZTogbnVsbCxcbiAgICAgICAgY29sdW1uOiBudWxsXG4gICAgICB9O1xuICAgIH07XG4gICAgSW5kZXhlZFNvdXJjZU1hcENvbnN1bWVyLnByb3RvdHlwZS5fcGFyc2VNYXBwaW5ncyA9IGZ1bmN0aW9uIEluZGV4ZWRTb3VyY2VNYXBDb25zdW1lcl9wYXJzZU1hcHBpbmdzKGFTdHIsIGFTb3VyY2VSb290KSB7XG4gICAgICB0aGlzLl9fZ2VuZXJhdGVkTWFwcGluZ3MgPSBbXTtcbiAgICAgIHRoaXMuX19vcmlnaW5hbE1hcHBpbmdzID0gW107XG4gICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMuX3NlY3Rpb25zLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHZhciBzZWN0aW9uID0gdGhpcy5fc2VjdGlvbnNbaV07XG4gICAgICAgIHZhciBzZWN0aW9uTWFwcGluZ3MgPSBzZWN0aW9uLmNvbnN1bWVyLl9nZW5lcmF0ZWRNYXBwaW5ncztcbiAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCBzZWN0aW9uTWFwcGluZ3MubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICB2YXIgbWFwcGluZyA9IHNlY3Rpb25NYXBwaW5nc1tqXTtcbiAgICAgICAgICB2YXIgc291cmNlID0gc2VjdGlvbi5jb25zdW1lci5fc291cmNlcy5hdChtYXBwaW5nLnNvdXJjZSk7XG4gICAgICAgICAgc291cmNlID0gdXRpbC5jb21wdXRlU291cmNlVVJMKHNlY3Rpb24uY29uc3VtZXIuc291cmNlUm9vdCwgc291cmNlLCB0aGlzLl9zb3VyY2VNYXBVUkwpO1xuICAgICAgICAgIHRoaXMuX3NvdXJjZXMuYWRkKHNvdXJjZSk7XG4gICAgICAgICAgc291cmNlID0gdGhpcy5fc291cmNlcy5pbmRleE9mKHNvdXJjZSk7XG4gICAgICAgICAgdmFyIG5hbWUgPSBudWxsO1xuICAgICAgICAgIGlmIChtYXBwaW5nLm5hbWUpIHtcbiAgICAgICAgICAgIG5hbWUgPSBzZWN0aW9uLmNvbnN1bWVyLl9uYW1lcy5hdChtYXBwaW5nLm5hbWUpO1xuICAgICAgICAgICAgdGhpcy5fbmFtZXMuYWRkKG5hbWUpO1xuICAgICAgICAgICAgbmFtZSA9IHRoaXMuX25hbWVzLmluZGV4T2YobmFtZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHZhciBhZGp1c3RlZE1hcHBpbmcgPSB7XG4gICAgICAgICAgICBzb3VyY2UsXG4gICAgICAgICAgICBnZW5lcmF0ZWRMaW5lOiBtYXBwaW5nLmdlbmVyYXRlZExpbmUgKyAoc2VjdGlvbi5nZW5lcmF0ZWRPZmZzZXQuZ2VuZXJhdGVkTGluZSAtIDEpLFxuICAgICAgICAgICAgZ2VuZXJhdGVkQ29sdW1uOiBtYXBwaW5nLmdlbmVyYXRlZENvbHVtbiArIChzZWN0aW9uLmdlbmVyYXRlZE9mZnNldC5nZW5lcmF0ZWRMaW5lID09PSBtYXBwaW5nLmdlbmVyYXRlZExpbmUgPyBzZWN0aW9uLmdlbmVyYXRlZE9mZnNldC5nZW5lcmF0ZWRDb2x1bW4gLSAxIDogMCksXG4gICAgICAgICAgICBvcmlnaW5hbExpbmU6IG1hcHBpbmcub3JpZ2luYWxMaW5lLFxuICAgICAgICAgICAgb3JpZ2luYWxDb2x1bW46IG1hcHBpbmcub3JpZ2luYWxDb2x1bW4sXG4gICAgICAgICAgICBuYW1lXG4gICAgICAgICAgfTtcbiAgICAgICAgICB0aGlzLl9fZ2VuZXJhdGVkTWFwcGluZ3MucHVzaChhZGp1c3RlZE1hcHBpbmcpO1xuICAgICAgICAgIGlmICh0eXBlb2YgYWRqdXN0ZWRNYXBwaW5nLm9yaWdpbmFsTGluZSA9PT0gXCJudW1iZXJcIikge1xuICAgICAgICAgICAgdGhpcy5fX29yaWdpbmFsTWFwcGluZ3MucHVzaChhZGp1c3RlZE1hcHBpbmcpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcXVpY2tTb3J0KHRoaXMuX19nZW5lcmF0ZWRNYXBwaW5ncywgdXRpbC5jb21wYXJlQnlHZW5lcmF0ZWRQb3NpdGlvbnNEZWZsYXRlZCk7XG4gICAgICBxdWlja1NvcnQodGhpcy5fX29yaWdpbmFsTWFwcGluZ3MsIHV0aWwuY29tcGFyZUJ5T3JpZ2luYWxQb3NpdGlvbnMpO1xuICAgIH07XG4gICAgZXhwb3J0cy5JbmRleGVkU291cmNlTWFwQ29uc3VtZXIgPSBJbmRleGVkU291cmNlTWFwQ29uc3VtZXI7XG4gIH1cbn0pO1xuXG4vLyBub2RlX21vZHVsZXMvc291cmNlLW1hcC1qcy9saWIvc291cmNlLW5vZGUuanNcbnZhciByZXF1aXJlX3NvdXJjZV9ub2RlID0gX19jb21tb25KUyh7XG4gIFwibm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvbGliL3NvdXJjZS1ub2RlLmpzXCIoZXhwb3J0cykge1xuICAgIHZhciBTb3VyY2VNYXBHZW5lcmF0b3IgPSByZXF1aXJlX3NvdXJjZV9tYXBfZ2VuZXJhdG9yKCkuU291cmNlTWFwR2VuZXJhdG9yO1xuICAgIHZhciB1dGlsID0gcmVxdWlyZV91dGlsKCk7XG4gICAgdmFyIFJFR0VYX05FV0xJTkUgPSAvKFxccj9cXG4pLztcbiAgICB2YXIgTkVXTElORV9DT0RFID0gMTA7XG4gICAgdmFyIGlzU291cmNlTm9kZSA9IFwiJCQkaXNTb3VyY2VOb2RlJCQkXCI7XG4gICAgZnVuY3Rpb24gU291cmNlTm9kZShhTGluZSwgYUNvbHVtbiwgYVNvdXJjZSwgYUNodW5rcywgYU5hbWUpIHtcbiAgICAgIHRoaXMuY2hpbGRyZW4gPSBbXTtcbiAgICAgIHRoaXMuc291cmNlQ29udGVudHMgPSB7fTtcbiAgICAgIHRoaXMubGluZSA9IGFMaW5lID09IG51bGwgPyBudWxsIDogYUxpbmU7XG4gICAgICB0aGlzLmNvbHVtbiA9IGFDb2x1bW4gPT0gbnVsbCA/IG51bGwgOiBhQ29sdW1uO1xuICAgICAgdGhpcy5zb3VyY2UgPSBhU291cmNlID09IG51bGwgPyBudWxsIDogYVNvdXJjZTtcbiAgICAgIHRoaXMubmFtZSA9IGFOYW1lID09IG51bGwgPyBudWxsIDogYU5hbWU7XG4gICAgICB0aGlzW2lzU291cmNlTm9kZV0gPSB0cnVlO1xuICAgICAgaWYgKGFDaHVua3MgIT0gbnVsbClcbiAgICAgICAgdGhpcy5hZGQoYUNodW5rcyk7XG4gICAgfVxuICAgIFNvdXJjZU5vZGUuZnJvbVN0cmluZ1dpdGhTb3VyY2VNYXAgPSBmdW5jdGlvbiBTb3VyY2VOb2RlX2Zyb21TdHJpbmdXaXRoU291cmNlTWFwKGFHZW5lcmF0ZWRDb2RlLCBhU291cmNlTWFwQ29uc3VtZXIsIGFSZWxhdGl2ZVBhdGgpIHtcbiAgICAgIHZhciBub2RlID0gbmV3IFNvdXJjZU5vZGUoKTtcbiAgICAgIHZhciByZW1haW5pbmdMaW5lcyA9IGFHZW5lcmF0ZWRDb2RlLnNwbGl0KFJFR0VYX05FV0xJTkUpO1xuICAgICAgdmFyIHJlbWFpbmluZ0xpbmVzSW5kZXggPSAwO1xuICAgICAgdmFyIHNoaWZ0TmV4dExpbmUgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIGxpbmVDb250ZW50cyA9IGdldE5leHRMaW5lKCk7XG4gICAgICAgIHZhciBuZXdMaW5lID0gZ2V0TmV4dExpbmUoKSB8fCBcIlwiO1xuICAgICAgICByZXR1cm4gbGluZUNvbnRlbnRzICsgbmV3TGluZTtcbiAgICAgICAgZnVuY3Rpb24gZ2V0TmV4dExpbmUoKSB7XG4gICAgICAgICAgcmV0dXJuIHJlbWFpbmluZ0xpbmVzSW5kZXggPCByZW1haW5pbmdMaW5lcy5sZW5ndGggPyByZW1haW5pbmdMaW5lc1tyZW1haW5pbmdMaW5lc0luZGV4KytdIDogdm9pZCAwO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgdmFyIGxhc3RHZW5lcmF0ZWRMaW5lID0gMSwgbGFzdEdlbmVyYXRlZENvbHVtbiA9IDA7XG4gICAgICB2YXIgbGFzdE1hcHBpbmcgPSBudWxsO1xuICAgICAgYVNvdXJjZU1hcENvbnN1bWVyLmVhY2hNYXBwaW5nKGZ1bmN0aW9uKG1hcHBpbmcpIHtcbiAgICAgICAgaWYgKGxhc3RNYXBwaW5nICE9PSBudWxsKSB7XG4gICAgICAgICAgaWYgKGxhc3RHZW5lcmF0ZWRMaW5lIDwgbWFwcGluZy5nZW5lcmF0ZWRMaW5lKSB7XG4gICAgICAgICAgICBhZGRNYXBwaW5nV2l0aENvZGUobGFzdE1hcHBpbmcsIHNoaWZ0TmV4dExpbmUoKSk7XG4gICAgICAgICAgICBsYXN0R2VuZXJhdGVkTGluZSsrO1xuICAgICAgICAgICAgbGFzdEdlbmVyYXRlZENvbHVtbiA9IDA7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHZhciBuZXh0TGluZSA9IHJlbWFpbmluZ0xpbmVzW3JlbWFpbmluZ0xpbmVzSW5kZXhdIHx8IFwiXCI7XG4gICAgICAgICAgICB2YXIgY29kZSA9IG5leHRMaW5lLnN1YnN0cigwLCBtYXBwaW5nLmdlbmVyYXRlZENvbHVtbiAtIGxhc3RHZW5lcmF0ZWRDb2x1bW4pO1xuICAgICAgICAgICAgcmVtYWluaW5nTGluZXNbcmVtYWluaW5nTGluZXNJbmRleF0gPSBuZXh0TGluZS5zdWJzdHIobWFwcGluZy5nZW5lcmF0ZWRDb2x1bW4gLSBsYXN0R2VuZXJhdGVkQ29sdW1uKTtcbiAgICAgICAgICAgIGxhc3RHZW5lcmF0ZWRDb2x1bW4gPSBtYXBwaW5nLmdlbmVyYXRlZENvbHVtbjtcbiAgICAgICAgICAgIGFkZE1hcHBpbmdXaXRoQ29kZShsYXN0TWFwcGluZywgY29kZSk7XG4gICAgICAgICAgICBsYXN0TWFwcGluZyA9IG1hcHBpbmc7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHdoaWxlIChsYXN0R2VuZXJhdGVkTGluZSA8IG1hcHBpbmcuZ2VuZXJhdGVkTGluZSkge1xuICAgICAgICAgIG5vZGUuYWRkKHNoaWZ0TmV4dExpbmUoKSk7XG4gICAgICAgICAgbGFzdEdlbmVyYXRlZExpbmUrKztcbiAgICAgICAgfVxuICAgICAgICBpZiAobGFzdEdlbmVyYXRlZENvbHVtbiA8IG1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uKSB7XG4gICAgICAgICAgdmFyIG5leHRMaW5lID0gcmVtYWluaW5nTGluZXNbcmVtYWluaW5nTGluZXNJbmRleF0gfHwgXCJcIjtcbiAgICAgICAgICBub2RlLmFkZChuZXh0TGluZS5zdWJzdHIoMCwgbWFwcGluZy5nZW5lcmF0ZWRDb2x1bW4pKTtcbiAgICAgICAgICByZW1haW5pbmdMaW5lc1tyZW1haW5pbmdMaW5lc0luZGV4XSA9IG5leHRMaW5lLnN1YnN0cihtYXBwaW5nLmdlbmVyYXRlZENvbHVtbik7XG4gICAgICAgICAgbGFzdEdlbmVyYXRlZENvbHVtbiA9IG1hcHBpbmcuZ2VuZXJhdGVkQ29sdW1uO1xuICAgICAgICB9XG4gICAgICAgIGxhc3RNYXBwaW5nID0gbWFwcGluZztcbiAgICAgIH0sIHRoaXMpO1xuICAgICAgaWYgKHJlbWFpbmluZ0xpbmVzSW5kZXggPCByZW1haW5pbmdMaW5lcy5sZW5ndGgpIHtcbiAgICAgICAgaWYgKGxhc3RNYXBwaW5nKSB7XG4gICAgICAgICAgYWRkTWFwcGluZ1dpdGhDb2RlKGxhc3RNYXBwaW5nLCBzaGlmdE5leHRMaW5lKCkpO1xuICAgICAgICB9XG4gICAgICAgIG5vZGUuYWRkKHJlbWFpbmluZ0xpbmVzLnNwbGljZShyZW1haW5pbmdMaW5lc0luZGV4KS5qb2luKFwiXCIpKTtcbiAgICAgIH1cbiAgICAgIGFTb3VyY2VNYXBDb25zdW1lci5zb3VyY2VzLmZvckVhY2goZnVuY3Rpb24oc291cmNlRmlsZSkge1xuICAgICAgICB2YXIgY29udGVudCA9IGFTb3VyY2VNYXBDb25zdW1lci5zb3VyY2VDb250ZW50Rm9yKHNvdXJjZUZpbGUpO1xuICAgICAgICBpZiAoY29udGVudCAhPSBudWxsKSB7XG4gICAgICAgICAgaWYgKGFSZWxhdGl2ZVBhdGggIT0gbnVsbCkge1xuICAgICAgICAgICAgc291cmNlRmlsZSA9IHV0aWwuam9pbihhUmVsYXRpdmVQYXRoLCBzb3VyY2VGaWxlKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgbm9kZS5zZXRTb3VyY2VDb250ZW50KHNvdXJjZUZpbGUsIGNvbnRlbnQpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHJldHVybiBub2RlO1xuICAgICAgZnVuY3Rpb24gYWRkTWFwcGluZ1dpdGhDb2RlKG1hcHBpbmcsIGNvZGUpIHtcbiAgICAgICAgaWYgKG1hcHBpbmcgPT09IG51bGwgfHwgbWFwcGluZy5zb3VyY2UgPT09IHZvaWQgMCkge1xuICAgICAgICAgIG5vZGUuYWRkKGNvZGUpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHZhciBzb3VyY2UgPSBhUmVsYXRpdmVQYXRoID8gdXRpbC5qb2luKGFSZWxhdGl2ZVBhdGgsIG1hcHBpbmcuc291cmNlKSA6IG1hcHBpbmcuc291cmNlO1xuICAgICAgICAgIG5vZGUuYWRkKG5ldyBTb3VyY2VOb2RlKFxuICAgICAgICAgICAgbWFwcGluZy5vcmlnaW5hbExpbmUsXG4gICAgICAgICAgICBtYXBwaW5nLm9yaWdpbmFsQ29sdW1uLFxuICAgICAgICAgICAgc291cmNlLFxuICAgICAgICAgICAgY29kZSxcbiAgICAgICAgICAgIG1hcHBpbmcubmFtZVxuICAgICAgICAgICkpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcbiAgICBTb3VyY2VOb2RlLnByb3RvdHlwZS5hZGQgPSBmdW5jdGlvbiBTb3VyY2VOb2RlX2FkZChhQ2h1bmspIHtcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGFDaHVuaykpIHtcbiAgICAgICAgYUNodW5rLmZvckVhY2goZnVuY3Rpb24oY2h1bmspIHtcbiAgICAgICAgICB0aGlzLmFkZChjaHVuayk7XG4gICAgICAgIH0sIHRoaXMpO1xuICAgICAgfSBlbHNlIGlmIChhQ2h1bmtbaXNTb3VyY2VOb2RlXSB8fCB0eXBlb2YgYUNodW5rID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIGlmIChhQ2h1bmspIHtcbiAgICAgICAgICB0aGlzLmNoaWxkcmVuLnB1c2goYUNodW5rKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcbiAgICAgICAgICBcIkV4cGVjdGVkIGEgU291cmNlTm9kZSwgc3RyaW5nLCBvciBhbiBhcnJheSBvZiBTb3VyY2VOb2RlcyBhbmQgc3RyaW5ncy4gR290IFwiICsgYUNodW5rXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9O1xuICAgIFNvdXJjZU5vZGUucHJvdG90eXBlLnByZXBlbmQgPSBmdW5jdGlvbiBTb3VyY2VOb2RlX3ByZXBlbmQoYUNodW5rKSB7XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShhQ2h1bmspKSB7XG4gICAgICAgIGZvciAodmFyIGkgPSBhQ2h1bmsubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgICB0aGlzLnByZXBlbmQoYUNodW5rW2ldKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChhQ2h1bmtbaXNTb3VyY2VOb2RlXSB8fCB0eXBlb2YgYUNodW5rID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHRoaXMuY2hpbGRyZW4udW5zaGlmdChhQ2h1bmspO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcbiAgICAgICAgICBcIkV4cGVjdGVkIGEgU291cmNlTm9kZSwgc3RyaW5nLCBvciBhbiBhcnJheSBvZiBTb3VyY2VOb2RlcyBhbmQgc3RyaW5ncy4gR290IFwiICsgYUNodW5rXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9O1xuICAgIFNvdXJjZU5vZGUucHJvdG90eXBlLndhbGsgPSBmdW5jdGlvbiBTb3VyY2VOb2RlX3dhbGsoYUZuKSB7XG4gICAgICB2YXIgY2h1bms7XG4gICAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gdGhpcy5jaGlsZHJlbi5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgICBjaHVuayA9IHRoaXMuY2hpbGRyZW5baV07XG4gICAgICAgIGlmIChjaHVua1tpc1NvdXJjZU5vZGVdKSB7XG4gICAgICAgICAgY2h1bmsud2FsayhhRm4pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGlmIChjaHVuayAhPT0gXCJcIikge1xuICAgICAgICAgICAgYUZuKGNodW5rLCB7XG4gICAgICAgICAgICAgIHNvdXJjZTogdGhpcy5zb3VyY2UsXG4gICAgICAgICAgICAgIGxpbmU6IHRoaXMubGluZSxcbiAgICAgICAgICAgICAgY29sdW1uOiB0aGlzLmNvbHVtbixcbiAgICAgICAgICAgICAgbmFtZTogdGhpcy5uYW1lXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICAgIFNvdXJjZU5vZGUucHJvdG90eXBlLmpvaW4gPSBmdW5jdGlvbiBTb3VyY2VOb2RlX2pvaW4oYVNlcCkge1xuICAgICAgdmFyIG5ld0NoaWxkcmVuO1xuICAgICAgdmFyIGk7XG4gICAgICB2YXIgbGVuID0gdGhpcy5jaGlsZHJlbi5sZW5ndGg7XG4gICAgICBpZiAobGVuID4gMCkge1xuICAgICAgICBuZXdDaGlsZHJlbiA9IFtdO1xuICAgICAgICBmb3IgKGkgPSAwOyBpIDwgbGVuIC0gMTsgaSsrKSB7XG4gICAgICAgICAgbmV3Q2hpbGRyZW4ucHVzaCh0aGlzLmNoaWxkcmVuW2ldKTtcbiAgICAgICAgICBuZXdDaGlsZHJlbi5wdXNoKGFTZXApO1xuICAgICAgICB9XG4gICAgICAgIG5ld0NoaWxkcmVuLnB1c2godGhpcy5jaGlsZHJlbltpXSk7XG4gICAgICAgIHRoaXMuY2hpbGRyZW4gPSBuZXdDaGlsZHJlbjtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH07XG4gICAgU291cmNlTm9kZS5wcm90b3R5cGUucmVwbGFjZVJpZ2h0ID0gZnVuY3Rpb24gU291cmNlTm9kZV9yZXBsYWNlUmlnaHQoYVBhdHRlcm4sIGFSZXBsYWNlbWVudCkge1xuICAgICAgdmFyIGxhc3RDaGlsZCA9IHRoaXMuY2hpbGRyZW5bdGhpcy5jaGlsZHJlbi5sZW5ndGggLSAxXTtcbiAgICAgIGlmIChsYXN0Q2hpbGRbaXNTb3VyY2VOb2RlXSkge1xuICAgICAgICBsYXN0Q2hpbGQucmVwbGFjZVJpZ2h0KGFQYXR0ZXJuLCBhUmVwbGFjZW1lbnQpO1xuICAgICAgfSBlbHNlIGlmICh0eXBlb2YgbGFzdENoaWxkID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHRoaXMuY2hpbGRyZW5bdGhpcy5jaGlsZHJlbi5sZW5ndGggLSAxXSA9IGxhc3RDaGlsZC5yZXBsYWNlKGFQYXR0ZXJuLCBhUmVwbGFjZW1lbnQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5jaGlsZHJlbi5wdXNoKFwiXCIucmVwbGFjZShhUGF0dGVybiwgYVJlcGxhY2VtZW50KSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9O1xuICAgIFNvdXJjZU5vZGUucHJvdG90eXBlLnNldFNvdXJjZUNvbnRlbnQgPSBmdW5jdGlvbiBTb3VyY2VOb2RlX3NldFNvdXJjZUNvbnRlbnQoYVNvdXJjZUZpbGUsIGFTb3VyY2VDb250ZW50KSB7XG4gICAgICB0aGlzLnNvdXJjZUNvbnRlbnRzW3V0aWwudG9TZXRTdHJpbmcoYVNvdXJjZUZpbGUpXSA9IGFTb3VyY2VDb250ZW50O1xuICAgIH07XG4gICAgU291cmNlTm9kZS5wcm90b3R5cGUud2Fsa1NvdXJjZUNvbnRlbnRzID0gZnVuY3Rpb24gU291cmNlTm9kZV93YWxrU291cmNlQ29udGVudHMoYUZuKSB7XG4gICAgICBmb3IgKHZhciBpID0gMCwgbGVuID0gdGhpcy5jaGlsZHJlbi5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgICBpZiAodGhpcy5jaGlsZHJlbltpXVtpc1NvdXJjZU5vZGVdKSB7XG4gICAgICAgICAgdGhpcy5jaGlsZHJlbltpXS53YWxrU291cmNlQ29udGVudHMoYUZuKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdmFyIHNvdXJjZXMgPSBPYmplY3Qua2V5cyh0aGlzLnNvdXJjZUNvbnRlbnRzKTtcbiAgICAgIGZvciAodmFyIGkgPSAwLCBsZW4gPSBzb3VyY2VzLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgIGFGbih1dGlsLmZyb21TZXRTdHJpbmcoc291cmNlc1tpXSksIHRoaXMuc291cmNlQ29udGVudHNbc291cmNlc1tpXV0pO1xuICAgICAgfVxuICAgIH07XG4gICAgU291cmNlTm9kZS5wcm90b3R5cGUudG9TdHJpbmcgPSBmdW5jdGlvbiBTb3VyY2VOb2RlX3RvU3RyaW5nKCkge1xuICAgICAgdmFyIHN0ciA9IFwiXCI7XG4gICAgICB0aGlzLndhbGsoZnVuY3Rpb24oY2h1bmspIHtcbiAgICAgICAgc3RyICs9IGNodW5rO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gc3RyO1xuICAgIH07XG4gICAgU291cmNlTm9kZS5wcm90b3R5cGUudG9TdHJpbmdXaXRoU291cmNlTWFwID0gZnVuY3Rpb24gU291cmNlTm9kZV90b1N0cmluZ1dpdGhTb3VyY2VNYXAoYUFyZ3MpIHtcbiAgICAgIHZhciBnZW5lcmF0ZWQgPSB7XG4gICAgICAgIGNvZGU6IFwiXCIsXG4gICAgICAgIGxpbmU6IDEsXG4gICAgICAgIGNvbHVtbjogMFxuICAgICAgfTtcbiAgICAgIHZhciBtYXAgPSBuZXcgU291cmNlTWFwR2VuZXJhdG9yKGFBcmdzKTtcbiAgICAgIHZhciBzb3VyY2VNYXBwaW5nQWN0aXZlID0gZmFsc2U7XG4gICAgICB2YXIgbGFzdE9yaWdpbmFsU291cmNlID0gbnVsbDtcbiAgICAgIHZhciBsYXN0T3JpZ2luYWxMaW5lID0gbnVsbDtcbiAgICAgIHZhciBsYXN0T3JpZ2luYWxDb2x1bW4gPSBudWxsO1xuICAgICAgdmFyIGxhc3RPcmlnaW5hbE5hbWUgPSBudWxsO1xuICAgICAgdGhpcy53YWxrKGZ1bmN0aW9uKGNodW5rLCBvcmlnaW5hbCkge1xuICAgICAgICBnZW5lcmF0ZWQuY29kZSArPSBjaHVuaztcbiAgICAgICAgaWYgKG9yaWdpbmFsLnNvdXJjZSAhPT0gbnVsbCAmJiBvcmlnaW5hbC5saW5lICE9PSBudWxsICYmIG9yaWdpbmFsLmNvbHVtbiAhPT0gbnVsbCkge1xuICAgICAgICAgIGlmIChsYXN0T3JpZ2luYWxTb3VyY2UgIT09IG9yaWdpbmFsLnNvdXJjZSB8fCBsYXN0T3JpZ2luYWxMaW5lICE9PSBvcmlnaW5hbC5saW5lIHx8IGxhc3RPcmlnaW5hbENvbHVtbiAhPT0gb3JpZ2luYWwuY29sdW1uIHx8IGxhc3RPcmlnaW5hbE5hbWUgIT09IG9yaWdpbmFsLm5hbWUpIHtcbiAgICAgICAgICAgIG1hcC5hZGRNYXBwaW5nKHtcbiAgICAgICAgICAgICAgc291cmNlOiBvcmlnaW5hbC5zb3VyY2UsXG4gICAgICAgICAgICAgIG9yaWdpbmFsOiB7XG4gICAgICAgICAgICAgICAgbGluZTogb3JpZ2luYWwubGluZSxcbiAgICAgICAgICAgICAgICBjb2x1bW46IG9yaWdpbmFsLmNvbHVtblxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBnZW5lcmF0ZWQ6IHtcbiAgICAgICAgICAgICAgICBsaW5lOiBnZW5lcmF0ZWQubGluZSxcbiAgICAgICAgICAgICAgICBjb2x1bW46IGdlbmVyYXRlZC5jb2x1bW5cbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgbmFtZTogb3JpZ2luYWwubmFtZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGxhc3RPcmlnaW5hbFNvdXJjZSA9IG9yaWdpbmFsLnNvdXJjZTtcbiAgICAgICAgICBsYXN0T3JpZ2luYWxMaW5lID0gb3JpZ2luYWwubGluZTtcbiAgICAgICAgICBsYXN0T3JpZ2luYWxDb2x1bW4gPSBvcmlnaW5hbC5jb2x1bW47XG4gICAgICAgICAgbGFzdE9yaWdpbmFsTmFtZSA9IG9yaWdpbmFsLm5hbWU7XG4gICAgICAgICAgc291cmNlTWFwcGluZ0FjdGl2ZSA9IHRydWU7XG4gICAgICAgIH0gZWxzZSBpZiAoc291cmNlTWFwcGluZ0FjdGl2ZSkge1xuICAgICAgICAgIG1hcC5hZGRNYXBwaW5nKHtcbiAgICAgICAgICAgIGdlbmVyYXRlZDoge1xuICAgICAgICAgICAgICBsaW5lOiBnZW5lcmF0ZWQubGluZSxcbiAgICAgICAgICAgICAgY29sdW1uOiBnZW5lcmF0ZWQuY29sdW1uXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgbGFzdE9yaWdpbmFsU291cmNlID0gbnVsbDtcbiAgICAgICAgICBzb3VyY2VNYXBwaW5nQWN0aXZlID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgZm9yICh2YXIgaWR4ID0gMCwgbGVuZ3RoID0gY2h1bmsubGVuZ3RoOyBpZHggPCBsZW5ndGg7IGlkeCsrKSB7XG4gICAgICAgICAgaWYgKGNodW5rLmNoYXJDb2RlQXQoaWR4KSA9PT0gTkVXTElORV9DT0RFKSB7XG4gICAgICAgICAgICBnZW5lcmF0ZWQubGluZSsrO1xuICAgICAgICAgICAgZ2VuZXJhdGVkLmNvbHVtbiA9IDA7XG4gICAgICAgICAgICBpZiAoaWR4ICsgMSA9PT0gbGVuZ3RoKSB7XG4gICAgICAgICAgICAgIGxhc3RPcmlnaW5hbFNvdXJjZSA9IG51bGw7XG4gICAgICAgICAgICAgIHNvdXJjZU1hcHBpbmdBY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoc291cmNlTWFwcGluZ0FjdGl2ZSkge1xuICAgICAgICAgICAgICBtYXAuYWRkTWFwcGluZyh7XG4gICAgICAgICAgICAgICAgc291cmNlOiBvcmlnaW5hbC5zb3VyY2UsXG4gICAgICAgICAgICAgICAgb3JpZ2luYWw6IHtcbiAgICAgICAgICAgICAgICAgIGxpbmU6IG9yaWdpbmFsLmxpbmUsXG4gICAgICAgICAgICAgICAgICBjb2x1bW46IG9yaWdpbmFsLmNvbHVtblxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgZ2VuZXJhdGVkOiB7XG4gICAgICAgICAgICAgICAgICBsaW5lOiBnZW5lcmF0ZWQubGluZSxcbiAgICAgICAgICAgICAgICAgIGNvbHVtbjogZ2VuZXJhdGVkLmNvbHVtblxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgbmFtZTogb3JpZ2luYWwubmFtZVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZ2VuZXJhdGVkLmNvbHVtbisrO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICB0aGlzLndhbGtTb3VyY2VDb250ZW50cyhmdW5jdGlvbihzb3VyY2VGaWxlLCBzb3VyY2VDb250ZW50KSB7XG4gICAgICAgIG1hcC5zZXRTb3VyY2VDb250ZW50KHNvdXJjZUZpbGUsIHNvdXJjZUNvbnRlbnQpO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4geyBjb2RlOiBnZW5lcmF0ZWQuY29kZSwgbWFwIH07XG4gICAgfTtcbiAgICBleHBvcnRzLlNvdXJjZU5vZGUgPSBTb3VyY2VOb2RlO1xuICB9XG59KTtcblxuLy8gbm9kZV9tb2R1bGVzL3NvdXJjZS1tYXAtanMvc291cmNlLW1hcC5qc1xudmFyIHJlcXVpcmVfc291cmNlX21hcCA9IF9fY29tbW9uSlMoe1xuICBcIm5vZGVfbW9kdWxlcy9zb3VyY2UtbWFwLWpzL3NvdXJjZS1tYXAuanNcIihleHBvcnRzKSB7XG4gICAgZXhwb3J0cy5Tb3VyY2VNYXBHZW5lcmF0b3IgPSByZXF1aXJlX3NvdXJjZV9tYXBfZ2VuZXJhdG9yKCkuU291cmNlTWFwR2VuZXJhdG9yO1xuICAgIGV4cG9ydHMuU291cmNlTWFwQ29uc3VtZXIgPSByZXF1aXJlX3NvdXJjZV9tYXBfY29uc3VtZXIoKS5Tb3VyY2VNYXBDb25zdW1lcjtcbiAgICBleHBvcnRzLlNvdXJjZU5vZGUgPSByZXF1aXJlX3NvdXJjZV9ub2RlKCkuU291cmNlTm9kZTtcbiAgfVxufSk7XG5cbi8vIHNyYy93ZWJ2aWV3LnRzXG52YXIgaW1wb3J0X3NvdXJjZV9tYXBfanMgPSBfX3RvRVNNKHJlcXVpcmVfc291cmNlX21hcCgpLCAxKTtcbmFzeW5jIGZ1bmN0aW9uIGZldGNoQ2FsbChwYXRoQ29tcG9uZW50cywgLi4uYXJncykge1xuICBjb25zdCB1cmwgPSBuZXcgVVJMKHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4pO1xuICB1cmwucGF0aG5hbWUgPSBwYXRoQ29tcG9uZW50cy5qb2luKFwiL1wiKTtcbiAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwudG9TdHJpbmcoKSwge1xuICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgYm9keTogSlNPTi5zdHJpbmdpZnkoYXJncylcbiAgfSk7XG4gIHJldHVybiByZXNwb25zZS5oZWFkZXJzLmdldChcImNvbnRlbnQtdHlwZVwiKT8uc3RhcnRzV2l0aChcImFwcGxpY2F0aW9uL2pzb25cIikgPyByZXNwb25zZS5qc29uKCkgOiByZXNwb25zZS50ZXh0KCk7XG59XG5mdW5jdGlvbiByZWN1cnNlSW5Qcm94eSh0YXJnZXQsIHBhdGhDb21wb25lbnRzID0gW10pIHtcbiAgcmV0dXJuIG5ldyBQcm94eSh0YXJnZXQsIHtcbiAgICBhcHBseTogKHRhcmdldDIsIF8sIGFyZ0FycmF5KSA9PiB7XG4gICAgICByZXR1cm4gdGFyZ2V0MihwYXRoQ29tcG9uZW50cywgLi4uYXJnQXJyYXkpO1xuICAgIH0sXG4gICAgZ2V0OiAoXywgcCkgPT4ge1xuICAgICAgcGF0aENvbXBvbmVudHMucHVzaChwKTtcbiAgICAgIHJldHVybiByZWN1cnNlSW5Qcm94eSh0YXJnZXQsIHBhdGhDb21wb25lbnRzKTtcbiAgICB9XG4gIH0pO1xufVxuZnVuY3Rpb24gcnBjKCkge1xuICByZXR1cm4gcmVjdXJzZUluUHJveHkoZmV0Y2hDYWxsKTtcbn1cbndpbmRvdy5ycGMgPSBycGM7XG53aW5kb3cub25QdXNoID0ge307XG53aW5kb3cucHVzaCA9IChtZXNzYWdlVHlwZSwgbWVzc2FnZSkgPT4ge1xuICBjb25zdCBjYWxsYmFjayA9IHdpbmRvdy5vblB1c2hbbWVzc2FnZVR5cGVdO1xuICBpZiAoIWNhbGxiYWNrKVxuICAgIHRocm93IGBObyBvblB1c2ggY2FsbGJhY2sgZm9yIG1lc3NhZ2UgdHlwZSBbJHttZXNzYWdlVHlwZX1dLiBSZWNlaXZlZCBtZXNzYWdlIFske21lc3NhZ2V9XWA7XG4gIGNhbGxiYWNrKG1lc3NhZ2UpO1xufTtcbnZhciBwbGF0Zm9ybSA9IGF3YWl0IHJwYygpLnBsYXRmb3JtKCk7XG5pZiAocGxhdGZvcm0gPT09IFwibm9kZVwiKSB7XG4gIGNvbnN0IHVybCA9ICh3aW5kb3cubG9jYXRpb24ucHJvdG9jb2wgPT09IFwiaHR0cDpcIiA/IFwid3M6XCIgOiBcIndzczpcIikgKyBcIi8vXCIgKyB3aW5kb3cubG9jYXRpb24uaG9zdDtcbiAgY29uc3Qgd3MgPSBuZXcgV2ViU29ja2V0KHVybCk7XG4gIHdzLm9ubWVzc2FnZSA9ICh7IGRhdGEgfSkgPT4ge1xuICAgIGNvbnN0IHsgbWVzc2FnZVR5cGUsIG1lc3NhZ2UgfSA9IEpTT04ucGFyc2UoZGF0YSk7XG4gICAgd2luZG93LnB1c2gobWVzc2FnZVR5cGUsIG1lc3NhZ2UpO1xuICB9O1xufVxud2luZG93LnNvdXJjZU1hcENvbnN1bWVyID0gaW1wb3J0X3NvdXJjZV9tYXBfanMuU291cmNlTWFwQ29uc3VtZXI7XG5leHBvcnQge1xuICBycGMgYXMgZGVmYXVsdFxufTtcblxuaW1wb3J0KFwiL1VzZXJzL2NwbGVwYWdlL0Rlc2t0b3AvRGVtby93ZWJ2aWV3L2luZGV4LmpzXCIpOyJdLAogICJtYXBwaW5ncyI6ICI7Ozs7OztBQUFBO0FBQUE7QUFBQSxhQUFTLGlCQUFpQixPQUFPLEVBQUUsUUFBUSxPQUFNLFNBQVE7QUFDdkQsWUFBTSxXQUFXLE1BQU0sS0FBSyxLQUFLLFVBQVUsT0FBTyxDQUFDLEVBQUUsT0FBTyxlQUFhLGNBQWMsTUFBTSxFQUFFLEdBQUcsQ0FBQztBQUNuRyxXQUFLLFlBQVksT0FBTyxNQUFNLE1BQU0seUJBQXlCLFFBQVEsTUFBTSxHQUFHLEtBQUs7QUFBQSxJQUNyRixDQUFDO0FBQUE7QUFBQTs7O0FDSEQsSUFBTSxhQUVBO0FBRk47QUFBQTtBQUFBLElBQU0sY0FBYyxTQUFTLGNBQWMscUJBQXFCO0FBRWhFLElBQU0sWUFBWSxDQUFDLENBQUMsU0FBUyxNQUFNLElBQUksRUFBRSxNQUFNLE9BQU8sQ0FBQztBQUN2RCxRQUFHLFdBQVU7QUFDWCxlQUFTLGdCQUFnQixVQUFVLElBQUksTUFBTTtBQUM3QyxrQkFBWSxVQUFVO0FBQUEsSUFDeEI7QUFFQSxnQkFBWSxpQkFBaUIsVUFBVSxPQUFLO0FBQzFDLFlBQU0sU0FBUyxDQUFDLEVBQUUsY0FBYztBQUNoQyxVQUFHLFFBQU87QUFDUixpQkFBUyxnQkFBZ0IsVUFBVSxJQUFJLE1BQU07QUFBQSxNQUMvQyxPQUFPO0FBQ0wsaUJBQVMsZ0JBQWdCLFVBQVUsT0FBTyxNQUFNO0FBQUEsTUFDbEQ7QUFFQSxVQUFJLEVBQUUsTUFBTSxTQUFTLFNBQVMsTUFBTSxHQUFHO0FBQUEsSUFDekMsQ0FBQztBQUFBO0FBQUE7OztBQ2pCTSxTQUFTLFVBQVUsUUFBUTtBQUNoQyxRQUFNLFFBQVEsS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLE9BQU8sTUFBTTtBQUN0RCxVQUFRLElBQUksT0FBTyxLQUFLLENBQUM7QUFDM0I7QUFIQTtBQUFBO0FBQUE7QUFBQTs7O0FDQUEsSUFFTSxXQUNFLEtBQUssS0FBSyxPQUVkLE9BR0UsYUE2QkE7QUFyQ047QUFBQTtBQUFBO0FBRUEsSUFBTSxZQUFZLFNBQVMsY0FBYyxzQkFBc0I7QUFDL0QsSUFBTSxDQUFFLEtBQUssS0FBSyxTQUFVLFNBQVMsaUJBQWlCLGlCQUFpQjtBQUV2RSxJQUFJLFFBQVEsU0FBUyxNQUFNLElBQUksRUFBRSxNQUFNLEtBQUssQ0FBQztBQUM3QyxjQUFVLFlBQVksTUFBTSxTQUFTO0FBRXJDLElBQU0sY0FBYyxNQUFNO0FBQ3hCLGdCQUFVLFlBQVksTUFBTSxTQUFTO0FBQ3JDLFVBQUcsQ0FBQyxPQUFNO0FBQ1IsWUFBSSxFQUFFLE1BQU0sTUFBTTtBQUFBLE1BQ3BCLE9BQU87QUFDTCxZQUFJLEVBQUUsTUFBTSxLQUFLLE1BQU0sU0FBUyxDQUFDO0FBQUEsTUFDbkM7QUFFQSxVQUFHLFFBQVEsTUFBTSxHQUFHO0FBQ2xCLGtCQUFVLGFBQWE7QUFBQSxNQUN6QjtBQUFBLElBQ0Y7QUFFQSxRQUFJLGlCQUFpQixTQUFTLE1BQU07QUFDbEM7QUFDQSxrQkFBWTtBQUFBLElBQ2QsQ0FBQztBQUVELFFBQUksaUJBQWlCLFNBQVMsTUFBTTtBQUNsQztBQUNBLGtCQUFZO0FBQUEsSUFDZCxDQUFDO0FBRUQsVUFBTSxpQkFBaUIsU0FBUyxNQUFNO0FBQ3BDLGNBQVE7QUFDUixrQkFBWTtBQUFBLElBQ2QsQ0FBQztBQUdELElBQU0sZ0JBQWdCO0FBQUEsTUFDcEI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUE7QUFBQTs7O0FDM0VBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7OztBQ0ZBLElBQUksV0FBVyxPQUFPO0FBQ3RCLElBQUksWUFBWSxPQUFPO0FBQ3ZCLElBQUksbUJBQW1CLE9BQU87QUFDOUIsSUFBSUEscUJBQW9CLE9BQU87QUFDL0IsSUFBSSxlQUFlLE9BQU87QUFDMUIsSUFBSSxlQUFlLE9BQU8sVUFBVTtBQUNwQyxJQUFJLGFBQWEsQ0FBQyxJQUFJLFFBQVEsU0FBUyxZQUFZO0FBQ2pELFNBQU8sUUFBUSxHQUFHLEdBQUdBLG1CQUFrQixFQUFFLEVBQUUsQ0FBQyxDQUFDLElBQUksTUFBTSxFQUFFLFNBQVMsQ0FBQyxFQUFFLEdBQUcsU0FBUyxHQUFHLEdBQUcsSUFBSTtBQUM3RjtBQUNBLElBQUksY0FBYyxDQUFDLElBQUksTUFBTSxRQUFRLFNBQVM7QUFDNUMsTUFBSSxRQUFRLE9BQU8sU0FBUyxZQUFZLE9BQU8sU0FBUyxZQUFZO0FBQ2xFLGFBQVMsT0FBT0EsbUJBQWtCLElBQUk7QUFDcEMsVUFBSSxDQUFDLGFBQWEsS0FBSyxJQUFJLEdBQUcsS0FBSyxRQUFRO0FBQ3pDLGtCQUFVLElBQUksS0FBSyxFQUFFLEtBQUssTUFBTSxLQUFLLEdBQUcsR0FBRyxZQUFZLEVBQUUsT0FBTyxpQkFBaUIsTUFBTSxHQUFHLE1BQU0sS0FBSyxXQUFXLENBQUM7QUFBQSxFQUN2SDtBQUNBLFNBQU87QUFDVDtBQUNBLElBQUksVUFBVSxDQUFDLEtBQUssWUFBWSxZQUFZLFNBQVMsT0FBTyxPQUFPLFNBQVMsYUFBYSxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS25HLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxhQUFhLFVBQVUsUUFBUSxXQUFXLEVBQUUsT0FBTyxLQUFLLFlBQVksS0FBSyxDQUFDLElBQUk7QUFBQSxFQUN6RztBQUNGO0FBR0EsSUFBSSxpQkFBaUIsV0FBVztBQUFBLEVBQzlCLDJDQUEyQyxTQUFTO0FBQ2xELFFBQUksZUFBZSxtRUFBbUUsTUFBTSxFQUFFO0FBQzlGLFlBQVEsU0FBUyxTQUFTLFFBQVE7QUFDaEMsVUFBSSxLQUFLLFVBQVUsU0FBUyxhQUFhLFFBQVE7QUFDL0MsZUFBTyxhQUFhLE1BQU07QUFBQSxNQUM1QjtBQUNBLFlBQU0sSUFBSSxVQUFVLCtCQUErQixNQUFNO0FBQUEsSUFDM0Q7QUFDQSxZQUFRLFNBQVMsU0FBUyxVQUFVO0FBQ2xDLFVBQUksT0FBTztBQUNYLFVBQUksT0FBTztBQUNYLFVBQUksVUFBVTtBQUNkLFVBQUksVUFBVTtBQUNkLFVBQUksT0FBTztBQUNYLFVBQUksT0FBTztBQUNYLFVBQUksT0FBTztBQUNYLFVBQUksUUFBUTtBQUNaLFVBQUksZUFBZTtBQUNuQixVQUFJLGVBQWU7QUFDbkIsVUFBSSxRQUFRLFlBQVksWUFBWSxNQUFNO0FBQ3hDLGVBQU8sV0FBVztBQUFBLE1BQ3BCO0FBQ0EsVUFBSSxXQUFXLFlBQVksWUFBWSxTQUFTO0FBQzlDLGVBQU8sV0FBVyxVQUFVO0FBQUEsTUFDOUI7QUFDQSxVQUFJLFFBQVEsWUFBWSxZQUFZLE1BQU07QUFDeEMsZUFBTyxXQUFXLE9BQU87QUFBQSxNQUMzQjtBQUNBLFVBQUksWUFBWSxNQUFNO0FBQ3BCLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxZQUFZLE9BQU87QUFDckIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBR0QsSUFBSSxxQkFBcUIsV0FBVztBQUFBLEVBQ2xDLCtDQUErQyxTQUFTO0FBQ3RELFFBQUksU0FBUyxlQUFlO0FBQzVCLFFBQUksaUJBQWlCO0FBQ3JCLFFBQUksV0FBVyxLQUFLO0FBQ3BCLFFBQUksZ0JBQWdCLFdBQVc7QUFDL0IsUUFBSSx1QkFBdUI7QUFDM0IsYUFBUyxZQUFZLFFBQVE7QUFDM0IsYUFBTyxTQUFTLEtBQUssQ0FBQyxVQUFVLEtBQUssS0FBSyxVQUFVLEtBQUs7QUFBQSxJQUMzRDtBQUNBLGFBQVMsY0FBYyxRQUFRO0FBQzdCLFVBQUksY0FBYyxTQUFTLE9BQU87QUFDbEMsVUFBSSxVQUFVLFVBQVU7QUFDeEIsYUFBTyxhQUFhLENBQUMsVUFBVTtBQUFBLElBQ2pDO0FBQ0EsWUFBUSxTQUFTLFNBQVMsaUJBQWlCLFFBQVE7QUFDakQsVUFBSSxVQUFVO0FBQ2QsVUFBSTtBQUNKLFVBQUksTUFBTSxZQUFZLE1BQU07QUFDNUIsU0FBRztBQUNELGdCQUFRLE1BQU07QUFDZCxpQkFBUztBQUNULFlBQUksTUFBTSxHQUFHO0FBQ1gsbUJBQVM7QUFBQSxRQUNYO0FBQ0EsbUJBQVcsT0FBTyxPQUFPLEtBQUs7QUFBQSxNQUNoQyxTQUFTLE1BQU07QUFDZixhQUFPO0FBQUEsSUFDVDtBQUNBLFlBQVEsU0FBUyxTQUFTLGlCQUFpQixNQUFNLFFBQVEsV0FBVztBQUNsRSxVQUFJLFNBQVMsS0FBSztBQUNsQixVQUFJLFNBQVM7QUFDYixVQUFJLFFBQVE7QUFDWixVQUFJLGNBQWM7QUFDbEIsU0FBRztBQUNELFlBQUksVUFBVSxRQUFRO0FBQ3BCLGdCQUFNLElBQUksTUFBTSw0Q0FBNEM7QUFBQSxRQUM5RDtBQUNBLGdCQUFRLE9BQU8sT0FBTyxLQUFLLFdBQVcsUUFBUSxDQUFDO0FBQy9DLFlBQUksVUFBVSxJQUFJO0FBQ2hCLGdCQUFNLElBQUksTUFBTSwyQkFBMkIsS0FBSyxPQUFPLFNBQVMsQ0FBQyxDQUFDO0FBQUEsUUFDcEU7QUFDQSx1QkFBZSxDQUFDLEVBQUUsUUFBUTtBQUMxQixpQkFBUztBQUNULGlCQUFTLFVBQVUsU0FBUztBQUM1QixpQkFBUztBQUFBLE1BQ1gsU0FBUztBQUNULGdCQUFVLFFBQVEsY0FBYyxNQUFNO0FBQ3RDLGdCQUFVLE9BQU87QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFDRixDQUFDO0FBR0QsSUFBSSxlQUFlLFdBQVc7QUFBQSxFQUM1Qix5Q0FBeUMsU0FBUztBQUNoRCxhQUFTLE9BQU8sT0FBTyxPQUFPLGVBQWU7QUFDM0MsVUFBSSxTQUFTLE9BQU87QUFDbEIsZUFBTyxNQUFNLEtBQUs7QUFBQSxNQUNwQixXQUFXLFVBQVUsV0FBVyxHQUFHO0FBQ2pDLGVBQU87QUFBQSxNQUNULE9BQU87QUFDTCxjQUFNLElBQUksTUFBTSxNQUFNLFFBQVEsMkJBQTJCO0FBQUEsTUFDM0Q7QUFBQSxJQUNGO0FBQ0EsWUFBUSxTQUFTO0FBQ2pCLFFBQUksWUFBWTtBQUNoQixRQUFJLGdCQUFnQjtBQUNwQixhQUFTLFNBQVMsTUFBTTtBQUN0QixVQUFJLFFBQVEsS0FBSyxNQUFNLFNBQVM7QUFDaEMsVUFBSSxDQUFDLE9BQU87QUFDVixlQUFPO0FBQUEsTUFDVDtBQUNBLGFBQU87QUFBQSxRQUNMLFFBQVEsTUFBTSxDQUFDO0FBQUEsUUFDZixNQUFNLE1BQU0sQ0FBQztBQUFBLFFBQ2IsTUFBTSxNQUFNLENBQUM7QUFBQSxRQUNiLE1BQU0sTUFBTSxDQUFDO0FBQUEsUUFDYixNQUFNLE1BQU0sQ0FBQztBQUFBLE1BQ2Y7QUFBQSxJQUNGO0FBQ0EsWUFBUSxXQUFXO0FBQ25CLGFBQVMsWUFBWSxZQUFZO0FBQy9CLFVBQUksTUFBTTtBQUNWLFVBQUksV0FBVyxRQUFRO0FBQ3JCLGVBQU8sV0FBVyxTQUFTO0FBQUEsTUFDN0I7QUFDQSxhQUFPO0FBQ1AsVUFBSSxXQUFXLE1BQU07QUFDbkIsZUFBTyxXQUFXLE9BQU87QUFBQSxNQUMzQjtBQUNBLFVBQUksV0FBVyxNQUFNO0FBQ25CLGVBQU8sV0FBVztBQUFBLE1BQ3BCO0FBQ0EsVUFBSSxXQUFXLE1BQU07QUFDbkIsZUFBTyxNQUFNLFdBQVc7QUFBQSxNQUMxQjtBQUNBLFVBQUksV0FBVyxNQUFNO0FBQ25CLGVBQU8sV0FBVztBQUFBLE1BQ3BCO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxZQUFRLGNBQWM7QUFDdEIsUUFBSSxvQkFBb0I7QUFDeEIsYUFBUyxXQUFXLEdBQUc7QUFDckIsVUFBSSxRQUFRLENBQUM7QUFDYixhQUFPLFNBQVMsT0FBTztBQUNyQixpQkFBUyxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztBQUNyQyxjQUFJLE1BQU0sQ0FBQyxFQUFFLFVBQVUsT0FBTztBQUM1QixnQkFBSSxPQUFPLE1BQU0sQ0FBQztBQUNsQixrQkFBTSxDQUFDLElBQUksTUFBTSxDQUFDO0FBQ2xCLGtCQUFNLENBQUMsSUFBSTtBQUNYLG1CQUFPLE1BQU0sQ0FBQyxFQUFFO0FBQUEsVUFDbEI7QUFBQSxRQUNGO0FBQ0EsWUFBSSxTQUFTLEVBQUUsS0FBSztBQUNwQixjQUFNLFFBQVE7QUFBQSxVQUNaO0FBQUEsVUFDQTtBQUFBLFFBQ0YsQ0FBQztBQUNELFlBQUksTUFBTSxTQUFTLG1CQUFtQjtBQUNwQyxnQkFBTSxJQUFJO0FBQUEsUUFDWjtBQUNBLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUNBLFFBQUksWUFBWSxXQUFXLFNBQVMsV0FBVyxPQUFPO0FBQ3BELFVBQUksT0FBTztBQUNYLFVBQUksTUFBTSxTQUFTLEtBQUs7QUFDeEIsVUFBSSxLQUFLO0FBQ1AsWUFBSSxDQUFDLElBQUksTUFBTTtBQUNiLGlCQUFPO0FBQUEsUUFDVDtBQUNBLGVBQU8sSUFBSTtBQUFBLE1BQ2I7QUFDQSxVQUFJLGFBQWEsUUFBUSxXQUFXLElBQUk7QUFDeEMsVUFBSSxRQUFRLENBQUM7QUFDYixVQUFJLFFBQVE7QUFDWixVQUFJLElBQUk7QUFDUixhQUFPLE1BQU07QUFDWCxnQkFBUTtBQUNSLFlBQUksS0FBSyxRQUFRLEtBQUssS0FBSztBQUMzQixZQUFJLE1BQU0sSUFBSTtBQUNaLGdCQUFNLEtBQUssS0FBSyxNQUFNLEtBQUssQ0FBQztBQUM1QjtBQUFBLFFBQ0YsT0FBTztBQUNMLGdCQUFNLEtBQUssS0FBSyxNQUFNLE9BQU8sQ0FBQyxDQUFDO0FBQy9CLGlCQUFPLElBQUksS0FBSyxVQUFVLEtBQUssQ0FBQyxNQUFNLEtBQUs7QUFDekM7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxlQUFTLE1BQU0sS0FBSyxHQUFHLElBQUksTUFBTSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7QUFDeEQsZUFBTyxNQUFNLENBQUM7QUFDZCxZQUFJLFNBQVMsS0FBSztBQUNoQixnQkFBTSxPQUFPLEdBQUcsQ0FBQztBQUFBLFFBQ25CLFdBQVcsU0FBUyxNQUFNO0FBQ3hCO0FBQUEsUUFDRixXQUFXLEtBQUssR0FBRztBQUNqQixjQUFJLFNBQVMsSUFBSTtBQUNmLGtCQUFNLE9BQU8sSUFBSSxHQUFHLEVBQUU7QUFDdEIsaUJBQUs7QUFBQSxVQUNQLE9BQU87QUFDTCxrQkFBTSxPQUFPLEdBQUcsQ0FBQztBQUNqQjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLGFBQU8sTUFBTSxLQUFLLEdBQUc7QUFDckIsVUFBSSxTQUFTLElBQUk7QUFDZixlQUFPLGFBQWEsTUFBTTtBQUFBLE1BQzVCO0FBQ0EsVUFBSSxLQUFLO0FBQ1AsWUFBSSxPQUFPO0FBQ1gsZUFBTyxZQUFZLEdBQUc7QUFBQSxNQUN4QjtBQUNBLGFBQU87QUFBQSxJQUNULENBQUM7QUFDRCxZQUFRLFlBQVk7QUFDcEIsYUFBUyxLQUFLLE9BQU8sT0FBTztBQUMxQixVQUFJLFVBQVUsSUFBSTtBQUNoQixnQkFBUTtBQUFBLE1BQ1Y7QUFDQSxVQUFJLFVBQVUsSUFBSTtBQUNoQixnQkFBUTtBQUFBLE1BQ1Y7QUFDQSxVQUFJLFdBQVcsU0FBUyxLQUFLO0FBQzdCLFVBQUksV0FBVyxTQUFTLEtBQUs7QUFDN0IsVUFBSSxVQUFVO0FBQ1osZ0JBQVEsU0FBUyxRQUFRO0FBQUEsTUFDM0I7QUFDQSxVQUFJLFlBQVksQ0FBQyxTQUFTLFFBQVE7QUFDaEMsWUFBSSxVQUFVO0FBQ1osbUJBQVMsU0FBUyxTQUFTO0FBQUEsUUFDN0I7QUFDQSxlQUFPLFlBQVksUUFBUTtBQUFBLE1BQzdCO0FBQ0EsVUFBSSxZQUFZLE1BQU0sTUFBTSxhQUFhLEdBQUc7QUFDMUMsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFlBQVksQ0FBQyxTQUFTLFFBQVEsQ0FBQyxTQUFTLE1BQU07QUFDaEQsaUJBQVMsT0FBTztBQUNoQixlQUFPLFlBQVksUUFBUTtBQUFBLE1BQzdCO0FBQ0EsVUFBSSxTQUFTLE1BQU0sT0FBTyxDQUFDLE1BQU0sTUFBTSxRQUFRLFVBQVUsTUFBTSxRQUFRLFFBQVEsRUFBRSxJQUFJLE1BQU0sS0FBSztBQUNoRyxVQUFJLFVBQVU7QUFDWixpQkFBUyxPQUFPO0FBQ2hCLGVBQU8sWUFBWSxRQUFRO0FBQUEsTUFDN0I7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLFlBQVEsT0FBTztBQUNmLFlBQVEsYUFBYSxTQUFTLE9BQU87QUFDbkMsYUFBTyxNQUFNLE9BQU8sQ0FBQyxNQUFNLE9BQU8sVUFBVSxLQUFLLEtBQUs7QUFBQSxJQUN4RDtBQUNBLGFBQVMsU0FBUyxPQUFPLE9BQU87QUFDOUIsVUFBSSxVQUFVLElBQUk7QUFDaEIsZ0JBQVE7QUFBQSxNQUNWO0FBQ0EsY0FBUSxNQUFNLFFBQVEsT0FBTyxFQUFFO0FBQy9CLFVBQUksUUFBUTtBQUNaLGFBQU8sTUFBTSxRQUFRLFFBQVEsR0FBRyxNQUFNLEdBQUc7QUFDdkMsWUFBSSxRQUFRLE1BQU0sWUFBWSxHQUFHO0FBQ2pDLFlBQUksUUFBUSxHQUFHO0FBQ2IsaUJBQU87QUFBQSxRQUNUO0FBQ0EsZ0JBQVEsTUFBTSxNQUFNLEdBQUcsS0FBSztBQUM1QixZQUFJLE1BQU0sTUFBTSxtQkFBbUIsR0FBRztBQUNwQyxpQkFBTztBQUFBLFFBQ1Q7QUFDQSxVQUFFO0FBQUEsTUFDSjtBQUNBLGFBQU8sTUFBTSxRQUFRLENBQUMsRUFBRSxLQUFLLEtBQUssSUFBSSxNQUFNLE9BQU8sTUFBTSxTQUFTLENBQUM7QUFBQSxJQUNyRTtBQUNBLFlBQVEsV0FBVztBQUNuQixRQUFJLG9CQUFvQixXQUFXO0FBQ2pDLFVBQUksTUFBc0IsdUJBQU8sT0FBTyxJQUFJO0FBQzVDLGFBQU8sRUFBRSxlQUFlO0FBQUEsSUFDMUIsRUFBRTtBQUNGLGFBQVMsU0FBUyxHQUFHO0FBQ25CLGFBQU87QUFBQSxJQUNUO0FBQ0EsYUFBUyxZQUFZLE1BQU07QUFDekIsVUFBSSxjQUFjLElBQUksR0FBRztBQUN2QixlQUFPLE1BQU07QUFBQSxNQUNmO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxZQUFRLGNBQWMsb0JBQW9CLFdBQVc7QUFDckQsYUFBUyxjQUFjLE1BQU07QUFDM0IsVUFBSSxjQUFjLElBQUksR0FBRztBQUN2QixlQUFPLEtBQUssTUFBTSxDQUFDO0FBQUEsTUFDckI7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLFlBQVEsZ0JBQWdCLG9CQUFvQixXQUFXO0FBQ3ZELGFBQVMsY0FBYyxHQUFHO0FBQ3hCLFVBQUksQ0FBQyxHQUFHO0FBQ04sZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFNBQVMsRUFBRTtBQUNmLFVBQUksU0FBUyxHQUFHO0FBQ2QsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLEVBQUUsV0FBVyxTQUFTLENBQUMsTUFBTSxNQUFNLEVBQUUsV0FBVyxTQUFTLENBQUMsTUFBTSxNQUFNLEVBQUUsV0FBVyxTQUFTLENBQUMsTUFBTSxPQUFPLEVBQUUsV0FBVyxTQUFTLENBQUMsTUFBTSxPQUFPLEVBQUUsV0FBVyxTQUFTLENBQUMsTUFBTSxPQUFPLEVBQUUsV0FBVyxTQUFTLENBQUMsTUFBTSxPQUFPLEVBQUUsV0FBVyxTQUFTLENBQUMsTUFBTSxPQUFPLEVBQUUsV0FBVyxTQUFTLENBQUMsTUFBTSxNQUFNLEVBQUUsV0FBVyxTQUFTLENBQUMsTUFBTSxJQUFJO0FBQ2hVLGVBQU87QUFBQSxNQUNUO0FBQ0EsZUFBUyxJQUFJLFNBQVMsSUFBSSxLQUFLLEdBQUcsS0FBSztBQUNyQyxZQUFJLEVBQUUsV0FBVyxDQUFDLE1BQU0sSUFBSTtBQUMxQixpQkFBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxhQUFTLDJCQUEyQixVQUFVLFVBQVUscUJBQXFCO0FBQzNFLFVBQUksTUFBTSxPQUFPLFNBQVMsUUFBUSxTQUFTLE1BQU07QUFDakQsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sU0FBUyxlQUFlLFNBQVM7QUFDdkMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sU0FBUyxpQkFBaUIsU0FBUztBQUN6QyxVQUFJLFFBQVEsS0FBSyxxQkFBcUI7QUFDcEMsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLFNBQVMsa0JBQWtCLFNBQVM7QUFDMUMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sU0FBUyxnQkFBZ0IsU0FBUztBQUN4QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTyxPQUFPLFNBQVMsTUFBTSxTQUFTLElBQUk7QUFBQSxJQUM1QztBQUNBLFlBQVEsNkJBQTZCO0FBQ3JDLGFBQVMsbUNBQW1DLFVBQVUsVUFBVSxxQkFBcUI7QUFDbkYsVUFBSTtBQUNKLFlBQU0sU0FBUyxlQUFlLFNBQVM7QUFDdkMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sU0FBUyxpQkFBaUIsU0FBUztBQUN6QyxVQUFJLFFBQVEsS0FBSyxxQkFBcUI7QUFDcEMsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLFNBQVMsa0JBQWtCLFNBQVM7QUFDMUMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sU0FBUyxnQkFBZ0IsU0FBUztBQUN4QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTyxPQUFPLFNBQVMsTUFBTSxTQUFTLElBQUk7QUFBQSxJQUM1QztBQUNBLFlBQVEscUNBQXFDO0FBQzdDLGFBQVMsb0NBQW9DLFVBQVUsVUFBVSxzQkFBc0I7QUFDckYsVUFBSSxNQUFNLFNBQVMsZ0JBQWdCLFNBQVM7QUFDNUMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sU0FBUyxrQkFBa0IsU0FBUztBQUMxQyxVQUFJLFFBQVEsS0FBSyxzQkFBc0I7QUFDckMsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLE9BQU8sU0FBUyxRQUFRLFNBQVMsTUFBTTtBQUM3QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxTQUFTLGVBQWUsU0FBUztBQUN2QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxTQUFTLGlCQUFpQixTQUFTO0FBQ3pDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFDQSxhQUFPLE9BQU8sU0FBUyxNQUFNLFNBQVMsSUFBSTtBQUFBLElBQzVDO0FBQ0EsWUFBUSxzQ0FBc0M7QUFDOUMsYUFBUywwQ0FBMEMsVUFBVSxVQUFVLHNCQUFzQjtBQUMzRixVQUFJLE1BQU0sU0FBUyxrQkFBa0IsU0FBUztBQUM5QyxVQUFJLFFBQVEsS0FBSyxzQkFBc0I7QUFDckMsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLE9BQU8sU0FBUyxRQUFRLFNBQVMsTUFBTTtBQUM3QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxTQUFTLGVBQWUsU0FBUztBQUN2QyxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxTQUFTLGlCQUFpQixTQUFTO0FBQ3pDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFDQSxhQUFPLE9BQU8sU0FBUyxNQUFNLFNBQVMsSUFBSTtBQUFBLElBQzVDO0FBQ0EsWUFBUSw0Q0FBNEM7QUFDcEQsYUFBUyxPQUFPLE9BQU8sT0FBTztBQUM1QixVQUFJLFVBQVUsT0FBTztBQUNuQixlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksVUFBVSxNQUFNO0FBQ2xCLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxVQUFVLE1BQU07QUFDbEIsZUFBTztBQUFBLE1BQ1Q7QUFDQSxVQUFJLFFBQVEsT0FBTztBQUNqQixlQUFPO0FBQUEsTUFDVDtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsYUFBUyxvQ0FBb0MsVUFBVSxVQUFVO0FBQy9ELFVBQUksTUFBTSxTQUFTLGdCQUFnQixTQUFTO0FBQzVDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLFNBQVMsa0JBQWtCLFNBQVM7QUFDMUMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUNBLFlBQU0sT0FBTyxTQUFTLFFBQVEsU0FBUyxNQUFNO0FBQzdDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLFNBQVMsZUFBZSxTQUFTO0FBQ3ZDLFVBQUksUUFBUSxHQUFHO0FBQ2IsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLFNBQVMsaUJBQWlCLFNBQVM7QUFDekMsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVDtBQUNBLGFBQU8sT0FBTyxTQUFTLE1BQU0sU0FBUyxJQUFJO0FBQUEsSUFDNUM7QUFDQSxZQUFRLHNDQUFzQztBQUM5QyxhQUFTLG9CQUFvQixLQUFLO0FBQ2hDLGFBQU8sS0FBSyxNQUFNLElBQUksUUFBUSxrQkFBa0IsRUFBRSxDQUFDO0FBQUEsSUFDckQ7QUFDQSxZQUFRLHNCQUFzQjtBQUM5QixhQUFTLGlCQUFpQixZQUFZLFdBQVcsY0FBYztBQUM3RCxrQkFBWSxhQUFhO0FBQ3pCLFVBQUksWUFBWTtBQUNkLFlBQUksV0FBVyxXQUFXLFNBQVMsQ0FBQyxNQUFNLE9BQU8sVUFBVSxDQUFDLE1BQU0sS0FBSztBQUNyRSx3QkFBYztBQUFBLFFBQ2hCO0FBQ0Esb0JBQVksYUFBYTtBQUFBLE1BQzNCO0FBQ0EsVUFBSSxjQUFjO0FBQ2hCLFlBQUksU0FBUyxTQUFTLFlBQVk7QUFDbEMsWUFBSSxDQUFDLFFBQVE7QUFDWCxnQkFBTSxJQUFJLE1BQU0sa0NBQWtDO0FBQUEsUUFDcEQ7QUFDQSxZQUFJLE9BQU8sTUFBTTtBQUNmLGNBQUksUUFBUSxPQUFPLEtBQUssWUFBWSxHQUFHO0FBQ3ZDLGNBQUksU0FBUyxHQUFHO0FBQ2QsbUJBQU8sT0FBTyxPQUFPLEtBQUssVUFBVSxHQUFHLFFBQVEsQ0FBQztBQUFBLFVBQ2xEO0FBQUEsUUFDRjtBQUNBLG9CQUFZLEtBQUssWUFBWSxNQUFNLEdBQUcsU0FBUztBQUFBLE1BQ2pEO0FBQ0EsYUFBTyxVQUFVLFNBQVM7QUFBQSxJQUM1QjtBQUNBLFlBQVEsbUJBQW1CO0FBQUEsRUFDN0I7QUFDRixDQUFDO0FBR0QsSUFBSSxvQkFBb0IsV0FBVztBQUFBLEVBQ2pDLDhDQUE4QyxTQUFTO0FBQ3JELFFBQUksT0FBTyxhQUFhO0FBQ3hCLFFBQUksTUFBTSxPQUFPLFVBQVU7QUFDM0IsUUFBSSxlQUFlLE9BQU8sUUFBUTtBQUNsQyxhQUFTLFdBQVc7QUFDbEIsV0FBSyxTQUFTLENBQUM7QUFDZixXQUFLLE9BQU8sZUFBK0Isb0JBQUksSUFBSSxJQUFvQix1QkFBTyxPQUFPLElBQUk7QUFBQSxJQUMzRjtBQUNBLGFBQVMsWUFBWSxTQUFTLG1CQUFtQixRQUFRLGtCQUFrQjtBQUN6RSxVQUFJLE1BQU0sSUFBSSxTQUFTO0FBQ3ZCLGVBQVMsSUFBSSxHQUFHLE1BQU0sT0FBTyxRQUFRLElBQUksS0FBSyxLQUFLO0FBQ2pELFlBQUksSUFBSSxPQUFPLENBQUMsR0FBRyxnQkFBZ0I7QUFBQSxNQUNyQztBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsYUFBUyxVQUFVLE9BQU8sU0FBUyxnQkFBZ0I7QUFDakQsYUFBTyxlQUFlLEtBQUssS0FBSyxPQUFPLE9BQU8sb0JBQW9CLEtBQUssSUFBSSxFQUFFO0FBQUEsSUFDL0U7QUFDQSxhQUFTLFVBQVUsTUFBTSxTQUFTLGFBQWEsTUFBTSxrQkFBa0I7QUFDckUsVUFBSSxPQUFPLGVBQWUsT0FBTyxLQUFLLFlBQVksSUFBSTtBQUN0RCxVQUFJLGNBQWMsZUFBZSxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksS0FBSyxLQUFLLE1BQU0sSUFBSTtBQUMxRSxVQUFJLE1BQU0sS0FBSyxPQUFPO0FBQ3RCLFVBQUksQ0FBQyxlQUFlLGtCQUFrQjtBQUNwQyxhQUFLLE9BQU8sS0FBSyxJQUFJO0FBQUEsTUFDdkI7QUFDQSxVQUFJLENBQUMsYUFBYTtBQUNoQixZQUFJLGNBQWM7QUFDaEIsZUFBSyxLQUFLLElBQUksTUFBTSxHQUFHO0FBQUEsUUFDekIsT0FBTztBQUNMLGVBQUssS0FBSyxJQUFJLElBQUk7QUFBQSxRQUNwQjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsYUFBUyxVQUFVLE1BQU0sU0FBUyxhQUFhLE1BQU07QUFDbkQsVUFBSSxjQUFjO0FBQ2hCLGVBQU8sS0FBSyxLQUFLLElBQUksSUFBSTtBQUFBLE1BQzNCLE9BQU87QUFDTCxZQUFJLE9BQU8sS0FBSyxZQUFZLElBQUk7QUFDaEMsZUFBTyxJQUFJLEtBQUssS0FBSyxNQUFNLElBQUk7QUFBQSxNQUNqQztBQUFBLElBQ0Y7QUFDQSxhQUFTLFVBQVUsVUFBVSxTQUFTLGlCQUFpQixNQUFNO0FBQzNELFVBQUksY0FBYztBQUNoQixZQUFJLE1BQU0sS0FBSyxLQUFLLElBQUksSUFBSTtBQUM1QixZQUFJLE9BQU8sR0FBRztBQUNaLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0YsT0FBTztBQUNMLFlBQUksT0FBTyxLQUFLLFlBQVksSUFBSTtBQUNoQyxZQUFJLElBQUksS0FBSyxLQUFLLE1BQU0sSUFBSSxHQUFHO0FBQzdCLGlCQUFPLEtBQUssS0FBSyxJQUFJO0FBQUEsUUFDdkI7QUFBQSxNQUNGO0FBQ0EsWUFBTSxJQUFJLE1BQU0sTUFBTSxPQUFPLHNCQUFzQjtBQUFBLElBQ3JEO0FBQ0EsYUFBUyxVQUFVLEtBQUssU0FBUyxZQUFZLE1BQU07QUFDakQsVUFBSSxRQUFRLEtBQUssT0FBTyxLQUFLLE9BQU8sUUFBUTtBQUMxQyxlQUFPLEtBQUssT0FBTyxJQUFJO0FBQUEsTUFDekI7QUFDQSxZQUFNLElBQUksTUFBTSwyQkFBMkIsSUFBSTtBQUFBLElBQ2pEO0FBQ0EsYUFBUyxVQUFVLFVBQVUsU0FBUyxtQkFBbUI7QUFDdkQsYUFBTyxLQUFLLE9BQU8sTUFBTTtBQUFBLElBQzNCO0FBQ0EsWUFBUSxXQUFXO0FBQUEsRUFDckI7QUFDRixDQUFDO0FBR0QsSUFBSSx1QkFBdUIsV0FBVztBQUFBLEVBQ3BDLGlEQUFpRCxTQUFTO0FBQ3hELFFBQUksT0FBTyxhQUFhO0FBQ3hCLGFBQVMsdUJBQXVCLFVBQVUsVUFBVTtBQUNsRCxVQUFJLFFBQVEsU0FBUztBQUNyQixVQUFJLFFBQVEsU0FBUztBQUNyQixVQUFJLFVBQVUsU0FBUztBQUN2QixVQUFJLFVBQVUsU0FBUztBQUN2QixhQUFPLFFBQVEsU0FBUyxTQUFTLFNBQVMsV0FBVyxXQUFXLEtBQUssb0NBQW9DLFVBQVUsUUFBUSxLQUFLO0FBQUEsSUFDbEk7QUFDQSxhQUFTLGNBQWM7QUFDckIsV0FBSyxTQUFTLENBQUM7QUFDZixXQUFLLFVBQVU7QUFDZixXQUFLLFFBQVEsRUFBRSxlQUFlLElBQUksaUJBQWlCLEVBQUU7QUFBQSxJQUN2RDtBQUNBLGdCQUFZLFVBQVUsa0JBQWtCLFNBQVMsb0JBQW9CLFdBQVcsVUFBVTtBQUN4RixXQUFLLE9BQU8sUUFBUSxXQUFXLFFBQVE7QUFBQSxJQUN6QztBQUNBLGdCQUFZLFVBQVUsTUFBTSxTQUFTLGdCQUFnQixVQUFVO0FBQzdELFVBQUksdUJBQXVCLEtBQUssT0FBTyxRQUFRLEdBQUc7QUFDaEQsYUFBSyxRQUFRO0FBQ2IsYUFBSyxPQUFPLEtBQUssUUFBUTtBQUFBLE1BQzNCLE9BQU87QUFDTCxhQUFLLFVBQVU7QUFDZixhQUFLLE9BQU8sS0FBSyxRQUFRO0FBQUEsTUFDM0I7QUFBQSxJQUNGO0FBQ0EsZ0JBQVksVUFBVSxVQUFVLFNBQVMsc0JBQXNCO0FBQzdELFVBQUksQ0FBQyxLQUFLLFNBQVM7QUFDakIsYUFBSyxPQUFPLEtBQUssS0FBSyxtQ0FBbUM7QUFDekQsYUFBSyxVQUFVO0FBQUEsTUFDakI7QUFDQSxhQUFPLEtBQUs7QUFBQSxJQUNkO0FBQ0EsWUFBUSxjQUFjO0FBQUEsRUFDeEI7QUFDRixDQUFDO0FBR0QsSUFBSSwrQkFBK0IsV0FBVztBQUFBLEVBQzVDLHlEQUF5RCxTQUFTO0FBQ2hFLFFBQUksWUFBWSxtQkFBbUI7QUFDbkMsUUFBSSxPQUFPLGFBQWE7QUFDeEIsUUFBSSxXQUFXLGtCQUFrQixFQUFFO0FBQ25DLFFBQUksY0FBYyxxQkFBcUIsRUFBRTtBQUN6QyxhQUFTLG1CQUFtQixPQUFPO0FBQ2pDLFVBQUksQ0FBQyxPQUFPO0FBQ1YsZ0JBQVEsQ0FBQztBQUFBLE1BQ1g7QUFDQSxXQUFLLFFBQVEsS0FBSyxPQUFPLE9BQU8sUUFBUSxJQUFJO0FBQzVDLFdBQUssY0FBYyxLQUFLLE9BQU8sT0FBTyxjQUFjLElBQUk7QUFDeEQsV0FBSyxrQkFBa0IsS0FBSyxPQUFPLE9BQU8sa0JBQWtCLEtBQUs7QUFDakUsV0FBSyxXQUFXLElBQUksU0FBUztBQUM3QixXQUFLLFNBQVMsSUFBSSxTQUFTO0FBQzNCLFdBQUssWUFBWSxJQUFJLFlBQVk7QUFDakMsV0FBSyxtQkFBbUI7QUFBQSxJQUMxQjtBQUNBLHVCQUFtQixVQUFVLFdBQVc7QUFDeEMsdUJBQW1CLGdCQUFnQixTQUFTLGlDQUFpQyxvQkFBb0I7QUFDL0YsVUFBSSxhQUFhLG1CQUFtQjtBQUNwQyxVQUFJLFlBQVksSUFBSSxtQkFBbUI7QUFBQSxRQUNyQyxNQUFNLG1CQUFtQjtBQUFBLFFBQ3pCO0FBQUEsTUFDRixDQUFDO0FBQ0QseUJBQW1CLFlBQVksU0FBUyxTQUFTO0FBQy9DLFlBQUksYUFBYTtBQUFBLFVBQ2YsV0FBVztBQUFBLFlBQ1QsTUFBTSxRQUFRO0FBQUEsWUFDZCxRQUFRLFFBQVE7QUFBQSxVQUNsQjtBQUFBLFFBQ0Y7QUFDQSxZQUFJLFFBQVEsVUFBVSxNQUFNO0FBQzFCLHFCQUFXLFNBQVMsUUFBUTtBQUM1QixjQUFJLGNBQWMsTUFBTTtBQUN0Qix1QkFBVyxTQUFTLEtBQUssU0FBUyxZQUFZLFdBQVcsTUFBTTtBQUFBLFVBQ2pFO0FBQ0EscUJBQVcsV0FBVztBQUFBLFlBQ3BCLE1BQU0sUUFBUTtBQUFBLFlBQ2QsUUFBUSxRQUFRO0FBQUEsVUFDbEI7QUFDQSxjQUFJLFFBQVEsUUFBUSxNQUFNO0FBQ3hCLHVCQUFXLE9BQU8sUUFBUTtBQUFBLFVBQzVCO0FBQUEsUUFDRjtBQUNBLGtCQUFVLFdBQVcsVUFBVTtBQUFBLE1BQ2pDLENBQUM7QUFDRCx5QkFBbUIsUUFBUSxRQUFRLFNBQVMsWUFBWTtBQUN0RCxZQUFJLGlCQUFpQjtBQUNyQixZQUFJLGVBQWUsTUFBTTtBQUN2QiwyQkFBaUIsS0FBSyxTQUFTLFlBQVksVUFBVTtBQUFBLFFBQ3ZEO0FBQ0EsWUFBSSxDQUFDLFVBQVUsU0FBUyxJQUFJLGNBQWMsR0FBRztBQUMzQyxvQkFBVSxTQUFTLElBQUksY0FBYztBQUFBLFFBQ3ZDO0FBQ0EsWUFBSSxVQUFVLG1CQUFtQixpQkFBaUIsVUFBVTtBQUM1RCxZQUFJLFdBQVcsTUFBTTtBQUNuQixvQkFBVSxpQkFBaUIsWUFBWSxPQUFPO0FBQUEsUUFDaEQ7QUFBQSxNQUNGLENBQUM7QUFDRCxhQUFPO0FBQUEsSUFDVDtBQUNBLHVCQUFtQixVQUFVLGFBQWEsU0FBUyw4QkFBOEIsT0FBTztBQUN0RixVQUFJLFlBQVksS0FBSyxPQUFPLE9BQU8sV0FBVztBQUM5QyxVQUFJLFdBQVcsS0FBSyxPQUFPLE9BQU8sWUFBWSxJQUFJO0FBQ2xELFVBQUksU0FBUyxLQUFLLE9BQU8sT0FBTyxVQUFVLElBQUk7QUFDOUMsVUFBSSxPQUFPLEtBQUssT0FBTyxPQUFPLFFBQVEsSUFBSTtBQUMxQyxVQUFJLENBQUMsS0FBSyxpQkFBaUI7QUFDekIsYUFBSyxpQkFBaUIsV0FBVyxVQUFVLFFBQVEsSUFBSTtBQUFBLE1BQ3pEO0FBQ0EsVUFBSSxVQUFVLE1BQU07QUFDbEIsaUJBQVMsT0FBTyxNQUFNO0FBQ3RCLFlBQUksQ0FBQyxLQUFLLFNBQVMsSUFBSSxNQUFNLEdBQUc7QUFDOUIsZUFBSyxTQUFTLElBQUksTUFBTTtBQUFBLFFBQzFCO0FBQUEsTUFDRjtBQUNBLFVBQUksUUFBUSxNQUFNO0FBQ2hCLGVBQU8sT0FBTyxJQUFJO0FBQ2xCLFlBQUksQ0FBQyxLQUFLLE9BQU8sSUFBSSxJQUFJLEdBQUc7QUFDMUIsZUFBSyxPQUFPLElBQUksSUFBSTtBQUFBLFFBQ3RCO0FBQUEsTUFDRjtBQUNBLFdBQUssVUFBVSxJQUFJO0FBQUEsUUFDakIsZUFBZSxVQUFVO0FBQUEsUUFDekIsaUJBQWlCLFVBQVU7QUFBQSxRQUMzQixjQUFjLFlBQVksUUFBUSxTQUFTO0FBQUEsUUFDM0MsZ0JBQWdCLFlBQVksUUFBUSxTQUFTO0FBQUEsUUFDN0M7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUNBLHVCQUFtQixVQUFVLG1CQUFtQixTQUFTLG9DQUFvQyxhQUFhLGdCQUFnQjtBQUN4SCxVQUFJLFNBQVM7QUFDYixVQUFJLEtBQUssZUFBZSxNQUFNO0FBQzVCLGlCQUFTLEtBQUssU0FBUyxLQUFLLGFBQWEsTUFBTTtBQUFBLE1BQ2pEO0FBQ0EsVUFBSSxrQkFBa0IsTUFBTTtBQUMxQixZQUFJLENBQUMsS0FBSyxrQkFBa0I7QUFDMUIsZUFBSyxtQkFBbUMsdUJBQU8sT0FBTyxJQUFJO0FBQUEsUUFDNUQ7QUFDQSxhQUFLLGlCQUFpQixLQUFLLFlBQVksTUFBTSxDQUFDLElBQUk7QUFBQSxNQUNwRCxXQUFXLEtBQUssa0JBQWtCO0FBQ2hDLGVBQU8sS0FBSyxpQkFBaUIsS0FBSyxZQUFZLE1BQU0sQ0FBQztBQUNyRCxZQUFJLE9BQU8sS0FBSyxLQUFLLGdCQUFnQixFQUFFLFdBQVcsR0FBRztBQUNuRCxlQUFLLG1CQUFtQjtBQUFBLFFBQzFCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSx1QkFBbUIsVUFBVSxpQkFBaUIsU0FBUyxrQ0FBa0Msb0JBQW9CLGFBQWEsZ0JBQWdCO0FBQ3hJLFVBQUksYUFBYTtBQUNqQixVQUFJLGVBQWUsTUFBTTtBQUN2QixZQUFJLG1CQUFtQixRQUFRLE1BQU07QUFDbkMsZ0JBQU0sSUFBSTtBQUFBLFlBQ1I7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUNBLHFCQUFhLG1CQUFtQjtBQUFBLE1BQ2xDO0FBQ0EsVUFBSSxhQUFhLEtBQUs7QUFDdEIsVUFBSSxjQUFjLE1BQU07QUFDdEIscUJBQWEsS0FBSyxTQUFTLFlBQVksVUFBVTtBQUFBLE1BQ25EO0FBQ0EsVUFBSSxhQUFhLElBQUksU0FBUztBQUM5QixVQUFJLFdBQVcsSUFBSSxTQUFTO0FBQzVCLFdBQUssVUFBVSxnQkFBZ0IsU0FBUyxTQUFTO0FBQy9DLFlBQUksUUFBUSxXQUFXLGNBQWMsUUFBUSxnQkFBZ0IsTUFBTTtBQUNqRSxjQUFJLFdBQVcsbUJBQW1CLG9CQUFvQjtBQUFBLFlBQ3BELE1BQU0sUUFBUTtBQUFBLFlBQ2QsUUFBUSxRQUFRO0FBQUEsVUFDbEIsQ0FBQztBQUNELGNBQUksU0FBUyxVQUFVLE1BQU07QUFDM0Isb0JBQVEsU0FBUyxTQUFTO0FBQzFCLGdCQUFJLGtCQUFrQixNQUFNO0FBQzFCLHNCQUFRLFNBQVMsS0FBSyxLQUFLLGdCQUFnQixRQUFRLE1BQU07QUFBQSxZQUMzRDtBQUNBLGdCQUFJLGNBQWMsTUFBTTtBQUN0QixzQkFBUSxTQUFTLEtBQUssU0FBUyxZQUFZLFFBQVEsTUFBTTtBQUFBLFlBQzNEO0FBQ0Esb0JBQVEsZUFBZSxTQUFTO0FBQ2hDLG9CQUFRLGlCQUFpQixTQUFTO0FBQ2xDLGdCQUFJLFNBQVMsUUFBUSxNQUFNO0FBQ3pCLHNCQUFRLE9BQU8sU0FBUztBQUFBLFlBQzFCO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQSxZQUFJLFNBQVMsUUFBUTtBQUNyQixZQUFJLFVBQVUsUUFBUSxDQUFDLFdBQVcsSUFBSSxNQUFNLEdBQUc7QUFDN0MscUJBQVcsSUFBSSxNQUFNO0FBQUEsUUFDdkI7QUFDQSxZQUFJLE9BQU8sUUFBUTtBQUNuQixZQUFJLFFBQVEsUUFBUSxDQUFDLFNBQVMsSUFBSSxJQUFJLEdBQUc7QUFDdkMsbUJBQVMsSUFBSSxJQUFJO0FBQUEsUUFDbkI7QUFBQSxNQUNGLEdBQUcsSUFBSTtBQUNQLFdBQUssV0FBVztBQUNoQixXQUFLLFNBQVM7QUFDZCx5QkFBbUIsUUFBUSxRQUFRLFNBQVMsYUFBYTtBQUN2RCxZQUFJLFVBQVUsbUJBQW1CLGlCQUFpQixXQUFXO0FBQzdELFlBQUksV0FBVyxNQUFNO0FBQ25CLGNBQUksa0JBQWtCLE1BQU07QUFDMUIsMEJBQWMsS0FBSyxLQUFLLGdCQUFnQixXQUFXO0FBQUEsVUFDckQ7QUFDQSxjQUFJLGNBQWMsTUFBTTtBQUN0QiwwQkFBYyxLQUFLLFNBQVMsWUFBWSxXQUFXO0FBQUEsVUFDckQ7QUFDQSxlQUFLLGlCQUFpQixhQUFhLE9BQU87QUFBQSxRQUM1QztBQUFBLE1BQ0YsR0FBRyxJQUFJO0FBQUEsSUFDVDtBQUNBLHVCQUFtQixVQUFVLG1CQUFtQixTQUFTLG1DQUFtQyxZQUFZLFdBQVcsU0FBUyxPQUFPO0FBQ2pJLFVBQUksYUFBYSxPQUFPLFVBQVUsU0FBUyxZQUFZLE9BQU8sVUFBVSxXQUFXLFVBQVU7QUFDM0YsY0FBTSxJQUFJO0FBQUEsVUFDUjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsVUFBSSxjQUFjLFVBQVUsY0FBYyxZQUFZLGNBQWMsV0FBVyxPQUFPLEtBQUssV0FBVyxVQUFVLEtBQUssQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLE9BQU87QUFDcko7QUFBQSxNQUNGLFdBQVcsY0FBYyxVQUFVLGNBQWMsWUFBWSxjQUFjLGFBQWEsVUFBVSxhQUFhLFlBQVksYUFBYSxXQUFXLE9BQU8sS0FBSyxXQUFXLFVBQVUsS0FBSyxVQUFVLE9BQU8sS0FBSyxVQUFVLFVBQVUsS0FBSyxTQUFTO0FBQy9PO0FBQUEsTUFDRixPQUFPO0FBQ0wsY0FBTSxJQUFJLE1BQU0sc0JBQXNCLEtBQUssVUFBVTtBQUFBLFVBQ25ELFdBQVc7QUFBQSxVQUNYLFFBQVE7QUFBQSxVQUNSLFVBQVU7QUFBQSxVQUNWLE1BQU07QUFBQSxRQUNSLENBQUMsQ0FBQztBQUFBLE1BQ0o7QUFBQSxJQUNGO0FBQ0EsdUJBQW1CLFVBQVUscUJBQXFCLFNBQVMsdUNBQXVDO0FBQ2hHLFVBQUksMEJBQTBCO0FBQzlCLFVBQUksd0JBQXdCO0FBQzVCLFVBQUkseUJBQXlCO0FBQzdCLFVBQUksdUJBQXVCO0FBQzNCLFVBQUksZUFBZTtBQUNuQixVQUFJLGlCQUFpQjtBQUNyQixVQUFJLFNBQVM7QUFDYixVQUFJO0FBQ0osVUFBSTtBQUNKLFVBQUk7QUFDSixVQUFJO0FBQ0osVUFBSSxXQUFXLEtBQUssVUFBVSxRQUFRO0FBQ3RDLGVBQVMsSUFBSSxHQUFHLE1BQU0sU0FBUyxRQUFRLElBQUksS0FBSyxLQUFLO0FBQ25ELGtCQUFVLFNBQVMsQ0FBQztBQUNwQixlQUFPO0FBQ1AsWUFBSSxRQUFRLGtCQUFrQix1QkFBdUI7QUFDbkQsb0NBQTBCO0FBQzFCLGlCQUFPLFFBQVEsa0JBQWtCLHVCQUF1QjtBQUN0RCxvQkFBUTtBQUNSO0FBQUEsVUFDRjtBQUFBLFFBQ0YsT0FBTztBQUNMLGNBQUksSUFBSSxHQUFHO0FBQ1QsZ0JBQUksQ0FBQyxLQUFLLG9DQUFvQyxTQUFTLFNBQVMsSUFBSSxDQUFDLENBQUMsR0FBRztBQUN2RTtBQUFBLFlBQ0Y7QUFDQSxvQkFBUTtBQUFBLFVBQ1Y7QUFBQSxRQUNGO0FBQ0EsZ0JBQVEsVUFBVSxPQUFPLFFBQVEsa0JBQWtCLHVCQUF1QjtBQUMxRSxrQ0FBMEIsUUFBUTtBQUNsQyxZQUFJLFFBQVEsVUFBVSxNQUFNO0FBQzFCLHNCQUFZLEtBQUssU0FBUyxRQUFRLFFBQVEsTUFBTTtBQUNoRCxrQkFBUSxVQUFVLE9BQU8sWUFBWSxjQUFjO0FBQ25ELDJCQUFpQjtBQUNqQixrQkFBUSxVQUFVLE9BQU8sUUFBUSxlQUFlLElBQUksb0JBQW9CO0FBQ3hFLGlDQUF1QixRQUFRLGVBQWU7QUFDOUMsa0JBQVEsVUFBVSxPQUFPLFFBQVEsaUJBQWlCLHNCQUFzQjtBQUN4RSxtQ0FBeUIsUUFBUTtBQUNqQyxjQUFJLFFBQVEsUUFBUSxNQUFNO0FBQ3hCLHNCQUFVLEtBQUssT0FBTyxRQUFRLFFBQVEsSUFBSTtBQUMxQyxvQkFBUSxVQUFVLE9BQU8sVUFBVSxZQUFZO0FBQy9DLDJCQUFlO0FBQUEsVUFDakI7QUFBQSxRQUNGO0FBQ0Esa0JBQVU7QUFBQSxNQUNaO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSx1QkFBbUIsVUFBVSwwQkFBMEIsU0FBUywwQ0FBMEMsVUFBVSxhQUFhO0FBQy9ILGFBQU8sU0FBUyxJQUFJLFNBQVMsUUFBUTtBQUNuQyxZQUFJLENBQUMsS0FBSyxrQkFBa0I7QUFDMUIsaUJBQU87QUFBQSxRQUNUO0FBQ0EsWUFBSSxlQUFlLE1BQU07QUFDdkIsbUJBQVMsS0FBSyxTQUFTLGFBQWEsTUFBTTtBQUFBLFFBQzVDO0FBQ0EsWUFBSSxNQUFNLEtBQUssWUFBWSxNQUFNO0FBQ2pDLGVBQU8sT0FBTyxVQUFVLGVBQWUsS0FBSyxLQUFLLGtCQUFrQixHQUFHLElBQUksS0FBSyxpQkFBaUIsR0FBRyxJQUFJO0FBQUEsTUFDekcsR0FBRyxJQUFJO0FBQUEsSUFDVDtBQUNBLHVCQUFtQixVQUFVLFNBQVMsU0FBUyw0QkFBNEI7QUFDekUsVUFBSSxNQUFNO0FBQUEsUUFDUixTQUFTLEtBQUs7QUFBQSxRQUNkLFNBQVMsS0FBSyxTQUFTLFFBQVE7QUFBQSxRQUMvQixPQUFPLEtBQUssT0FBTyxRQUFRO0FBQUEsUUFDM0IsVUFBVSxLQUFLLG1CQUFtQjtBQUFBLE1BQ3BDO0FBQ0EsVUFBSSxLQUFLLFNBQVMsTUFBTTtBQUN0QixZQUFJLE9BQU8sS0FBSztBQUFBLE1BQ2xCO0FBQ0EsVUFBSSxLQUFLLGVBQWUsTUFBTTtBQUM1QixZQUFJLGFBQWEsS0FBSztBQUFBLE1BQ3hCO0FBQ0EsVUFBSSxLQUFLLGtCQUFrQjtBQUN6QixZQUFJLGlCQUFpQixLQUFLLHdCQUF3QixJQUFJLFNBQVMsSUFBSSxVQUFVO0FBQUEsTUFDL0U7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLHVCQUFtQixVQUFVLFdBQVcsU0FBUyw4QkFBOEI7QUFDN0UsYUFBTyxLQUFLLFVBQVUsS0FBSyxPQUFPLENBQUM7QUFBQSxJQUNyQztBQUNBLFlBQVEscUJBQXFCO0FBQUEsRUFDL0I7QUFDRixDQUFDO0FBR0QsSUFBSSx3QkFBd0IsV0FBVztBQUFBLEVBQ3JDLGtEQUFrRCxTQUFTO0FBQ3pELFlBQVEsdUJBQXVCO0FBQy9CLFlBQVEsb0JBQW9CO0FBQzVCLGFBQVMsZ0JBQWdCLE1BQU0sT0FBTyxTQUFTLFdBQVcsVUFBVSxPQUFPO0FBQ3pFLFVBQUksTUFBTSxLQUFLLE9BQU8sUUFBUSxRQUFRLENBQUMsSUFBSTtBQUMzQyxVQUFJLE1BQU0sU0FBUyxTQUFTLFVBQVUsR0FBRyxHQUFHLElBQUk7QUFDaEQsVUFBSSxRQUFRLEdBQUc7QUFDYixlQUFPO0FBQUEsTUFDVCxXQUFXLE1BQU0sR0FBRztBQUNsQixZQUFJLFFBQVEsTUFBTSxHQUFHO0FBQ25CLGlCQUFPLGdCQUFnQixLQUFLLE9BQU8sU0FBUyxXQUFXLFVBQVUsS0FBSztBQUFBLFFBQ3hFO0FBQ0EsWUFBSSxTQUFTLFFBQVEsbUJBQW1CO0FBQ3RDLGlCQUFPLFFBQVEsVUFBVSxTQUFTLFFBQVE7QUFBQSxRQUM1QyxPQUFPO0FBQ0wsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRixPQUFPO0FBQ0wsWUFBSSxNQUFNLE9BQU8sR0FBRztBQUNsQixpQkFBTyxnQkFBZ0IsTUFBTSxLQUFLLFNBQVMsV0FBVyxVQUFVLEtBQUs7QUFBQSxRQUN2RTtBQUNBLFlBQUksU0FBUyxRQUFRLG1CQUFtQjtBQUN0QyxpQkFBTztBQUFBLFFBQ1QsT0FBTztBQUNMLGlCQUFPLE9BQU8sSUFBSSxLQUFLO0FBQUEsUUFDekI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFlBQVEsU0FBUyxTQUFTLE9BQU8sU0FBUyxXQUFXLFVBQVUsT0FBTztBQUNwRSxVQUFJLFVBQVUsV0FBVyxHQUFHO0FBQzFCLGVBQU87QUFBQSxNQUNUO0FBQ0EsVUFBSSxRQUFRO0FBQUEsUUFDVjtBQUFBLFFBQ0EsVUFBVTtBQUFBLFFBQ1Y7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsU0FBUyxRQUFRO0FBQUEsTUFDbkI7QUFDQSxVQUFJLFFBQVEsR0FBRztBQUNiLGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTyxRQUFRLEtBQUssR0FBRztBQUNyQixZQUFJLFNBQVMsVUFBVSxLQUFLLEdBQUcsVUFBVSxRQUFRLENBQUMsR0FBRyxJQUFJLE1BQU0sR0FBRztBQUNoRTtBQUFBLFFBQ0Y7QUFDQSxVQUFFO0FBQUEsTUFDSjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFHRCxJQUFJLHFCQUFxQixXQUFXO0FBQUEsRUFDbEMsK0NBQStDLFNBQVM7QUFDdEQsYUFBUyxhQUFhLFlBQVk7QUFDaEMsZUFBUyxLQUFLLEtBQUssR0FBRyxHQUFHO0FBQ3ZCLFlBQUksT0FBTyxJQUFJLENBQUM7QUFDaEIsWUFBSSxDQUFDLElBQUksSUFBSSxDQUFDO0FBQ2QsWUFBSSxDQUFDLElBQUk7QUFBQSxNQUNYO0FBQ0EsZUFBUyxpQkFBaUIsS0FBSyxNQUFNO0FBQ25DLGVBQU8sS0FBSyxNQUFNLE1BQU0sS0FBSyxPQUFPLEtBQUssT0FBTyxJQUFJO0FBQUEsTUFDdEQ7QUFDQSxlQUFTLFlBQVksS0FBSyxhQUFhLEdBQUcsR0FBRztBQUMzQyxZQUFJLElBQUksR0FBRztBQUNULGNBQUksYUFBYSxpQkFBaUIsR0FBRyxDQUFDO0FBQ3RDLGNBQUksSUFBSSxJQUFJO0FBQ1osZUFBSyxLQUFLLFlBQVksQ0FBQztBQUN2QixjQUFJLFFBQVEsSUFBSSxDQUFDO0FBQ2pCLG1CQUFTLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztBQUMxQixnQkFBSSxZQUFZLElBQUksQ0FBQyxHQUFHLE9BQU8sS0FBSyxLQUFLLEdBQUc7QUFDMUMsbUJBQUs7QUFDTCxtQkFBSyxLQUFLLEdBQUcsQ0FBQztBQUFBLFlBQ2hCO0FBQUEsVUFDRjtBQUNBLGVBQUssS0FBSyxJQUFJLEdBQUcsQ0FBQztBQUNsQixjQUFJLElBQUksSUFBSTtBQUNaLHNCQUFZLEtBQUssYUFBYSxHQUFHLElBQUksQ0FBQztBQUN0QyxzQkFBWSxLQUFLLGFBQWEsSUFBSSxHQUFHLENBQUM7QUFBQSxRQUN4QztBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLGFBQVMsVUFBVSxZQUFZO0FBQzdCLFVBQUksV0FBVyxhQUFhLFNBQVM7QUFDckMsVUFBSSxhQUFhLElBQUksU0FBUyxVQUFVLFFBQVEsRUFBRSxFQUFFO0FBQ3BELGFBQU8sV0FBVyxVQUFVO0FBQUEsSUFDOUI7QUFDQSxRQUFJLFlBQTRCLG9CQUFJLFFBQVE7QUFDNUMsWUFBUSxZQUFZLFNBQVMsS0FBSyxZQUFZLFFBQVEsR0FBRztBQUN2RCxVQUFJLGNBQWMsVUFBVSxJQUFJLFVBQVU7QUFDMUMsVUFBSSxnQkFBZ0IsUUFBUTtBQUMxQixzQkFBYyxVQUFVLFVBQVU7QUFDbEMsa0JBQVUsSUFBSSxZQUFZLFdBQVc7QUFBQSxNQUN2QztBQUNBLGtCQUFZLEtBQUssWUFBWSxPQUFPLElBQUksU0FBUyxDQUFDO0FBQUEsSUFDcEQ7QUFBQSxFQUNGO0FBQ0YsQ0FBQztBQUdELElBQUksOEJBQThCLFdBQVc7QUFBQSxFQUMzQyx3REFBd0QsU0FBUztBQUMvRCxRQUFJLE9BQU8sYUFBYTtBQUN4QixRQUFJLGVBQWUsc0JBQXNCO0FBQ3pDLFFBQUksV0FBVyxrQkFBa0IsRUFBRTtBQUNuQyxRQUFJLFlBQVksbUJBQW1CO0FBQ25DLFFBQUksWUFBWSxtQkFBbUIsRUFBRTtBQUNyQyxhQUFTLG1CQUFtQixZQUFZLGVBQWU7QUFDckQsVUFBSSxZQUFZO0FBQ2hCLFVBQUksT0FBTyxlQUFlLFVBQVU7QUFDbEMsb0JBQVksS0FBSyxvQkFBb0IsVUFBVTtBQUFBLE1BQ2pEO0FBQ0EsYUFBTyxVQUFVLFlBQVksT0FBTyxJQUFJLHlCQUF5QixXQUFXLGFBQWEsSUFBSSxJQUFJLHVCQUF1QixXQUFXLGFBQWE7QUFBQSxJQUNsSjtBQUNBLHVCQUFtQixnQkFBZ0IsU0FBUyxZQUFZLGVBQWU7QUFDckUsYUFBTyx1QkFBdUIsY0FBYyxZQUFZLGFBQWE7QUFBQSxJQUN2RTtBQUNBLHVCQUFtQixVQUFVLFdBQVc7QUFDeEMsdUJBQW1CLFVBQVUsc0JBQXNCO0FBQ25ELFdBQU8sZUFBZSxtQkFBbUIsV0FBVyxzQkFBc0I7QUFBQSxNQUN4RSxjQUFjO0FBQUEsTUFDZCxZQUFZO0FBQUEsTUFDWixLQUFLLFdBQVc7QUFDZCxZQUFJLENBQUMsS0FBSyxxQkFBcUI7QUFDN0IsZUFBSyxlQUFlLEtBQUssV0FBVyxLQUFLLFVBQVU7QUFBQSxRQUNyRDtBQUNBLGVBQU8sS0FBSztBQUFBLE1BQ2Q7QUFBQSxJQUNGLENBQUM7QUFDRCx1QkFBbUIsVUFBVSxxQkFBcUI7QUFDbEQsV0FBTyxlQUFlLG1CQUFtQixXQUFXLHFCQUFxQjtBQUFBLE1BQ3ZFLGNBQWM7QUFBQSxNQUNkLFlBQVk7QUFBQSxNQUNaLEtBQUssV0FBVztBQUNkLFlBQUksQ0FBQyxLQUFLLG9CQUFvQjtBQUM1QixlQUFLLGVBQWUsS0FBSyxXQUFXLEtBQUssVUFBVTtBQUFBLFFBQ3JEO0FBQ0EsZUFBTyxLQUFLO0FBQUEsTUFDZDtBQUFBLElBQ0YsQ0FBQztBQUNELHVCQUFtQixVQUFVLDBCQUEwQixTQUFTLHlDQUF5QyxNQUFNLE9BQU87QUFDcEgsVUFBSSxJQUFJLEtBQUssT0FBTyxLQUFLO0FBQ3pCLGFBQU8sTUFBTSxPQUFPLE1BQU07QUFBQSxJQUM1QjtBQUNBLHVCQUFtQixVQUFVLGlCQUFpQixTQUFTLGdDQUFnQyxNQUFNLGFBQWE7QUFDeEcsWUFBTSxJQUFJLE1BQU0sMENBQTBDO0FBQUEsSUFDNUQ7QUFDQSx1QkFBbUIsa0JBQWtCO0FBQ3JDLHVCQUFtQixpQkFBaUI7QUFDcEMsdUJBQW1CLHVCQUF1QjtBQUMxQyx1QkFBbUIsb0JBQW9CO0FBQ3ZDLHVCQUFtQixVQUFVLGNBQWMsU0FBUyw4QkFBOEIsV0FBVyxVQUFVLFFBQVE7QUFDN0csVUFBSSxVQUFVLFlBQVk7QUFDMUIsVUFBSSxRQUFRLFVBQVUsbUJBQW1CO0FBQ3pDLFVBQUk7QUFDSixjQUFRLE9BQU87QUFBQSxRQUNiLEtBQUssbUJBQW1CO0FBQ3RCLHFCQUFXLEtBQUs7QUFDaEI7QUFBQSxRQUNGLEtBQUssbUJBQW1CO0FBQ3RCLHFCQUFXLEtBQUs7QUFDaEI7QUFBQSxRQUNGO0FBQ0UsZ0JBQU0sSUFBSSxNQUFNLDZCQUE2QjtBQUFBLE1BQ2pEO0FBQ0EsVUFBSSxhQUFhLEtBQUs7QUFDdEIsVUFBSSxnQkFBZ0IsVUFBVSxLQUFLLE9BQU87QUFDMUMsVUFBSSxRQUFRLEtBQUs7QUFDakIsVUFBSSxVQUFVLEtBQUs7QUFDbkIsVUFBSSxlQUFlLEtBQUs7QUFDeEIsZUFBUyxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsSUFBSSxHQUFHLEtBQUs7QUFDL0MsWUFBSSxVQUFVLFNBQVMsQ0FBQztBQUN4QixZQUFJLFNBQVMsUUFBUSxXQUFXLE9BQU8sT0FBTyxRQUFRLEdBQUcsUUFBUSxNQUFNO0FBQ3ZFLGlCQUFTLEtBQUssaUJBQWlCLFlBQVksUUFBUSxZQUFZO0FBQy9ELHNCQUFjO0FBQUEsVUFDWjtBQUFBLFVBQ0EsZUFBZSxRQUFRO0FBQUEsVUFDdkIsaUJBQWlCLFFBQVE7QUFBQSxVQUN6QixjQUFjLFFBQVE7QUFBQSxVQUN0QixnQkFBZ0IsUUFBUTtBQUFBLFVBQ3hCLE1BQU0sUUFBUSxTQUFTLE9BQU8sT0FBTyxNQUFNLEdBQUcsUUFBUSxJQUFJO0FBQUEsUUFDNUQsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQ0EsdUJBQW1CLFVBQVUsMkJBQTJCLFNBQVMsMkNBQTJDLE9BQU87QUFDakgsVUFBSSxPQUFPLEtBQUssT0FBTyxPQUFPLE1BQU07QUFDcEMsVUFBSSxTQUFTO0FBQUEsUUFDWCxRQUFRLEtBQUssT0FBTyxPQUFPLFFBQVE7QUFBQSxRQUNuQyxjQUFjO0FBQUEsUUFDZCxnQkFBZ0IsS0FBSyxPQUFPLE9BQU8sVUFBVSxDQUFDO0FBQUEsTUFDaEQ7QUFDQSxhQUFPLFNBQVMsS0FBSyxpQkFBaUIsT0FBTyxNQUFNO0FBQ25ELFVBQUksT0FBTyxTQUFTLEdBQUc7QUFDckIsZUFBTyxDQUFDO0FBQUEsTUFDVjtBQUNBLFVBQUksV0FBVyxDQUFDO0FBQ2hCLFVBQUksUUFBUSxLQUFLO0FBQUEsUUFDZjtBQUFBLFFBQ0EsS0FBSztBQUFBLFFBQ0w7QUFBQSxRQUNBO0FBQUEsUUFDQSxLQUFLO0FBQUEsUUFDTCxhQUFhO0FBQUEsTUFDZjtBQUNBLFVBQUksU0FBUyxHQUFHO0FBQ2QsWUFBSSxVQUFVLEtBQUssa0JBQWtCLEtBQUs7QUFDMUMsWUFBSSxNQUFNLFdBQVcsUUFBUTtBQUMzQixjQUFJLGVBQWUsUUFBUTtBQUMzQixpQkFBTyxXQUFXLFFBQVEsaUJBQWlCLGNBQWM7QUFDdkQscUJBQVMsS0FBSztBQUFBLGNBQ1osTUFBTSxLQUFLLE9BQU8sU0FBUyxpQkFBaUIsSUFBSTtBQUFBLGNBQ2hELFFBQVEsS0FBSyxPQUFPLFNBQVMsbUJBQW1CLElBQUk7QUFBQSxjQUNwRCxZQUFZLEtBQUssT0FBTyxTQUFTLHVCQUF1QixJQUFJO0FBQUEsWUFDOUQsQ0FBQztBQUNELHNCQUFVLEtBQUssa0JBQWtCLEVBQUUsS0FBSztBQUFBLFVBQzFDO0FBQUEsUUFDRixPQUFPO0FBQ0wsY0FBSSxpQkFBaUIsUUFBUTtBQUM3QixpQkFBTyxXQUFXLFFBQVEsaUJBQWlCLFFBQVEsUUFBUSxrQkFBa0IsZ0JBQWdCO0FBQzNGLHFCQUFTLEtBQUs7QUFBQSxjQUNaLE1BQU0sS0FBSyxPQUFPLFNBQVMsaUJBQWlCLElBQUk7QUFBQSxjQUNoRCxRQUFRLEtBQUssT0FBTyxTQUFTLG1CQUFtQixJQUFJO0FBQUEsY0FDcEQsWUFBWSxLQUFLLE9BQU8sU0FBUyx1QkFBdUIsSUFBSTtBQUFBLFlBQzlELENBQUM7QUFDRCxzQkFBVSxLQUFLLGtCQUFrQixFQUFFLEtBQUs7QUFBQSxVQUMxQztBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxZQUFRLG9CQUFvQjtBQUM1QixhQUFTLHVCQUF1QixZQUFZLGVBQWU7QUFDekQsVUFBSSxZQUFZO0FBQ2hCLFVBQUksT0FBTyxlQUFlLFVBQVU7QUFDbEMsb0JBQVksS0FBSyxvQkFBb0IsVUFBVTtBQUFBLE1BQ2pEO0FBQ0EsVUFBSSxVQUFVLEtBQUssT0FBTyxXQUFXLFNBQVM7QUFDOUMsVUFBSSxVQUFVLEtBQUssT0FBTyxXQUFXLFNBQVM7QUFDOUMsVUFBSSxRQUFRLEtBQUssT0FBTyxXQUFXLFNBQVMsQ0FBQyxDQUFDO0FBQzlDLFVBQUksYUFBYSxLQUFLLE9BQU8sV0FBVyxjQUFjLElBQUk7QUFDMUQsVUFBSSxpQkFBaUIsS0FBSyxPQUFPLFdBQVcsa0JBQWtCLElBQUk7QUFDbEUsVUFBSSxXQUFXLEtBQUssT0FBTyxXQUFXLFVBQVU7QUFDaEQsVUFBSSxPQUFPLEtBQUssT0FBTyxXQUFXLFFBQVEsSUFBSTtBQUM5QyxVQUFJLFdBQVcsS0FBSyxVQUFVO0FBQzVCLGNBQU0sSUFBSSxNQUFNLDBCQUEwQixPQUFPO0FBQUEsTUFDbkQ7QUFDQSxVQUFJLFlBQVk7QUFDZCxxQkFBYSxLQUFLLFVBQVUsVUFBVTtBQUFBLE1BQ3hDO0FBQ0EsZ0JBQVUsUUFBUSxJQUFJLE1BQU0sRUFBRSxJQUFJLEtBQUssU0FBUyxFQUFFLElBQUksU0FBUyxRQUFRO0FBQ3JFLGVBQU8sY0FBYyxLQUFLLFdBQVcsVUFBVSxLQUFLLEtBQUssV0FBVyxNQUFNLElBQUksS0FBSyxTQUFTLFlBQVksTUFBTSxJQUFJO0FBQUEsTUFDcEgsQ0FBQztBQUNELFdBQUssU0FBUyxTQUFTLFVBQVUsTUFBTSxJQUFJLE1BQU0sR0FBRyxJQUFJO0FBQ3hELFdBQUssV0FBVyxTQUFTLFVBQVUsU0FBUyxJQUFJO0FBQ2hELFdBQUssbUJBQW1CLEtBQUssU0FBUyxRQUFRLEVBQUUsSUFBSSxTQUFTLEdBQUc7QUFDOUQsZUFBTyxLQUFLLGlCQUFpQixZQUFZLEdBQUcsYUFBYTtBQUFBLE1BQzNELENBQUM7QUFDRCxXQUFLLGFBQWE7QUFDbEIsV0FBSyxpQkFBaUI7QUFDdEIsV0FBSyxZQUFZO0FBQ2pCLFdBQUssZ0JBQWdCO0FBQ3JCLFdBQUssT0FBTztBQUFBLElBQ2Q7QUFDQSwyQkFBdUIsWUFBWSxPQUFPLE9BQU8sbUJBQW1CLFNBQVM7QUFDN0UsMkJBQXVCLFVBQVUsV0FBVztBQUM1QywyQkFBdUIsVUFBVSxtQkFBbUIsU0FBUyxTQUFTO0FBQ3BFLFVBQUksaUJBQWlCO0FBQ3JCLFVBQUksS0FBSyxjQUFjLE1BQU07QUFDM0IseUJBQWlCLEtBQUssU0FBUyxLQUFLLFlBQVksY0FBYztBQUFBLE1BQ2hFO0FBQ0EsVUFBSSxLQUFLLFNBQVMsSUFBSSxjQUFjLEdBQUc7QUFDckMsZUFBTyxLQUFLLFNBQVMsUUFBUSxjQUFjO0FBQUEsTUFDN0M7QUFDQSxVQUFJO0FBQ0osV0FBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLGlCQUFpQixRQUFRLEVBQUUsR0FBRztBQUNqRCxZQUFJLEtBQUssaUJBQWlCLENBQUMsS0FBSyxTQUFTO0FBQ3ZDLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLDJCQUF1QixnQkFBZ0IsU0FBUyxnQ0FBZ0MsWUFBWSxlQUFlO0FBQ3pHLFVBQUksTUFBTSxPQUFPLE9BQU8sdUJBQXVCLFNBQVM7QUFDeEQsVUFBSSxRQUFRLElBQUksU0FBUyxTQUFTLFVBQVUsV0FBVyxPQUFPLFFBQVEsR0FBRyxJQUFJO0FBQzdFLFVBQUksVUFBVSxJQUFJLFdBQVcsU0FBUyxVQUFVLFdBQVcsU0FBUyxRQUFRLEdBQUcsSUFBSTtBQUNuRixVQUFJLGFBQWEsV0FBVztBQUM1QixVQUFJLGlCQUFpQixXQUFXO0FBQUEsUUFDOUIsSUFBSSxTQUFTLFFBQVE7QUFBQSxRQUNyQixJQUFJO0FBQUEsTUFDTjtBQUNBLFVBQUksT0FBTyxXQUFXO0FBQ3RCLFVBQUksZ0JBQWdCO0FBQ3BCLFVBQUksbUJBQW1CLElBQUksU0FBUyxRQUFRLEVBQUUsSUFBSSxTQUFTLEdBQUc7QUFDNUQsZUFBTyxLQUFLLGlCQUFpQixJQUFJLFlBQVksR0FBRyxhQUFhO0FBQUEsTUFDL0QsQ0FBQztBQUNELFVBQUksb0JBQW9CLFdBQVcsVUFBVSxRQUFRLEVBQUUsTUFBTTtBQUM3RCxVQUFJLHdCQUF3QixJQUFJLHNCQUFzQixDQUFDO0FBQ3ZELFVBQUksdUJBQXVCLElBQUkscUJBQXFCLENBQUM7QUFDckQsZUFBUyxJQUFJLEdBQUcsU0FBUyxrQkFBa0IsUUFBUSxJQUFJLFFBQVEsS0FBSztBQUNsRSxZQUFJLGFBQWEsa0JBQWtCLENBQUM7QUFDcEMsWUFBSSxjQUFjLElBQUksUUFBUTtBQUM5QixvQkFBWSxnQkFBZ0IsV0FBVztBQUN2QyxvQkFBWSxrQkFBa0IsV0FBVztBQUN6QyxZQUFJLFdBQVcsUUFBUTtBQUNyQixzQkFBWSxTQUFTLFFBQVEsUUFBUSxXQUFXLE1BQU07QUFDdEQsc0JBQVksZUFBZSxXQUFXO0FBQ3RDLHNCQUFZLGlCQUFpQixXQUFXO0FBQ3hDLGNBQUksV0FBVyxNQUFNO0FBQ25CLHdCQUFZLE9BQU8sTUFBTSxRQUFRLFdBQVcsSUFBSTtBQUFBLFVBQ2xEO0FBQ0EsK0JBQXFCLEtBQUssV0FBVztBQUFBLFFBQ3ZDO0FBQ0EsOEJBQXNCLEtBQUssV0FBVztBQUFBLE1BQ3hDO0FBQ0EsZ0JBQVUsSUFBSSxvQkFBb0IsS0FBSywwQkFBMEI7QUFDakUsYUFBTztBQUFBLElBQ1Q7QUFDQSwyQkFBdUIsVUFBVSxXQUFXO0FBQzVDLFdBQU8sZUFBZSx1QkFBdUIsV0FBVyxXQUFXO0FBQUEsTUFDakUsS0FBSyxXQUFXO0FBQ2QsZUFBTyxLQUFLLGlCQUFpQixNQUFNO0FBQUEsTUFDckM7QUFBQSxJQUNGLENBQUM7QUFDRCxhQUFTLFVBQVU7QUFDakIsV0FBSyxnQkFBZ0I7QUFDckIsV0FBSyxrQkFBa0I7QUFDdkIsV0FBSyxTQUFTO0FBQ2QsV0FBSyxlQUFlO0FBQ3BCLFdBQUssaUJBQWlCO0FBQ3RCLFdBQUssT0FBTztBQUFBLElBQ2Q7QUFDQSxRQUFJLG1CQUFtQixLQUFLO0FBQzVCLGFBQVMsY0FBYyxPQUFPLE9BQU87QUFDbkMsVUFBSSxJQUFJLE1BQU07QUFDZCxVQUFJLElBQUksTUFBTSxTQUFTO0FBQ3ZCLFVBQUksS0FBSyxHQUFHO0FBQ1Y7QUFBQSxNQUNGLFdBQVcsS0FBSyxHQUFHO0FBQ2pCLFlBQUksSUFBSSxNQUFNLEtBQUs7QUFDbkIsWUFBSSxJQUFJLE1BQU0sUUFBUSxDQUFDO0FBQ3ZCLFlBQUksaUJBQWlCLEdBQUcsQ0FBQyxJQUFJLEdBQUc7QUFDOUIsZ0JBQU0sS0FBSyxJQUFJO0FBQ2YsZ0JBQU0sUUFBUSxDQUFDLElBQUk7QUFBQSxRQUNyQjtBQUFBLE1BQ0YsV0FBVyxJQUFJLElBQUk7QUFDakIsaUJBQVMsSUFBSSxPQUFPLElBQUksR0FBRyxLQUFLO0FBQzlCLG1CQUFTLElBQUksR0FBRyxJQUFJLE9BQU8sS0FBSztBQUM5QixnQkFBSSxJQUFJLE1BQU0sSUFBSSxDQUFDO0FBQ25CLGdCQUFJLElBQUksTUFBTSxDQUFDO0FBQ2YsZ0JBQUksaUJBQWlCLEdBQUcsQ0FBQyxLQUFLLEdBQUc7QUFDL0I7QUFBQSxZQUNGO0FBQ0Esa0JBQU0sSUFBSSxDQUFDLElBQUk7QUFDZixrQkFBTSxDQUFDLElBQUk7QUFBQSxVQUNiO0FBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLGtCQUFVLE9BQU8sa0JBQWtCLEtBQUs7QUFBQSxNQUMxQztBQUFBLElBQ0Y7QUFDQSwyQkFBdUIsVUFBVSxpQkFBaUIsU0FBUyxnQ0FBZ0MsTUFBTSxhQUFhO0FBQzVHLFVBQUksZ0JBQWdCO0FBQ3BCLFVBQUksMEJBQTBCO0FBQzlCLFVBQUksdUJBQXVCO0FBQzNCLFVBQUkseUJBQXlCO0FBQzdCLFVBQUksaUJBQWlCO0FBQ3JCLFVBQUksZUFBZTtBQUNuQixVQUFJLFNBQVMsS0FBSztBQUNsQixVQUFJLFFBQVE7QUFDWixVQUFJLGlCQUFpQixDQUFDO0FBQ3RCLFVBQUksT0FBTyxDQUFDO0FBQ1osVUFBSSxtQkFBbUIsQ0FBQztBQUN4QixVQUFJLG9CQUFvQixDQUFDO0FBQ3pCLFVBQUksU0FBUyxLQUFLLFNBQVMsS0FBSztBQUNoQyxVQUFJLGdCQUFnQjtBQUNwQixhQUFPLFFBQVEsUUFBUTtBQUNyQixZQUFJLEtBQUssT0FBTyxLQUFLLE1BQU0sS0FBSztBQUM5QjtBQUNBO0FBQ0Esb0NBQTBCO0FBQzFCLHdCQUFjLG1CQUFtQixhQUFhO0FBQzlDLDBCQUFnQixrQkFBa0I7QUFBQSxRQUNwQyxXQUFXLEtBQUssT0FBTyxLQUFLLE1BQU0sS0FBSztBQUNyQztBQUFBLFFBQ0YsT0FBTztBQUNMLG9CQUFVLElBQUksUUFBUTtBQUN0QixrQkFBUSxnQkFBZ0I7QUFDeEIsZUFBSyxNQUFNLE9BQU8sTUFBTSxRQUFRLE9BQU87QUFDckMsZ0JBQUksS0FBSyx3QkFBd0IsTUFBTSxHQUFHLEdBQUc7QUFDM0M7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUNBLGdCQUFNLEtBQUssTUFBTSxPQUFPLEdBQUc7QUFDM0Isb0JBQVUsQ0FBQztBQUNYLGlCQUFPLFFBQVEsS0FBSztBQUNsQixzQkFBVSxPQUFPLE1BQU0sT0FBTyxJQUFJO0FBQ2xDLG9CQUFRLEtBQUs7QUFDYixvQkFBUSxLQUFLO0FBQ2Isb0JBQVEsS0FBSyxLQUFLO0FBQUEsVUFDcEI7QUFDQSxjQUFJLFFBQVEsV0FBVyxHQUFHO0FBQ3hCLGtCQUFNLElBQUksTUFBTSx3Q0FBd0M7QUFBQSxVQUMxRDtBQUNBLGNBQUksUUFBUSxXQUFXLEdBQUc7QUFDeEIsa0JBQU0sSUFBSSxNQUFNLHdDQUF3QztBQUFBLFVBQzFEO0FBQ0Esa0JBQVEsa0JBQWtCLDBCQUEwQixRQUFRLENBQUM7QUFDN0Qsb0NBQTBCLFFBQVE7QUFDbEMsY0FBSSxRQUFRLFNBQVMsR0FBRztBQUN0QixvQkFBUSxTQUFTLGlCQUFpQixRQUFRLENBQUM7QUFDM0MsOEJBQWtCLFFBQVEsQ0FBQztBQUMzQixvQkFBUSxlQUFlLHVCQUF1QixRQUFRLENBQUM7QUFDdkQsbUNBQXVCLFFBQVE7QUFDL0Isb0JBQVEsZ0JBQWdCO0FBQ3hCLG9CQUFRLGlCQUFpQix5QkFBeUIsUUFBUSxDQUFDO0FBQzNELHFDQUF5QixRQUFRO0FBQ2pDLGdCQUFJLFFBQVEsU0FBUyxHQUFHO0FBQ3RCLHNCQUFRLE9BQU8sZUFBZSxRQUFRLENBQUM7QUFDdkMsOEJBQWdCLFFBQVEsQ0FBQztBQUFBLFlBQzNCO0FBQUEsVUFDRjtBQUNBLDRCQUFrQixLQUFLLE9BQU87QUFDOUIsY0FBSSxPQUFPLFFBQVEsaUJBQWlCLFVBQVU7QUFDNUMsZ0JBQUksZ0JBQWdCLFFBQVE7QUFDNUIsbUJBQU8saUJBQWlCLFVBQVUsZUFBZTtBQUMvQywrQkFBaUIsS0FBSyxJQUFJO0FBQUEsWUFDNUI7QUFDQSxnQkFBSSxpQkFBaUIsYUFBYSxNQUFNLE1BQU07QUFDNUMsK0JBQWlCLGFBQWEsSUFBSSxDQUFDO0FBQUEsWUFDckM7QUFDQSw2QkFBaUIsYUFBYSxFQUFFLEtBQUssT0FBTztBQUFBLFVBQzlDO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxvQkFBYyxtQkFBbUIsYUFBYTtBQUM5QyxXQUFLLHNCQUFzQjtBQUMzQixlQUFTLElBQUksR0FBRyxJQUFJLGlCQUFpQixRQUFRLEtBQUs7QUFDaEQsWUFBSSxpQkFBaUIsQ0FBQyxLQUFLLE1BQU07QUFDL0Isb0JBQVUsaUJBQWlCLENBQUMsR0FBRyxLQUFLLGtDQUFrQztBQUFBLFFBQ3hFO0FBQUEsTUFDRjtBQUNBLFdBQUsscUJBQXFCLENBQUMsRUFBRSxPQUFPLEdBQUcsZ0JBQWdCO0FBQUEsSUFDekQ7QUFDQSwyQkFBdUIsVUFBVSxlQUFlLFNBQVMsOEJBQThCLFNBQVMsV0FBVyxXQUFXLGFBQWEsYUFBYSxPQUFPO0FBQ3JKLFVBQUksUUFBUSxTQUFTLEtBQUssR0FBRztBQUMzQixjQUFNLElBQUksVUFBVSxrREFBa0QsUUFBUSxTQUFTLENBQUM7QUFBQSxNQUMxRjtBQUNBLFVBQUksUUFBUSxXQUFXLElBQUksR0FBRztBQUM1QixjQUFNLElBQUksVUFBVSxvREFBb0QsUUFBUSxXQUFXLENBQUM7QUFBQSxNQUM5RjtBQUNBLGFBQU8sYUFBYSxPQUFPLFNBQVMsV0FBVyxhQUFhLEtBQUs7QUFBQSxJQUNuRTtBQUNBLDJCQUF1QixVQUFVLHFCQUFxQixTQUFTLHVDQUF1QztBQUNwRyxlQUFTLFFBQVEsR0FBRyxRQUFRLEtBQUssbUJBQW1CLFFBQVEsRUFBRSxPQUFPO0FBQ25FLFlBQUksVUFBVSxLQUFLLG1CQUFtQixLQUFLO0FBQzNDLFlBQUksUUFBUSxJQUFJLEtBQUssbUJBQW1CLFFBQVE7QUFDOUMsY0FBSSxjQUFjLEtBQUssbUJBQW1CLFFBQVEsQ0FBQztBQUNuRCxjQUFJLFFBQVEsa0JBQWtCLFlBQVksZUFBZTtBQUN2RCxvQkFBUSxzQkFBc0IsWUFBWSxrQkFBa0I7QUFDNUQ7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUNBLGdCQUFRLHNCQUFzQjtBQUFBLE1BQ2hDO0FBQUEsSUFDRjtBQUNBLDJCQUF1QixVQUFVLHNCQUFzQixTQUFTLHNDQUFzQyxPQUFPO0FBQzNHLFVBQUksU0FBUztBQUFBLFFBQ1gsZUFBZSxLQUFLLE9BQU8sT0FBTyxNQUFNO0FBQUEsUUFDeEMsaUJBQWlCLEtBQUssT0FBTyxPQUFPLFFBQVE7QUFBQSxNQUM5QztBQUNBLFVBQUksUUFBUSxLQUFLO0FBQUEsUUFDZjtBQUFBLFFBQ0EsS0FBSztBQUFBLFFBQ0w7QUFBQSxRQUNBO0FBQUEsUUFDQSxLQUFLO0FBQUEsUUFDTCxLQUFLLE9BQU8sT0FBTyxRQUFRLG1CQUFtQixvQkFBb0I7QUFBQSxNQUNwRTtBQUNBLFVBQUksU0FBUyxHQUFHO0FBQ2QsWUFBSSxVQUFVLEtBQUssbUJBQW1CLEtBQUs7QUFDM0MsWUFBSSxRQUFRLGtCQUFrQixPQUFPLGVBQWU7QUFDbEQsY0FBSSxTQUFTLEtBQUssT0FBTyxTQUFTLFVBQVUsSUFBSTtBQUNoRCxjQUFJLFdBQVcsTUFBTTtBQUNuQixxQkFBUyxLQUFLLFNBQVMsR0FBRyxNQUFNO0FBQ2hDLHFCQUFTLEtBQUssaUJBQWlCLEtBQUssWUFBWSxRQUFRLEtBQUssYUFBYTtBQUFBLFVBQzVFO0FBQ0EsY0FBSSxPQUFPLEtBQUssT0FBTyxTQUFTLFFBQVEsSUFBSTtBQUM1QyxjQUFJLFNBQVMsTUFBTTtBQUNqQixtQkFBTyxLQUFLLE9BQU8sR0FBRyxJQUFJO0FBQUEsVUFDNUI7QUFDQSxpQkFBTztBQUFBLFlBQ0w7QUFBQSxZQUNBLE1BQU0sS0FBSyxPQUFPLFNBQVMsZ0JBQWdCLElBQUk7QUFBQSxZQUMvQyxRQUFRLEtBQUssT0FBTyxTQUFTLGtCQUFrQixJQUFJO0FBQUEsWUFDbkQ7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsUUFDTCxRQUFRO0FBQUEsUUFDUixNQUFNO0FBQUEsUUFDTixRQUFRO0FBQUEsUUFDUixNQUFNO0FBQUEsTUFDUjtBQUFBLElBQ0Y7QUFDQSwyQkFBdUIsVUFBVSwwQkFBMEIsU0FBUyxpREFBaUQ7QUFDbkgsVUFBSSxDQUFDLEtBQUssZ0JBQWdCO0FBQ3hCLGVBQU87QUFBQSxNQUNUO0FBQ0EsYUFBTyxLQUFLLGVBQWUsVUFBVSxLQUFLLFNBQVMsS0FBSyxLQUFLLENBQUMsS0FBSyxlQUFlLEtBQUssU0FBUyxJQUFJO0FBQ2xHLGVBQU8sTUFBTTtBQUFBLE1BQ2YsQ0FBQztBQUFBLElBQ0g7QUFDQSwyQkFBdUIsVUFBVSxtQkFBbUIsU0FBUyxtQ0FBbUMsU0FBUyxlQUFlO0FBQ3RILFVBQUksQ0FBQyxLQUFLLGdCQUFnQjtBQUN4QixlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUksUUFBUSxLQUFLLGlCQUFpQixPQUFPO0FBQ3pDLFVBQUksU0FBUyxHQUFHO0FBQ2QsZUFBTyxLQUFLLGVBQWUsS0FBSztBQUFBLE1BQ2xDO0FBQ0EsVUFBSSxpQkFBaUI7QUFDckIsVUFBSSxLQUFLLGNBQWMsTUFBTTtBQUMzQix5QkFBaUIsS0FBSyxTQUFTLEtBQUssWUFBWSxjQUFjO0FBQUEsTUFDaEU7QUFDQSxVQUFJO0FBQ0osVUFBSSxLQUFLLGNBQWMsU0FBUyxNQUFNLEtBQUssU0FBUyxLQUFLLFVBQVUsSUFBSTtBQUNyRSxZQUFJLGlCQUFpQixlQUFlLFFBQVEsY0FBYyxFQUFFO0FBQzVELFlBQUksSUFBSSxVQUFVLFVBQVUsS0FBSyxTQUFTLElBQUksY0FBYyxHQUFHO0FBQzdELGlCQUFPLEtBQUssZUFBZSxLQUFLLFNBQVMsUUFBUSxjQUFjLENBQUM7QUFBQSxRQUNsRTtBQUNBLGFBQUssQ0FBQyxJQUFJLFFBQVEsSUFBSSxRQUFRLFFBQVEsS0FBSyxTQUFTLElBQUksTUFBTSxjQUFjLEdBQUc7QUFDN0UsaUJBQU8sS0FBSyxlQUFlLEtBQUssU0FBUyxRQUFRLE1BQU0sY0FBYyxDQUFDO0FBQUEsUUFDeEU7QUFBQSxNQUNGO0FBQ0EsVUFBSSxlQUFlO0FBQ2pCLGVBQU87QUFBQSxNQUNULE9BQU87QUFDTCxjQUFNLElBQUksTUFBTSxNQUFNLGlCQUFpQiw0QkFBNEI7QUFBQSxNQUNyRTtBQUFBLElBQ0Y7QUFDQSwyQkFBdUIsVUFBVSx1QkFBdUIsU0FBUyx1Q0FBdUMsT0FBTztBQUM3RyxVQUFJLFNBQVMsS0FBSyxPQUFPLE9BQU8sUUFBUTtBQUN4QyxlQUFTLEtBQUssaUJBQWlCLE1BQU07QUFDckMsVUFBSSxTQUFTLEdBQUc7QUFDZCxlQUFPO0FBQUEsVUFDTCxNQUFNO0FBQUEsVUFDTixRQUFRO0FBQUEsVUFDUixZQUFZO0FBQUEsUUFDZDtBQUFBLE1BQ0Y7QUFDQSxVQUFJLFNBQVM7QUFBQSxRQUNYO0FBQUEsUUFDQSxjQUFjLEtBQUssT0FBTyxPQUFPLE1BQU07QUFBQSxRQUN2QyxnQkFBZ0IsS0FBSyxPQUFPLE9BQU8sUUFBUTtBQUFBLE1BQzdDO0FBQ0EsVUFBSSxRQUFRLEtBQUs7QUFBQSxRQUNmO0FBQUEsUUFDQSxLQUFLO0FBQUEsUUFDTDtBQUFBLFFBQ0E7QUFBQSxRQUNBLEtBQUs7QUFBQSxRQUNMLEtBQUssT0FBTyxPQUFPLFFBQVEsbUJBQW1CLG9CQUFvQjtBQUFBLE1BQ3BFO0FBQ0EsVUFBSSxTQUFTLEdBQUc7QUFDZCxZQUFJLFVBQVUsS0FBSyxrQkFBa0IsS0FBSztBQUMxQyxZQUFJLFFBQVEsV0FBVyxPQUFPLFFBQVE7QUFDcEMsaUJBQU87QUFBQSxZQUNMLE1BQU0sS0FBSyxPQUFPLFNBQVMsaUJBQWlCLElBQUk7QUFBQSxZQUNoRCxRQUFRLEtBQUssT0FBTyxTQUFTLG1CQUFtQixJQUFJO0FBQUEsWUFDcEQsWUFBWSxLQUFLLE9BQU8sU0FBUyx1QkFBdUIsSUFBSTtBQUFBLFVBQzlEO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsUUFDTCxNQUFNO0FBQUEsUUFDTixRQUFRO0FBQUEsUUFDUixZQUFZO0FBQUEsTUFDZDtBQUFBLElBQ0Y7QUFDQSxZQUFRLHlCQUF5QjtBQUNqQyxhQUFTLHlCQUF5QixZQUFZLGVBQWU7QUFDM0QsVUFBSSxZQUFZO0FBQ2hCLFVBQUksT0FBTyxlQUFlLFVBQVU7QUFDbEMsb0JBQVksS0FBSyxvQkFBb0IsVUFBVTtBQUFBLE1BQ2pEO0FBQ0EsVUFBSSxVQUFVLEtBQUssT0FBTyxXQUFXLFNBQVM7QUFDOUMsVUFBSSxXQUFXLEtBQUssT0FBTyxXQUFXLFVBQVU7QUFDaEQsVUFBSSxXQUFXLEtBQUssVUFBVTtBQUM1QixjQUFNLElBQUksTUFBTSwwQkFBMEIsT0FBTztBQUFBLE1BQ25EO0FBQ0EsV0FBSyxXQUFXLElBQUksU0FBUztBQUM3QixXQUFLLFNBQVMsSUFBSSxTQUFTO0FBQzNCLFVBQUksYUFBYTtBQUFBLFFBQ2YsTUFBTTtBQUFBLFFBQ04sUUFBUTtBQUFBLE1BQ1Y7QUFDQSxXQUFLLFlBQVksU0FBUyxJQUFJLFNBQVMsR0FBRztBQUN4QyxZQUFJLEVBQUUsS0FBSztBQUNULGdCQUFNLElBQUksTUFBTSxvREFBb0Q7QUFBQSxRQUN0RTtBQUNBLFlBQUksU0FBUyxLQUFLLE9BQU8sR0FBRyxRQUFRO0FBQ3BDLFlBQUksYUFBYSxLQUFLLE9BQU8sUUFBUSxNQUFNO0FBQzNDLFlBQUksZUFBZSxLQUFLLE9BQU8sUUFBUSxRQUFRO0FBQy9DLFlBQUksYUFBYSxXQUFXLFFBQVEsZUFBZSxXQUFXLFFBQVEsZUFBZSxXQUFXLFFBQVE7QUFDdEcsZ0JBQU0sSUFBSSxNQUFNLHNEQUFzRDtBQUFBLFFBQ3hFO0FBQ0EscUJBQWE7QUFDYixlQUFPO0FBQUEsVUFDTCxpQkFBaUI7QUFBQTtBQUFBO0FBQUEsWUFHZixlQUFlLGFBQWE7QUFBQSxZQUM1QixpQkFBaUIsZUFBZTtBQUFBLFVBQ2xDO0FBQUEsVUFDQSxVQUFVLElBQUksbUJBQW1CLEtBQUssT0FBTyxHQUFHLEtBQUssR0FBRyxhQUFhO0FBQUEsUUFDdkU7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQ0EsNkJBQXlCLFlBQVksT0FBTyxPQUFPLG1CQUFtQixTQUFTO0FBQy9FLDZCQUF5QixVQUFVLGNBQWM7QUFDakQsNkJBQXlCLFVBQVUsV0FBVztBQUM5QyxXQUFPLGVBQWUseUJBQXlCLFdBQVcsV0FBVztBQUFBLE1BQ25FLEtBQUssV0FBVztBQUNkLFlBQUksVUFBVSxDQUFDO0FBQ2YsaUJBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxVQUFVLFFBQVEsS0FBSztBQUM5QyxtQkFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLFVBQVUsQ0FBQyxFQUFFLFNBQVMsUUFBUSxRQUFRLEtBQUs7QUFDbEUsb0JBQVEsS0FBSyxLQUFLLFVBQVUsQ0FBQyxFQUFFLFNBQVMsUUFBUSxDQUFDLENBQUM7QUFBQSxVQUNwRDtBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0YsQ0FBQztBQUNELDZCQUF5QixVQUFVLHNCQUFzQixTQUFTLDZDQUE2QyxPQUFPO0FBQ3BILFVBQUksU0FBUztBQUFBLFFBQ1gsZUFBZSxLQUFLLE9BQU8sT0FBTyxNQUFNO0FBQUEsUUFDeEMsaUJBQWlCLEtBQUssT0FBTyxPQUFPLFFBQVE7QUFBQSxNQUM5QztBQUNBLFVBQUksZUFBZSxhQUFhO0FBQUEsUUFDOUI7QUFBQSxRQUNBLEtBQUs7QUFBQSxRQUNMLFNBQVMsU0FBUyxVQUFVO0FBQzFCLGNBQUksTUFBTSxRQUFRLGdCQUFnQixTQUFTLGdCQUFnQjtBQUMzRCxjQUFJLEtBQUs7QUFDUCxtQkFBTztBQUFBLFVBQ1Q7QUFDQSxpQkFBTyxRQUFRLGtCQUFrQixTQUFTLGdCQUFnQjtBQUFBLFFBQzVEO0FBQUEsTUFDRjtBQUNBLFVBQUksVUFBVSxLQUFLLFVBQVUsWUFBWTtBQUN6QyxVQUFJLENBQUMsU0FBUztBQUNaLGVBQU87QUFBQSxVQUNMLFFBQVE7QUFBQSxVQUNSLE1BQU07QUFBQSxVQUNOLFFBQVE7QUFBQSxVQUNSLE1BQU07QUFBQSxRQUNSO0FBQUEsTUFDRjtBQUNBLGFBQU8sUUFBUSxTQUFTLG9CQUFvQjtBQUFBLFFBQzFDLE1BQU0sT0FBTyxpQkFBaUIsUUFBUSxnQkFBZ0IsZ0JBQWdCO0FBQUEsUUFDdEUsUUFBUSxPQUFPLG1CQUFtQixRQUFRLGdCQUFnQixrQkFBa0IsT0FBTyxnQkFBZ0IsUUFBUSxnQkFBZ0Isa0JBQWtCLElBQUk7QUFBQSxRQUNqSixNQUFNLE1BQU07QUFBQSxNQUNkLENBQUM7QUFBQSxJQUNIO0FBQ0EsNkJBQXlCLFVBQVUsMEJBQTBCLFNBQVMsbURBQW1EO0FBQ3ZILGFBQU8sS0FBSyxVQUFVLE1BQU0sU0FBUyxHQUFHO0FBQ3RDLGVBQU8sRUFBRSxTQUFTLHdCQUF3QjtBQUFBLE1BQzVDLENBQUM7QUFBQSxJQUNIO0FBQ0EsNkJBQXlCLFVBQVUsbUJBQW1CLFNBQVMsMENBQTBDLFNBQVMsZUFBZTtBQUMvSCxlQUFTLElBQUksR0FBRyxJQUFJLEtBQUssVUFBVSxRQUFRLEtBQUs7QUFDOUMsWUFBSSxVQUFVLEtBQUssVUFBVSxDQUFDO0FBQzlCLFlBQUksVUFBVSxRQUFRLFNBQVMsaUJBQWlCLFNBQVMsSUFBSTtBQUM3RCxZQUFJLFNBQVM7QUFDWCxpQkFBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQ0EsVUFBSSxlQUFlO0FBQ2pCLGVBQU87QUFBQSxNQUNULE9BQU87QUFDTCxjQUFNLElBQUksTUFBTSxNQUFNLFVBQVUsNEJBQTRCO0FBQUEsTUFDOUQ7QUFBQSxJQUNGO0FBQ0EsNkJBQXlCLFVBQVUsdUJBQXVCLFNBQVMsOENBQThDLE9BQU87QUFDdEgsZUFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLFVBQVUsUUFBUSxLQUFLO0FBQzlDLFlBQUksVUFBVSxLQUFLLFVBQVUsQ0FBQztBQUM5QixZQUFJLFFBQVEsU0FBUyxpQkFBaUIsS0FBSyxPQUFPLE9BQU8sUUFBUSxDQUFDLE1BQU0sSUFBSTtBQUMxRTtBQUFBLFFBQ0Y7QUFDQSxZQUFJLG9CQUFvQixRQUFRLFNBQVMscUJBQXFCLEtBQUs7QUFDbkUsWUFBSSxtQkFBbUI7QUFDckIsY0FBSSxNQUFNO0FBQUEsWUFDUixNQUFNLGtCQUFrQixRQUFRLFFBQVEsZ0JBQWdCLGdCQUFnQjtBQUFBLFlBQ3hFLFFBQVEsa0JBQWtCLFVBQVUsUUFBUSxnQkFBZ0Isa0JBQWtCLGtCQUFrQixPQUFPLFFBQVEsZ0JBQWdCLGtCQUFrQixJQUFJO0FBQUEsVUFDdko7QUFDQSxpQkFBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQ0EsYUFBTztBQUFBLFFBQ0wsTUFBTTtBQUFBLFFBQ04sUUFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQ0EsNkJBQXlCLFVBQVUsaUJBQWlCLFNBQVMsdUNBQXVDLE1BQU0sYUFBYTtBQUNySCxXQUFLLHNCQUFzQixDQUFDO0FBQzVCLFdBQUsscUJBQXFCLENBQUM7QUFDM0IsZUFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLFVBQVUsUUFBUSxLQUFLO0FBQzlDLFlBQUksVUFBVSxLQUFLLFVBQVUsQ0FBQztBQUM5QixZQUFJLGtCQUFrQixRQUFRLFNBQVM7QUFDdkMsaUJBQVMsSUFBSSxHQUFHLElBQUksZ0JBQWdCLFFBQVEsS0FBSztBQUMvQyxjQUFJLFVBQVUsZ0JBQWdCLENBQUM7QUFDL0IsY0FBSSxTQUFTLFFBQVEsU0FBUyxTQUFTLEdBQUcsUUFBUSxNQUFNO0FBQ3hELG1CQUFTLEtBQUssaUJBQWlCLFFBQVEsU0FBUyxZQUFZLFFBQVEsS0FBSyxhQUFhO0FBQ3RGLGVBQUssU0FBUyxJQUFJLE1BQU07QUFDeEIsbUJBQVMsS0FBSyxTQUFTLFFBQVEsTUFBTTtBQUNyQyxjQUFJLE9BQU87QUFDWCxjQUFJLFFBQVEsTUFBTTtBQUNoQixtQkFBTyxRQUFRLFNBQVMsT0FBTyxHQUFHLFFBQVEsSUFBSTtBQUM5QyxpQkFBSyxPQUFPLElBQUksSUFBSTtBQUNwQixtQkFBTyxLQUFLLE9BQU8sUUFBUSxJQUFJO0FBQUEsVUFDakM7QUFDQSxjQUFJLGtCQUFrQjtBQUFBLFlBQ3BCO0FBQUEsWUFDQSxlQUFlLFFBQVEsaUJBQWlCLFFBQVEsZ0JBQWdCLGdCQUFnQjtBQUFBLFlBQ2hGLGlCQUFpQixRQUFRLG1CQUFtQixRQUFRLGdCQUFnQixrQkFBa0IsUUFBUSxnQkFBZ0IsUUFBUSxnQkFBZ0Isa0JBQWtCLElBQUk7QUFBQSxZQUM1SixjQUFjLFFBQVE7QUFBQSxZQUN0QixnQkFBZ0IsUUFBUTtBQUFBLFlBQ3hCO0FBQUEsVUFDRjtBQUNBLGVBQUssb0JBQW9CLEtBQUssZUFBZTtBQUM3QyxjQUFJLE9BQU8sZ0JBQWdCLGlCQUFpQixVQUFVO0FBQ3BELGlCQUFLLG1CQUFtQixLQUFLLGVBQWU7QUFBQSxVQUM5QztBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsZ0JBQVUsS0FBSyxxQkFBcUIsS0FBSyxtQ0FBbUM7QUFDNUUsZ0JBQVUsS0FBSyxvQkFBb0IsS0FBSywwQkFBMEI7QUFBQSxJQUNwRTtBQUNBLFlBQVEsMkJBQTJCO0FBQUEsRUFDckM7QUFDRixDQUFDO0FBR0QsSUFBSSxzQkFBc0IsV0FBVztBQUFBLEVBQ25DLGdEQUFnRCxTQUFTO0FBQ3ZELFFBQUkscUJBQXFCLDZCQUE2QixFQUFFO0FBQ3hELFFBQUksT0FBTyxhQUFhO0FBQ3hCLFFBQUksZ0JBQWdCO0FBQ3BCLFFBQUksZUFBZTtBQUNuQixRQUFJLGVBQWU7QUFDbkIsYUFBUyxXQUFXLE9BQU8sU0FBUyxTQUFTLFNBQVMsT0FBTztBQUMzRCxXQUFLLFdBQVcsQ0FBQztBQUNqQixXQUFLLGlCQUFpQixDQUFDO0FBQ3ZCLFdBQUssT0FBTyxTQUFTLE9BQU8sT0FBTztBQUNuQyxXQUFLLFNBQVMsV0FBVyxPQUFPLE9BQU87QUFDdkMsV0FBSyxTQUFTLFdBQVcsT0FBTyxPQUFPO0FBQ3ZDLFdBQUssT0FBTyxTQUFTLE9BQU8sT0FBTztBQUNuQyxXQUFLLFlBQVksSUFBSTtBQUNyQixVQUFJLFdBQVc7QUFDYixhQUFLLElBQUksT0FBTztBQUFBLElBQ3BCO0FBQ0EsZUFBVywwQkFBMEIsU0FBUyxtQ0FBbUMsZ0JBQWdCLG9CQUFvQixlQUFlO0FBQ2xJLFVBQUksT0FBTyxJQUFJLFdBQVc7QUFDMUIsVUFBSSxpQkFBaUIsZUFBZSxNQUFNLGFBQWE7QUFDdkQsVUFBSSxzQkFBc0I7QUFDMUIsVUFBSSxnQkFBZ0IsV0FBVztBQUM3QixZQUFJLGVBQWUsWUFBWTtBQUMvQixZQUFJLFVBQVUsWUFBWSxLQUFLO0FBQy9CLGVBQU8sZUFBZTtBQUN0QixpQkFBUyxjQUFjO0FBQ3JCLGlCQUFPLHNCQUFzQixlQUFlLFNBQVMsZUFBZSxxQkFBcUIsSUFBSTtBQUFBLFFBQy9GO0FBQUEsTUFDRjtBQUNBLFVBQUksb0JBQW9CLEdBQUcsc0JBQXNCO0FBQ2pELFVBQUksY0FBYztBQUNsQix5QkFBbUIsWUFBWSxTQUFTLFNBQVM7QUFDL0MsWUFBSSxnQkFBZ0IsTUFBTTtBQUN4QixjQUFJLG9CQUFvQixRQUFRLGVBQWU7QUFDN0MsK0JBQW1CLGFBQWEsY0FBYyxDQUFDO0FBQy9DO0FBQ0Esa0NBQXNCO0FBQUEsVUFDeEIsT0FBTztBQUNMLGdCQUFJLFdBQVcsZUFBZSxtQkFBbUIsS0FBSztBQUN0RCxnQkFBSSxPQUFPLFNBQVMsT0FBTyxHQUFHLFFBQVEsa0JBQWtCLG1CQUFtQjtBQUMzRSwyQkFBZSxtQkFBbUIsSUFBSSxTQUFTLE9BQU8sUUFBUSxrQkFBa0IsbUJBQW1CO0FBQ25HLGtDQUFzQixRQUFRO0FBQzlCLCtCQUFtQixhQUFhLElBQUk7QUFDcEMsMEJBQWM7QUFDZDtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0EsZUFBTyxvQkFBb0IsUUFBUSxlQUFlO0FBQ2hELGVBQUssSUFBSSxjQUFjLENBQUM7QUFDeEI7QUFBQSxRQUNGO0FBQ0EsWUFBSSxzQkFBc0IsUUFBUSxpQkFBaUI7QUFDakQsY0FBSSxXQUFXLGVBQWUsbUJBQW1CLEtBQUs7QUFDdEQsZUFBSyxJQUFJLFNBQVMsT0FBTyxHQUFHLFFBQVEsZUFBZSxDQUFDO0FBQ3BELHlCQUFlLG1CQUFtQixJQUFJLFNBQVMsT0FBTyxRQUFRLGVBQWU7QUFDN0UsZ0NBQXNCLFFBQVE7QUFBQSxRQUNoQztBQUNBLHNCQUFjO0FBQUEsTUFDaEIsR0FBRyxJQUFJO0FBQ1AsVUFBSSxzQkFBc0IsZUFBZSxRQUFRO0FBQy9DLFlBQUksYUFBYTtBQUNmLDZCQUFtQixhQUFhLGNBQWMsQ0FBQztBQUFBLFFBQ2pEO0FBQ0EsYUFBSyxJQUFJLGVBQWUsT0FBTyxtQkFBbUIsRUFBRSxLQUFLLEVBQUUsQ0FBQztBQUFBLE1BQzlEO0FBQ0EseUJBQW1CLFFBQVEsUUFBUSxTQUFTLFlBQVk7QUFDdEQsWUFBSSxVQUFVLG1CQUFtQixpQkFBaUIsVUFBVTtBQUM1RCxZQUFJLFdBQVcsTUFBTTtBQUNuQixjQUFJLGlCQUFpQixNQUFNO0FBQ3pCLHlCQUFhLEtBQUssS0FBSyxlQUFlLFVBQVU7QUFBQSxVQUNsRDtBQUNBLGVBQUssaUJBQWlCLFlBQVksT0FBTztBQUFBLFFBQzNDO0FBQUEsTUFDRixDQUFDO0FBQ0QsYUFBTztBQUNQLGVBQVMsbUJBQW1CLFNBQVMsTUFBTTtBQUN6QyxZQUFJLFlBQVksUUFBUSxRQUFRLFdBQVcsUUFBUTtBQUNqRCxlQUFLLElBQUksSUFBSTtBQUFBLFFBQ2YsT0FBTztBQUNMLGNBQUksU0FBUyxnQkFBZ0IsS0FBSyxLQUFLLGVBQWUsUUFBUSxNQUFNLElBQUksUUFBUTtBQUNoRixlQUFLLElBQUksSUFBSTtBQUFBLFlBQ1gsUUFBUTtBQUFBLFlBQ1IsUUFBUTtBQUFBLFlBQ1I7QUFBQSxZQUNBO0FBQUEsWUFDQSxRQUFRO0FBQUEsVUFDVixDQUFDO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsZUFBVyxVQUFVLE1BQU0sU0FBUyxlQUFlLFFBQVE7QUFDekQsVUFBSSxNQUFNLFFBQVEsTUFBTSxHQUFHO0FBQ3pCLGVBQU8sUUFBUSxTQUFTLE9BQU87QUFDN0IsZUFBSyxJQUFJLEtBQUs7QUFBQSxRQUNoQixHQUFHLElBQUk7QUFBQSxNQUNULFdBQVcsT0FBTyxZQUFZLEtBQUssT0FBTyxXQUFXLFVBQVU7QUFDN0QsWUFBSSxRQUFRO0FBQ1YsZUFBSyxTQUFTLEtBQUssTUFBTTtBQUFBLFFBQzNCO0FBQUEsTUFDRixPQUFPO0FBQ0wsY0FBTSxJQUFJO0FBQUEsVUFDUixnRkFBZ0Y7QUFBQSxRQUNsRjtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLGVBQVcsVUFBVSxVQUFVLFNBQVMsbUJBQW1CLFFBQVE7QUFDakUsVUFBSSxNQUFNLFFBQVEsTUFBTSxHQUFHO0FBQ3pCLGlCQUFTLElBQUksT0FBTyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7QUFDM0MsZUFBSyxRQUFRLE9BQU8sQ0FBQyxDQUFDO0FBQUEsUUFDeEI7QUFBQSxNQUNGLFdBQVcsT0FBTyxZQUFZLEtBQUssT0FBTyxXQUFXLFVBQVU7QUFDN0QsYUFBSyxTQUFTLFFBQVEsTUFBTTtBQUFBLE1BQzlCLE9BQU87QUFDTCxjQUFNLElBQUk7QUFBQSxVQUNSLGdGQUFnRjtBQUFBLFFBQ2xGO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBQ0EsZUFBVyxVQUFVLE9BQU8sU0FBUyxnQkFBZ0IsS0FBSztBQUN4RCxVQUFJO0FBQ0osZUFBUyxJQUFJLEdBQUcsTUFBTSxLQUFLLFNBQVMsUUFBUSxJQUFJLEtBQUssS0FBSztBQUN4RCxnQkFBUSxLQUFLLFNBQVMsQ0FBQztBQUN2QixZQUFJLE1BQU0sWUFBWSxHQUFHO0FBQ3ZCLGdCQUFNLEtBQUssR0FBRztBQUFBLFFBQ2hCLE9BQU87QUFDTCxjQUFJLFVBQVUsSUFBSTtBQUNoQixnQkFBSSxPQUFPO0FBQUEsY0FDVCxRQUFRLEtBQUs7QUFBQSxjQUNiLE1BQU0sS0FBSztBQUFBLGNBQ1gsUUFBUSxLQUFLO0FBQUEsY0FDYixNQUFNLEtBQUs7QUFBQSxZQUNiLENBQUM7QUFBQSxVQUNIO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsZUFBVyxVQUFVLE9BQU8sU0FBUyxnQkFBZ0IsTUFBTTtBQUN6RCxVQUFJO0FBQ0osVUFBSTtBQUNKLFVBQUksTUFBTSxLQUFLLFNBQVM7QUFDeEIsVUFBSSxNQUFNLEdBQUc7QUFDWCxzQkFBYyxDQUFDO0FBQ2YsYUFBSyxJQUFJLEdBQUcsSUFBSSxNQUFNLEdBQUcsS0FBSztBQUM1QixzQkFBWSxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUM7QUFDakMsc0JBQVksS0FBSyxJQUFJO0FBQUEsUUFDdkI7QUFDQSxvQkFBWSxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUM7QUFDakMsYUFBSyxXQUFXO0FBQUEsTUFDbEI7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLGVBQVcsVUFBVSxlQUFlLFNBQVMsd0JBQXdCLFVBQVUsY0FBYztBQUMzRixVQUFJLFlBQVksS0FBSyxTQUFTLEtBQUssU0FBUyxTQUFTLENBQUM7QUFDdEQsVUFBSSxVQUFVLFlBQVksR0FBRztBQUMzQixrQkFBVSxhQUFhLFVBQVUsWUFBWTtBQUFBLE1BQy9DLFdBQVcsT0FBTyxjQUFjLFVBQVU7QUFDeEMsYUFBSyxTQUFTLEtBQUssU0FBUyxTQUFTLENBQUMsSUFBSSxVQUFVLFFBQVEsVUFBVSxZQUFZO0FBQUEsTUFDcEYsT0FBTztBQUNMLGFBQUssU0FBUyxLQUFLLEdBQUcsUUFBUSxVQUFVLFlBQVksQ0FBQztBQUFBLE1BQ3ZEO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFDQSxlQUFXLFVBQVUsbUJBQW1CLFNBQVMsNEJBQTRCLGFBQWEsZ0JBQWdCO0FBQ3hHLFdBQUssZUFBZSxLQUFLLFlBQVksV0FBVyxDQUFDLElBQUk7QUFBQSxJQUN2RDtBQUNBLGVBQVcsVUFBVSxxQkFBcUIsU0FBUyw4QkFBOEIsS0FBSztBQUNwRixlQUFTLElBQUksR0FBRyxNQUFNLEtBQUssU0FBUyxRQUFRLElBQUksS0FBSyxLQUFLO0FBQ3hELFlBQUksS0FBSyxTQUFTLENBQUMsRUFBRSxZQUFZLEdBQUc7QUFDbEMsZUFBSyxTQUFTLENBQUMsRUFBRSxtQkFBbUIsR0FBRztBQUFBLFFBQ3pDO0FBQUEsTUFDRjtBQUNBLFVBQUksVUFBVSxPQUFPLEtBQUssS0FBSyxjQUFjO0FBQzdDLGVBQVMsSUFBSSxHQUFHLE1BQU0sUUFBUSxRQUFRLElBQUksS0FBSyxLQUFLO0FBQ2xELFlBQUksS0FBSyxjQUFjLFFBQVEsQ0FBQyxDQUFDLEdBQUcsS0FBSyxlQUFlLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFBQSxNQUNyRTtBQUFBLElBQ0Y7QUFDQSxlQUFXLFVBQVUsV0FBVyxTQUFTLHNCQUFzQjtBQUM3RCxVQUFJLE1BQU07QUFDVixXQUFLLEtBQUssU0FBUyxPQUFPO0FBQ3hCLGVBQU87QUFBQSxNQUNULENBQUM7QUFDRCxhQUFPO0FBQUEsSUFDVDtBQUNBLGVBQVcsVUFBVSx3QkFBd0IsU0FBUyxpQ0FBaUMsT0FBTztBQUM1RixVQUFJLFlBQVk7QUFBQSxRQUNkLE1BQU07QUFBQSxRQUNOLE1BQU07QUFBQSxRQUNOLFFBQVE7QUFBQSxNQUNWO0FBQ0EsVUFBSSxNQUFNLElBQUksbUJBQW1CLEtBQUs7QUFDdEMsVUFBSSxzQkFBc0I7QUFDMUIsVUFBSSxxQkFBcUI7QUFDekIsVUFBSSxtQkFBbUI7QUFDdkIsVUFBSSxxQkFBcUI7QUFDekIsVUFBSSxtQkFBbUI7QUFDdkIsV0FBSyxLQUFLLFNBQVMsT0FBTyxVQUFVO0FBQ2xDLGtCQUFVLFFBQVE7QUFDbEIsWUFBSSxTQUFTLFdBQVcsUUFBUSxTQUFTLFNBQVMsUUFBUSxTQUFTLFdBQVcsTUFBTTtBQUNsRixjQUFJLHVCQUF1QixTQUFTLFVBQVUscUJBQXFCLFNBQVMsUUFBUSx1QkFBdUIsU0FBUyxVQUFVLHFCQUFxQixTQUFTLE1BQU07QUFDaEssZ0JBQUksV0FBVztBQUFBLGNBQ2IsUUFBUSxTQUFTO0FBQUEsY0FDakIsVUFBVTtBQUFBLGdCQUNSLE1BQU0sU0FBUztBQUFBLGdCQUNmLFFBQVEsU0FBUztBQUFBLGNBQ25CO0FBQUEsY0FDQSxXQUFXO0FBQUEsZ0JBQ1QsTUFBTSxVQUFVO0FBQUEsZ0JBQ2hCLFFBQVEsVUFBVTtBQUFBLGNBQ3BCO0FBQUEsY0FDQSxNQUFNLFNBQVM7QUFBQSxZQUNqQixDQUFDO0FBQUEsVUFDSDtBQUNBLCtCQUFxQixTQUFTO0FBQzlCLDZCQUFtQixTQUFTO0FBQzVCLCtCQUFxQixTQUFTO0FBQzlCLDZCQUFtQixTQUFTO0FBQzVCLGdDQUFzQjtBQUFBLFFBQ3hCLFdBQVcscUJBQXFCO0FBQzlCLGNBQUksV0FBVztBQUFBLFlBQ2IsV0FBVztBQUFBLGNBQ1QsTUFBTSxVQUFVO0FBQUEsY0FDaEIsUUFBUSxVQUFVO0FBQUEsWUFDcEI7QUFBQSxVQUNGLENBQUM7QUFDRCwrQkFBcUI7QUFDckIsZ0NBQXNCO0FBQUEsUUFDeEI7QUFDQSxpQkFBUyxNQUFNLEdBQUcsU0FBUyxNQUFNLFFBQVEsTUFBTSxRQUFRLE9BQU87QUFDNUQsY0FBSSxNQUFNLFdBQVcsR0FBRyxNQUFNLGNBQWM7QUFDMUMsc0JBQVU7QUFDVixzQkFBVSxTQUFTO0FBQ25CLGdCQUFJLE1BQU0sTUFBTSxRQUFRO0FBQ3RCLG1DQUFxQjtBQUNyQixvQ0FBc0I7QUFBQSxZQUN4QixXQUFXLHFCQUFxQjtBQUM5QixrQkFBSSxXQUFXO0FBQUEsZ0JBQ2IsUUFBUSxTQUFTO0FBQUEsZ0JBQ2pCLFVBQVU7QUFBQSxrQkFDUixNQUFNLFNBQVM7QUFBQSxrQkFDZixRQUFRLFNBQVM7QUFBQSxnQkFDbkI7QUFBQSxnQkFDQSxXQUFXO0FBQUEsa0JBQ1QsTUFBTSxVQUFVO0FBQUEsa0JBQ2hCLFFBQVEsVUFBVTtBQUFBLGdCQUNwQjtBQUFBLGdCQUNBLE1BQU0sU0FBUztBQUFBLGNBQ2pCLENBQUM7QUFBQSxZQUNIO0FBQUEsVUFDRixPQUFPO0FBQ0wsc0JBQVU7QUFBQSxVQUNaO0FBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUNELFdBQUssbUJBQW1CLFNBQVMsWUFBWSxlQUFlO0FBQzFELFlBQUksaUJBQWlCLFlBQVksYUFBYTtBQUFBLE1BQ2hELENBQUM7QUFDRCxhQUFPLEVBQUUsTUFBTSxVQUFVLE1BQU0sSUFBSTtBQUFBLElBQ3JDO0FBQ0EsWUFBUSxhQUFhO0FBQUEsRUFDdkI7QUFDRixDQUFDO0FBR0QsSUFBSSxxQkFBcUIsV0FBVztBQUFBLEVBQ2xDLDJDQUEyQyxTQUFTO0FBQ2xELFlBQVEscUJBQXFCLDZCQUE2QixFQUFFO0FBQzVELFlBQVEsb0JBQW9CLDRCQUE0QixFQUFFO0FBQzFELFlBQVEsYUFBYSxvQkFBb0IsRUFBRTtBQUFBLEVBQzdDO0FBQ0YsQ0FBQztBQUdELElBQUksdUJBQXVCLFFBQVEsbUJBQW1CLEdBQUcsQ0FBQztBQUMxRCxlQUFlLFVBQVUsbUJBQW1CLE1BQU07QUFDaEQsUUFBTSxNQUFNLElBQUksSUFBSSxPQUFPLFNBQVMsTUFBTTtBQUMxQyxNQUFJLFdBQVcsZUFBZSxLQUFLLEdBQUc7QUFDdEMsUUFBTSxXQUFXLE1BQU0sTUFBTSxJQUFJLFNBQVMsR0FBRztBQUFBLElBQzNDLFFBQVE7QUFBQSxJQUNSLE1BQU0sS0FBSyxVQUFVLElBQUk7QUFBQSxFQUMzQixDQUFDO0FBQ0QsU0FBTyxTQUFTLFFBQVEsSUFBSSxjQUFjLEdBQUcsV0FBVyxrQkFBa0IsSUFBSSxTQUFTLEtBQUssSUFBSSxTQUFTLEtBQUs7QUFDaEg7QUFDQSxTQUFTLGVBQWUsUUFBUSxpQkFBaUIsQ0FBQyxHQUFHO0FBQ25ELFNBQU8sSUFBSSxNQUFNLFFBQVE7QUFBQSxJQUN2QixPQUFPLENBQUMsU0FBUyxHQUFHLGFBQWE7QUFDL0IsYUFBTyxRQUFRLGdCQUFnQixHQUFHLFFBQVE7QUFBQSxJQUM1QztBQUFBLElBQ0EsS0FBSyxDQUFDLEdBQUcsTUFBTTtBQUNiLHFCQUFlLEtBQUssQ0FBQztBQUNyQixhQUFPLGVBQWUsUUFBUSxjQUFjO0FBQUEsSUFDOUM7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUNBLFNBQVNDLE9BQU07QUFDYixTQUFPLGVBQWUsU0FBUztBQUNqQztBQUNBLE9BQU8sTUFBTUE7QUFDYixPQUFPLFNBQVMsQ0FBQztBQUNqQixPQUFPLE9BQU8sQ0FBQyxhQUFhLFlBQVk7QUFDdEMsUUFBTSxXQUFXLE9BQU8sT0FBTyxXQUFXO0FBQzFDLE1BQUksQ0FBQztBQUNILFVBQU0sd0NBQXdDLFdBQVcsd0JBQXdCLE9BQU87QUFDMUYsV0FBUyxPQUFPO0FBQ2xCO0FBQ0EsSUFBSSxXQUFXLE1BQU1BLEtBQUksRUFBRSxTQUFTO0FBQ3BDLElBQUksYUFBYSxRQUFRO0FBQ3ZCLFFBQU0sT0FBTyxPQUFPLFNBQVMsYUFBYSxVQUFVLFFBQVEsVUFBVSxPQUFPLE9BQU8sU0FBUztBQUM3RixRQUFNLEtBQUssSUFBSSxVQUFVLEdBQUc7QUFDNUIsS0FBRyxZQUFZLENBQUMsRUFBRSxLQUFLLE1BQU07QUFDM0IsVUFBTSxFQUFFLGFBQWEsUUFBUSxJQUFJLEtBQUssTUFBTSxJQUFJO0FBQ2hELFdBQU8sS0FBSyxhQUFhLE9BQU87QUFBQSxFQUNsQztBQUNGO0FBQ0EsT0FBTyxvQkFBb0IscUJBQXFCO0FBS2hEOyIsCiAgIm5hbWVzIjogWyJfX2dldE93blByb3BOYW1lcyIsICJycGMiXQp9Cg==
